package org.mvel2.ast;

public interface IntOptimized {
}
