/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.ibm.ugl.eswt;


/**
 * The UGL API hierarchy as it applies to eSWT is as follows.
 * The API hierarchy can be thought of as a class hierarchy in  
 * OO terms. E.g., the Widget, Control and Button API can be  
 * called with a Checkbox handle, in addition to the Checkbox
 * API.
 * <p>
 * <table border=0>
 * <tr><td colspan=5>Clipboard</td></tr>
 * <tr><td colspan=5>Color</td></tr>
 * <tr><td colspan=5>Cursor</td></tr>
 * <tr><td colspan=5>Device</td></tr>
 * <tr><td width=25>&nbsp;</td><td colspan=4>Display</td></tr>
 * <tr><td colspan=5>Font</td></tr>
 * <tr><td colspan=5>Graphics</td></tr>
 * <tr><td colspan=5>Image</td></tr>
 * <tr><td colspan=5>MessageBox</td></tr>
 * <tr><td colspan=5>Widget</td></tr>
 * <tr><td>&nbsp;</td><td colspan=4>Control</td></tr>
 * <tr><td>&nbsp;</td><td width=25>&nbsp;</td><td colspan=3>Button</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td width=25>&nbsp;</td><td colspan=2>Checkbox</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>PushButton</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>RadioButton</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>ToggleButton</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>Choice</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>Combo</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>Label</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>ProgressBar</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>Scrollable</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>Composite</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td width=25>&nbsp;</td><td>Shell</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>List</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>AbstractTextComponent</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>TextArea</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>TextField</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>Scrollbar</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>Separator</td></tr>
 * <tr><td>&nbsp;</td><td colspan=4>FileDialog</td></tr>
 * <tr><td>&nbsp;</td><td colspan=4>AbstractMenu</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>DropDownMenu</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>PopupMenu</td></tr>
 * <tr><td>&nbsp;</td><td colspan=4>MenuBar</td></tr>
 * <tr><td>&nbsp;</td><td colspan=4>AbstractMenuItem</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>LabeledMenuItem</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>CascadeMenuItem</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>PushMenuItem</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan=2>StateMenuItem</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=3>SeparatorItem</td></tr>
 * </table>
 * </p>
 * <br>
 * 
 * <p><h2>Abstract widget documentation.</h2></p><br>
 * 
 * <p><h3>Control</h3></p><br>
 * 
 * <ol>
 * <li><b>Valid constructor hints</b>: STYLE_BORDER
 * <li><b>Z order expectations</b>: When a Control is created, it is expected to be placed below
 * its siblings in the Z order.  (Siblings are children of the same parent.)
 * </ol>
 * <br>
 * 
 * <p><h3>Scrollable</h3></p><br>
 * 
 * <ol>
 * <li><b>Valid constructor styles</b>: STYLE_V_SCROLL, STYLE_H_SCROLL
 * </ol> 
 * <br>
 * 
 */
public class OS extends com.ibm.ugl.p3ml.OS {
	
	/** File dialog style for opening a file. */
	public static final int STYLE_OPEN = 1 << 12;
	
	/** File dialog style for saving a file. */
	public static final int STYLE_SAVE = 1 << 13;
	
	/** 
	 * The following label styles are used by toolkits to specify
	 * the vertical alignment of the text. This is necessary since,
	 * for example, eSWT and Personal Profile have different defaults.
	 * 
	 * Note that these values overlap with the values used to
	 * specify the horizontal alignment. This is currently ok
	 * since the vertical alignment is specified on the constructor
	 * while horizontal alignment is set via the _SetAlignment API.
	 */
	
	/** Label style for top aligning the text. */
	public static final int STYLE_TOP = 1;
	
	/** Label style for vertically centering the text. */
	public static final int STYLE_MIDDLE = 1 << 1;
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int CALLBACK_COMBO = 14;
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int CALLBACK_HAS_MENU = 1458260670;
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int CALLBACK_TEXT_VERIFY = 15;
	
	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_MENU = 16;
	
	/** Combo text changed.  Passed as an argument to the 
	 * method registered as the CALLBACK_COMBO. */
	public static final int EVENT_COMBO_TEXT = 1;
	
	/** 
	 * Combo was default selected when the user pressed the ENTER key.  
	 * Passed as an argument to the method registered as the CALLBACK_COMBO. 
	 */
	public static final int EVENT_COMBO_DEFAULTSELECTION = 2;

	/** 
	 * Event indicating that a menu has been popped up or dropped down.
	 */
	public static final int EVENT_MENU_SHOW = 1;
	
	/** 
	 * Event indicating that a menu that has been popped up or 
     * dropped down has been hidden (i.e., no longer displayed).
	 */
	public static final int EVENT_MENU_HIDE = 2;
	
	public static final int INFO_HASMENU_MAYBE = 0;
	public static final int INFO_HASMENU_YES = 1;
	public static final int INFO_HASMENU_NO = 2;	

	/** 
	 * Styles to indicate logical font names that can have
	 * different mappings on each platform.  This represents
	 * the platform's default font.
	 */
	public static final int FONT_LOGICAL_DEFAULT = 0;

	/** 
	 * Styles to indicate logical font names that can have
	 * different mappings on each platform.  This represents
	 * the font that might appear in platform dialogs.
	 */
	public static final int FONT_LOGICAL_DIALOG = 1;

	/** 
	 * Styles to indicate logical font names that can have
	 * different mappings on each platform.  This represents
	 * a sans-serif font, such as Helvetica.
	 */
	public static final int FONT_LOGICAL_SANSSERIF = 2;

	/** 
	 * Styles to indicate logical font names that can have
	 * different mappings on each platform.  This represents
	 * a serif font, such as Times Roman.
	 */
	public static final int FONT_LOGICAL_SERIF = 3;

	/** 
	 * Styles to indicate logical font names that can have
	 * different mappings on each platform.  This represents
	 * a monospaced font where all characters are equal widths, 
	 * such as Courier.
	 */
	public static final int FONT_LOGICAL_MONOSPACED = 4;

	/** 
	 * Styles to indicate logical font names that can have
	 * different mappings on each platform.  This represents
	 * a font that might be used for dialog input on a platform.
	 */
	public static final int FONT_LOGICAL_DIALOGINPUT = 5;
	
	public static final int LINE_CAP_BUTT = 1 << 5;
	public static final int LINE_CAP_ROUND = 1 << 6;
	public static final int LINE_CAP_SQUARE = 1 << 7;
	public static final int LINE_JOIN_BEVEL = 1 << 8;
	public static final int LINE_JOIN_MITER = 1 << 9;
	public static final int LINE_JOIN_ROUND = 1 << 10;
	
	
	// The following MessageBox styles must be exclusive of the modality style constants.
	
	public static final int MESSAGEBOX_OK 		= 1 << 11;
	public static final int MESSAGEBOX_CANCEL 	= 1 << 12;
	public static final int MESSAGEBOX_YES		= 1 << 13; 
	public static final int MESSAGEBOX_NO		= 1 << 14;
	public static final int MESSAGEBOX_RETRY	= 1 << 15;
	
	public static final int MESSAGEBOX_ICON_ERROR		= 1 << 18;
	public static final int MESSAGEBOX_ICON_INFORMATION	= 1 << 19;
	public static final int MESSAGEBOX_ICON_QUESTION	= 1 << 20;
	public static final int MESSAGEBOX_ICON_WARNING		= 1 << 21;
	public static final int MESSAGEBOX_ICON_WORKING		= 1 << 22;
	
	/** 
	 * Shell style for indicating that a Shell is 
	 * to remain on top of the z order.  This style
	 * is a hint, so it may not be implemented everywhere.
	 */
	public static final int STYLE_ON_TOP = 1 << 25;
	
	/**
	 * A hint the ProgressBar widget to display as 
	 * a constant line. 
	 */
	public static final int STYLE_SMOOTH = 1 << 16;

	/**
	 * Shell style indicating that while the Shell is open it will
	 * block all input from the system. Modality styles are treated 
	 * as hints since all types of modality are not supported on every 
	 * platform.
	 */
	public static final int STYLE_SYSTEM_MODAL = 1 << 27;

	/**
	 * ProgressBar style for indicating that the amount
	 * of work to be done is not known.
	 */
	public static final int STYLE_INDETERMINATE = 1 << 1;

	
	/**
	 * The constant used to ask the platform whether it supports
	 * making toplevel shells user resizable.  The return value from
	 * the platform should be non-zero if the platform can support
	 * toplevel shells that are user resizable.
	 */
	public static final int CAPABILITY_SHELL_TOPLEVEL_RESIZABLE = 1;
	
	/**
	 * The constant used to ask the platform whether it supports
	 * making child shells user resizable.  The return value from
	 * the platform should be non-zero if the platform can support
	 * child shells that are user resizable.
	 */
	public static final int CAPABILITY_SHELL_CHILD_RESIZABLE = 2;
	
	/**
	 * The constant used to ask the platform whether it supports minimizing
	 * or maximizing shells.  The return value from the platform should be 
	 * non-zero if the platform supports minimizing and maximizing shells.
	 */
	public static final int CAPABILITY_SHELL_MINMAX = 3;
	
	/**
	 * The constant used to ask the platform about the Personal Profile and
	 * Personal Basis Profile restrictions that are in place.  The return 
	 * value should be a bitwise-OR of RESTRICTION flags, or zero if no 
	 * restrictions are in place
	 */
	public static final int CAPABILITY_AWT_RESTRICTIONS = 4;
	
	/**
	 * The constant used to ask the platform whether it supports fullscreen
	 * exclusive mode.  In this mode, a shell stays on top in the z-order 
	 * and no other windows overlap it.  The return value from the platform 
	 * should be non-zero if the platform supports fullscreen exclusive mode.
	 * 
	 * If this mode is unsupported, the Java libraries will emulate fullscreen
	 * exclusive mode by setting the shell bounds to the display bounds.
	 */
	public static final int CAPABILITY_FULLSCREEN_EXCLUSIVE_MODE = 5;
	
	/** java.awt.AlphaComposite.SRC_OVER.isRestricted */
	public static final int RESTRICTION_AlphaComposite_SRC_OVER = 1;

	/** java.awt.Component.setCursor.isRestricted */
	public static final int RESTRICTION_Component_setCursor = 1 << 1;
	
	/** java.awt.Frame.setSize.isRestricted */
	public static final int RESTRICTION_Frame_setSize = 1 << 2;
	
	/** java.awt.Frame.setResizable.isRestricted */
	public static final int RESTRICTION_Frame_setResizable = 1 << 3;
	
	/** java.awt.Frame.setLocation.isRestricted */
	public static final int RESTRICTION_Frame_setLocation = 1 << 4;
	
	/** java.awt.Frame.setState.isRestricted */
	public static final int RESTRICTION_Frame_setState = 1 << 5;
	
	/** java.awt.Frame.setTitle.isRestricted */
	public static final int RESTRICTION_Frame_setTitle = 1 << 6;
	
	/** java.awt.TextField.setEchoChar.isRestricted */
	public static final int RESTRICTION_TextField_setEchoChar = 1 << 7;

	/** java.awt.Dialog.setSize.isRestricted */
	public static final int RESTRICTION_Dialog_setSize = 1 << 8;
	
	/** java.awt.Dialog.setResizable.isRestricted */
	public static final int RESTRICTION_Dialog_setResizable = 1 << 9;
	
	/** java.awt.Dialog.setLocation.isRestricted */
	public static final int RESTRICTION_Dialog_setLocation = 1 << 10;
	
	/** java.awt.Dialog.setTitle.isRestricted */
	public static final int RESTRICTION_Dialog_setTitle = 1 << 11;
	
	/** java.awt.Graphics2D.setStroke.BasicStroke.isRestricted */
	public static final int RESTRICTION_Graphics2D_setStroke_BasicStroke = 1 << 12;
	
	/** java.awt.event.MouseEvent.isRestricted */
	public static final int RESTRICTION_MouseEvent = 1 << 13;
	
	/** java.awt.event.KeyEvent.isRestricted */
	public static final int RESTRICTION_KeyEvent = 1 << 14;

	/**
	 * Value used by <code>Sound_GetPreferredChunkSize()</code> 
	 * indicating that the entire sound data should be written 
	 * in a single chunk.
	 */
	public static final int SOUND_CHUNK_SIZE_ALL = -1;

	/**
	 * Value used by <code>Sound_Play()</code> indicating that 
	 * the sound data should be played back until <code>Sound_Stop()</code> 
	 * is called.
	 */
	public static final int SOUND_REPEAT_FOREVER = -1;
	
	/**
	 * Sets the position of the label or image on the button.
	 * On left to right locales, STYLE_LEAD is left, and STYLE_TRAIL
	 * is right.  Right to left locales reverse this notation.
	 * 
	 * @param handle the button handle
	 * @param alignment OS.STYLE_LEAD, OS.STYLE_CENTER or OS.STYLE_TRAIL
	 */
	public static final native void Button_SetAlignment(int handle, int alignment);
	
	/**
	 * Sets the image of a button.  Please note that a button may not display
	 * its image and its label simultaneously.
	 * 
	 * @param handle the button handle
	 * @param imageHandle the image handle
	 */
	public static final native void Button_SetImage(int handle, int imageHandle);
	/**
	 * Sets the label of a button.  Please note that a button may not display
	 * its image and its label simultaneously. 
	 * 
	 * @param handle the button handle
	 * @param string the label
	 */
	public static final native void Button_SetLabel(int handle, String string);
	
	/**
	 * Set the selection state of a button.
	 * 
	 * @param handle the button handle
	 * @param selection true for selected, false for unselected
	 */
	public static final native void Button_SetSelection(int handle, boolean selection);

	/**
	 * Creates a new Checkbox widget
	 * 
	 * @param parentHandle handle of parent widget
	 * @param style STYLE_FLAT or 0
	 * @return handle of new widget
	 * @uglGroup Button 
	 */
	public static final native int Checkbox_New(int parentHandle, int style);
	/**
	 * Returns a handle to an instance of the system font.  The system font
	 * is a good default font for an application to use.  This handle
	 * must be disposed by the caller with Font_Dispose.
	 * 
	 * @param handle device handle
	 * @return handle of system font
	 */
	public static final native int Device_GetSystemFont(int handle);
	
	/**
	 * Returns the number of bytes available in accelerated memory on this device.  The return
	 * value is considered a shapshot of the current amount of available memory, and is used in
	 * calculations for image allocation.  Depending on a variety of platform conditions,
	 * the full extent of this number of bytes might not be available for an image.
	 * 
	 * @param handle device handle
	 * @return number of bytes available in accelerated memory. 
	 * A negative value indicates an unlimited amount of available
	 * space.
	 */
	public static final native int Device_GetAvailableAcceleratedMemory(int handle);
	
	/**
	 * Returns the color depth, in bits per pixel, of the device 
	 * identified by <code>handle</code>.
	 * 
	 * @param handle the device handle
	 * @return the color depth, in bits per pixel
	 */
	public static final native int Device_GetDepth(int handle);
	
	/**
	 * Returns the resolution, in pixels, of the device identified by 
	 * <code>handle</code>.
	 * 
	 * @param handle the device handle
	 * @return (point) the resolution of the device. Access the 
	 * 	horizontal resolution using the <code>INDEX_X</code> constant
	 * 	and the vertical resolution using the <code>INDEX_Y</code> 
	 * 	constant
	 */
	public static final native int[] Device_GetDPI(int handle);

	/**
	 * Returns <code>true</code> if the device identified by 
	 * <code>handle</code> is using a direct color model. Returns
	 * <code>false</code> if the device is using an indexed color 
	 * model. 
	 * 
	 * @param handle the device handle.
	 * @return true - the device is using a direct color model
	 * 	false - the device is using an indexed color model
	 * @see #Device_GetDirectPaletteMasks
	 * @see #Device_GetIndexedPalette
	 */
	public static final native boolean Device_IsDirect(int handle);	
	
	/**
	 * Returns the palette masks of the direct, default color model of the 
	 * device identified by <code>handle</code>. Must not be called if the 
	 * device uses an indexed color model.
	 * 
	 * @param handle the device handle
	 * @return (palettemasks) the direct palette masks of the default 
	 * 	color model of the specified device. Access array elements using 
	 * 	the <code>PALETTE_MASK_RED</code>, <code>PALETTE_MASK_GREEN</code>, 
	 * 	<code>PALETTE_MASK_BLUE</code> and <code>PALETTE_MASK_ALPHA</code> 
	 * 	constants.
	 * @see #Device_IsDirect
	 * @see #Device_GetIndexedPalette
	 */
	public static final native int[] Device_GetDirectPaletteMasks(int handle);
	/**
	 * Returns the palette of the indexed, default color model of the device 
	 * identified by <code>handle</code>. The red, green and blue arrays must be 
	 * big enough to hold all color indices for the device's color depth. Must 
	 * not be called if the device uses a direct color model. 
	 *  
	 * @param handle the device handle
	 * @param red the red component of palette colors
	 * @param green the green component of palette colors
	 * @param blue the blue component of palette colors
	 * @see #Device_IsDirect
	 * @see #Device_GetDirectPaletteMasks
	 */
	public static final native void Device_GetIndexedPalette(int handle, byte[] red, byte[] green, byte[] blue);
	
	/**
	 * Creates a new graphics context (GC) on the device identified by
	 * <code>handle</code>.
	 * 
	 * @param handle the device handle
	 * @return the new graphics context
	 */
	public static final native int Device_NewGraphics(int handle);
	
	/**
	 * Copies a rectangular region of the device to an image.
	 * 
	 * @param handle the device handle
	 * @param image the image handle
	 * @param x the x origin of the region
	 * @param y the y origin of the region
	 * @param width the width of the region
	 * @param height the height of the region
	 */
	public static final native void Device_CopyArea(int handle, int image, int x, int y, int width, int height);
	
	/**
	 * Causes the system hardware to emit a short sound
	 * (if it supports this capability).
	 * 
	 * @param handle the display handle
	 */
	public static final native void Display_Beep(int handle);
	
	/**
	 * Returns the handle of the system color which corresponds with 
	 * the given id.  The id should be one of the COLOR constants
	 * (e.g., COLOR_CONTROL_FOREGROUND).  The color resource should 
	 * always be disposed by the caller.
	 * 
	 * @param handle the display handle
	 * @param id the system color id (one of the COLOR constants)
	 * @return system color handle
	 */
	public static final native int Display_GetSystemColor(int handle, int id);

	/**
	 * Returns the longest duration, in milliseconds, between
	 * two mouse button clicks that will be considered a 
	 * <em>double click</em>. 
	 * 
	 * @param handle the display handle
	 * @return the longest duration, in milliseconds, between
	 * two mouse button clicks that will be considered a 
	 * <em>double click</em>
	 */
	public static final native int Display_GetDoubleClickTime(int handle);

	/**
	 * Starts a timer which will go off after the given number
	 * of milliseconds.  The timerId is passed to the timer
	 * callback when the timer has gone off.
	 * 
	 * @param handle the display handle
	 * @param milliseconds must be greater than or equal to zero
	 * @param timerId can be any value
	 */
	public static final native void Display_StartTimer(int handle, int milliseconds, int timerId);
	
	/**
	 * On platforms which support it, sets the application name
	 * to be the argument. On Motif, for example, this can be used
	 * to set the name used for resource lookup.
	 *
	 * @param name the new app name
	 */
	public static final native void Display_SetAppName(String name);
	
	/**
	 * Returns the insets of the display identified by <code>handle</code>.
	 * This is the portion of the screen that is unusable for drawing, 
	 * such as the area covered by a task bar.  These insets are positive
	 * integers that indicate the distance inward from each edge.
	 * 
	 * @param handle the display handle
	 * @return (insets) the display insets. Access array members using the 
	 * 	<code>INDEX_LEFT</code>, <code>INDEX_TOP</code>, <code>INDEX_RIGHT</code> 
	 * 	and <code>INDEX_BOTTOM</code> constants.
	 */
	public static final native int[] Display_GetInsets(int handle);
	
	/**
	 * Generates a system key event. Either the <code>keyCode</code> or 
	 * <code>character</code> argument has to be specified. 
	 * 
	 * @param handle the display handle
	 * @param type either <code>EVENT_KEY_DOWN</code> or <code>EVENT_KEY_UP</code>
	 * @param keyCode one of the KEYCODE constants
	 * @param character the character
	 * 
	 * @return true if the event was generated or false otherwise
	 */
	public static final native boolean Display_PostKeyEvent(int handle, int type, int keyCode, char character);
	
	/**
	 * Generates a system pointer event.
	 * 
	 * @param handle the display handle
	 * @param type the type of mouse event to generate. Either 
	 * 	<code>EVENT_POINTER_DOWN</code> or <code>EVENT_POINTER_UP</code>
	 * @param button the pointer button to set in the event. one of 
	 * 	<code>POINTER_MASK_BUTTON1</code>, <code>POINTER_MASK_BUTTON2</code> or 
	 * 	<code>POINTER_MASK_BUTTON3</code>
	 * 
	 * @return true if the event was generated or false otherwise
	 */
	public static final native boolean Display_PostPointerEvent(int handle, int type, int button);
	
	/**
	 * Generates a system pointer move event.
	 * 
	 * @param handle the display handle
	 * @param x the x coordinate of the new pointer location 
	 * @param y the y coordinate of the new pointer location
	 * 
	 * @return true if the event was generated or false otherwise
	 */
	public static final native boolean Display_PostPointerMoveEvent(int handle, int x, int y);
	
	/**
	 * Sets the window indicated by the argument to be in
	 * exclusive full screen mode.  In this mode, a shell stays on top in 
	 * the z-order and no other windows overlap it.
	 * 
	 * If this <code>shellHandle</code> is a valid handle for
	 * a shell different than the current full screen shell, the current
	 * full screen shell is restored to its previous size (i.e. the size
	 * it was before it became full screen).
	 * 
	 * If the <code>shellHandle</code> is 0,
	 * then overlapping window mode is restored.
	 * 
	 * If CAPABILITY_FULLSCREEN_EXCLUSIVE_MODE is not natively supported, 
	 * the Java toolkit will emulate this behavior, and this function will
	 * not be called.
	 * 
	 * @param handle the display handle
	 * @param shellHandle handle of the shell to be made exclusive full screen
	 * @see #CAPABILITY_FULLSCREEN_EXCLUSIVE_MODE
	 */
	public static final native void Display_SetFullScreenShell(int handle, int shellHandle);
	
	/**
	 * Unfocuses the currently focused widget.  The currently active window should
	 * stay active, but it will have no focused widget.  
	 * 
	 * @param handle the display handle
	 */
	public static final native void Display_ClearFocus(int handle);
	
	/**
	 * Creates a new font with the specified logical type, height 
	 * in points, and style flags.  This method allows the platform to resolve 
	 * logical fonts with size and style requirements in addition to the 
	 * logical type.  On some platforms, two different monospaced fonts may be 
	 * used for two different sizes. 
	 * 
	 * The value of the logical type can be one of the following:
	 * 
	 * <ul>
	 *    <li>FONT_LOGICAL_DEFAULT</li>
	 *    <li>FONT_LOGICAL_DIALOG</li>
	 *    <li>FONT_LOGICAL_SANSSERIF</li>
	 *    <li>FONT_LOGICAL_SERIF</li>
	 *    <li>FONT_LOGICAL_MONOSPACED</li>
	 *    <li>FONT_LOGICAL_DIALOGINPUT</li>
	 * </ul>
	 * 
	 * @param deviceHandle the device/display handle
	 * @param logicalFont one of the font constants above 
	 * @param height the requested height of the font in points
	 * @param style one of the FONT_STYLE constants
	 * 
	 * @return the font with the specified qualities.
	 */
	public static final native int Font_NewLogical(int deviceHandle, int logicalFont, int height, int style);

	/**
	 * Measures the advance width, in pixels, of the given string.
	 * <p>
	 * The advance width is the distance to where the next string in 
	 * a series of strings should be drawn. This is typically not the
	 * same as the width returned by <code>Font_StringExtent()</code>.  
	 * </p>
	 * 
	 * @param handle the font handle
	 * @param string the text to measure
	 * @return the advance width of the given string
	 */
	public static final native int Font_StringAdvance(int handle, String string);
	
	/**
	 * Returns the average character width of the font with the specified handle.
	 * 
	 * @param handle font handle
	 * @return average character width
	 */
	public static final native int Font_GetAverageCharWidth(int handle);
	
	/**
	 * Returns a font's style flags.  The return value should be a bitwise OR 
	 * of FONT_STYLE_BOLD, FONT_STYLE_ITALIC, FONT_STYLE_STRIKETHROUGH, and FONT_STYLE_UNDERLINED.
	 * Or the return value may be zero, to indicate a normal font.
	 * 
	 * @param handle the font handle
	 * @return style flags for font
	 */
	public static final native int Font_GetStyle(int handle);
	
	/**
	 * Returns the name of a font.  The name should be one 
	 * of the system typeface names returned by Device_GetTypefaces.
	 *   
	 * @param handle the font handle
	 * @return font name
	 */
	public static final native String Font_GetName(int handle);
	
	/**
	 * Creates a new shell that is a child of the shell identified by 
	 * <code>parentHandle</code>. 
	 * <p>Note: The styles supported by this method must be treated
	 * as <em>HINT</em>s, since the window manager has ultimate
	 * control over the appearance and behavior of decorations
	 * and modality.  In addition, if a  modality style is not 
	 * supported, it is "upgraded" to a more restrictive modality 
	 * style that is supported. For example, if <code>STYLE_PRIMARY_MODAL</code> 
	 * is not supported, it would be upgraded to <code>STYLE_APPLICATION_MODAL</code>.
	 * </p>
	 * 
	 * @param parentHandle the parent shell handle. Must not be 0.
	 * @param style one or more of <code>CLOSE</code>, <code>MIN</code>,  
	 * 	<code>MAX</code>, <code>NO_TRIM</code>,  
	 *  <code>TITLE</code>, <code>STYLE_APPLICATION_MODAL</code>,
	 *  <code>STYLE_SYSTEM_MODAL</code>,  
	 *  <code>STYLE_MODELESS</code> and <code>STYLE_PRIMARY_MODAL</code> 
	 * @return the new shell
	 */
	public static final native int Shell_NewChild(int parentHandle, int style);
	
	/**
	 * Returns <code>true</code> if the shell identified by <code>handle</code> 
	 * is currently minimized, and <code>false</code> otherwise. 

	 * @param handle the shell handle
	 * @return <code>true</code> if the shell is currently minimized, 
	 * 	and <code>false</code> otherwise.
	 */
	public static final native boolean Shell_GetMinimized(int handle);
	
	/**
	 * Returns <code>true</code> if the shell identified by <code>handle</code> 
	 * is currently maximized, and <code>false</code> otherwise. 

	 * @param handle the shell handle
	 * @return <code>true</code> if the shell is currently maximized, 
	 * 	and <code>false</code> otherwise.
	 */
	public static final native boolean Shell_GetMaximized(int handle);
	
	/**
	 * Sets the minimized stated of the shell identified by <code>handle</code>.
	 * 
	 * Note: some platforms do not have the capability to programmatically change
	 * the minimized or maximized state, so calls to this method on those platforms
	 * should fail silently.
	 *  
	 * @param handle the shell handle
	 * @param minimized true - the shell switches to the minimized state
	 * 	false - if the shell was previously minimized, causes the
	 * 	shell to switch back to either the maximized or normal states.
	 */
	public static final native void Shell_SetMinimized(int handle, boolean minimized);

	/**
	 * Sets the image of the shell identified by <code>handle</code> 
	 * to the argument, which may be 0. The image is typically 
	 * displayed by the window manager when the instance is 
	 * marked as iconified, and may also be displayed somewhere 
	 * in the trim when the instance is in normal or maximized 
	 * states.
	 *
	 * @param handle the shell handle
	 * @param imageHandle the image handle. 0 to remove the shell image.
	 * @see #Display_GetIconSize
	 */
	public static final native void Shell_SetImage(int handle, int imageHandle);
	/**
	 * Specifies whether the size of the shell identified by 
	 * <code>handle</code> may be changed.
	 * 
	 * Note: some platforms do not support resizing of shells, so calls to this method on those platforms
	 * should fail silently.
	 *
	 * @param handle the shell handle 
	 * @param resizable true - the shell may be resized
	 *	false - the shell size may not be changed
	 */
	public static final native void Shell_SetResizable(int handle, boolean resizable);
	
	/**
	 * Sets the specified menu bar as the shell menu bar for the 
	 * shell identified by <code>handle</code>.
	 * 
	 * @param handle the shell handle 
	 * @param menuBarHandle the menu bar handle. 0 to remove the current menu bar.
	 */
	public static final native void Shell_SetMenuBar(int handle, int menuBarHandle);
	
	/**
	 * Makes a button the default for this shell.  Default buttons may
	 * have a special appearance, or they may take the initial focus
	 * from the shell.  
	 * 
	 * @param shellHandle the handle to the shell
	 * @param buttonHandle the button to be made default, or 0 if no default
	 *                     button should be used.  This handle will only
	 *                     be buttons created with PushButton_New()
	 */
	public static final native void Shell_SetDefaultButton(int shellHandle, int buttonHandle);
	

	/**
	 * Disposes off resources associated with the specified sound 
	 * <code>handle</code>
	 * 
	 * @param handle the sound handle 
	 */
	public static final native void Sound_Dispose(int handle);
	
	/**
	 * Get the preferred size of a sound data chunk.
	 * Returns <code>SOUND_CHUNK_SIZE_ALL</code> to indicate that  
	 * the entire sound data should be written in a single chunk.
	 *
	 * @param handle the sound handle
	 * @return the preferred size of a sound data chunk.
	 */
	public static final native int Sound_GetPreferredChunkSize(int handle);

	/**
	 * Creates a new sound clip.
	 * 
	 * @return the sound handle or 0 if sound is not supported
	 */
	public static final native int Sound_New();

	/**
	 * Writes a sound data chunk to the sound clip identified by 
	 * <code>handle</code>. The chunk size is no bigger than the 
	 * preferred size returned by <code>Sound_GetPreferredChunkSize()</code>.
	 * Playback begins immediately and is asynchronous. This call 
	 * returns as soon as playback has started. 
	 * Playback is not interrupted by other calls to 
	 * <code>Sound_Play()</code>. Instead the data is queued for 
	 * playback after the last chunk finishes playing.
	 * <p>
	 * To loop an entire sound clip the sound data has to be written
	 * in a single chunk.
	 * </p>
	 * 
	 * @param handle the sound handle
	 * @param data the sound data
	 * @param length length of the sound data chunk. 
	 * @param repeatCount number of repeated playbacks. Use 0 to play 
	 * 	once. Use <code>SOUND_REPEAT_FOREVER</code> to continue
	 * 	playing until <code>Sound_Stop()</code> is called.
	 * @see #Sound_GetPreferredChunkSize
	 */
	public static final native void Sound_Play(int handle, byte[] data, int length, int repeatCount);

	/**
	 * Stops playback of the sound clip identified by 
	 * <code>handle</code>. Does nothing if no sound is currently 
	 * playing.
	 * 
	 * @param handle the sound handle 
	 */
	public static final native void Sound_Stop(int handle);
	
	/**
	 * Valid styles are STYLE_READ_ONLY.  All Combos are drop down lists.
	 * 
	 * @param parentHandle handle of the parent container
	 * @param style a logical OR of styles for this widget
	 * @return handle of new widget
	 */
	public static final native int Combo_New(int parentHandle, int style);
	
	/**
	 * Replaces the text between two caret positions with 
	 * new text.  See AbstractTextComponent_SetCaretPosition
	 * for valid start and end values.  This method should not
	 * generate a modify callback.
	 * 
	 * @param handle the combo handle
	 * @param text the new text
	 * @param start the start position
	 * @param end the end position
	 * @see #AbstractTextComponent_SetCaretPosition(int, int)
	 */
	public static final native void Combo_ReplaceText(int handle, String text, int start, int end);
	
	/**
	 * Returns the start and end position of the current text selection.
	 * The values returned range from 0 to N inclusive, where N is the 
	 * number of characters in the text field.
	 * 
	 * @param handle handle of combo widget
	 * @return (point)
	 */
	public static final native int[] Combo_GetTextSelection(int handle);
	
	/**
	 * Returns the entire contents of the text field.
	 * 
	 * @param handle handle of combo widget
	 * @return entire text from text field
	 */
	public static final native String Combo_GetText(int handle);
	
	/**
	 * Returns the height of the text field.
	 * 
	 * @param handle handle of combo widget
	 * @return height of text field
	 */
	public static final native int Combo_GetTextHeight(int handle);
	
	/**
	 * Sets the start and end positions of the text selection.  Both values
	 * must be in the range 0 to N inclusive, where N is the number of 
	 * characters in the text field.
	 * 
	 * @param handle handle of combo widget
	 * @param start start position of new text selection
	 * @param end end position of new text selection
	 */
	public static final native void Combo_SetTextSelection(int handle, int start, int end);
	
	/**
	 * Sets the contents of the text field.  Any existing text will be
	 * removed.
	 * 
	 * @param handle handle of combo widget
	 * @param string new contents of text field
	 */
	public static final native void Combo_SetText(int handle, String string);
	
	/**
	 * Sets the maximum number of characters that the text field can hold.
	 * The value must be in the range 0 to M inclusive, where M is the value
	 * returned by Combo_GetDefaultTextLimit().
	 * 
	 * @param handle handle of combo widget
	 * @param limit max number of characters text field can hold
	 */
	public static final native void Combo_SetTextLimit(int handle, int limit);
	
	/**
	 * Returns the default maximum number of characters that the text field
	 * can hold.
	 * 
	 * @return maximum number of characters in text field
	 */
	public static final native int Combo_GetDefaultTextLimit();
	
	/**
	 * Sets the orientation of the text field.  The argument must be either
	 * STYLE_LEFT_TO_RIGHT or STYLE_RIGHT_TO_LEFT.
	 * 
	 * @param handle widget handle
	 * @param orientation STYLE_LEFT_TO_RIGHT or STYLE_RIGHT_TO_LEFT
	 */
	public static final native void Combo_SetOrientation(int handle, int orientation);
	
	/**
	 * Deselects the item at index, if and only if it is currently selected.
	 * 
	 * @param handle widget handle
	 * @param index index of item to be deselected
	 */
	public static final native void Combo_DeselectItem(int handle, int index);
	
	/**
	 * Deselects all currently selected items.
	 * 
	 * @param handle widget handle
	 */
	public static final native void Combo_DeselectAllItems(int handle);
	
	/**
	 * Returns the height of an individual list item.
	 * 
	 * @param handle widget handle
	 * @return height of each item in the drop down list
	 */
	public static final native int Combo_GetItemHeight(int handle);
	
	/**
	 * Sets the value of the item at the given index.
	 * 
	 * @param handle handle of the combo widget
	 * @param string text to be used for this item
	 * @param index index of the item to be changed
	 */
	public static final native void Combo_SetItem(int handle, String string, int index);
	
	/**
	 * Returns the number of items that are visible in the drop down list.
	 * This getter is necessary because there is no default value for this
	 * property.
	 * 
	 * @param handle handle of the combo widget
	 * @return number of visible items
	 */
	public static final native int Combo_GetVisibleItemCount(int handle);
	
	/**
	 * Sets the number of items that are visible in the drop down list.
	 * 
	 * @param handle handle of the combo widget
	 * @param count new number of visible items
	 */
	public static final native void Combo_SetVisibleItemCount(int handle, int count);
	/**
	 * Creates a new Composite.  Valid styles are STYLE_NO_BACKGROUND,
	 * STYLE_NO_FOCUS, STYLE_NO_MERGE_PAINTS, and STYLE_NO_REDRAW_RESIZE.
	 * 
	 * @param parentHandle the parent handle
	 * @param style the style
	 * @return handle of new widget
	 */
	public static final native int Composite_New(int parentHandle, int style);
	
	/**
	 * Copies a rectangular region of the control to an image.
	 * 
	 * @param handle the control handle
	 * @param image the image handle
	 * @param x the x origin of the region
	 * @param y the y origin of the region
	 * @param width the width of the region
	 * @param height the height of the region
	 */
	public static final native void Control_CopyArea(int handle, int image, int x, int y, int width, int height);
	
	/**
	 * Sets the control's background color.  The background color of child widgets
	 * should not be set to this new color.  If the color handle is zero, the 
	 * default background color should be used.
	 * 
	 * @param handle the control handle
	 * @param color the color handle
	 */
	public static final native void Control_SetBackground(int handle, int color);
	
	/**
	 * Returns an RGB value which represents the control's background
	 * color.  The return value will have the format 0x00RRGGBB.
	 * 
	 * @param handle the control handle
	 * @return RGB value of background color
	 */
	public static final native int Control_GetBackgroundRGB(int handle);
	
	/**
	 * Returns an RGB value which represents the control's foreground
	 * color.  The return value will have the format 0x00RRGGBB.
	 * 
	 * @param handle the control handle
	 * @return RGB value of foreground color
	 */
	public static final native int Control_GetForegroundRGB(int handle);
	
	/**
	 * Enables or disables the control.  Disabled controls do not respond
	 * to mouse, key, or focus events.  They may appear dimmed or "grayed-out",
	 * depending on the implementation. 
	 * 
	 * @param handle the control handle
	 * @param enabled enables the control if true, disables the control if false
	 */
	public static final native void Control_SetEnabled(int handle, boolean enabled);
	
	/**
	 * Sets the control's font.  
	 * 
	 * @param handle the control handle
	 * @param font the font handle
	 */
	public static final native void Control_SetFont(int handle, int font);
	
	/**
	 * Sets the control's foreground color.  The background color of child widgets
	 * should not be set to this new color.  If the color handle is zero, the 
	 * default foreground color should be used.
	 * 
	 * @param handle the control handle
	 * @param color the color handle
	 */
	public static final native void Control_SetForeground(int handle, int color);
	
	/**
	 * Forces the control to have keyboard focus.  Returns true
	 * if the control got focus, false otherwise.
	 * 
	 * @param handle the control handle
	 * @return whether the control received focus
	 */
	public static final native boolean Control_ForceFocus(int handle);
	
	/**
	 * Sets the control's cursor.
	 * 
	 * @param handle the control handle
	 * @param cursor the cursor handle
	 */
	public static final native void Control_SetCursor(int handle, int cursor);
	
	/**
	 * Moves the control above another control in the z order.  If the second
	 * argument is zero, the control will be moved to the top of the z order.
	 * 
	 * @param handle the control handle
	 * @param control the other control handle
	 */
	public static final native void Control_MoveAbove(int handle, int control);
	
	/**
	 * Moves a Control below another Control in the drawing order.
	 * If the second parameter is 0, the Control will be moved to
	 * the bottom of the drawing order.
	 * 
	 * @param handle the handle of the Control to move
	 * @param otherHandle the other Control
	 */
	public static final native void Control_MoveBelow(int handle, int otherHandle);
	
	/**
	 * Returns the control's minimum size.
	 * 
	 * @param handle the control handle
	 * @return (size)
	 */
	public static final native int[] Control_GetMinimumSize(int handle);
	
	/**
	 * Sets the control's redraw flag.  When set to false, the UGL 
	 * implementation should not allow the control to be redrawn.
	 * When set to true, redrawing should proceed as usual. In addition,
	 * an invalidate of the control may be necessary as the control may 
	 * have become stale while redraw was disabled.
	 * Please note that calls to this method should not be nested.
	 * This is because not all UGL implementations can implement
	 * nested redraws.
	 * 
	 * @param handle the control handle
	 * @param redraw true to allow redraws, false to disallow redraws
	 */
	public static final native void Control_SetRedraw(int handle, boolean redraw);
	
	/**
	 * Returns the font that this control would use if no font is set.  
	 * 
	 * NOTE:  This API must always return a valid font object.  The font is assumed to
	 * be owned by the system and will not be disposed from java.
	 * 
	 * @param handle the control
	 * @return the default font for this control.
	 */
	public static final native int Control_GetDefaultFont(int handle);
	
	/**
	 * Returns whether this control would like to inherit the background color
	 * of the parent during creation.  Some controls like Labels and Checkboxes 
	 * typically look better when they inherit the parent's color both others
	 * do not, like List and Text.  
	 * 
	 * NOTE:  This API is only used to support Personal Profile since in eSWT controls never
	 * inherit the background color of the parent.  Returning false from this 
	 * method will not stop the background color from being inherited if 
	 * SetBackground(null) is called after creation, but makes it the ONLY time that
	 * the background is passed down from the parent.
	 * 
	 * @param handle the target control
	 * @return true if the background color should be passed down during creation
	 */
	public static final native boolean Control_InheritsBackground(int handle);	
	
	/**
	 * Requests that a rectangular region of the control be redrawn.  
	 * Please note that the actual redraw will not occur until the 
	 * event loop has processed the draw event.
	 * 
	 * @param handle the control handle
	 * @param x the x origin of the region
	 * @param y the y origin of the region
	 * @param width the width of the region
	 * @param height the height of the region
	 */
	public static final native void Control_RedrawRegion(int handle, int x, int y, int width, int height);
	
	/**
	 * Forces all outstanding redraw requests.
	 *  
	 * @param handle control handle
	 * @param updateChildren if true, force all children to redraw also
	 */
	public static final native void Control_Update(int handle, boolean updateChildren);
	
	/**
	 * Returns the control's border width in pixels.  The border is 
	 * assumed to be the same size on each side of the control.
	 * 
	 * @param handle the control handle
	 * @return the border width in pixels
	 */
	public static final native int Control_GetBorderWidth(int handle);
	
	/**
	 * Toggles the pointer capture state of the control.  If capture is true,
	 * the control will receive all pointer events, regardless of their
	 * origin.  If capture is false, pointer events are delivered to their
	 * respective controls.
	 * 
	 * @param handle control handle
	 * @param capture the pointer capture state
	 */
	public static final native void Control_SetPointerCapture(int handle, boolean capture);	
	
	/**
	 * Returns whether or not the Control can change its parent.  This behavior
	 * should be considered optional for UGL implementors, because reparenting
	 * is considered to be improper, and may not be supported by the underlying
	 * widget library.
	 *  
	 * @param handle the Control handle
	 * @return true if the Control can change its parent, false otherwise
	 * @see #Control_SetParent(int, int)
	 */
	public static final native boolean Control_IsReparentable(int handle);
	
	/**
	 * Sets a new parent on a Control.  This method is expected to work only
	 * if Control_IsReparentable() returns true.
	 * 
	 * @param handle the Control handle
	 * @param parentHandle the new parent handle (must be a Composite or Composite subclass)
	 * @return true if the Control was reparented, false otherwise
	 * @see #Control_IsReparentable(int)
	 */
	public static final native boolean Control_SetParent(int handle, int parentHandle);
	
	/**
	 * Returns the red component of a color.  This value should
	 * be between 0 and 255 inclusive.
	 * 
	 * @param handle the color handle
	 * @return the color's red component
	 */
	public static final native int Color_GetRed(int handle);

	/**
	 * Returns the green component of a color.  This value should
	 * be between 0 and 255 inclusive.
	 * 
	 * @param handle the color handle
	 * @return the color's green component
	 */
	public static final native int Color_GetGreen(int handle);
	
	/**
	 * Returns the blue component of a color.  This value should
	 * be between 0 and 255 inclusive.
	 * 
	 * @param handle the color handle
	 * @return the color's blue component
	 */
	public static final native int Color_GetBlue(int handle);
	
	/**
	 * Clears the previously set clipping in the graphics context 
	 * identified by <code>handle</code>.
	 * 
	 * @param handle the graphics context handle
	 */
	public static final native void Graphics_ClearClipping(int handle);
	
	/**
	 * Copies the specified region of the graphics context identified 
	 * by <code>handle</code>.
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the region to copy
	 * @param y y coordinate of the top left corner of the region to copy
	 * @param width width of the region to copy
	 * @param height height of the region to copy
	 * @param destX destination x coordinate of the copied region
	 * @param destY destination y coordinate of the copied region
	 */
	public static final native void Graphics_CopyArea(int handle, int x, int y, int width, int height, int destX, int destY);
	
	/**
	 * Draws a rectangle indicating widget focus on the graphics context 
	 * identified by <code>handle</code>.
	 * <p>
	 * The rectangle's right edge is at location <code>x + width - 1</code>
	 * on the graphics context. The rectangle's bottom edge is at location 
	 * <code>y + height - 1</code> on the graphics context.
	 * </p>
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the focus rectangle
	 * @param y y coordinate of the top left corner of the focus rectangle
	 * @param width width of the focus rectangle
	 * @param height height of the focus rectangle
	 */
	public static final native void Graphics_DrawFocus(int handle, int x, int y, int width, int height);
	
	/**
	 * Draws the specified sub-image within the given bounding rectangle on 
	 * the graphics context identified by <code>handle</code>.
	 * <p>
	 * The region of the image to draw described by <code>srcX</code>, 
	 * <code>srcY</code>, <code>srcWidth</code>, <code>srcHeight</code>
	 * must be within the image bounds.
	 * </p> 
	 * <p>
	 * The drawn image's right edge is at location <code>destX + destWidth - 1</code>
	 * on the graphics context. The image's bottom edge is at location 
	 * <code>destY + destHeight - 1</code> on the graphics context. The drawn 
	 * image region will be stretched or shrunk to fit the destination bounds. 
	 * </p>
	 * 
	 * @param handle the graphics context handle
	 * @param image image handle
	 * @param srcX x coordinate of the top left corner of the sub-image
	 * @param srcY y coordinate of the top left corner of the sub-image
	 * @param srcWidth width of the sub-image to draw
	 * @param srcHeight height of the sub-image to draw
	 * @param destX x coordinate of the top left corner of the 
	 * 	destination bounding rectangle to draw the sub-image in.
	 * @param destY y coordinate of the top left corner of the 
	 * 	destination bounding rectangle to draw the sub-image in.
	 * @param destWidth width of the destination bounding rectangle to 
	 * 	draw the sub-image in. Must be > 0.
	 * @param destHeight height of the destination bounding rectangle to 
	 * 	draw the sub-image in. Must be > 0.
	 */
	public static final native void Graphics_DrawImageRegion(int handle, int image, int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY, int destWidth, int destHeight);
	
	/**
	 * Fills the specified rectangle with the given color on the graphics 
	 * context identified by <code>handle</code>.  The current XOR mode should
	 * be ignored and specified color should be filled as is.
	 *  
	 * @param handle the graphics context handle
	 * @param color the handle of the fill color
	 * @param x x coordinate of the top left corner of the fill rectangle
	 * @param y y coordinate of the top left corner of the fill rectangle
	 * @param width width of the fill rectangle
	 * @param height height of the fill rectangle
	 */
	public static final native void Graphics_FillBackground(int handle, int color, int x, int y, int width, int height);
	
	/**
	 * Sets the line rendering style of the graphics context identified by
	 * <code>handle</code>. All subsequent outline rendering operations will 
	 * use this line style. E.g., line, rectangle, oval.
	 * 
	 * @param handle the graphics context handle
	 * @param style one of LINE_SOLID, LINE_DASH, LINE_DOT, LINE_DASHDOT, 
	 * 	LINE_DASHDOTDOT   
	 */
	public static final native void Graphics_SetLineStyle(int handle, int style);

	/**
	 * Sets the line style attributes of the graphics context identified by
	 * <code>handle</code>. All subsequent outline rendering operations will 
	 * use these line styles. E.g., line, rectangle, oval.
	 * 
	 * <b>Note:</b> for Personal Profile 1.1 and Personal Basis Profile 1.1,
	 * these are optional settings.  Platforms that cannot support these can
	 * ignore these settings.
	 * 
	 * @param handle the graphics context handle
	 * @param endCap the decoration of the ends of a line
	 * @param lineJoin the decoration used where line segments connect
	 * @param miterLimit the limit to trim the miter join
	 */
	public static final native void Graphics_SetLineNodeStyle(int handle, int endCap, int lineJoin, int miterLimit);
	
	/**
	 * Sets XOR mode.  If <code>xorMode</code> is true all subsequent 
	 * graphics operations are XORed with the background.
	 * 
	 * @param handle the graphics context handle
	 * @param xorMode if true all graphics operations are XORed with the background.
	 * 	If false all graphics operations are drawn normally, erasing the background.
	 */
	public static final native void Graphics_SetXORMode(int handle, boolean xorMode);
	
	/**
	 * Flips the specified area of the image identified by <code>handle</code> 
	 * and returns the resulting image handle. The original image is unchanged.
	 * 
	 * @param handle image handle
	 * @param hFlip flip horizontally
	 * @param vFlip flip vertically
	 * @param x x coordinate of the area to flip. Must be within the image's bounds.
	 * @param y y coordinate of the area to flip. Must be within the image's bounds.
	 * @param width width of the area to flip. Must be within the image's bounds.
	 * @param height height of the area to flip. Must be within the image's bounds.
	 * @return the flipped sub-image
	 */
	public static final native int Image_Flip(int handle, boolean hFlip, boolean vFlip, int x, int y, int width, int height);

	/**
	 * Creates a new image which is a duplicate of the image identified by 
	 * <code>handle</code>. 
	 * 
	 * @param deviceHandle the device/display handle
	 * @param handle image handle
	 * @return handle to the new image
	 */
	public static final native int Image_NewFromHandle(int deviceHandle, int handle);
	
	/**
	 * Creates a new image loaded from the specified file.
	 * <p>
	 * May result in the following errors:
	 * <ul>
	 * <li>ERROR_IO - I/O error occurred opening or reading the image file</li>
	 * <li>ERROR_UNSUPPORTED_DEPTH - the color depth is not supported</li>
	 * <li>ERROR_INVALID_IMAGE - an error has occurred while creating the image</li>
	 * </ul>  
	 * </p>
	 * 
	 * @param deviceHandle the device/display handle
	 * @param fileName image file to load
	 * @return handle to the new image loaded from the specified file. 
	 * 	0 if the file could not be decoded as an image.
	 */
	public static final native int Image_NewFromFile(int deviceHandle, String fileName);
	
	/**
	 * Sets the specified pixel to the given ARGB color. The new pixel value 
	 * is supplied in 0xAARRGGBB format, regardless of the actual color depth 
	 * and color model of the image.
	 * <p>
	 * If the image is using an indexed color model there may not be an exact
	 * match for the specified ARGB color. The color will be matched to a 
	 * close palette index in this case. 
	 * </p>
	 * 
	 * @param handle image handle
	 * @param x x coordinate of the pixel
	 * @param y y coordinate of the pixel
	 * @param argb new pixel value in 0xAARRGGBB format 
	 * @see #Image_IsDirect
	 */
	public static final native void Image_SetRGB(int handle, int x, int y, int argb);	
	
	/**
	 * Returns the direct color model masks of the image identified by 
	 * <code>handle</code>. 
	 * <p>
	 * Color masks are used to access individual color components of a 
	 * direct color pixel. There is one mask for each of the red, green, 
	 * blue and alpha component of a pixel. The masks for a 32 bit 
	 * per pixel image for example might be red=0xFF, green=0x00FF, 
	 * blue=0x0000FF, alpha=0x000000FF.
	 * </p>
	 * <p>
	 * Example: Given a pixel value, <code>int pixel</code>, returned by 
	 * <code>Image_GetPixelsHighColor()</code> the red color component can be extracted 
	 * as follows.
	 * <pre>
	 * 	int[] masks = Image_GetDirectPaletteMasks(imageHandle);
	 * 	int redMask = masks[OS.PALETTE_MASK_RED]; 
	 * 	int redShift = getMaskShift(redMask);
	 * 	int red = (pixel & redMask) >>> redShift;
	 * </pre>
	 * Where getMaskShift is defined separately to return the bit shift 
	 * necessary to shift the masked bits to the low order bits.
	 * <pre>
	 * 	int getMaskShift(int colorMask) {
	 *		int shiftCount = 0;
	 *		if (mask == 0) return 0;
	 *		while (((mask >> shiftCount) & 0x1) == 0) {
	 *			shiftCount++;
	 *		}
	 *		return shiftCount;
	 *	}
	 * </pre>
	 * </p> 
	 * <p>
	 * May result in the following error:
	 * <ul>
	 * <li>ERROR_UNSUPPORTED_DEPTH - direct palette not supported for this color depth</li>
	 * </ul>  
	 * </p>
	 * 
	 * @param handle image handle
	 * @return (palettemasks) the direct color model masks of the specified 
	 * 	image. Access array elements using the <code>PALETTE_MASK_RED</code>, 
	 * 	<code>PALETTE_MASK_GREEN</code>, <code>PALETTE_MASK_BLUE</code>, 
	 * 	<code>PALETTE_MASK_ALPHA</code> constants.
	 * @see #Image_IsDirect
	 */
	public static final native int[] Image_GetDirectPaletteMasks(int handle);
	
	/**
	 * Returns the indexed palette of the image identified by <code>handle</code>.
	 * The red, green and blue arrays must be big enough to hold all color 
	 * indices for the image's color depth.
	 * <p>
	 * May result in the following error:
	 * <ul>
	 * <li>ERROR_UNSUPPORTED_DEPTH - indexed palette not supported for this color depth</li>
	 * </ul>  
	 * </p>
	 *  
	 * @param handle image handle
	 * @param red red component of palette colors
	 * @param green green component of palette colors
	 * @param blue blue component of palette colors
	 * @see #Image_IsDirect
	 */
	public static final native void Image_GetIndexedPalette(int handle, byte[] red, byte[] green, byte[] blue);
	/**
	 * Returns pixel data for images with 8 bit per pixel color depth or less.
	 * Each byte array element holds one or more pixels but it never holds 
	 * pixels of two different scanlines. An 8 bpp image has one pixel per byte, 
	 * a 4 bpp image has up to 2 pixels per byte etc. Each pixel is an index 
	 * into the image's indexed color palette (Image_GetIndexedPalette).
	 * <p> 
	 * The most significant bit of each scanline in the returned buffer 
	 * corresponds to the leftmost pixel on the displayed scanline. Each 
	 * scanline in the returned buffer may have unused bits, depending on color 
	 * depth and image width. For example in a 3x3 image with 4 bpp color depth 
	 * the 4 least significant bits of the last byte on each scanline will be 
	 * unused. In addition, each scanline may be padded with unused bytes. The 
	 * number of bytes per scanline is determined by dividing the image size 
	 * (the size of the returned array) by the number of scanlines (height  
	 * returned by Image_GetBounds()).
	 * </p>
	 * <p>
	 * May result in the following error:
	 * <ul>
	 * <li>ERROR_UNSUPPORTED_DEPTH - the color depth is not supported</li>
	 * </ul>
	 * </p>
	 * 
	 * @param handle image handle
	 * @return pixel data of entire image
	 * @see #Image_GetIndexedPalette
	 * @ignore non-standard array creation, implementation provided
	 */
	public static final native byte[] Image_GetPixelsLowColor(int handle);
	/**
	 * Returns pixel data for images with more than 8 bit per pixel color depth.
	 * Each int array element holds exactly one pixel, compatible with the image's 
	 * color model. The color components of each pixel are layed out to match the
	 * direct palette masks returned by <code>Image_GetDirectPaletteMasks()</code>.
	 * <p>
	 * There is no scanline pad. Therefore, the size of the returned array equals
	 * the image width multiplied with the image height.
	 * </p>
	 * <p>
	 * May result in the following error:
	 * <ul>
	 * <li>ERROR_UNSUPPORTED_DEPTH - the color depth is not supported</li>
	 * </ul>  
	 * </p>
	 * 
	 * @param handle image handle
	 * @return pixel data of entire image
	 * @see #Image_GetDirectPaletteMasks
	 * @ignore non-standard array creation, implementation provided 
	 */
	public static final native int[] Image_GetPixelsHighColor(int handle);

	/**
	 * Returns the transparent color of the image identified by 
	 * <code>handle</code> or -1 if the image has no transparency.
	 * 
	 * @param handle image handle
	 * @return the transparent color of the image. This is a palette index
	 * 	in the case of paletted images or an RGB color value for direct 
	 * 	color images (Image_IsDirect). For RGB values the format matches 
	 * 	that returned by <code>Image_GetDirectPaletteMasks()</code> 
	 * @see #Image_GetDirectPaletteMasks
	 * @see #Image_GetIndexedPalette
	 * @see #Image_IsDirect
	 */
	public static final native int Image_GetTransparentColor(int handle);
	/**
	 * Returns whether the image identified by <code>handle</code> uses
	 * a direct color model or a paletted color model. 
	 * 
	 * @param handle image handle
	 * @return true - the image uses a direct color model. Pixel values are 
	 * 	RGB values (Red, Green, Blue) with optional alpha channel. 
	 * 	false - the image uses a paletted color mode. Pixel values are indices
	 * 	into a color palette.
	 * @see #Image_GetDirectPaletteMasks
	 * @see #Image_GetIndexedPalette
	 */
	public static final native boolean Image_IsDirect(int handle);

	/**
	 * Creates a new single line text widget.  Valid
	 * styles include STYLE_BORDER | STYLE_LEFT_TO_RIGHT | STYLE_RIGHT_TO_LEFT.
	 * 
	 * @param parent parent container of the text field widget
	 * @param style logical OR of widget styles 
	 * @return handle of new text field widget
	 */
	public static final native int TextField_New(int parent, int style);
	
	/**
	 * Returns the minimum size required to display a text field with
	 * the desired number of columns.
	 * 
	 * @param handle the text field handle
	 * @param columns the desired number of columns
	 * @return (size)
	 */
	public static final native int[] TextField_GetMinimumSize(int handle, int columns);
	
	/**
	 * Creates a new multiple line text widget.  Valid styles are 
	 * STYLE_H_SCROLL and STYLE_V_SCROLL. Horizontal and vertical
	 * scollbars should always be visible if the STYLE_H_SCROLL and
	 * STYLE_V_SCROLL flags, respectively, are supplied.
	 * 
	 * Other valid styles include STYLE_WRAP, STYLE_BORDER, 
	 * STYLE_LEFT_TO_RIGHT, and STYLE_RIGHT_TO_LEFT. 
	 * 
	 * @param parent the parent container of the text area widget
	 * @param style a logical OR of styles used for this widget
	 * @return handle of new text area widget
	 */
	public static final native int TextArea_New(int parent, int style);
	
	/**
	 * Returns the minimum size required to display a text area with
	 * the desired number of rows and columns.
	 * 
	 * @param handle the text area handle
	 * @param rows the desired number of rows
	 * @param columns the desired number of columns
	 * @return (size)
	 */
	public static final native int[] TextArea_GetMinimumSize(int handle, int rows, int columns);
	
	/**
	 * Returns the index of the first visible line of the text widget.
	 * This value is zero indexed.
	 * 
	 * @param handle text widget handle
	 * @return topmost visible line number of widget
	 */
	public static final native int TextArea_GetTopLine(int handle);
	
	/**
	 * Sets the index of the first visible line of the text widget.
	 * The line parameter is zero indexed.  If the argument is larger 
	 * than the total number of lines, the top line will be set to the
	 * last line.
	 * 
	 * @param handle widget handle
	 * @param line index of first visible line
	 */
	public static final native void TextArea_SetTopLine(int handle, int line);	
	
	/**
	 * Returns the number of lines in a text widget.  The result must be greater
	 * than or equal to one.
	 * 
	 * @param handle text widget handle
	 * @return number of lines in the widget
	 */
	public static final native int TextArea_GetLineCount(int handle);
	
	/**
	 * Returns the line that the caret is on.  This value is zero indexed.
	 * 
	 * @param handle text widget handle
	 * @return number of line containing the caret
	 */
	public static final native int TextArea_GetCaretLineNumber(int handle);	
	/**
	 * Returns the current text.
	 * 
	 * @param handle the text component handle
	 * @return current text string
	 */
	public static final native String AbstractTextComponent_GetText(int handle);
	
	/**
	 * Returns the currently selected text.
	 * 
	 * @param handle the text component handle
	 * @return currently selected text string
	 */
	public static final native String AbstractTextComponent_GetSelectionText(int handle);
	
	/**
	 * Sets the text.  This method does not make a text callback.
	 * The reason for this behavior is that some toolkits require
	 * an event to be created as a result of this call.  In those
	 * cases, the event needs to be created in Java because it is 
	 * possible to call setText before the event dispatch loop is 
	 * running. Unfortunately, some UGL implementations cannot make 
	 * callbacks without this loop.
	 * 
	 * @param handle widget handle
	 * @param text new text value
	 */
	public static final native void AbstractTextComponent_SetText(int handle, String text);
	
	/**
	 * Sets a text component's editable flag.  When the flag is false,
	 * the text component is considered to be read only.  
	 * 
	 * @param handle the text component handle
	 * @param editable true for read and write, false for read only
	 */
	public static final native void AbstractTextComponent_SetEditable(int handle, boolean editable);
	
	/**
	 * Selects all of the text in a text component.
	 * 
	 * @param handle the text component handle
	 */
	public static final native void AbstractTextComponent_SelectAll(int handle);
	
	/**
	 * Sets the selection between two positions in the text.  The start
	 * value should be between 0 and N inclusive, where N is the number
	 * of characters.  The end value should be greater than or equal to
	 * the start value.
	 * 
	 * @param handle the text component handle
	 * @param start the start position
	 * @param end the end position
	 */
	public static final native void AbstractTextComponent_SetSelection(int handle, int start, int end);
	
	/**
	 * Returns the number of characters in a text component.
	 * 
	 * @param handle the text component handle
	 * @return number of characters in component
	 */
	public static final native int AbstractTextComponent_GetCharCount(int handle);
	
	/**
	 * Sets the caret position of a text component.  The position
	 * value should be between 0 and N inclusive, where N is 
	 * the number of characters in the component.
	 * 
	 * @param handle the text component handle
	 * @param position the index where the caret should be displayed
	 */
	public static final native void AbstractTextComponent_SetCaretPosition(int handle, int position);
	
	/**
	 * Returns an array containing the start and end positions of the
	 * current selection.
	 * 
	 * @param handle the text component handle
	 * @return (point)
	 */
	public static final native int[] AbstractTextComponent_GetSelection(int handle);
	
	/**
	 * Replaces the text between two caret positions with 
	 * new text.  See AbstractTextComponent_SetCaretPosition
	 * for valid start and end values.  Please note that this
	 * method does not make a TextModifyCallback.
	 * 
	 * @param handle the text component handle
	 * @param string the new text
	 * @param start the start position
	 * @param end the end position
	 * @see #AbstractTextComponent_SetCaretPosition(int, int)
	 */
	public static final native void AbstractTextComponent_Replace(int handle, String string, int start, int end);
	
	/**
	 * Sets the echo character.  The echo character is
	 * displayed instead of the character that was typed.
	 * 
	 * <b>Note:</b> some platforms support a limited set of echo characters.
	 * In these cases, the suggested <code>echo</code> character might
	 * be ignored for a suitable substitute. 
	 *  
	 * @param handle the text component handle
	 * @param echo the echo character
	 */
	public static final native void AbstractTextComponent_SetEchoChar(int handle, char echo);
	/**
	 * Returns the line delimiter used by the text widget.
	 * 
	 * @return the native line delimiter for multi-line text widgets
	 */
	public static final native String AbstractTextComponent_GetDelimiter();
	
	/**
	 * Computes the minimum size of the text component based on the width passed in.  This 
	 * method is used for text components instead of Control_GetMinimumSize because the 
	 * WRAP flag makes desired width important to properly calculate the height.
	 * 
	 * @param handle the text component
	 * @param width the desired width, this value will be -1 if no
	 *              desired width is provided. 
	 * @return (point)
	 */
	public static final native int[] AbstractTextComponent_GetMinimumSize(int handle, int width);
	
	/**
	 * Returns the height of a single line of text.
	 * 
	 * @param handle widget handle
	 * @return height of text line
	 */
	public static final native int AbstractTextComponent_GetLineHeight(int handle);
	
	/**
	 * Returns the maximum number of characters that a text widget can hold.
	 * This is a default value which is valid when the widget has been 
	 * created.  Call AbstractTextComponent_SetTextLimit() to override this value.
	 *  
	 * @return maximum number of characters that the widget can hold
	 */
	public static final native int AbstractTextComponent_GetDefaultTextLimit();
	
	/**
	 * Sets the maximum number of characters that can be held by a text widget.
	 * This value must be greater than zero, and less than or equal to the value
	 * returned by AbstractTextComponent_GetDefaultTextLimit().
	 * 
	 * @param handle widget handle
	 * @param limit set the number of characters limit for the text
	 */
	public static final native void AbstractTextComponent_SetTextLimit(int handle, int limit);

	/**
	 * Returns the (x,y) position of the caret relative to the text widget's origin.
	 * 
	 * @param handle widget handle
	 * @return (point)
	 */
	public static final native int[] AbstractTextComponent_GetCaretPosition(int handle);
	
	/**
	 * Enables or disables the default double-click behavior for the text component.
	 * This setting is enabled when a text component is created.
	 * 
	 * @param handle the text component handle
	 * @param enabled true to enable, false to disable
	 */
	public static final native void AbstractTextComponent_SetDoubleClickEnabled(int handle, boolean enabled);
	
	
	public static final native void AbstractTextComponent_SetVKStatus(boolean show, int handle);
	
	
	/**
	 * Valid styles include STYLE_WRAP and STYLE_TOP, STYLE_MIDDLE for
	 * specifying the vertical alignment.
	 * 
	 * @param parentHandle handle of parent container
	 * @param style a logical OR of styles for this widget
	 * @return handle of new label widget
	 */
	public static final native int Label_New(int parentHandle, int style);
	
	/**
	 * Valid alignments include STYLE_LEAD, STYLE_TRAIL, STYLE_CENTER.
	 * 
	 * @param handle widget handle
	 * @param alignment new alignment style for label
	 */
	public static final native void Label_SetAlignment(int handle, int alignment);
	
	/**
	 * Sets the label's text.  The label can have text or an
	 * image, but not both.
	 * 
	 * @param handle the label handle
	 * @param string the new text
	 */
	public static final native void Label_SetText(int handle, String string);
	/**
	 * Computes the minimum size of the label based on the width passed in.  This 
	 * method is used for labels instead of Control_GetMinimumSize because the
	 * WRAP flag makes the width important when calculating the height.
	 * 
	 * @param handle the label
	 * @param width the desired width, this value will be -1 if no
	 *              desired width is provided. 
	 * @return (point)
	 */
	public static final native int[] Label_GetMinimumSize(int handle, int width);
	
	/**
	 * Sets the label's image.  The label can have text or an
	 * image, but not both.
	 * 
	 * @param handle the label handle
	 * @param imageHandle the image handle
	 */
	public static final native void Label_SetImage(int handle, int imageHandle);
	
	
	/** 
	 * Valid styles include STYLE_LEFT_TO_RIGHT, STYLE_RIGHT_TO_LEFT, STYLE_BORDER,
	 * STYLE_V_SCROLL, and STYLE_H_SCROLL.
	 * 
	 * @param parentHandle handle of parent widget
	 * @param style a logical OR of styles for this widget
	 * @return handle of new List widget
	 */
	public static final native int List_New(int parentHandle, int style);
	
	/**
	 * Deselects the item at the given index.
	 * 
	 * @param handle the list handle
	 * @param index the index to be deselected
	 */
	public static final native void List_Deselect(int handle, int index);

	/**
	 * Deselects all selected items.
	 * 
	 * @param handle the list handle
	 */
	public static final native void List_DeselectAll(int handle);

	/**
	 * Returns the number of selected items.
	 * 
	 * @param handle the list handle
	 * @return number of selected items
	 */
	public static final native int List_GetSelectionCount(int handle);
	
	/**
	 * Removes all items from the list.
	 * 
	 * @param handle the list handle
	 */
	public static final native void List_RemoveAll(int handle);
	
	/**
	 * Sets the text of the item at the given index.
	 * 
	 * @param handle the list handle
	 * @param index the item index
	 * @param string the new text
	 */
	public static final native void List_SetItem(int handle, int index, String string);
	
	/**
	 * Returns the selection state of the item at the given index.
	 * 
	 * @param handle the list handle
	 * @param index the item index
	 * @return true if the item is selected, false otherwise
	 */
	public static final native boolean List_IsSelected(int handle, int index);
	
	/**
	 * Selects the item at the given index.
	 * 
	 * @param handle the list handle
	 * @param index the item index
	 */
	public static final native void List_Select(int handle, int index);
	
	/**
	 * Returns an array containing the indices of the currently
	 * selected items.
	 * 
	 * @param handle the list handle
	 * @return indices of selected items
	 */
	public static final native int[] List_GetSelectionIndices(int handle);
	
	/**
	 * Returns the index of the currently selected item.  When multiple items
	 * are selected, the index of the topmost item will be returned.
	 * 
	 * @param handle the list handle
	 * @return the selection index of the list
	 */
	public static final native int List_GetSelectionIndex(int handle);
	
	/**
	 * Adds an item with the given text at the given index.
	 * 
	 * @param handle the list handle
	 * @param string the item text
	 * @param index the item index
	 */
	public static final native void List_Add(int handle, String string, int index);

	/**
	 * Sets the selection mode.  If the mode is true, the list should
	 * allow selection of multiple items.  If the mode is false, the
	 * list should allow selection of only one item.
	 * 
	 * @param handle the list handle
	 * @param multipleMode true for multiple selection, false for single selection
	 */
	public static final native void List_SetMultipleMode(int handle, boolean multipleMode);
	
	/**
	 * Sets the index of the item which should appear at the top of the list.
	 * 
	 * @param handle the list handle
	 * @param index the item index
	 */
	public static final native void List_SetTopItemIndex(int handle, int index);
	
	/**
	 * Removes the item at the given index from the list.
	 * 
	 * @param handle the list handle
	 * @param index the item index
	 */
	public static final native void List_Remove(int handle, int index);

	/**
	 * Returns the minimum size of the list if it 
	 * had the desired number of rows.
	 * 
	 * @param handle the list handle
	 * @param rows the desired number of rows
	 * @return (size)
	 */
	public static final native int[] List_GetMinimumSize(int handle, int rows);
	


	/**
	 * Selects the items which have the given indices.
	 * 
	 * @param handle the list handle
	 * @param indices the indices to select
	 * @param length length of indices array
	 */
	public static final native void List_SelectIndices(int handle, int[] indices, int length);
	
	

	/**
	 * Returns the height of an item.  Please note that
	 * all items must have the same height.
	 * 
	 * @param handle the list handle
	 * @return item height
	 */
	public static final native int List_GetItemHeight(int handle);
	
	/**
	 * Returns the index of the item which is currently
	 * at the top of the list.
	 * 
	 * @param handle the list handle
	 * @return index of topmost item displayed in list
	 */
	public static final native int List_GetTopItemIndex(int handle);
	
	/**
	 * Makes the currently selected items visible.  If there
	 * are more items than the list can currently display,
	 * make sure that the top selected item is visible.
	 * 
	 * @param handle the list handle
	 */
	public static final native void List_MakeSelectionVisible(int handle);
	
	/**
	 * Returns the currently focused item, which is not
	 * necessarily the currently selected item.
	 * 
	 * @param handle widget handle
	 * @return index of currently focused item
	 */
	public static final native int List_GetCurrentItemIndex(int handle);
	
	
	/**
	 * Separator styles include STYLE_VERTICAL, STYLE_HORIZONTAL, STYLE_SHADOW_IN, 
	 * STYLE_SHADOW_OUT, STYLE_SHADOW_NONE.
	 * 
	 * @param parentHandle handle for parent widget
	 * @param style a logical OR of styles for this widget
	 * @return handle of new separator widget
	 */
	public static final native int Separator_New(int parentHandle, int style);
	/**
	 * Create a new PushButton widget
	 * 
	 * @param parentHandle handle of parent widget
	 * @param style STYLE_FLAT or 0
	 * @return handle of new widget
	 * @uglGroup Button
	 */
	public static final native int PushButton_New(int parentHandle, int style);

	/**
	 * Create a new RadioButton widget
	 * 
	 * @param parentHandle handle of parent widget
	 * @param style STYLE_FLAT or 0
	 * @return handle of new widget
	 * @uglGroup Button
	 */
	public static final native int RadioButton_New(int parentHandle, int style);
	/**
	 * Create a new ToggleButton widget
	 * 
	 * @param parentHandle handle of parent widget
	 * @param style STYLE_FLAT or 0
	 * @return handle of new widget
	 * @uglGroup Button
	 */
	public static final native int ToggleButton_New(int parentHandle, int style);
	/**
	 * Returns the horizontal adjustable.  The returned adjustable must implement
	 * the Adjustable interface, and it must be a Widget subclass.
	 * Note this will not be called for Scrollables created without STYLE_H_SCROLL.
	 * 
	 * @param handle the scrollable handle
	 * @return horizontal adjustable handle
	 */
	public static final native int Scrollable_GetHorizontalBar(int handle);
	
	/**
	 * Returns the vertical adjustable.  The returned adjustable must implement
	 * the Adjustable interface, and it must be a Widget subclass.
	 * Note this will not be called for Scrollables created without STYLE_V_SCROLL.
	 * 
	 * @param handle the scrollable handle
	 * @return vertical adjustable handle
	 */
	public static final native int Scrollable_GetVerticalBar(int handle);
	
	/**
	 * Creates a new scrollbar.  The scrollbar must implement the
	 * Adjustable interface.
	 * 
	 * @param parentHandle the parent handle
	 * @return handle of new widget
	 */
	public static final native int Scrollbar_New(int parentHandle);
	
	/**
	 * Returns the bounding rectangle of the adjustable, relative to the parent.
	 * 
	 * @param handle the handle of the scrollable (the container)
	 * @param adjustableHandle the handle of the adjustable (the scrollbar)
	 * @return (rect)
	 */
	public static final native int[] Scrollable_GetAdjustableBounds(int handle, int adjustableHandle);
	
	/**
	 * Enable or disable a Scrollable's Adjustable.
	 * 
	 * @param handle the handle of the scrollable (the container)
	 * @param adjustableHandle the handle of the adjustable (the scrollbar)
	 * @param enabled a boolean indicating whether the adjustable should be enabled
	 */
	public static final native void Scrollable_SetAdjustableEnabled(int handle, int adjustableHandle, boolean enabled);
	
	/**
	 * Show or hide a Scrollable's Adjustable.
	 * 
	 * @param handle the handle of the scrollable (the container)
	 * @param adjustableHandle the handle of the adjustable (the scrollbar)
	 * @param visible a boolean indicating whether the adjustable should be visible
	 */
	public static final native void Scrollable_SetAdjustableVisible(int handle, int adjustableHandle, boolean visible);
	
	/**
	 * Returns the scrollbar's maximum value.
	 * 
	 * @param handle the scrollbar handle
	 * @return maximum value of scrollbar
	 */
	public static final native int Adjustable_GetMaximum(int handle);

	/**
	 * Returns the scrollbar's minimum value.
	 * 
	 * @param handle the scrollbar handle
	 * @return minimum value of scrollbar
	 */
	public static final native int Adjustable_GetMinimum(int handle);

	/**
	 * Returns the scrollbar's current value.
	 * 
	 * @param handle the scrollbar handle
	 * @return current value of scrollbar
	 */
	public static final native int Adjustable_GetValue(int handle);

	/**
	 * Returns the scrollbar's visible amount.  This is also
	 * known as the thumb size.
	 * 
	 * @param handle the scrollbar handle
	 * @return size of scrollbar thumb
	 */
	public static final native int Adjustable_GetVisibleAmount(int handle);
	
	/**
	 * Sets the scrollbar's block increment.
	 * 
	 * @param handle the scrollbar handle
	 * @param value the block increment value
	 */
	public static final native void Adjustable_SetBlockIncrement(int handle, int value);
	
	/**
	 * Sets the scrollbar's maximum value.
	 * 
	 * @param handle the scrollbar handle
	 * @param value the maximum value
	 */
	public static final native void Adjustable_SetMaximum(int handle, int value);
	
	/**
	 * Sets the scrollbar's minimum value.
	 * 
	 * @param handle the scrollbar handle
	 * @param value the minimum value
	 */
	public static final native void Adjustable_SetMinimum(int handle, int value);
	
	/**
	 * Sets the scrollbar's orientation.
	 * 
	 * @param handle the scrollbar handle
	 * @param orientation either STYLE_HORIZONTAL or STYLE_VERTICAL
	 */
	public static final native void Scrollbar_SetOrientation(int handle, int orientation);
	
	/**
	 * Sets the scrollbar's unit increment.
	 * 
	 * @param handle the scrollbar handle
	 * @param value the unit increment value
	 */
	public static final native void Adjustable_SetUnitIncrement(int handle, int value);
	
	/**
	 * Sets the scrollbar's current value.
	 * 
	 * @param handle the scrollbar handle
	 * @param value the current value of the scrollbar
	 */
	public static final native void Adjustable_SetValue(int handle, int value);
	
	/**
	 * Sets the scrollbar's visible amount.
	 * 
	 * @param handle the scrollbar handle
	 * @param value the visible amount of the scrollbar
	 */
	public static final native void Adjustable_SetVisibleAmount(int handle, int value);
	
	/**
	 * Returns the scrollbar's unit increment.
	 * 
	 * @param handle the scrollbar handle
	 * @return scrollbar's unit increment
	 */
	public static final native int Adjustable_GetUnitIncrement(int handle);
	
	/**
	 * Returns the scrollbar's block increment.
	 * 
	 * @param handle the scrollbar handle
	 * @return block increment for the scrollbar
	 */
	public static final native int Adjustable_GetBlockIncrement(int handle);

	/**
	 * Returns the text that is on the system clipboard.
	 * 
	 * @return text from system clipboard
	 */
	public static final native String Clipboard_GetText();
	
	/**
	 * Put the text on the system clipboard.
	 * 
	 * @param text new text to be stored on the clipboard
	 */
	public static final native void Clipboard_SetText(String text);
	
	/**
	 * Creates a new choice widget.
	 * 
	 * @param parentHandle handle of the parent container
	 * @return handle of new widget
	 */
	public static final native int Choice_New(int parentHandle);
	
	/**
	 * Returns the index of the currently selected item.  If no item
	 * is selected, return -1.
	 * 
	 * @param handle widget handle
	 * @return index of currently selected item or -1
	 */
	public static final native int Choice_GetSelectedItemIndex(int handle);
	
	/**
	 * Adds an item at the given index.  The index must be in the range 0 to
	 * N inclusive, where N is the number of items in the list.
	 *  
	 * @param handle widget handle
	 * @param string item to be added
	 * @param index insertion index
	 */
	public static final native void Choice_AddItem(int handle, String string, int index);

	/**
	 * Removes the item at the given index from the list.  The index must be in 
	 * the range 0 to (N - 1) inclusive, where N is the number of items in the list.
	 * 
	 * @param handle widget handle
	 * @param index index of item to be removed
	 */
	public static final native void Choice_RemoveItem(int handle, int index);
	
	/**
	 * Selects the item at the given index.  Any previous selection will be
	 * cleared first.  The index must be in the range 0 to (N - 1) inclusive, 
	 * where N is the number of items in the list.
	 * 
	 * @param handle widget handle
	 * @param index index of item to be selected
	 */
	public static final native void Choice_SelectItem(int handle, int index);
	
	/**
	 * Removes all items from the list.
	 * 
	 * @param handle widget handle
	 */
	public static final native void Choice_RemoveAllItems(int handle);

	/**
	 * Creates a new menu bar for the shell.
	 * 
	 * @param shellHandle the shell which owns the new menu bar
	 * @return handle of new widget
	 * @uglGroup Menu
	 */
	public static final native int MenuBar_New(int shellHandle);
	
	/**
	 * Creates a new popup menu for the shell.
	 * 
	 * @param shellHandle the shell which owns the new popup menu
	 * @return handle of new widget
	 * @uglGroup Menu
	 */	
	public static final native int PopupMenu_New(int shellHandle);
	
	/**
	 * Creates a new drop down menu for the shell.
	 * 
	 * @param shellHandle the shell which owns the new drop down menu
	 * @return handle of new widget
	 * @uglGroup Menu
	 */
	public static final native int DropDownMenu_New(int shellHandle);
	/**
	 * Sets the font of a menu.
	 * 
	 * @param menuHandle the menu
	 * @param fontHandle the font
	 */
	public static final native void Menu_SetFont(int menuHandle, int fontHandle);
	/**
	 * Shows the popup menu identified by <code>popupMenuHandle</code>
	 * at the specified location. 
	 * 
	 * @param popupMenuHandle popup menu handle
	 * @param x x coordinate of the menu location, relative to the owning shell
	 * @param y y coordinate of the menu location, relative to the owning shell
	 * @uglGroup Menu
	 */	
	public static final native void PopupMenu_Show(int popupMenuHandle, int x, int y);
	
	/**
	 * Enables or disables a menu item.
	 * 
	 * @param menuItemHandle the menu item handle
	 * @param enabled the enablement state of the menu item
	 * @uglGroup MenuItem
	 */	
	public static final native void AbstractMenuItem_SetEnabled(int menuItemHandle, boolean enabled);
	
	/**
	 * Creates a new push menu item.  
	 * 
	 * @param menuHandle the menu handle which contains this new item
	 * @param index the index inside menu where this new item is placed
	 * @return handle of new widget
	 * @uglGroup MenuItem
	 */	
	public static final native int PushMenuItem_New(int menuHandle, int index);
	
	/**
	 * Sets the descriptive text and the accelerator text of a LabeledMenuItem.
	 * 
	 * The descriptive text may contain mnemonic characters, which are preceded
	 * by the '&amp;' character.  In order to add a '&amp;' character to the text,
	 * it should be escaped with another '&amp;' character.  
	 * 
	 * The accelerator text is displayed next to the descriptive text in the item, 
	 * and usually describes the accelerator, if one is being used.  Note that the 
	 * accelerator text does not actually set the accelerator.  That is done by 
	 * LabeledMenuItem_SetAccelerator.
	 * 
	 * @param menuItemHandle the menu item handle
	 * @param text the descriptive text
	 * @param accelText the accelerator text
	 * @uglGroup MenuItem
	 */	
	public static final native void LabeledMenuItem_SetText(int menuItemHandle, String text, String accelText);
	/**
	 * Sets the font of a LabeledMenuItem.
	 * 
	 * @param menuItemHandle the menu item handle
	 * @param fontHandle the font handle
	 * @uglGroup MenuItem
	 */	
	public static final native void LabeledMenuItem_SetFont(int menuItemHandle, int fontHandle);
	
	/**
	 * Sets the image which is displayed on a LabeledMenuItem.  If the
	 * imageHandle is zero, remove the current image.
	 * 
	 * @param menuItemHandle the menu item handle
	 * @param imageHandle the image handle
	 * @uglGroup MenuItem
	 */	
	public static final native void LabeledMenuItem_SetImage(int menuItemHandle, int imageHandle);
	/**
	 * Sets the accelerator for a LabeledMenuItem.  The accelerator is a bitwise
	 * OR of MODIFIER_MASK constants and keycode values.  The MODIFIER_MASK constants
	 * are placed in the upper 16 bits of the value.  The keycode is in the lower 
	 * 16 bits.  Valid keycodes are either KEYCODE constants or 16-bit char values.
	 * 
	 * @param menuItemHandle the menu item handle
	 * @param accelerator the accelerator
	 * @uglGroup MenuItem
	 */	
	public static final native void LabeledMenuItem_SetAccelerator(int menuItemHandle, int accelerator);

	/**
	 * Creates a new menu item which has a selection state, similar to a checkbox.
	 * 
	 * @param menuHandle the menu handle which contains this new item
	 * @param index the index inside menu where this new item is placed
	 * @param style either STYLE_RADIO or STYLE_CHECK
	 * @return handle of new widget
	 * @uglGroup MenuItem
	 */	
	public static final native int StateMenuItem_New(int menuHandle, int index, int style);
	
	/**
	 * Sets the selection state of a state menu item.
	 * 
	 * @param statefulMenuItemHandle the menu item handle
	 * @param selected the new selection state
	 * @uglGroup MenuItem
	 */	
	public static final native void StateMenuItem_SetSelection(int statefulMenuItemHandle, boolean selected);
	
	/**
	 * Creates a new cascade menu item, and places it at the given
	 * index of the menu.  If the index value is -1, the menu should
	 * append the new item.
	 * 
	 * @param menuHandle the menu handle which contains this new item
	 * @param index the index inside menu where this new item is placed
	 * @return handle of new widget
	 * @uglGroup MenuItem
	 */	
	public static final native int CascadeMenuItem_New(int menuHandle, int index);
	
	/**
	 * Sets the submenu of a cascade menu item.
	 * 
	 * @param cascadeMenuItemHandle the cascade menu item
	 * @param dropDownMenuHandle the submenu, or 0 if the current menu 
	 *                           should be removed.  
	 * @uglGroup MenuItem
	 */	
	public static final native void CascadeMenuItem_SetMenu(int cascadeMenuItemHandle, int dropDownMenuHandle);
	
	/**
	 * Creates a new separator menu item.
	 * 
	 * @param menuHandle the menu handle which contains this new item
	 * @param index the index inside menu where this new item is placed	 
	 * @return handle of new widget
	 * @uglGroup MenuItem
	 */	
	public static final native int SeparatorItem_New(int menuHandle, int index);
	
	/**
	 * Creates a new cursor.  The style value should be one 
	 * of the CURSOR constants.
	 * 
	 * @param deviceHandle the device handle
	 * @param style the cursor style
	 * @return handle of new widget
	 */
	public static final native int Cursor_New(int deviceHandle, int style);
	
	/**
	 * Release any resources that were allocated to a cursor.
	 * 
	 * @param handle the cursor handle
	 */
	public static final native void Cursor_Dispose(int handle);
	
	/**
	 * Creates a new file dialog.  Valid styles are STYLE_APPLICATION_MODAL,
	 * STYLE_PRIMARY_MODAL, STYLE_OPEN, STYLE_SAVE, and STYLE_MULTI.
	 * 
	 * @param peerParent handle of shell this dialog is modal to
	 * @param style a logical OR of styles for this widget
	 * @return handle of new FileDialog widget
	 */
	public static final native int FileDialog_New(int peerParent, int style);
	
	/**
	 * Returns the list of file names that were selected by the user.
	 * This list has a length greater than one only if the dialog was
	 * created with STYLE_MULTI.
	 * 
	 * @param peerHandle widget handle
	 * @return selected file name(s)
	 */
	public static final native String[] FileDialog_GetFileNames(int peerHandle);
	
	/**
	 * Returns the path of the directory that contains all selected files.
	 * 
	 * @param peerHandle widget handle
	 * @return directory path for selected file(s)
	 */
	public static final native String FileDialog_GetFilterPath(int peerHandle);

	/**
	 * Opens a file dialog.  Returns true if the dialog was opened
	 * successfully, false otherwise.  
	 * 
	 * @param peerHandle widget handle
	 * @return boolean indicating whether the file selection was accepted
	 */
	public static final native boolean FileDialog_Open(int peerHandle);
	
	/**
	 * Sets the initial file name that the file dialog should display.
	 * 
	 * @param peerHandle widget handle
	 * @param string file name to display in text field
	 */
	public static final native void FileDialog_SetFileName(int peerHandle, String string);
	
	/**
	 * Sets the filter extension of the file dialog.
	 * 
	 * @param peerHandle widget handle
	 * @param string[] filter extension
	 */
	public static final native void FileDialog_SetFilterExtensions(int peerHandle, String[] extensions);

	/**
	 * Sets the filter name of the file dialog.
	 * 
	 * @param peerHandle widget handle
	 * @param string[] filter name
	 */
	public static final native void FileDialog_SetFilterNames(int peerHandle, String[] names);

	/**
	 * Sets the filter path of the file dialog.
	 * 
	 * @param peerHandle widget handle
	 * @param string filter path (such as "*.txt")
	 */
	public static final native void FileDialog_SetFilterPath(int peerHandle, String string);
	
	/**
	 * Sets the title of a file dialog.  This method will only be called if the
	 * user would like to use a non default title.
	 * 
	 * @param peerHandle widget handle
	 * @param string the new title to use for the dialog.  This will never be null
	 */
	public static final native void FileDialog_SetTitle(int peerHandle, String string);
	
	/**
	 * Returns the name of the native platform.  This is typically
	 * the name of the user interface library or window toolkit.
	 * 
	 * @return a string indicating the platform name
	 */
	public static final native String Platform_GetName();
	
	public static final native int Platform_GetIdentifyCode();

	public static final native int Platform_GetMajorVersion();

	/**
	 * Returns the platform support for certain capabilities.  The meaning of
	 * the return value is dependent on the capability parameter.  Possible 
	 * values for the parameter are below and the corresponding return value 
	 * is documented with each constant: 
	 * 
	 * CAPABILITY_SHELL_TOPLEVEL_RESIZING - indicates whether top-level shells (i.e. shells without a parent shell) are resizable
	 * CAPABILITY_SHELL_CHILD_RESIZABLE - indicates whether shells that are children of another shell can be resized
	 * CAPABILITY_SHELL_MINMAX - indicates whether shells can be minimized and maximized on this platform
	 * 
	 * @param capability a constant representing a particular platform capability
	 * @return an integer that represents the platform's ability to fulfill a capability (0 indicates a lack of capability)
	 */
	public static final native int Platform_GetCapability(int capability);
	
	/**
	 * Opens a new message box and waits for the user to dismiss it. 
	 * 
	 * @param parentShell the parent of the message box
	 * @param style one of the following combinations of MESSAGEBOX_* styles, denoting 
	 *              which buttons should be available in the message box, and 
	 *              zero or one MESSAGEBOX_ICON_* style denoting which icon should 
	 *              be used. Valid button combinations are ok, ok/cancel, yes/no, 
	 *              yes/no/cancel, retry/cancel.  Style also can indicate modality 
	 *              (one of STYLE_SYSTEM_MODAL, STYLE_APPLICATION_MODAL, STYLE_PRIMARY_MODAL,
	 *              STYLE_MODELESS).  Modality styles are hints and may not be supported
	 *              on all platforms.
	 * @param title the tile of the message box, or null if the default title should
	 *              be used
	 * @param message the message to display for the user
	 * @return one of the MESSAGEBOX_* styles denoting which button was pressed to
	 *         dismiss the message.
	 */
	public static final native int MessageBox_Open(int parentShell, int style, String title, String message);
	
	/**
	 * Creates a new progress bar.  In addition to the styles supported by
	 * Control, the valid styles are STYLE_VERTICAL, STYLE_HORIZONTAL, STYLE_SMOOTH, INDETERMINATE.
	 * 
	 * @param parentHandle handle of parent widget
	 * @param style one of the valid style constants
	 * @return handle of new widget
	 */
	public static final native int ProgressBar_New(int parentHandle, int style);
	
	/**
	 * Updates the current selection in the progress bar.  The value passed 
	 * in will always be in [min,max].  
	 * 
	 * @param handle the handle to the bar
	 * @param value the new selection
	 */
	public static final native void ProgressBar_SetSelection(int handle, int value);
	
	/**
	 * Updates the current minimum in the progress bar.  The value passed in 
	 * will always be in [0,max].
	 * 
	 * @param handle the handle the bar
	 * @param value the new minimum value
	 */
	public static final native void ProgressBar_SetMinimum(int handle, int value);
	
	/**
	 * Updates the current maximum in the progress bar.  The value passed in 
	 * will always be in [min,MAX_INT].
	 * 
	 * @param handle the handle the bar
	 * @param value the new maximum value
	 */	
	public static final native void ProgressBar_SetMaximum(int handle, int value);
	
	public static final native int Tray_New(int displayHandle);
	public static final native int TrayItem_New(int trayHandle);
	public static final native void TrayItem_setImage(int handle, int imageHandle);
	public static final native void TrayItem_setToolTipText(int handle, String toolTip);
	public static final native void TrayItem_setVisible(int handle, boolean visible);
	
}
