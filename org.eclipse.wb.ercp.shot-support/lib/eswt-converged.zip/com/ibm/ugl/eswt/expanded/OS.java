/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.ibm.ugl.eswt.expanded;

import com.ibm.ugl.UGLCompatibility;

public class OS {
	static { 
		UGLCompatibility.loadLibrary("eswt-exp");
	}	  
	/**
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int CALLBACK_TREE = 17;
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int CALLBACK_TABLE = 18;
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int CALLBACK_TABLECOLUMN = 19;

	/**
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int CALLBACK_BROWSER_TITLE_CHANGED = 1748788638; 
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */	
	public static final int CALLBACK_BROWSER_STATUSTEXT_CHANGED = 1617659889;
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */	
	public static final int CALLBACK_BROWSER_PROGRESS = 2129896520;
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */	
	public static final int CALLBACK_BROWSER_LOCATION_CHANGING = 874900120;
	
	/**
	 * @internal this should only be used by toolkit implementors
	 */	
	public static final int CALLBACK_BROWSER_LOCATION_CHANGED = 1275148711;
	
	
	public static final int EVENT_TREE_SELECTION = 1;
	public static final int EVENT_TREE_ACTION = 2;
	public static final int EVENT_TREE_COLLAPSE = 3;
	public static final int EVENT_TREE_EXPAND = 4;
	public static final int EVENT_TREE_GETDISPINFO = 5;
	
	public static final int EVENT_TABLE_SELECTION = 1;
	public static final int EVENT_TABLE_ACTION = 2;
	public static final int EVENT_TABLE_GETDISPINFO = 3;
	
	public static final int EVENT_TABLECOLUMN_SELECTION = 1;
	public static final int EVENT_TABLECOLUMN_ACTION = 2;
	public static final int EVENT_TABLECOLUMN_MOVE = 3;
	public static final int EVENT_TABLECOLUMN_RESIZE = 4;
	/**
	 * Image formats defined by eSWT
	 */
	public static final int IMAGE_FORMAT_GIF = 1;
	public static final int IMAGE_FORMAT_JPEG = 2;
	public static final int IMAGE_FORMAT_PNG = 3;

	/**
	 * Table style for indicating full row selection for the table.
	 */
	public static final int STYLE_FULLSELECTION = 1 << 30;

	/**
	 * Table style for indicating full row selection for the table.
	 */
	public static final int STYLE_HIDESELECTION = 1 << 15;

	/** Single selection and single line style */
	public static final int STYLE_SINGLE = 1 << 22;

	/**
	 * Create a new web browser control with the given parent and style
	 * 
	 * @param parentHandle
	 * @param style
	 * @return a new web browser control.
	 */
	public static final native int Browser_New(int parentHandle, int style);

    /**
	 * Refresh the currently displayed page
	 * 
	 * @param browserHandle the browser control
	 */
	public static final native void Browser_Refresh(int browserHandle);
	
	/**
	 * Navigate forward in the browser's history
	 * 
	 * @param browserHandle the browser control
	 * @return true if the browser successully navigated forward
	 */
	public static final native boolean Browser_Forward(int browserHandle);
	
	/**
	 * Stop loading the current page
	 * 
	 * @param browserHandle the browser control
	 */
	public static final native void Browser_Stop(int browserHandle);
	
	/**
	 * Navigate backwards in the browser's history
	 * 
	 * @param browserHandle the browser control
	 * @return true if the browser successully navigated backward
	 */
	public static final native boolean Browser_Back(int browserHandle);
	
	/**
	 * Navigate execute the specified script
	 * 
	 * @param browserHandle the browser control
	 * @param script the script with javascript commands
	 * @return true operation was successful
	 */
	public static final native boolean Browser_Execute(int browserHandle, String script);

	/**
	 * Returns whether there is enough history to navigate backwards
	 * 
	 * @param browserHandle the browser control
	 * @return true if the browser could navigate backwards
	 */
	public static final native boolean Browser_IsBackEnabled(int browserHandle);

	/**
	 * Returns whether there is enough history to navigate forward
	 * 
	 * @param browserHandle the browser control
	 * @return true if the browser could navigate forward
	 */
	public static final native boolean Browser_IsForwardEnabled(int browserHandle);
	
	
	/**
	 * Changes the URL that the specified browser should render.  
	 * 
	 * @param browserHandle the browser to adjust
	 * @param url the new URL to render.  This will never be NULL.
	 * @return true if the URL loaded without error, false otherwise
	 */
	public static final native boolean Browser_SetURL(int browserHandle, String url);
	
	/**
	 * set the html text for browser to render
	 * 
	 * @param browserHandle
	 * @param html the html to be rendered.
	 * @return true if html rendered without error, false otherwise
	 */
	public static final native boolean Browser_SetText(int browserHandle, String html);

	/**
	 * Gets the current URL displayed by the browser.  
	 * 
	 * @param browserHandle the browser to query
	 * @return the URL displayed in the browser, or null if there is
	 *         no currently displayed url
	 */
	public static final native String Browser_GetURL(int browserHandle);
	
	/**
	 * Clear all clipboard content.
	 * 
	 * @uglGroup ClipboardEx
	 */
	public static final native void Clipboard_Clear();
	
	/**
	 * Return the native ids which are associated with
	 * strings.
	 * 
	 * @return the platform specific ids used for string contents
	 * @uglGroup ClipboardEx
	 */
	public static final native int[] Clipboard_GetStringIds();
	
	/**
	 * Return the native ids which are available on the clipboard.
	 * 
	 * @return the platform specific ids which are available.
	 * @uglGroup ClipboardEx
	 */
	public static final native int[] Clipboard_GetAvailableIds();
	
	/**
	 * @uglGroup ClipboardEx
	 */
	public static final native byte[] Clipboard_GetByteData(int id);
	
	/**
	 * @uglGroup ClipboardEx
	 */	
	public static final native void Clipboard_SetByteData(int id, byte[] data, int arrayLength);

	/**
	 * @uglGroup ClipboardEx
	 */
	public static final native int Clipboard_RegisterFormat(String name);

	/**
	 * @uglGroup ClipboardEx
	 */
	public static final native String Clipboard_GetTypeName(int id);
	
	/**
	 * Prompts the user with a color dialog.  The initial value used in the 
	 * color dialog should match the initial value passed in, or if the value 
	 * passed to this method is -1 then the platform default should be used.
	 * 
	 * @param parentHandle the parent of this dialog
	 * @param style the style for the dialog.  This value will be one of the 
	 *              modality style.
	 * @param initialColor the initial RGB for the dialog, or -1 to use the platform
	 *                     default
	 * @param title the title to use for this dialog, or null indicating that the 
	 *              system default title should be used
	 * @return either the rgb value selected by the user or -1 if the dialog was 
	 *         cancelled 
	 */
	public static final native int ColorDialog_Open(int parentHandle, int style, String title, int initialColor);
	
	/**
	 * Opens a dialog that will allow the user to select a directory.  This method
	 * should block until the user has either selected a directory or cancelled
	 * the dialog.
	 * 
	 * @param parentHandle the handle the owning shell
	 * @param style one of the modality styles
	 * @param title the title for the dialog, or null if the default title
	 *              should be used
	 * @param message the message to present to the user
	 * @param initialPath the initial directory to select in the dialog, or 
	 *                    null if the default directory should be selected
	 * @return the directory selected by the user, or null if the dialog was
	 *         cancelled.
	 */
	public static final native String DirectoryDialog_Open(int parentHandle, int style, String title, String message, String initialPath);
	
	/**
	 * Create a new font dialog with the specified parent and style.
	 * 
	 * @param parentHandle the parent
	 * @param style can be one of the modality styles
	 * @return a handle to the new font dialog
	 */
	public static final native int FontDialog_New(int parentHandle, int style);
	
	/**
	 * Sets the font that should be initially displayed when the dialog is 
	 * opened.  This method will only be called if the user has specified 
	 * an initial font selection. 
	 * 
	 * @param fontDialog a handle to a font dialog
	 * @param fontname the name of the font to select
	 * @param size the size of the font in points
	 * @param style a combination of the FONT_STYLE_* constants
	 */
	public static final native void FontDialog_SetInitialFontData(int fontDialog, String fontname, int size, int style);
	
	/**
	 * Sets the color that will be initially selected when the dialog is opened.
	 * This method will only be called if the user has specified an intial color.
	 * 
	 * @param fontDialog
	 * @param rgb
	 */
	public static final native void FontDialog_SetInitialRGB(int fontDialog, int rgb);
	
	/**
	 * Opens the specified font dialog and waits for the user to either select a font
	 * or cancel the dialog.
	 * 
	 * @param fontDialog
	 * @param title the title to display on the dialog, or null if the platform
	 *              default should be used
	 * @return true if the user selected a font, or false if the user cancelled it.
	 */
	public static final native boolean FontDialog_Open(int fontDialog, String title);
	
	/**
	 * Returns the color that was selected by the user.  This method will not be called
	 * if the dialog was cancelled.
	 * 
	 * @param fontDialog
	 * @return a color encoded in an int with a RGB format.
	 */
	public static final native int FontDialog_GetRGB(int fontDialog);
	
	/**
	 * Returns the name of the font that was selected by the user.  This method will not
	 * be called if the dialog was cancelled.
	 * 
	 * @param fontDialog
	 * @return name of selected font
	 */
	public static final native String FontDialog_GetFontName(int fontDialog);
	
	/**
	 * Returns the size of the font that the user selected.  This method will not be called
	 * if the dialog was cancelled.
	 * 
	 * @param fontDialog
	 * @return the size of the selected font in points.
	 */
	public static final native int FontDialog_GetFontSize(int fontDialog);
	
	/**
	 * Returns the style of the font that the user selected.  This method will not be
	 * called if the user cancelled the dialog.
	 * 
	 * @param fontDialog
	 * @return a combination of the FONT_STYLE_* constants.
	 */
	public static final native int FontDialog_GetFontStyle(int fontDialog);
	
	/**
	 * Destory the font dialog.   
	 * 
	 * @param fontDialog
	 */
	public static final native void FontDialog_Dispose(int fontDialog);

	/**
	 * Save Image Data to File.  
	 * 
	 * This method should throw an ERROR_UNSUPPORTED_FORMAT exception if the format
	 * is not supported by the platform.
	 *
	 * @param handle image handle
	 * @param fileName name of file to save image to
	 * @param width width of the image, in pixels
	 * @param height height of the image, in pixels
	 * @param depth color depth of the image data, in number of bits per pixel. 
	 * 	One of 1, 2, 4, 8. It is acceptable for an implementation to create an
	 * 	image with a different depth if platform limitations do not allow the
	 * 	original color depth. The depth has to remain the same throughout the 
	 * 	life of the image.
	 * @param bytesPerLine length in bytes of a scan line. The number of bytes 
	 * 	per scan line may be greater than required for the actual number of 
	 * 	pixels. Excess bytes are unused.
	 * @param alpha the global alpha value to be used for every pixel. If this
	 *  value is set, the <code>alphaData</code> field is ignored. The default
	 *  value of -1 means 'no global alpha value'
	 * @param alphaData the alpha data of the image. Every pixel can have an
	 *  alpha blending value that varies from 0, meaning fully transparent, to
	 *  255 meaning fully opaque.  The number of bytes per scanline is 'width'.
	 * @param colors number of colors in colorTable being passed
	 * @param colorTable int array containing the color table values (RGB) for indexed images
	 * @param transparentPixel an index in the colorTable that represents
	 *  a fully transparent pixel. Ignored if the bit depth > 8 or a colorTable is
	 *  not provided (colorTable=NULL). The default value of -1 means
	 * 'no transparent Pixel'. If this value is supplied (not -1), then the value
	 *  must be 0 <= tansparentPixel < colors.
	 * @param imageData the pixel data. Each byte holds one or more pixels. An  
	 * 	8 bit per pixel image has one pixel per byte, a 4 bpp image has exactly 
	 * 	2 pixels per byte etc. The most significant bit of each byte corresponds
	 * 	to the leftmost pixel on a scanline. A scanline may have unused bits if 
	 * 	the color depth is less than 8 bpp.
	 * @param format the format that the image is to be saved to
	 * @uglGroup ImageSave
	 */
	public static final native void Image_Save(int handle, String fileName, int width, int height, int depth, int bytesPerLine, int alpha, byte[] alphaData, int colors, int[] colorTable, int transparentPixel, byte[] imageData, int format);	

	/**
	 * Save Image Data to as bytes.  
	 * 
	 * This method should throw an ERROR_UNSUPPORTED_FORMAT exception if the format
	 * is not supported by the platform.
	 *
	 * @param width width of the image, in pixels
	 * @param height height of the image, in pixels
	 * @param depth color depth of the image data, in number of bits per pixel. 
	 * 	One of 1, 2, 4, 8. It is acceptable for an implementation to create an
	 * 	image with a different depth if platform limitations do not allow the
	 * 	original color depth. The depth has to remain the same throughout the 
	 * 	life of the image.
	 * @param bytesPerLine length in bytes of a scan line. The number of bytes 
	 * 	per scan line may be greater than required for the actual number of 
	 * 	pixels. Excess bytes are unused.
	 * @param alpha the global alpha value to be used for every pixel. If this
	 *  value is set, the <code>alphaData</code> field is ignored. The default
	 *  value of -1 means 'no global alpha value'
	 * @param alphaData the alpha data of the image. Every pixel can have an
	 *  alpha blending value that varies from 0, meaning fully transparent, to
	 *  255 meaning fully opaque.  The number of bytes per scanline is 'width'.
	 * @param colors number of colors in colorTable being passed
	 * @param colorTable int array containing the color table values (RGB) for indexed images
	 * @param transparentPixel an index in the colorTable that represents
	 *  a fully transparent pixel. Ignored if the bit depth > 8 or a colorTable is
	 *  not provided (colorTable=NULL). The default value of -1 means
	 * 'no transparent Pixel'. If this value is supplied (not -1), then the value
	 *  must be 0 <= tansparentPixel < colors.
	 * @param imageData the pixel data. Each byte holds one or more pixels. An  
	 * 	8 bit per pixel image has one pixel per byte, a 4 bpp image has exactly 
	 * 	2 pixels per byte etc. The most significant bit of each byte corresponds
	 * 	to the leftmost pixel on a scanline. A scanline may have unused bits if 
	 * 	the color depth is less than 8 bpp.
	 * @param format the format that the image is to be saved to
	 * @uglGroup ImageSave
	 */
//	public static final native byte[] Image_SaveBytes(int width, int height, int depth, int bytesPerLine, int alpha, byte[] alphaData, int colors, int[] colorTable, int transparentPixel, byte[] imageData, int format);	
 
	/**
	* This method is a workaround for Windows problem.  It is not possible to create
	* a table that scrolls and does not have scroll bars, so on Windows Table widgets
	* will always be created with the H_SCROLL and V_SCROLL bits set.
	* 
	* @return true if scrollbars should always be included for Table widgets
	*/
	public static final native boolean Table_IncludeScrollbars();	
	
	/**
	 * Returns whether or not the item is checked.  This method only applies to
	 * check box table items.  
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @return true if the item is checked, false otherwise
	 */

	public static final native boolean TableItem_IsChecked(int tableHandle, int index);
	
	/**
	 * Returns whether or not the item is grayed.  This method only applies to
	 * check box table items.  The grayed state applies to the item's checkbox.
	 *
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @return true if the item is grayed, false otherwise
	 */
	public static final native boolean TableItem_IsGrayed(int tableHandle, int index);
	
	/**
	 * Valid styles include STYLE_LEFT_TO_RIGHT, STYLE_RIGHT_TO_LEFT, STYLE_BORDER,
	 * STYLE_V_SCROLL, STYLE_H_SCROLL, STYLE_SINGLE, STYLE_MULTI, STYLE_CHECK,
	 * STYLE_FULL_SELECTION, STYLE_HIDE_SELECTION, STYLE_VIRTUAL.
	 * 
	 * @param parentHandle 
	 * @param style
	 * @return handle handle to the Table widget
	 */ 
	public static final native int Table_New(int parentHandle, int style);
	
	/**
	 * Sets all the table items to the given selected state.
	 * 
	 * @param handle handle to the Table widget
	 * @param selected true to select all items, false to deselect all items
	 */
	public static final native void Table_SetAllSelected(int handle, boolean selected);

	/**
	 * Removes all the table items from the Table.
	 * 
	 * @param handle handle to the Table widget
	 */
	public static final native void Table_DeleteAllItems(int handle);

	/**
	 * Returns the width, in pixels, of the table grid lines.
	 * 
	 * @param handle handle to the Table widget
	 * @return int the grid line thickness in pixels
	 */
	public static final native int Table_GetGridLineWidth(int handle);

	/**
	 * Returns the height, in pixels, of the table header.
	 * 
	 * @param handle handle to the Table widget
	 * @return int the header height in pixels
	 */
	public static final native int Table_GetHeaderHeight(int handle);

	/**
	 * Returns whether or not the table header is visible.
	 * 
	 * @param handle handle to the Table widget
	 * @return boolean true if header is visible, false otherwise
	 */
	public static final native boolean Table_GetHeaderVisible(int handle);
	
	/**
	 * Returns the index of the table item at the specified point in the table 
	 * widget or -1 if no item exists at the given coordinates. The x and y 
	 * values are in the coordinate system of the receiver.
	 *
	 * @param handle handle to the Table widget
	 * @param x 
	 * @param y 
	 * @return the index of the TableItem at the given location
	 */
	public static final native int Table_GetItemAt(int handle, int x, int y);

	/**
	 * Returns the height, in pixels, of the table rows.
	 * 
	 * @param handle handle to the Table widget
	 * @return int the row height in pixels
	 */
	public static final native int Table_GetItemHeight(int handle);

	/**
	 * Returns whether or not the table grid lines are visible.
	 * 
	 * @param handle handle to the Table widget
	 * @return boolean true if grid is visible, false otherwise
	 */
	public static final native boolean Table_GetLinesVisible(int handle);

	/**
	 * Returns the indexes of the selected table items.
	 * 
	 * @param handle handle to the Table widget
	 * @return the indexes of the selected TableItems
	 */
	public static final native int[] Table_GetSelectionIndices(int handle);

	/**
	 * Returns the index of the TableItem which is currently at 
	 * the top of the receiver visually.
	 * 
	 * @param handle handle to the Table widget
	 * @return int zero-based index of top TableItem
	 */
	public static final native int Table_GetTopItemIndex(int handle);

	/**
	 * Sets whether or not the column headers for the Table are visible.
	 * 
	 * @param handle handle to the Table widget
	 * @param show true to show the headers, false otherwise
	 */
	public static final native void Table_SetColumnHeadersVisible(int handle, boolean show);

	/**
	 * Sets the number of items contained in the receiver.
	 *
	 * @param handle handle to the Table widget
	 * @param count the number of items
	 */
	public static final native void Table_SetItemCount(int handle, int count);

	/**
	 * Sets the focus item for the Table to the given index.  
	 *
	 * @param handle handle to the Table widget
	 * @param index zero-based index of the TableItem that should have focus
	 */
	public static final native void Table_SetFocusIndex(int handle, int index);

	/**
	 * Sets whether or not the grid lines for the table are visible.
	 * 
	 * @param handle handle to the Table widget
	 * @param show true to show the lines, false otherwise
	 */
	public static final native void Table_SetLinesVisible(int handle, boolean show);

	/**
	 * Sets the item which is currently at the top of the receiver.
	 * 
	 * @param handle handle to the Table widget
	 * @param index index of the TableItem to position at the top of the Table
	 */
	public static final native void Table_SetTopItemIndex(int handle, int index);

	/**
	 * Ensure that the TableColumn at the given index is visible within the Table widget.
	 * 
	 * @param handle handle to the Table widget
	 * @param index index of the TableColumn
	 */
	public static final native void Table_ShowColumnIndex(int handle, int index);

	/**
	 * Ensure that the item at the given index is visible within the Table widget.
	 * 
	 * @param handle handle to the Table widget
	 * @param index index of the TableItem to show
	 */
	public static final native void Table_ShowItemIndex(int handle, int index);
	
	public static final native int Table_GetFocusIndex(int handle);

	/**
	 * Create a new TableColumn at the given index.  Indices are zero-based.
	 * 
	 * @param tableHandle handle to the Table widget
	 * @param colIndex zero-based index
	 * @param style
	 * @return handle to the TableColumn widget
	 */ 
	public static final native int TableColumn_New(int tableHandle, int colIndex, int style);

	/**
	 * Set the table column to its preferred size.
	 * 
	 * @param tableHandle handle to the Table widget
	 * @return handle to the TableColumn widget
	 */ 
	public static final native void TableColumn_Pack(int handle);

	/**
	 * Remove the TableColumn from the Table.
	 * 
	 * @param handle to the TableColumn widget that should be removed
	 */ 
	public static final native void TableColumn_Delete(int handle);

	/**
	 * Gets the width, in pixels, of the TableColumn at the given index.
	 * 
	 * @param handle handle to the TableColumn
	 * @return width width of the TableColumn in pixels
	 */
	public static final native int TableColumn_GetWidth(int handle);

	/**
	 * Returns the number of pixels that is necessary to display the image and text
	 * that appears in the TableColumn at the given rowIndex.
	 * 
	 * @param handle handle to the TableColumn
	 * @param rowIndex zero-based index of the TableItem, a value of -1 will indicate that all
	 * 		TableItems should be measured, otherwise only the TableItem at the given index will
	 * 		be measured
	 * @return int the number of pixels needed to display the TableColumn data
	 */
	public static final native int TableColumn_GetMinimumWidth(int handle, int rowIndex);
	
	/**
	 * Sets the alignment of the TableColumn.
	 * 
	 * @param handle handle to the TableColumn
	 * @param alignment STYLE_LEAD, STYLE_CENTER, STYLE_TRAIL
	 */
	public static final native void TableColumn_SetAlignment(int handle, int alignment);

	/**
	 * Sets the image of the TableColumn.
	 * 
	 * @param handle handle to the TableColumn
	 * @param imageHandle handle to the image, a value of zero will remove the TableColumn
	 * 			image
	 */
	public static final native void TableColumn_SetImage(int handle, int imageHandle);

	/**
	 * Sets whether or not the TableColumn can be resized by the user.
	 * 
	 * @param handle handle to the TableColumn
	 * @param resizable true if the TableColumn can be resized, false otherwise
	 */
	public static final native void TableColumn_SetResizable(int handle, boolean resizable);

	/**
	 * Sets the text of the header for the given TableColumn.
	 * 
	 * @param handle handle to the TableColumn
	 * @param text the TableColumn heading text
	 */
	public static final native void TableColumn_SetText(int handle, String text);

	/**
	 * Sets the width of the given column.
	 * 
	 * @param handle handle to the TableColumn
	 * @param width width of TableColumn in pixels
	 */
	public static final native void TableColumn_SetWidth(int handle, int width);

	/**
	 * Create a new table row at the given index.  Indices are zero-based.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param rowIndex the index at which to create the TableItem
	 * @return handle to the TableItem
	 */ 
	public static final native int TableItem_New(int tableHandle, int rowIndex);
	
	/**
	 * Remove the table row at the given index.  Indices are zero-based.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param tableItemHandle the handle to the TableItem widget
	 * @param index index of the TableItem that should be deleted
	 */ 
	public static final native void TableItem_Delete(int tableHandle, int tableItemHandle, int index);

	/**
	 * Sets the item to the given selected state.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param selected true if item should be selected, false otherwise
	 */
	public static final native void TableItem_SetSelected(int tableHandle, int index, boolean selected);

	/**
	 * Set the text for the given TableItem at the given TableColumn.  Indices are zero-based.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param tableItemHandle the handle to the TableItem widget
	 * @param index index of the TableItem
	 * @param colIndex index of the TableColumn
	 * @param text
	 */ 
	public static final native void TableItem_SetCellText(int tableHandle, int tableItemHandle, int index, int colIndex, String text);

	/**
	 * Returns a rectangle for the given TableItem at the given TableColumn describing the 
	 * TableItem's size and location relative to its parent.
	 *
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param colIndex index of the TableColumn
	 * @return (rect) the item's bounding rectangle for the given column 
	 */	
	public static final native int[] TableItem_GetBounds(int tableHandle, int index, int colIndex);

	/**
	 * Returns a rectangle for the given TableItem at the given TableColumn describing the 
	 * TableItem's image size and location relative to its parent.
	 *
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param colIndex index of the TableColumn
	 * @return (rect) the item's bounding image rectangle for the given column 
	 */	
	public static final native int[] TableItem_GetImageBounds(int tableHandle, int index, int colIndex);
	
	/**
	 * Returns whether or not the TableItems is selected.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @return true if the item is selected, false otherwise
	 */
	public static final native boolean TableItem_IsSelected(int tableHandle, int index);

	/**
	 * Sets the background color for the given TableItem.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param colorHandle handle to the Color, a value of zero will clear the 
	 * 			background color for the item
	 */
	public static final native void TableItem_SetBackground(int tableHandle, int index, int colorHandle);	

	/**
	 * Sets the background color for the given cell.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param colIndex index of TableColumn
	 * @param colorHandle handle to the Color, a value of zero will clear the 
	 * 			background color for the cell
	 */
	public static final native void TableItem_SetCellBackground(int tableHandle, int index, int colIndex, int colorHandle);	

	/**
	 * Sets the foreground color for the given TableItem.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param colorHandle handle to the Color, a value of zero will clear the 
	 * 			foreground color for the item
	 */
	public static final native void TableItem_SetForeground(int tableHandle, int index, int colorHandle);	

	/**
	 * Sets the TableItem to the given grayed state.  This method only applies to
	 * check box table items.  The grayed state applies to the TableItem's checkbox.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param grayed true if item should be grayed, false otherwise
	 */
	public static final native void TableItem_SetGrayed(int tableHandle, int index, boolean grayed);

	/**
	 * Sets the TableItem to the given checked state.  This method only applies to
	 * check box table items. 
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param checked true if item should be checked, false otherwise
	 */
	public static final native void TableItem_SetChecked(int tableHandle, int index, boolean checked);

	/**
	 * Sets the font for the given TableItem.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param fontHandle handle to the Font, a value of zero will clear the 
	 * 			font for the TableItem
	 */
	public static final native void TableItem_SetFont(int tableHandle, int index, int fontHandle);	

	/**
	 * Sets the font for the given cell.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param colIndex index of TableColumn
	 * @param fontHandle handle to the Font, a value of zero will clear the 
	 * 			font setting for the cell
	 */
	public static final native void TableItem_SetCellFont(int tableHandle, int index, int colIndex, int fontHandle);	

	/**
	 * Sets the foreground color for the given cell.
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param index index of the TableItem
	 * @param colIndex index of TableColumn
	 * @param colorHandle handle to the Color, a value of zero will clear the 
	 * 			background color for the cell
	 */
	public static final native void TableItem_SetCellForeground(int tableHandle, int index, int colIndex, int colorHandle);	

	/**
	 * Set the image for the given cell.  
	 * 
	 * @param tableHandle the handle to the Table widget
	 * @param tableItemHandle the handle to the TableItem widget
	 * @param index index of the TableItem
	 * @param colIndex index of TableColumn
	 * @param imageHandle handle to the Image, a value of zero will clear the 
	 * 			image for the item
	 */ 
	public static final native void TableItem_SetImage(int tableHandle, int tableItemHandle, int index, int colIndex, int imageHandle);
	
	/**
	 * Valid styles include STYLE_LEFT_TO_RIGHT, STYLE_RIGHT_TO_LEFT, STYLE_BORDER,
	 * STYLE_V_SCROLL, STYLE_H_SCROLL, STYLE_SINGLE, STYLE_MULTI, STYLE_CHECK.
	 * 
	 * @param parentHandle
	 * @param style
	 * @return handle to the Tree widget
	 */ 
	public static final native int Tree_New(int parentHandle, int style);
	
	/**
	 * Returns the height of a tree item.  All items must have the same height.
	 * 
	 * @param treeHandle
	 * @return height of the tree items in pixels
	 */
	public static final native int Tree_GetItemHeight(int treeHandle);
	
	/**
	 * Returns the id of the tree item at the specified point in the tree widget
	 * or -1 if no item exists at the given coordinates. The x and y 
	 * values are in the coordinate system of the receiver.
	 *
	 * @param treeHandle
	 * @param x 
	 * @param y 
	 * @return the item id of the TreeItem at the given location, -1 indicates
	 * no item exists at the given location
	 */
	public static final native int Tree_GetItemAt(int treeHandle, int x, int y);

	/**
	 * Returns the id of the tree item that has focus.  In single select mode,
	 * the selected item is always the focus item.
	 * 
	 * @param treeHandle
	 * @return the item id of the TreeItem that has focus, -1 indicates no item
	 * has focus
	 */
	public static final native int Tree_GetFocusItem(int treeHandle);

	/**
	 * Returns the id of the TreeItem that is currently selected.
	 * This API should only be used when in single select mode.
	 * 
	 * @param treeHandle
	 * @return the item id of the TreeItem that has focus, -1 indicates no item
	 * is selected
	 */
	public static final native int Tree_GetSelectedItem(int treeHandle);
	
	/**
	 * Returns the id of the tree item which is currently at the top of the receiver.
	 * This item can change when items are expanded, collapsed, scrolled
	 * or new items are added or removed.
	 *
	 * @param treeHandle
	 * @return the item id of the TreeItem at the top of the tree widget, -1 
	 * indicates there is no top item 
	 */
	public static final native int Tree_GetTopItem(int treeHandle);

	/**
	 * Removes all items from the tree.
	 * 
	 * @param treeHandle
	 */
	public static final native void Tree_RemoveAll(int treeHandle);

	/**
	 * Sets the font for the given item.
	 * 
	 * @param itemHandle
	 * @param fontHandle
	 * @param fontHandle handle to the font, a value of zero will clear the 
	 * 			font for the item
	 */
	public static final native void TreeItem_SetFont(int itemHandle, int fontHandle);	
	
	/**
	 * Sets all the tree items to the given selected state.
	 * 
	 * @param handle
	 * @param selected true to select all items, false to deselect all items
	 */
	public static final native void Tree_SetAllSelected(int handle, boolean selected);

	/**
	 * Sets the focus item for the tree to the given item.  
	 *
	 * @param treeHandle
	 * @param itemHandle
	 */
	public static final native void Tree_SetFocusItem(int treeHandle, int itemHandle);

	/**
	 * Sets the item which is currently at the top of the receiver.
	 * This item can change when items are expanded, collapsed, scrolled
	 * or new items are added or removed.
	 *
	 * @param treeHandle
	 * @param itemHandle
	 */
	public static final native void Tree_SetTopItem(int treeHandle, int itemHandle);
	
	/**
	 * Scrolls the given item into view within the tree widget.
	 *
	 * @param treeHandle
	 * @param itemHandle
	 */
	public static final native void Tree_ShowItem(int treeHandle, int itemHandle);

	/**
	* This method is a workaround for Windows problem.  It is not possible to create
	* a tree that scrolls and does not have scroll bars, so on Windows Tree widgets
	* will always be created with the H_SCROLL and V_SCROLL bits set.
	* 
	* @return true if scrollbars should always be included for Tree widgets
	*/
	public static final native boolean Tree_IncludeScrollbars();

	/**
	 * Sets the background color for the given item.
	 * 
	 * @param itemHandle
	 * @param colorHandle handle to the Color, a value of zero will clear the 
	 * 			background color for the item
	 */
	public static final native void TreeItem_SetBackground(int itemHandle, int colorHandle);	

	/**
	 * Sets the foreground color for the given item.
	 * 
	 * @param itemHandle
	 * @param colorHandle handle to the Color, a value of zero will clear the 
	 * 			foreground color for the item
	 */
	public static final native void TreeItem_SetForeground(int itemHandle, int colorHandle);	

	/**
	 */	
	public static final native void TreeItem_Delete(int itemHandle);
	
	/**
	 * Returns a rectangle describing the receiver's size and location
	 * relative to its parent.
	 *
	 * @param itemHandle
	 * @return (rect) the item's bounding rectangle which includes only 
	 * 		the text of the item
	 */	
	public static final native int[] TreeItem_GetTextBounds(int itemHandle);
	
	/**
	 * Returns whether or not the item is checked.  This method only applies to
	 * check box tree items.  
	 * 
	 * @return true if the item is checked, false otherwise
	 */

	public static final native boolean TreeItem_IsChecked(int itemHandle);
	/**
	 * Returns whether or not the item is expanded.
	 *
	 * @param itemHandle
	 * @return true if the item is expanded, false otherwise
	 */
	public static final native boolean TreeItem_IsExpanded(int itemHandle);
	
	/**
	 * Returns whether or not the item is grayed.  This method only applies to
	 * check box tree items.  The grayed state applies to the item's checkbox.
	 *
	 * @param itemHandle
	 * @return true if the item is grayed, false otherwise
	 */
	public static final native boolean TreeItem_IsGrayed(int itemHandle);
		
	/**
	 * Returns whether or not the item is selected.
	 * 
	 * @param itemHandle
	 * @return true if the item is selected, false otherwise
	 */
	public static final native boolean TreeItem_IsSelected(int itemHandle);

	/**
	 * Sets the item to the given grayed state.  This method only applies to
	 * check box tree items.  The grayed state applies to the item's checkbox.
	 * 
	 * @param itemHandle
	 * @param grayed true if item should be grayed, false otherwise
	 */
	public static final native void TreeItem_SetGrayed(int itemHandle, boolean grayed);
		
	/**
	 * Sets the item to the given selected state.
	 * 
	 * @param itemHandle
	 * @param selected true if item should be selected, false otherwise
	 */
	public static final native void TreeItem_SetSelected(int itemHandle, boolean selected);
	
	/**
	 * Sets the item to the given checked state.  This method only applies to
	 * check box tree items. 
	 * 
	 * @param itemHandle
	 * @param checked true if item should be checked, false otherwise
	 */
	public static final native void TreeItem_SetChecked(int itemHandle, boolean checked);
	
	/**
	 * Sets the expanded state of the given item. 
	 * 
	 * @param itemHandle
	 * @param expanded true if item should be expanded, false to collapse the item
	 */
	public static final native void TreeItem_SetExpanded(int itemHandle, boolean expanded);
	
	/**
	 * Constructs a new TreeItem.
	 *
	 * @param treeHandle
	 * @param parentHandle
	 * @param id - a unique id to assign to the TreeItem, this id will be used when looking for
	 * 		TreeItems
	 * @param index - the index at which to insert the new treeItem, the index is relative to the
	 * 		parent's children, a value of -1 will add the item as the last child in the parent
	 *
	 */
	public static final native int TreeItem_New(int treeHandle, int parentHandle, int id, int index);

	/**
	 * Sets the item's text.
	 *
	 * @param itemHandle
	 * @param text the new text
	 */
	public static final native void TreeItem_SetText(int itemHandle, String text);
		
	/**
	 * Sets the item's image.
	 *
	 * @param itemHandle
	 * @param imageHandle handle to the Image, a value of zero will clear the 
	 * 			image for the item
	 */
	public static final native void TreeItem_SetImage(int itemHandle, int imageHandle);
	
	/**
	 * Sets the number of items contained in the receiver.
	 *
	 * @param handle handle to the Tree widget
	 * @param count the number of child items
	 */
	public static final native void TreeItem_SetItemCount(int itemHandle, int itemCount);
	
}
