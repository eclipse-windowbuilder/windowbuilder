/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *     Radoslav Gerganov <r.gerganov@prosyst.bg> - bug 213627
 *******************************************************************************/
package com.ibm.ugl.p3ml;


import com.ibm.ugl.UGLCompatibility;
import com.ibm.ugl.UGLErrorHandler;

/**
 * The UGL API hierarchy as it applies to P3ML is as follows.
 * The API hierarchy can be thought of as a class hierarchy in  
 * OO terms. E.g., the Widget, Control and Scrollable API can   
 * be called with a Shell handle, in addition to the Shell API.
 * <p>
 * <table border=0>
 * <tr><td colspan=4>Color</td></tr>
 * <tr><td colspan=4>Device</td></tr>
 * <tr><td width=25>&nbsp;</td><td colspan=3>Display</td></tr>
 * <tr><td colspan=4>Font</td></tr>
 * <tr><td colspan=4>Graphics</td></tr>
 * <tr><td colspan=4>Image</td></tr>
 * <tr><td colspan=4>Widget</td></tr>
 * <tr><td>&nbsp;</td><td colspan=3>Control</td></tr>
 * <tr><td>&nbsp;</td><td width=25>&nbsp;</td><td colspan=2>Scrollable</td></tr>
 * <tr><td>&nbsp;</td><td>&nbsp;</td><td width=25>&nbsp;</td><td>Shell</td></tr>
 * </table>
 * </p>
 */
public class OS {
	
	static {
		UGLCompatibility.loadLibrary("eswt-core");
	}	

	/**
	 * This field must be set by the toolkit
	 * to handle native errors that could occur.
	 * The toolkit may choose to have the handler
	 * be a no-op, but a handler must be set 
	 * regardless.
	 * @ignore don't generate anything for this field natively.
	 */
	public static UGLErrorHandler uglErrorHandler;
	
	/**
	 * No error has occurred.
	 */
	public static final int ERROR_NONE = 0;
	
	/**
	 * API/function is unimplemented
	 */
	public static final int ERROR_NOT_IMPLEMENTED = -1;

	/**
	 * An unrecoverable error occurred. The error is not specified further.
	 * Any API may throw this error.
	 */
	public static final int ERROR_OTHER = -3;
	
	/**
	 * Out of memory/handles. Any API may throw this error.
	 */
	public static final int ERROR_OUT_OF_MEMORY = -4;

	/**
	 * Attempt to load/create an image with unsupported color depth.
	 */
	public static final int ERROR_UNSUPPORTED_DEPTH = -5;

	/**
	 * Attempt to load/save an image of an unsupported format.
	 */
	public static final int ERROR_UNSUPPORTED_FORMAT = -6;	
	
	/**
	 * I/O error
	 */
	public static final int ERROR_IO = -7;

	/**
	 * Invalid image error
	 */
	public static final int ERROR_INVALID_IMAGE = -8;
	
	/**
	 * The x index into an array returning a rectangle  
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int INDEX_X 		= 0;
	
	/**
	 * The y index into an array returning a rectangle  
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int INDEX_Y 		= 1;
	
	/**
	 * The width index into an array returning a rectangle  
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int INDEX_WIDTH 	= 2;
	
	/**
	 * The height index into an array returning a rectangle  
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int INDEX_HEIGHT	= 3;
	
	/*
	 * Constants for indexing a four element insets array.
	 */
	/** @internal this should only be used by toolkit implementors */
	public static final int INDEX_LEFT 		= 0;
	/** @internal this should only be used by toolkit implementors */
	public static final int INDEX_TOP 		= 1;
	/** @internal this should only be used by toolkit implementors */
	public static final int INDEX_RIGHT 	= 2;
	/** @internal this should only be used by toolkit implementors */
	public static final int INDEX_BOTTOM	= 3;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_BUTTON = 0;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_CHOICE = 4;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_CONTROL_KEY = 5;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_CONTROL_POINTER = 7;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_FOCUS = 9;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_LIST = 1;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_MENU_SELECTION = 8;
	
	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_PAINT = 10;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_SCROLLBAR = 3;
	
	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_SHELL = 2;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_SHELL_RESIZE = 11;
	
	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_SHELL_MOVE = 12; 

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_TEXT_MODIFY = 6;
	
	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_CONTROL_WHEEL = 17;

	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_DISPLAY_TIMER = 13;  
	
	/** @internal this should only be used by toolkit implementors */
	public static final int CALLBACK_TRAYITEM = 50;

	/** Active caption background color id */
	public static final int COLOR_ACTIVE_CAPTION_BACKGROUND		= 1;

	/** Active caption border color id */
	public static final int COLOR_ACTIVE_CAPTION_BORDER 		= 3;

	/** Active caption foreground color id */
	public static final int COLOR_ACTIVE_CAPTION_FOREGROUND		= 2;

	/** Control background color id */
	public static final int COLOR_CONTROL_BACKGROUND			= 17;

	/** Control foreground color id */
	public static final int COLOR_CONTROL_FOREGROUND			= 18;

	/** Control light highlight color id */
	public static final int COLOR_CONTROL_HIGHLIGHT_LIGHT 		= 20;
	
	/** Control normal highlight color id */
	public static final int COLOR_CONTROL_HIGHLIGHT_NORMAL		= 19;

	/** Control dark shadow color id */
	public static final int COLOR_CONTROL_SHADOW_DARK 			= 22;

	/** Control normal shadow color id */
	public static final int COLOR_CONTROL_SHADOW_NORMAL			= 21;

	/** Desktop background color id */
	public static final int COLOR_DESKTOP_BACKGROUND			= 0;
	
	/** Inactive caption background color id */
	public static final int COLOR_INACTIVE_CAPTION_BACKGROUND	= 4;

	/** Inactive caption foreground color id */
	public static final int COLOR_INACTIVE_CAPTION_FOREGROUND	= 5;

	/** Inactive caption border color id */
	public static final int COLOR_INACTIVE_CAPTION_BORDER		= 6;
	
	/** Window background color id */
	public static final int COLOR_WINDOW_BACKGROUND 			= 7;

	/** Window border color id */
	public static final int COLOR_WINDOW_BORDER 				= 8;

	/** Window foreground color id */
	public static final int COLOR_WINDOW_FOREGROUND				= 9;
	
	/** Menu background color id */
	public static final int COLOR_MENU_BACKGROUND				= 10;

	/** Menu foreground color id */
	public static final int COLOR_MENU_FOREGROUND				= 11;
	
	/** Text widget background color id */
	public static final int COLOR_TEXT_BACKGROUND				= 12;

	/** Text widget foreground color id */
	public static final int COLOR_TEXT_FOREGROUND				= 13;
	
	/** Text widget inactive foreground color id */
	public static final int COLOR_TEXT_INACTIVE_FOREGROUND		= 16;	

	/** Scrollbar background color id */
	public static final int COLOR_SCROLLBAR_BACKGROUND			= 23;	

	/** Tool tip background color id */
	public static final int COLOR_INFO_BACKGROUND				= 24;

	/** Tool tip foreground color id */
	public static final int COLOR_INFO_FOREGROUND				= 25;

	/** Text widget highlight background color id */
	public static final int COLOR_TEXT_HIGHLIGHT_BACKGROUND		= 14;

	/** Text widget highlight foreground color id */
	public static final int COLOR_TEXT_HIGHLIGHT_FOREGROUND		= 15;

	/** Title bar background color id */
	public static final int COLOR_TITLE_BACKGROUND				= 26;

	/** Title bar foreground color id */
	public static final int COLOR_TITLE_FOREGROUND				= 27;

	/** Arrow cursor style */
	public static final int CURSOR_ARROW		= 1;

	/** Crosshair cursor style */
	public static final int CURSOR_CROSSHAIR	= 2;

	/** Hand cursor style */
	public static final int CURSOR_HAND			= 13;

	/** Move cursor style */
	public static final int CURSOR_MOVE			= 14;

	/** East resize cursor style */
	public static final int CURSOR_RESIZE_E		= 6;

	/** North resize cursor style */
	public static final int CURSOR_RESIZE_N		= 5;

	/** Northeast resize cursor style */
	public static final int CURSOR_RESIZE_NE	= 9;

	/** Northwest resize cursor style */
	public static final int CURSOR_RESIZE_NW	= 12;

	/** South resize cursor style */
	public static final int CURSOR_RESIZE_S		= 7;

	/** Southeast resize cursor style */
	public static final int CURSOR_RESIZE_SE	= 10;

	/** Southwest resize cursor style */
	public static final int CURSOR_RESIZE_SW	= 11;

	/** West resize cursor style */
	public static final int CURSOR_RESIZE_W		= 8;

	/** Text cursor style */
	public static final int CURSOR_TEXT			= 3;

	/** Wait cursor style */
	public static final int CURSOR_WAIT			= 4;

	/** Focus event triggered when a Control has gained focus. */
	public static final int EVENT_FOCUS_IN = 1;

	/** Focus event triggered when a Control has lost focus. */
	public static final int EVENT_FOCUS_OUT = 2;

	/** Focus event flag which indicates that the focus change was temporary. */
	public static final int EVENT_FOCUS_TEMPORARY_FLAG = 1 << 16;

	/** Key down event. */
	public static final int EVENT_KEY_DOWN = 1;

	/** Key up event. */
	public static final int EVENT_KEY_UP = 2;

	/** 
	 * List event which indicates that the currently selected item has
	 * been actioned.
	 */
	public static final int EVENT_LIST_ACTION = 2;

	/** List event which indicates that a new item has been selected. */
	public static final int EVENT_LIST_SELECTION = 1;

	/** The pointer has been double clicked. */
	public static final int EVENT_POINTER_DOUBLECLICK = 7;

	/** The pointer has been pressed. */
	public static final int EVENT_POINTER_DOWN = 1;

	/** The pointer has been released. */
	public static final int EVENT_POINTER_DRAG = 6;

	/** The pointer has entered a control's bounds. */
	public static final int EVENT_POINTER_ENTER = 4;

	/** The pointer has left a control's bounds. */
	public static final int EVENT_POINTER_EXIT = 5;

	/** The pointer has moved. */
	public static final int EVENT_POINTER_MOVE = 3;

	/** The pointer has been released. */
	public static final int EVENT_POINTER_UP = 2;

	/** The mouse wheel has been moved with a block scroll. */
	public static final int EVENT_WHEEL_BLOCK = 8;

	/** The mouse wheel has been moved with a unit scroll. */
	public static final int EVENT_WHEEL_UNIT = 9;

	/**
	 * Event code that will be passed into the shell callback method
	 * when the shell is activated.
	 */
	public static final int EVENT_SHELL_ACTIVATED = 205;

	/**
	 * Event code that will be passed into the shell callback method
	 * when the user clicks on the close button.
	 */
	public static final int EVENT_SHELL_CLOSING = 201;

	/**
	 * Event code that will be passed into the shell callback method
	 * when the shell is deactivated.
	 */
	public static final int EVENT_SHELL_DEACTIVATED = 206;

	/**
	 * Event code that will be passed into the shell callback method
	 * when the shell is deiconified.
	 */
	public static final int EVENT_SHELL_DEICONIFIED = 204;

	/**
	 * Event code that will be passed into the shell callback method
	 * when the shell is iconified.
	 */
	public static final int EVENT_SHELL_ICONIFIED = 203;

	/** Font style flag bold */
	public static final int FONT_STYLE_BOLD = 1 << 1;

	/** Font style flag italic */
	public static final int FONT_STYLE_ITALIC = 1 << 2;

	/** Font style flag underlined */
	public static final int FONT_STYLE_UNDERLINED = 1 << 3;

	/** Font style flag strikethrough (Personal Profile 1.1 only) */
	public static final int FONT_STYLE_STRIKETHROUGH = 1 << 4;
	
	public static final int KEYCODE_ALT = 1018;

	public static final int KEYCODE_ARROW_DOWN = 1016;

	public static final int KEYCODE_ARROW_LEFT = 1013;

	public static final int KEYCODE_ARROW_RIGHT = 1014;

	public static final int KEYCODE_ARROW_UP = 1015;

	public static final int KEYCODE_BACKSPACE = 1000;

	public static final int KEYCODE_CONTROL = 1019;

	public static final int KEYCODE_DELETE = 1012;

	public static final int KEYCODE_DEVICE0 = 1063;

	public static final int KEYCODE_DEVICE1 = 1064;

	public static final int KEYCODE_DEVICE2 = 1065;

	public static final int KEYCODE_DEVICE3 = 1066;

	public static final int KEYCODE_END = 1008;

	public static final int KEYCODE_ENTER = 1002;

	public static final int KEYCODE_ESCAPE = 1003;

	public static final int KEYCODE_F1 = 1023;

	public static final int KEYCODE_F10 = 1032;

	public static final int KEYCODE_F11 = 1033;

	public static final int KEYCODE_F12 = 1034;

	public static final int KEYCODE_F13 = 1035;

	public static final int KEYCODE_F14 = 1036;

	public static final int KEYCODE_F15 = 1037;

	public static final int KEYCODE_F16 = 1038;

	public static final int KEYCODE_F17 = 1039;

	public static final int KEYCODE_F18 = 1040;

	public static final int KEYCODE_F19 = 1041;

	public static final int KEYCODE_F2 = 1024;

	public static final int KEYCODE_F20 = 1042;

	public static final int KEYCODE_F21 = 1043;

	public static final int KEYCODE_F22 = 1044;

	public static final int KEYCODE_F23 = 1045;

	public static final int KEYCODE_F24 = 1046;

	public static final int KEYCODE_F3 = 1025;

	public static final int KEYCODE_F4 = 1026;

	public static final int KEYCODE_F5 = 1027;

	public static final int KEYCODE_F6 = 1028;

	public static final int KEYCODE_F7 = 1029;

	public static final int KEYCODE_F8 = 1030;

	public static final int KEYCODE_F9 = 1031;

	public static final int KEYCODE_HELP = 1062;

	public static final int KEYCODE_HOME = 1007;

	public static final int KEYCODE_INSERT = 1011;

	public static final int KEYCODE_LOCK_CAPS = 1020;

	public static final int KEYCODE_LOCK_NUM = 1021;

	public static final int KEYCODE_LOCK_SCROLL = 1022;

	public static final int KEYCODE_PAGE_DOWN = 1010;

	public static final int KEYCODE_PAGE_UP = 1009;

	public static final int KEYCODE_PAUSE = 1006;

	public static final int KEYCODE_PRINTSCREEN = 1005;

	public static final int KEYCODE_SHIFT = 1017;

	public static final int KEYCODE_TAB = 1001;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad multiply key.
	 */
	public static final int KEYCODE_KEYPAD_MULTIPLY = 1067;
	
	/**
	 * Keyboard event constant representing the numeric key
	 * pad add key.
	 */
	public static final int KEYCODE_KEYPAD_ADD = 1068;
	
	/**
	 * Keyboard event constant representing the numeric key
	 * pad subtract key.
	 */
	public static final int KEYCODE_KEYPAD_SUBTRACT = 1069;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad decimal key.
	 */
	public static final int KEYCODE_KEYPAD_DECIMAL = 1070;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad divide key.
	 */
	public static final int KEYCODE_KEYPAD_DIVIDE = 1071;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad zero key.
	 */
	public static final int KEYCODE_KEYPAD_0 = 1072;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad one key.
	 */
	public static final int KEYCODE_KEYPAD_1 = 1073;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad two key.
	 */
	public static final int KEYCODE_KEYPAD_2 = 1074;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad three key.
	 */
	public static final int KEYCODE_KEYPAD_3 = 1075;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad four key.
	 */
	public static final int KEYCODE_KEYPAD_4 = 1076;
	
	/**
	 * Keyboard event constant representing the numeric key
	 * pad five key.
	 */
	public static final int KEYCODE_KEYPAD_5 = 1077;
	
	/**
	 * Keyboard event constant representing the numeric key
	 * pad six key.
	 */
	public static final int KEYCODE_KEYPAD_6 = 1078;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad seven key.
	 */
	public static final int KEYCODE_KEYPAD_7 = 1079;

	/**
	 * Keyboard event constant representing the numeric key
	 * pad eight key.
	 */
	public static final int KEYCODE_KEYPAD_8 = 1080;
	
	/**
	 * Keyboard event constant representing the numeric key
	 * pad nine key.
	 */
	public static final int KEYCODE_KEYPAD_9 = 1081;
	
	/**
	 * Keyboard event constant representing the numeric key
	 * pad enter key.
	 */
	public static final int KEYCODE_KEYPAD_ENTER = 1082;
	
	public static final int LINE_DASH = 1 << 1;

	public static final int LINE_DASHDOT = 1 << 3;

	public static final int LINE_DASHDOTDOT = 1 << 4;

	public static final int LINE_DOT = 1 << 2;

	public static final int LINE_SOLID = 1;

	public static final int MODIFIER_MASK_ALT = 1;

	public static final int MODIFIER_MASK_CONTROL = 4;

	public static final int MODIFIER_MASK_SHIFT = 2;

	/**
	 * Index into palette mask array for alpha mask. 
	 * Palette mask array is returned by <code>Image_GetDirectPaletteMasks()</code>
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int PALETTE_MASK_ALPHA	= 3;

	/**
	 * Index into palette mask array for blue mask. 
	 * Palette mask array is returned by <code>Image_GetDirectPaletteMasks()</code>
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int PALETTE_MASK_BLUE	= 2;

	/**
	 * Index into palette mask array for green mask. 
	 * Palette mask array is returned by <code>Image_GetDirectPaletteMasks()</code>
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int PALETTE_MASK_GREEN	= 1;

	/**
	 * Index into palette mask array for red mask. 
	 * Palette mask array is returned by <code>Image_GetDirectPaletteMasks()</code>
	 * @internal this should only be used by toolkit implementors
	 */
	public static final int PALETTE_MASK_RED	= 0;

	/**
	 * Pointer button masks must not conflict with the alt, control, 
	 * and shift modifiers
	 */
	public static final int POINTER_MASK_NOBUTTON = 0;

	public static final int POINTER_MASK_BUTTON1 = 8;

	public static final int POINTER_MASK_BUTTON2 = 16;

	public static final int POINTER_MASK_BUTTON3 = 32;
	
	public static final int POINTER_POPUP_TRIGGER = 1 << 6;

	public static final int SCROLLBAR_ACTION_BLOCK_DECREMENT = 2;

	public static final int SCROLLBAR_ACTION_BLOCK_INCREMENT = 3;

	public static final int SCROLLBAR_ACTION_END = 6;

	public static final int SCROLLBAR_ACTION_HOME = 5;

	public static final int SCROLLBAR_ACTION_TRACK = 4;

	public static final int SCROLLBAR_ACTION_UNIT_DECREMENT	= 0;

	public static final int SCROLLBAR_ACTION_UNIT_INCREMENT	= 1;

	public static final int SCROLLBAR_ACTION_NONE = 7;

	/**
	 * Interpret tab characters (<code>"\t"</code>) as tab stops.
	 * @see #Graphics_DrawString
	 * @see #Font_StringExtent
	 */
	public static final int STRING_EXPAND_TAB = 1 << 1;

	/**
	 * Interpret a mnemonic character (<code>&amp;</code>) to 
	 * underline the next character	instead of rendering the 
	 * ampersand.
	 * @see #Graphics_DrawString
	 * @see #Font_StringExtent
	 */
	public static final int STRING_MNEMONIC = 1 << 2;

	/**
	 * Render text transparently on the background. 
	 * @see #Graphics_DrawString
	 */
	public static final int STRING_TRANSPARENT = 1 << 3;

	/**
	 * Wrap text at the line delimiters. Valid line delimiters are
	 * <code>"\r"</code>, <code>"\n"</code> and <code>"\r\n"</code>
	 * @see #Graphics_DrawString()
	 * @see #Font_StringExtent()
	 */
	public static final int STRING_WRAP = 1;

	/**
	 * Shell style indicating that while the Shell is open it will
	 * block input to every other Shell in the application.  Modality 
	 * styles are treated as hints since typically all types of modality 
	 * are not supported on every platform.  
	 */
	public static final int STYLE_APPLICATION_MODAL = 1 << 6;

	/** Border */
	public static final int STYLE_BORDER = 1 << 11;

	/** Center alignment */
	public static final int STYLE_CENTER = 1 << 1;

	/** The MenuItem style for a checkbox item */
	public static final int STYLE_CHECK = 1 << 5;

	/** Close trim */
	public static final int STYLE_CLOSE = 1;

	/** Drop-down menu and combo behavior */
	public static final int STYLE_DROP_DOWN = 1 << 26;

	/** Flat */
	public static final int STYLE_FLAT = 1 << 12;

	/** Horizontal scroll bars */
	public static final int STYLE_H_SCROLL = 1 << 16;

	/** Horizontal style */
	public static final int STYLE_HORIZONTAL = 1 << 4;

	/** Lead alignment (left alignment in left-to-right languages) */
	public static final int STYLE_LEAD = 1;

	/** Left to right orientation */
	public static final int STYLE_LEFT_TO_RIGHT = 1 << 14;

	/** Maximize trim */
	public static final int STYLE_MAX = 1 << 2;

	/** Minimize trim */
	public static final int STYLE_MIN = 1 << 1;

	/** Modeless */
	public static final int STYLE_MODELESS = 1 << 7;

	/** Multiple selection and multiple line style */
	public static final int STYLE_MULTI = 1 << 23;

	/** Do not clear the background on paint events */
	public static final int STYLE_NO_BACKGROUND = 1 << 18;

	/** Do not take focus */
	public static final int STYLE_NO_FOCUS = 1 << 20;

	/** Do not merge paint events */
	public static final int STYLE_NO_MERGE_PAINTS = 1 << 19;

	/** Do not redraw the entire client area on resize */
	public static final int STYLE_NO_REDRAW_RESIZE = 1 << 21;

	/**
	 * Shell style indicating that while the Shell is open it will
	 * block input to its parent.  Modality styles are treated as 
	 * hints since typically all types of modality are not supported
	 * on every platform.  
	 */
	public static final int STYLE_PRIMARY_MODAL = 1 << 8;

	/** The MenuItem style for a radio button item */
	public static final int STYLE_RADIO = 1 << 4;

	/** Read-only text field */
	public static final int STYLE_READ_ONLY = 1 << 24;

	/** Right to left orientation */
	public static final int STYLE_RIGHT_TO_LEFT = 1 << 15;

	/** Shadow inside */
	public static final int STYLE_SHADOW_IN = 1 << 5;

	/** No shadow */
	public static final int STYLE_SHADOW_NONE = 1 << 7;

	/** Shadow outside */
	public static final int STYLE_SHADOW_OUT = 1 << 6;

	/** Title trim */
	public static final int STYLE_TITLE = 1 << 5;

	/** Trail alignment (right alignment in left-to-right languages) */
	public static final int STYLE_TRAIL	= 1 << 2;

	/** Vertical scroll bars */
	public static final int STYLE_V_SCROLL = 1 << 17;

	/** Vertical style */
	public static final int STYLE_VERTICAL = 1 << 3;

	/** Line wrapping text */
	public static final int STYLE_WRAP = 1 << 8;
	
	/** No trimmings */
	public static final int STYLE_NO_TRIM = 1 << 3;

	/** virtual */
	public static final int STYLE_VIRTUAL = 1 << 28;

	/**
	 * Returns the bounds of the device identified by <code>handle</code>.
	 * 
	 * @param handle the device handle
	 * @return (rect) the device bounds. Access array members using the 
	 * 	<code>INDEX_X</code>, <code>INDEX_Y</code>, <code>INDEX_WIDTH</code> 
	 * 	and <code>INDEX_HEIGHT</code> constants.
	 */
	public static final native int[] Device_GetBounds(int handle);
	
	/**
	 * Returns a String array containing all typeface names which
	 * are either scalable or non-scalable.
	 * 
	 * @param handle device handle
	 * @param scalable indicates whether scalable typefaces are returned
	 */
	public static final native String[] Device_GetTypefaces(int handle, boolean scalable);
	
	/**
	 * Returns a String array containing all the available variants
	 * of a particular typeface.  Each returned String will have
	 * the following format:
	 * 
	 * 1|&lt;typeface name&gt;|&lt;height&gt;|&lt;style&gt;|
	 *  
	 * where:
	 *
	 * &lt;typeface name&gt; should match the faceName argument
	 * &lt;height&gt; is the height in points of the font
	 * &lt;style&gt; is a bitwise OR of FONT_STYLE constants
	 * 
	 * See Font_GetStyle() for a list of supported styles.
	 * 
	 * @param handle device handle
	 * @param faceName typeface name
	 * @param scalable indicates whether variants should be scalable
	 * @return string array of available variants
	 */ 
	public static final native String[] Device_GetTypefaceVariants(int handle, String faceName, boolean scalable);
	
	/**
	 * Frees the platform resources associated with the device 
	 * identified by <code>handle</code>.
	 * 
	 * @param handle the device handle
	 */	
	public static final native void Device_Dispose(int handle);
	
	/**
	 * Creates a new display.
	 * 
	 * @return the new display
	 */
	public static final native int Display_New();	

	/**
	 * Reads an event from the event queue of the display 
	 * identified by <code>handle</code>.
	 * The event is dispatched to one of the event handlers 
	 * registered using <code>Display_RegisterCallback()</code>
	 * 
	 * @param handle the display handle
	 * @return true - more events are pending
	 * 	false - no events are pending, <code>Display_Sleep()</code> 
	 * 	should be used to wait for the next event
	 * @see #Display_RegisterCallback
	 * @see #Display_Sleep
	 */
	public static final native boolean Display_ReadAndDispatch(int handle);

	/**
	 * Initializes the structure used to hold the callback data.  This
	 * method should always be called once per display and always before
	 * any calls to <code>Display_RegisterCallback()</code>.
	 * 
	 * @param handle the display handle
	 * @param display the display instance, which is used to setup the display timer callback
	 * @see #Display_RegisterCallback
	 * @ignore the implementation for this method is provided
	 */
	public static final native void Display_InitCallbacks(int handle, Object display);
	
	/**
	 * Registers listener a callback for events on the display 
	 * identified by <code>handle</code>.
	 * All events occurring on a class specified in the <code>classNames</code> 
	 * array are sent to the corresponding method specified in the
	 * <code>methodNames</code> array.
	 * 
	 * This method can only be called after 
	 * <code>Display_InitCallbacks()</code> has been called.
	 *  
	 * @param handle the display handle
	 * @param id the id of the event to register
	 * @param className the fully qualified, forward slash ('/') 
	 * 	separated name of the class to register the callback for
	 * @param methodName the name of the callback method to call 
	 * 	when event of type <code>id</code> occurs
	 * @see #Display_InitCallbacks 
	 * @ignore the implementation for this method is provided
	 */
	public static final native void Display_RegisterCallback(int handle, int id, String className, String methodName);

	/**
	 * Causes the calling thread to sleep (that is, to be put in 
	 * a state where it does not consume CPU cycles) until an 
	 * event is received for the display identified by 
	 * <code>handle</code> or until it is awakened by a call to
	 * <code>Display_Wake()</code>.
	 * 
	 * @param handle the display handle
	 * @see #Display_Wake
	 */
	public static final native void Display_Sleep(int handle);
	
	/**
	 * If the calling thread was sleeping, causes it to be 
	 * awakened and start running again. 
	 * 
	 * @param handle the display handle
	 * @see #Display_Sleep
	 */
	public static final native void Display_Wake(int handle);

	/**
	 * Creates a new font with the specified typeface name, height
	 * in points, and style flags.  In order for the implementation to
	 * correctly return a font handle, the exact combination of these
	 * parameters must match one of the variants returned by 
	 * Device_GetTypefaceVariants().  Otherwise, an error will occur.
	 * 
	 * @param deviceHandle the device/display handle
	 * @param name one of the system typeface names returned by Device_GetTypefaces
	 * @param height the requested height of the font in points
	 * @param style one of the FONT_STYLE constants
	 * @return handle of new font   
	 */
	public static final native int Font_New(int deviceHandle, String name, int height, int style);
	
	/**
	 * Frees the platform resources of the font with the specified handle.
	 * 
	 * @param handle font handle
	 */
	public static final native void Font_Dispose(int handle);
	
	/**
	 * Returns the advance width in pixels of a character for the 
	 * font with the specified handle.
	 * <p>
	 * The advance width is the number of pixels the cursor advances 
	 * when moving over the character.
	 * </p>
	 * 
	 * @param handle font handle
	 * @param ch character to be tested for advance width
	 * @return advance width in pixels
	 */
	public static final native int Font_GetAdvanceWidth(int handle, char ch);
	
	/**
	 * Returns the ascent in pixels of the font with the specified handle.
	 * 
	 * @param handle font handle
	 * @return ascent in pixels
	 */
	public static final native int Font_GetAscent(int handle);
	
	/**
	 * Returns the descent in pixels of the font with the specified handle.
	 * 
	 * @param handle font handle
	 * @return descent in pixels
	 */
	public static final native int Font_GetDescent(int handle);
	
	/**
	 * Returns the height of the font with the specified handle in points.
	 * 
	 * @param handle font handle
	 * @return font height
	 */
	public static final native int Font_GetSizeInPoints(int handle);
	
	/**
	 * Returns the leading in pixels of the font with the specified handle.
	 * 
	 * @param handle font handle
	 * @return leading in pixels
	 */
	public static final native int Font_GetLeading(int handle);
	
	/**
	 * Measures the width and height, in pixels, of the given string.
	 * <p>
	 * The returned extent is the width and height of the rectangular 
	 * area the string would cover if drawn in this font.
	 * </p>
	 * The following flags may be used:
	 * <ul>
	 * <li><code>STRING_WRAP</code> - wrap text at the line delimiters
	 *		prior to measuring. Valid line delimiters are <code>"\r"</code>, 
	 * 		<code>"\n"</code> and <code>"\r\n"</code></li>
	 * <li><code>STRING_MNEMONIC</code> - remove any mnemonic characters 
	 * 		('&amp;') prior to measuring</li>
	 * <li><code>STRING_EXPAND_TAB</code> - interpret tab characters 
	 * 		(<code>"\t"</code>) as tab stops.</li>
	 * </ul>
	 * <p>
	 * When measuring multiple lines, i.e., line delimiters are present 
	 * and <code>STRING_WRAP</code> is specified, the returned height 
	 * is the overall height of all lines combined. 
	 * </p>
	 * 
	 * @param handle the font handle
	 * @param string the text to measure
	 * @param flags one or more of <code>STRING_WRAP</code>, 
	 * 	<code>STRING_MNEMONIC</code> and <code>STRING_EXPAND_TAB</code> 
	 * @return (size) the width and height of the given string. Access
	 * 	array members using the <code>INDEX_X</code> constant for the 
	 * 	width and using the <code>INDEX_Y</code> constant for the height.
	 */
	public static final native int[] Font_StringExtent(int handle, String string, int flags);
	
	/**
	 * Frees the platform resources associated with the graphics context 
	 * identified by <code>handle</code>.
	 * 
	 * @param handle the graphics context handle
	 */
	public static final native void Graphics_Dispose(int handle);
	/**
	 * Draws an arc on the graphics context identified by <code>handle</code>.
	 * The arc is drawn within the specified bounding rectangle. The 
	 * arc starts at <code>startAngle</code> and extends counter-clockwise 
	 * for <code>arcAngle</code> degrees.
	 * <p>
	 * The center of the arc is the center of the rectangle whose origin 
	 * is <code>x</code>, <code>y</code> and whose size is specified by the 
	 * <code>width</code> and <code>height</code> arguments.
	 * </p>
	 * <p>
	 * The arc's left/top edge is at location <code>x</code>/<code>y</code>
	 * respectively. The arc's right edge is at location <code>x + width - 1</code>
	 * on the graphics context. The arc's bottom edge is at location 
	 * <code>y + height - 1</code> on the graphics context.
	 * </p>
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the arc bounding 
	 * 	rectangle
	 * @param y y coordinate of the top left corner of the arc bounding 
	 * 	rectangle
	 * @param width width of the arc
	 * @param height height of the arc
	 * @param startAngle identifies the start position of the arc. 0 degrees
	 * 	is at the 3 o'clock position.
	 * @param arcAngle the angular extent of the arc, relative to the 
	 * 	<code>startAngle</code>
	 */
	public static final native void Graphics_DrawArc(int handle, int x, int y, int width, int height, int startAngle, int arcAngle);
	
	/**
	 * Draws the specified image at the given location on the graphics
	 * context identified by <code>handle</code>.
	 * 
	 * @param handle the graphics context handle
	 * @param image image handle
	 * @param x x coordinate of the top left corner of the image
	 * @param y y coordinate of the top left corner of the image
	 */
	public static final native void Graphics_DrawImage(int handle, int image, int x, int y);
	
	
	/**
	 * Draws a line in the current pen width and style on the graphics  
	 * context identified by <code>handle</code>. The line is drawn between
	 * the end points identified by <code>x1</code>, <code>y1</code> and
	 * <code>x2</code>, <code>y2</code>. The end points are included in the 
	 * line.
	 * 
	 * @param handle the graphics context handle
	 * @param x1 x coordinate of the first end point
	 * @param y1 y coordinate of the first end point
	 * @param x2 x coordinate of the second end point
	 * @param y2 y coordinate of the second end point
	 */
	public static final native void Graphics_DrawLine(int handle, int x1, int y1, int x2, int y2);
	/**
	 * Draws an oval that is within the specified rectangle on the
	 * graphics context identified by <code>handle</code>.
	 * <p>
	 * The oval's left/top edge is at location <code>x</code>/<code>y</code>
	 * respectively. The oval's right edge is at location 
	 * <code>x + width - 1</code> on the graphics context. The oval's 
	 * bottom edge is at location <code>y + height - 1</code> on the 
	 * graphics context.
	 * </p>
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the oval bounding 
	 * 	rectangle
	 * @param y y coordinate of the top left corner of the oval bounding 
	 * 	rectangle
	 * @param width width of the oval
	 * @param height height of the oval
	 */
	public static final native void Graphics_DrawOval(int handle, int x, int y, int width, int height);
	/**
	 * Draws a closed polygon on the graphics context identified by 
	 * <code>handle</code>.
	 * 
	 * @param handle the graphics context handle
	 * @param pointArray an array of alternating x and y values which 
	 * 	are the vertices of the polygon
	 * @param length number of integers in the pointArray (twice the number of points)
	 */
	public static final native void Graphics_DrawPolygon(int handle, int[] pointArray, int length);
	/**
	 * Draws a polygon on the graphics context identified by <code>handle</code>.
	 * 
	 * @param handle the graphics context handle
	 * @param pointArray an array of alternating x and y values which 
	 * 	are the vertices of the polygon
	 * @param length number of integers in the pointArray (twice the number of points)
	 */
	public static final native void Graphics_DrawPolyline(int handle, int[] pointArray, int length);
	/**
	 * Draws a rectangle on the graphics context identified by 
	 * <code>handle</code>.
	 * <p>
	 * The rectangle's right edge is at location <code>x + width - 1</code>
	 * on the graphics context. The rectangle's bottom edge is at location 
	 * <code>y + height - 1</code> on the graphics context.
	 * </p>
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the rectangle
	 * @param y y coordinate of the top left corner of the rectangle
	 * @param width width of the rectangle
	 * @param height height of the rectangle
	 */
	public static final native void Graphics_DrawRectangle(int handle, int x, int y, int width, int height);
	/**
	 * Draws a round-cornered rectangle on the graphics context identified
	 * by <code>handle</code>.
	 * <p>
	 * The rectangle's right edge is at location <code>x + width - 1</code>
	 * on the graphics context. The rectangle's bottom edge is at location 
	 * <code>y + height - 1</code> on the graphics context.
	 * </p>
	 * <p>
 	 * The <em>roundness</em> of the corners is specified by the 
 	 * <code>arcWidth</code> and <code>arcHeight</code> arguments.
 	 * </p> 
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the rectangle
	 * @param y y coordinate of the top left corner of the rectangle
	 * @param width width of the rectangle
	 * @param height height of the rectangle
	 * @param arcWidth the horizontal radius of the arc at the four corners
	 * @param arcHeight the vertical radius of the arc at the four corners
	 */
	public static final native void Graphics_DrawRoundRectangle(int handle, int x, int y, int width, int height, int arcWidth, int arcHeight);
	/**
	 * Draws the specified string at the given location on the graphics 
	 * context identified by <code>handle</code>.
	 * The following flags may be used:
	 * <ul>
	 * 	<li><code>STRING_WRAP</code> - wrap text at the line delimiters 
	 * 		and render multiple lines. Valid line delimiters are <code>"\r"</code>, 
	 * 		<code>"\n"</code> and <code>"\r\n"</code></li>
	 * 	<li><code>STRING_MNEMONIC</code> - interpret the last mnemonic 
	 * 		character (<code>&amp;</code>) in the string to underline the 
	 * 		next character instead of rendering the ampersand</li>
	 *	<li><code>STRING_EXPAND_TAB</code> - expand tab characters into 
	 *		tab stops</li> 
	 *	<li><code>STRING_TRANSPARENT</code> - render transparently on the 
	 *		background</li>
	 * </ul>
	 * 
	 * @param handle the graphics context handle
	 * @param string the string to draw
	 * @param x the x coordinate of the top left corner of the bounding 
	 * 	rectangle surrounding the text
	 * @param y the y coordinate of the top left corner of the bounding 
	 * 	rectangle surrounding the text
	 * @param flags one or more of <code>STRING_WRAP</code>,  
	 * 	<code>STRING_MNEMONIC</code>, <code>STRING_EXPAND_TAB</code> and 
	 * 	<code>STRING_TRANSPARENT</code> 
	 */
	public static final native void Graphics_DrawString(int handle, String string, int x, int y, int flags);

	/**
	 * Draws a filled arc on the graphics context identified by 
	 * <code>handle</code>. The arc is drawn within the specified bounding 
	 * rectangle. It is filled with the graphics context's background 
	 * color. The arc starts at <code>startAngle</code> and extends 
	 * counter-clockwise for <code>arcAngle</code> degrees.
	 * <p>
	 * The center of the arc is the center of the rectangle whose origin 
	 * is <code>x</code>, <code>y</code> and whose size is specified by the 
	 * <code>width</code> and <code>height</code> arguments.
	 * </p>
	 * <p>
	 * The arc's left/top edge is at location <code>x</code>/<code>y</code>
	 * respectively. The arc's right edge is at location <code>x + width - 1</code>
	 * on the graphics context. The arc's bottom edge is at location 
	 * <code>y + height - 1</code> on the graphics context.
	 * </p>
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the arc bounding 
	 * 	rectangle
	 * @param y y coordinate of the top left corner of the arc bounding 
	 * 	rectangle
	 * @param width width of the arc
	 * @param height height of the arc
	 * @param startAngle identifies the start position of the arc. 0 degrees
	 * 	is at the 3 o'clock position.
	 * @param arcAngle the angular extent of the arc, relative to the 
	 * 	<code>startAngle</code>
	 */
	public static final native void Graphics_FillArc(int handle, int x, int y, int width, int height, int startAngle, int arcAngle);
	
	/**
	 * Draws a filled oval that is within the specified rectangle on the 
	 * graphics context identified by <code>handle</code>. The oval is 
	 * filled with the graphics context's background color.
	 * <p>
	 * The oval's left/top edge is at location <code>x</code>/<code>y</code>
	 * respectively. The oval's right edge is at location 
	 * <code>x + width - 1</code> on the graphics context. The oval's 
	 * bottom edge is at location <code>y + height - 1</code> on the 
	 * graphics context.
	 * </p>
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the oval bounding 
	 * 	rectangle
	 * @param y y coordinate of the top left corner of the oval bounding 
	 * 	rectangle
	 * @param width width of the oval
	 * @param height height of the oval
	 */
	public static final native void Graphics_FillOval(int handle, int x, int y, int width, int height);
	/**
	 * Draws a closed polygon on the graphics context identified by 
	 * <code>handle</code>. The closed regions of the polygon are filled
	 * with the graphics context's background color.
	 * 
	 * @param handle the graphics context handle
	 * @param pointArray an array of alternating x and y values which 
	 * 	are the vertices of the polygon
	 * @param length number of integers in the pointArray (twice the number of points)
	 */
	public static final native void Graphics_FillPolygon(int handle, int[] pointArray, int length);
	/**
	 * Draws a filled rectangle on the graphics context identified by 
	 * <code>handle</code>. The rectangle is filled with the graphics 
	 * context's background color.
	 * <p>
	 * The rectangle's right edge is at location <code>x + width - 1</code>
	 * on the graphics context. The rectangle's bottom edge is at location 
	 * <code>y + height - 1</code> on the graphics context.
	 * </p>
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the rectangle
	 * @param y y coordinate of the top left corner of the rectangle
	 * @param width width of the rectangle
	 * @param height height of the rectangle
	 */
	public static final native void Graphics_FillRectangle(int handle, int x, int y, int width, int height);
	/**
	 * Draws a filled round-cornered rectangle on the graphics context 
	 * identified by <code>handle</code>. The rectangle is filled with the  
	 * graphics context's background color.
	 * <p>
	 * The rectangle's right edge is at location <code>x + width - 1</code>
	 * on the graphics context. The rectangle's bottom edge is at location 
	 * <code>y + height - 1</code> on the graphics context.
	 * </p>
	 * <p>
 	 * The <em>roundness</em> of the corners is specified by the 
 	 * <code>arcWidth</code> and <code>arcHeight</code> arguments.
 	 * </p> 
	 * 
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the rectangle
	 * @param y y coordinate of the top left corner of the rectangle
	 * @param width width of the rectangle
	 * @param height height of the rectangle
	 * @param arcWidth the horizontal diameter of the arc at the four corners
	 * @param arcHeight the vertical diameter of the arc at the four corners
	 */
	public static final native void Graphics_FillRoundRectangle(int handle, int x, int y, int width, int height, int arcWidth, int arcHeight);
	/**
	 * Sets the background color of the graphics context identified by
	 * <code>handle</code>.   The background color should be used when filling 
	 * shapes (i.e. FillRectangle and FillArc).
	 * 
	 * @param handle the graphics context handle
	 * @param color the handle of the new background color
	 */
	public static final native void Graphics_SetBackground(int handle, int color);
	/**
	 * Sets the clipping of the graphics context identified by 
	 * <code>handle</code> to the specified rectangle.
	 *    
	 * @param handle the graphics context handle
	 * @param x x coordinate of the top left corner of the clipping 
	 * 	rectangle
	 * @param y y coordinate of the top left corner of the clipping
	 * 	rectangle
	 * @param width width of the clipping rectangle
	 * @param height height of the clipping rectangle
	 */
	public static final native void Graphics_SetClipping(int handle, int x, int y, int width, int height);
	/**
	 * Sets the font of the graphics context identified by <code>handle</code>.
	 *    
	 * @param handle the graphics context handle
	 * @param font the font handle 
	 */
	public static final native void Graphics_SetFont(int handle, int font);
	/**
	 * Sets the foreground color of the graphics context identified by
	 * <code>handle</code>.   The foreground color is used when drawing shape 
	 * outlines (i.e. DrawLine and DrawRectangle).
	 * 
	 * @param handle the graphics context handle
	 * @param color the handle of the new foreground color
	 */
	public static final native void Graphics_SetForeground(int handle, int color);
	
	/**
	 * Sets the line width of the graphics context identified by
	 * <code>handle</code>. All subsequent outline rendering operations will 
	 * use this line width. E.g., line, rectangle, oval.
	 * 
	 * @param handle the graphics context handle
	 * @param width the line width in pixels
	 */
	public static final native void Graphics_SetLineWidth(int handle, int width);

	/**
	 * Creates a new top-level shell on the display identified by 
	 * <code>displayHandle</code>.
	 * <p>Note: The styles supported by this method must be treated
	 * as <em>HINT</em>s, since the window manager has ultimate
	 * control over the appearance and behavior of decorations
	 * and modality. In addition, if a modality style is not supported, 
	 * it is "upgraded" to a more restrictive modality style that is 
	 * supported. For example, if <code>STYLE_PRIMARY_MODAL</code> is not supported,
	 * it would be upgraded to <code>STYLE_APPLICATION_MODAL</code>.
	 * </p>
	 * 
	 * @param displayHandle the display to create the shell on. 
	 * 	Must not be 0.
	 * @param style one or more of <code>CLOSE</code>, <code>MIN</code>,  
	 * 	<code>MAX</code>, <code>NO_TRIM</code>,   
	 *  <code>TITLE</code>, <code>STYLE_APPLICATION_MODAL</code>,  
	 *  <code>STYLE_SYSTEM_MODAL</code>,
	 *  <code>STYLE_MODELESS</code>, and <code>STYLE_PRIMARY_MODAL</code> 
	 * @return the new top-level shell
	 */
	public static final native int Shell_New(int displayHandle, int style);
	
	/**
	 * Sets the text of the shell identified by <code>handle</code>.
	 * This is the string that the window manager will typically 
	 * display as the <em>title</em>. 
	 * 
	 * Note: some platforms might ignore requests to set a shell title, 
	 * so calls to this method on those platforms should fail silently.
	 * 
	 * @param handle the shell handle
	 * @param text the new text. May not be <code>null</code> 
	 */
	public static final native void Shell_SetText(int handle, String text);
	
	/**
	 * Sets the maximized state of the shell identified by <code>handle</code>.
	 * 
	 * Note: some platforms do not have the capability to programmatically change
	 * the minimized or maximized state, so calls to this method on those platforms
	 * should fail silently.
	 *  
	 * @param handle the shell handle
	 * @param maximized true - the shell switches to the maximized state
	 * 	false - if the shell was previously maximized, causes the
	 * 	shell to switch back to either the minimized or normal states.
	 */
	public static final native void Shell_SetMaximized(int handle, boolean maximized);
	
	/**
	 * Requests that the window manager close the receiver in the 
	 * same way it would be closed when the user clicks on the 
	 * "close box" or performs some other platform specific key 
	 * or mouse combination that indicates the window should be 
	 * removed.
 	 *
	 * @param handle the shell handle
	 */
	public static final native void Shell_Close(int handle);

	/**
	 * Releases any resources that have been allocated to a widget.
	 * 
	 * @param handle the widget handle
	 */
	public static final native void Widget_Dispose(int handle);
	
	/**
	 * @ignore this method is ignored because the implementation is provided
	 */
	public static final native void Widget_SetData(int handle, Object data);
	
	/**
	 * Changes a control's visibility.  Whether or not a control is actually
	 * displayed depends on several factors, including the visibility of its
	 * ancestors.  So calling this method may not actually affect the appearance
	 * of a control.  
	 * 
	 * @param handle the control handle
	 * @param visible the new visibility state
	 */
	public static final native void Control_SetVisible(int handle, boolean visible);
	
	/**
	 * Set a control's bounds relative to its parent.  When the (x,y) position is (0,0),
	 * the control will be placed in the upper left corner (in left to right mode),
	 * and will not be covered by any of the parent's trimmings.
	 * 
	 * @param handle the control handle
	 * @param x the new x coordinate of the origin
	 * @param y the new y coordinate of the origin
	 * @param width the new width of the control
	 * @param height the new height of the control
	 */
	public static final native void Control_SetBounds(int handle, int x, int y, int width, int height); 
	
	/**
	 * Returns the bounding rectangle of the control, relative to the parent.
	 * See Control_SetBounds() for more detail about the position.
	 * 
	 * @param handle the control handle
	 * @return (rect)
	 */
	public static final native int[] Control_GetBounds(int handle);
	
	/**
	 * Creates a new graphics context (GC) on the control identified by
	 * <code>handle</code>.
	 * <p>
	 * The origin of the GC is at the top left corner of the control 
	 * client area. For composite controls, it is under the top
	 * decorations (title bar, menu bar, border) and to the right 
	 * of the left hand decorations (scroll bar, border).
	 * </p>
	 * 
	 * @param handle the control handle
	 * @return the new graphics context
	 */
	public static final native int Control_NewGraphics(int handle);
	
	/**
	 * Requests that the entire control be redrawn.  Please note that
	 * the actual redraw will not occur until the event loop has
	 * processed the draw event.
	 * 
	 * @param handle handle of the widget
	 */
	public static final native void Control_Redraw(int handle);
	
	/**
	 * Creates a new RGB color.
	 * 
	 * @param deviceHandle the device/display handle
	 * @param red the red component of the color. Valid values 0 to 255.
	 * @param green the green component of the color. Valid values 0 to 255.
	 * @param blue the blue component of the color. Valid values 0 to 255.
	 * @return a new RGB color with the specified red, green and blue components
	 */
	public static final native int Color_New(int deviceHandle, int red, int green, int blue);
	
	/**
	 * Releases any resources that have been allocated to a color.
	 * 
	 * @param handle the color handle
	 */
	public static final native void Color_Dispose(int handle);
	
	/**
	 * Copies the specified area from the image identified by <code>handle</code> 
	 * into the destination image. The area is copied from location <code>x</code>,
	 * <code>y</code> in the source image to location 0, 0 in the destination 
	 * image.
	 *  
	 * @param handle handle to the image to copy 
	 * @param destImageHandle handle to the destination image
	 * @param x x coordinate of the area to copy to the destination image.
	 * 	Must be within the image's bounds.
	 * @param y y coordinate of the area to copy to the destination image.
	 * 	Must be within the image's bounds.
	 * @param width width of the area to copy to the destination image.
	 * 	Must be within the image's bounds.
	 * @param height height of the area to copy to the destination image.
	 * 	Must be within the image's bounds.
	 */
	public static final native void Image_CopyArea(int handle, int destImageHandle, int x, int y, int width, int height);

	/**
	 * Frees the platform resources associated with the image identified by 
	 * <code>handle</code>.
	 * 
	 * @param handle image handle
	 */
	public static final native void Image_Dispose(int handle);
	
	/**
	 * Returns the position and size of the image identified by <code>handle</code>.
	 * 
	 * @param handle image handle
	 * @return (rect) the x, y, width and height describing the image location and 
	 * 	size. Access array members using the <code>INDEX_X</code>, <code>INDEX_Y</code>,
	 * 	<code>INDEX_WIDTH</code>, <code>INDEX_HEIGHT</code> constants.
	 */
	public static final native int[] Image_GetBounds(int handle);
	
	/**
	 * Returns the color depth of the image identified by <code>handle</code>.
	 * The supported color depths are 1, 2, 4, 8, 16, 24 and 32 bit. The 
	 * returned depth must be one of the values supported by UGL. In the case 
	 * of 3, 5, 6 or 7 bit GIFs the returned depth should reflect the actual 
	 * "color resolution" as defined in the GIF89a spec.
	 * 
	 * @param handle image handle
	 * @return color depth in bits per pixel
	 */
	public static final native int Image_GetDepth(int handle);
	
	/**
	 * Returns 32 bpp ARGB data from the specified region in the image  
	 * identified by <code>handle</code>. Each pixel is in 0xAARRGGBB format,  
	 * regardless of the actual color depth and color model of the image.
	 * The most significant byte contains the alpha data and the other three 
	 * bytes hold the red, green and blue color components respectively. The
	 * alpha data should default to 255 indicating opaque pixels if no alpha
	 * channel is present in the image.
	 * <p>
	 * The <code>rgbs</code> array must be big enough to hold the entire 
	 * requested image data.
	 * </p>
	 * 
	 * @param handle image handle
	 * @param startX x coordinate, start location of pixels to return
	 * @param startY y coordinate, start location of pixels to return
	 * @param width width of the image region to return
	 * @param height height of the image region to return
	 * @param offset offset into the rgb array to start writing data at
	 * @param scanSize width of each scanline in the returned rgb data
	 * @param rgbs return ARGB data. Each pixel is in 0xAARRGGBB format.
	 */
	public static final native void Image_GetRGB(int handle, int startX, int startY, int width, int height, int offset, int scanSize, int[] rgbs);
	
	/**
	 * Creates a new, empty image with the given dimensions.
	 * <p>
	 * Image will be filled with the provided fill color which
	 * is in 0xAARRGGBB format.
	 * </p>
	 * 
	 * @param deviceHandle the device/display handle
	 * @param width width of the new image
	 * @param height height of the new image
	 * @param fillColor value with which to fill the image in 0xAARRGGBB format.
	 * @return handle to the new image
	 */
	public static final native int Image_NewFromSize(int deviceHandle, int width, int height, int fillColor);
	
	/**
	 * Creates a new image from the supplied pixel data. Each pixel is a direct
	 * color RGB value. Supported color depths are 16, 24 and 32 bits per pixel. 
	 * For 16 bit depth the RGB bits are layed out as 5-6-5 bits for red, green 
	 * and blue respectively, 24 bit depth uses 8-8-8 bits and no alpha channel.
	 * 32 bit color depth uses 8-8-8 bits and the most significant byte for the
	 * alpha channel for an ARGB pixel layout. For 32 bit pixel data the alpha
	 * channel byte is ignored if either one of the 
	 * <code>transparentColor</code>, <code>globalAlpha</code> or 
	 * <code>alphaData</code> is specified. Only one of the three transparency/
	 * alpha arguments may be specified at a time.
	 * <p>
	 * May result in the following errors:
	 * <ul>
	 * <li>ERROR_UNSUPPORTED_DEPTH - the color depth is not supported</li>
	 * <li>ERROR_INVALID_IMAGE - an error has occurred while creating the image</li>
	 * </ul>  
	 * </p>
	 *
	 * @param deviceHandle the device handle
	 * @param width width of the new image in pixels
	 * @param height height of the new image
	 * @param imageData pixel data. Each int contains one pixel regardless of 
	 * 	color depth. E.g., a 16 bit pixel is packed in the two least 
	 * 	significant bytes of each int.
	 * @param depth color depth of the image data, in number of bits per pixel.
	 * 	One of 16, 24, 32. It is acceptable for an implementation to create an
	 * 	image with a different depth if platform limitations do not allow the
	 * 	original color depth. The depth has to remain the same throughout the 
	 * 	life of the image.
	 * @param transparentColor value of the transparent color. The transparent 
	 * 	color is specified in the same bit format as the image data. Value of 
	 * 	<code>-1</code> means no transparency.
	 * @param globalAlpha global alpha value. Each pixel will be blended using 
	 * 	this alpha value. Value of <code>-1</code> means no global alpha value.
	 * @param alphaData alpha data of the image. Each pixel may have an alpha 
	 * 	value ranging from 0 to 255. 0 means fully transparent, 255 means fully 
	 * 	opaque. May be <code>null</code>.
	 * @return handle to the new image. 0 if no image could be created using the
	 * 	supplied parameters.
	 */
	public static final native int Image_NewFromIntData(int deviceHandle, int width, int height, int[] imageData, int depth, int transparentColor, int globalAlpha, byte[] alphaData);

	/**
	 * Creates a new image from the supplied pixel data. Each pixel is an 
	 * index into a color palette. The color palette is supplied in the
	 * indexed color arrays. The palette may not use all possible color 
	 * values . In other words the number of elements may be less than 
	 * (2^depth). Supported color depths are 1, 2, 4 and 8 bits per pixel.
	 * <p>
	 * May result in the following errors:
	 * <ul>
	 * <li>ERROR_UNSUPPORTED_DEPTH - the color depth is not supported</li>
	 * <li>ERROR_INVALID_IMAGE - an error has occurred while creating the image</li>
	 * </ul>  
	 * </p>
	 * @param deviceHandle the device handle
	 * @param width width of the new image in pixels
	 * @param height height of the new image
	 * @param imageData the pixel data. Each byte holds one or more pixels. An  
	 * 	8 bit per pixel image has one pixel per byte, a 4 bpp image has exactly 
	 * 	2 pixels per byte etc. The most significant bit of each byte corresponds
	 * 	to the leftmost pixel on a scanline. A scanline may have unused bits if 
	 * 	the color depth is less than 8 bpp. 
	 * @param bytesPerLine length in bytes of a scan line. The number of bytes 
	 * 	per scan line may be greater than required for the actual number of 
	 * 	pixels. Excess bytes are unused.
	 * @param depth color depth of the image data, in number of bits per pixel. 
	 * 	One of 1, 2, 4, 8. It is acceptable for an implementation to create an
	 * 	image with a different depth if platform limitations do not allow the
	 * 	original color depth. The depth has to remain the same throughout the 
	 * 	life of the image. 
	 * @param indexedReds red components of indexed color palette.
	 * @param indexedGreens green components of indexed color palette.
	 * @param indexedBlues blue components of indexed color palette.
	 * @param paletteSize number of entries in the color palette arrays. This
	 * 	may be less than the maximum number allowed by the color depth.
	 * @param transparentPixel palette index of the transparent pixel. Value of 
	 * 	<code>-1</code> means no transparency.
	 * @return handle to the new image. 0 if no image could be created using the
	 * 	supplied parameters.
	 * @see com.ibm.ugl.p3ml.OS#Image_GetDepth(int)
	 */
	public static final native int Image_NewFromByteData(int deviceHandle, int width, int height, byte[] imageData, int bytesPerLine, int depth, byte[] indexedReds, byte[] indexedGreens, byte[] indexedBlues, int paletteSize, int transparentPixel);
	
	/**
	 * Creates a new image using the supplied raw data.
	 * <p>
	 * May result in the following errors:
	 * <ul>
	 * <li>ERROR_UNSUPPORTED_DEPTH - the color depth is not supported</li>
	 * <li>ERROR_INVALID_IMAGE - an error has occurred while creating the image</li>
	 * </ul>  
	 * </p>
	 * 
	 * @param deviceHandle the device/display handle
	 * @param data the raw image data, including image header
	 * @param length number of bytes in the data array
	 * @return handle to the new image or 0 if no image could be created 
	 * 	from the supplied data.
	 */
	public static final native int Image_NewFromFileData(int deviceHandle, byte[] data, int length);

	/**
	 * Creates a new graphics context on the image identified by
	 * <code>handle</code>
	 * 
	 * @param handle image handle
	 * @return handle to the new graphics context
	 */
	public static final native int Image_NewGraphics(int handle);
	
	/**
	 * Returns a scrollable's insets.  The insets contain the offset from
	 * each side of the scrollable to the actual client area.  The client
	 * area is where children are typically placed and drawing occurs.  Please
	 * note that if Adjustables have been created for the Scrollable (as
	 * returned by Scrollable_GetHorizontalBar and Scrollable_GetVerticalBar),
	 * they will increase the corresponding inset value only if visible.
	 * 
	 * @param handle handle of scrollable widget
	 * @return (insets)
	 */
	public static final native int[] Scrollable_GetInsets(int handle);
}
