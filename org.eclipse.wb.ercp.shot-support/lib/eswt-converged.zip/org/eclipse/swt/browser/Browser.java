/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.browser;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Widget;
import com.ibm.ugl.eswt.expanded.OS;

/**
 * Instances of this class implement the browser user interface
 * metaphor.  It allows the user to visualize and navigate through
 * HTML documents.
 * <p>
 * Note that although this class is a subclass of <code>Composite</code>,
 * it does not make sense to set a layout on it.
 * </p><p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 * 
 * @since 3.0
 */
public class Browser extends Composite {

	private List locationListeners;
	private List progressListeners;
	private List statusListeners;
	private List titleListeners;
	
	private static boolean eventsRegistered;
	private Listener disposeListener;


/**
 * Constructs a new instance of this class given its parent
 * and a style value describing its behavior and appearance.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a widget which will be the parent of the new instance (cannot be null)
 * @param style the style of widget to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 * </ul>
 * @exception SWTError <ul>
 *    <li>ERROR_NO_HANDLES if a handle could not be obtained for browser creation</li>
 * </ul>
 * 
 * @see Widget#getStyle
 * 
 * @since 3.0
 */
public Browser(Composite parent, int style) {
	super(parent, style);
	
	if (!eventsRegistered) {
		com.ibm.ugl.p3ml.OS.Display_RegisterCallback(getDisplay().internal_handle, OS.CALLBACK_BROWSER_TITLE_CHANGED, "org/eclipse/swt/browser/Browser", "titleChanged");
		com.ibm.ugl.p3ml.OS.Display_RegisterCallback(getDisplay().internal_handle, OS.CALLBACK_BROWSER_STATUSTEXT_CHANGED, "org/eclipse/swt/browser/Browser", "statusTextChanged");
		com.ibm.ugl.p3ml.OS.Display_RegisterCallback(getDisplay().internal_handle, OS.CALLBACK_BROWSER_PROGRESS, "org/eclipse/swt/browser/Browser", "progressCallback");
		com.ibm.ugl.p3ml.OS.Display_RegisterCallback(getDisplay().internal_handle, OS.CALLBACK_BROWSER_LOCATION_CHANGING, "org/eclipse/swt/browser/Browser", "locationChanging");
		com.ibm.ugl.p3ml.OS.Display_RegisterCallback(getDisplay().internal_handle, OS.CALLBACK_BROWSER_LOCATION_CHANGED, "org/eclipse/swt/browser/Browser", "locationChanged");
		eventsRegistered = true;
	}
	
	final Browser browserTemp = this;
	disposeListener = new Listener(){
		public void handleEvent(Event event) {
			if(event.widget == browserTemp) {
				internal_sendEvent(SWT.FocusOut);
			}
		}
	};
	getDisplay().addFilter(SWT.Dispose, disposeListener);

}


/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Composite#internal_createHandle(int)
 */
protected void internal_createHandle(int index) {
	internal_handle = OS.Browser_New(internal_parent.internal_handle, internal_getNativeStyle());
	if (internal_handle == 0) SWT.error(SWT.ERROR_NO_HANDLES);
}


/**	 
 * Adds the listener to receive events.
 * <p>
 *
 * @param listener the listener
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @since 3.0
 */
public void addLocationListener(LocationListener listener) {
	checkWidget();
	if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	
	if (locationListeners == null) locationListeners = new ArrayList();
	locationListeners.add(listener);
}

/**	 
 * Adds the listener to receive events.
 * <p>
 *
 * @param listener the listener
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @since 3.0
 */
public void addProgressListener(ProgressListener listener) {
	checkWidget();
	if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	
	if (progressListeners == null) progressListeners = new ArrayList();
	progressListeners.add(listener);
}

/**	 
 * Adds the listener to receive events.
 * <p>
 *
 * @param listener the listener
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @since 3.0
 */
public void addStatusTextListener(StatusTextListener listener) {
	checkWidget();
	if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	
	if (statusListeners == null) statusListeners = new ArrayList();
	statusListeners.add(listener);
}

/**	 
 * Adds the listener to receive events.
 * <p>
 *
 * @param listener the listener
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @since 3.0
 */
public void addTitleListener(TitleListener listener) {
	checkWidget();
	if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	
	if (titleListeners == null) titleListeners = new ArrayList();
	titleListeners.add(listener);
}

private boolean locationChanging(String location) {
	if (locationListeners == null) return true;
	
	LocationEvent event = new LocationEvent(this);
	event.doit = true;
	event.location = location;
	event.widget = this;
	event.display = getDisplay();
	event.time = ((int) System.currentTimeMillis()) & 0x7FFFFFFF;

	int listenerCount = locationListeners.size();
	for (int i=0;i<listenerCount;i++) {
		LocationListener listener = (LocationListener)locationListeners.get(i);
		listener.changing(event);
	}

	return event.doit;
}

private void locationChanged(String location, boolean isTop) {
	if (locationListeners != null) {
		LocationEvent event = new LocationEvent(this);
		event.location = location;
		event.top = isTop;
		event.widget = this;
		event.display = getDisplay();
		event.time = ((int) System.currentTimeMillis()) & 0x7FFFFFFF;
	
		int listenerCount = locationListeners.size();
		for (int i=0;i<listenerCount;i++) {
			LocationListener listener = (LocationListener)locationListeners.get(i);
			listener.changed(event);
		}
	}
}

private void titleChanged(String title) {
	if (titleListeners != null) {
		TitleEvent event = new TitleEvent(this);
		event.title = title;
		event.widget = this;
		event.display = getDisplay();
		event.time = ((int) System.currentTimeMillis()) & 0x7FFFFFFF;

		int listenerCount = titleListeners.size();
		for (int i=0;i<listenerCount;i++) {
			TitleListener listener = (TitleListener)titleListeners.get(i);
			listener.changed(event);
		}
	}
}

private void statusTextChanged(String statusText) {
	if (statusListeners != null) {
		StatusTextEvent event = new StatusTextEvent(this);
		event.text = statusText;
		event.widget = this;
		event.display = getDisplay();
		event.time = ((int) System.currentTimeMillis()) & 0x7FFFFFFF;

		int listenerCount = statusListeners.size();
		for (int i=0;i<listenerCount;i++) {
			StatusTextListener listener = (StatusTextListener)statusListeners.get(i);
			listener.changed(event);
		}
	}
}

private void progressCallback(int value, int max) {
	if (progressListeners != null) {
		ProgressEvent event = new ProgressEvent(this);
		
		if (value != max) {
			event.current = value;
			event.total = max;
		}
		
		event.widget = this;
		event.display = getDisplay();
		event.time = ((int) System.currentTimeMillis()) & 0x7FFFFFFF;

		int listenerCount = progressListeners.size();
		for (int i=0;i<listenerCount;i++) {
			ProgressListener listener = (ProgressListener)progressListeners.get(i);
			if (value != max) {
				listener.changed(event);
			} else {
				listener.completed(event);
			}
		}
	}
}

/**
 * Navigate to the previous session history item.
 *
 * @return <code>true</code> if the operation was successful and <code>false</code> otherwise
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @see #forward
 * 
 * @since 3.0
 */
public boolean back() {
	checkWidget();
	
	return OS.Browser_Back(internal_handle);
}

/**
 * Execute the specified script.
 *
 * <p>
 * Execute a script containing javascript commands in the context of the current document. 
 * 
 * @param script the script with javascript commands
 *  
 * @return <code>true</code> if the operation was successful and <code>false</code> otherwise
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the script is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @since eSWT 1.2
 */
public boolean execute (String script) {
	checkWidget();

	return OS.Browser_Execute(internal_handle, script);
}

/**
 * Navigate to the next session history item.
 *
 * @return <code>true</code> if the operation was successful and <code>false</code> otherwise
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 * 
 * @see #back
 * 
 * @since 3.0
 */
public boolean forward() {
	checkWidget();
	
	return OS.Browser_Forward(internal_handle);
}

/**
 * Returns <code>true</code> if the receiver can navigate to the 
 * previous session history item, and <code>false</code> otherwise.
 *
 * @return the receiver's back command enabled state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @see #back
 */
public boolean isBackEnabled() {
	checkWidget();
	
	return OS.Browser_IsBackEnabled(internal_handle);
}

/**
 * Returns <code>true</code> if the receiver can navigate to the 
 * next session history item, and <code>false</code> otherwise.
 *
 * @return the receiver's forward command enabled state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @see #forward
 */
public boolean isForwardEnabled() {
	checkWidget();
	
	return OS.Browser_IsForwardEnabled(internal_handle);
}

/**
 * Returns the current URL.
 *
 * @return the current URL or an empty <code>String</code> if there is no current URL
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @see #setUrl
 * 
 * @since 3.0
 */
public String getUrl() {
	checkWidget();
	
	String result =  OS.Browser_GetURL(internal_handle);
	return (result == null) ? "" : result;
}

/**
 * Refresh the current page.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @since 3.0
 */
public void refresh() {
	checkWidget();
	
	OS.Browser_Refresh(internal_handle);
}

/**	 
 * Removes the listener.
 *
 * @param listener the listener
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 * 
 * @since 3.0
 */
public void removeLocationListener(LocationListener listener) {
	checkWidget();
	
	if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	if (locationListeners != null) locationListeners.remove(listener);
}

/**	 
 * Removes the listener.
 *
 * @param listener the listener
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 * 
 * @since 3.0
 */
public void removeProgressListener(ProgressListener listener) {
	checkWidget();
	
	if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	if (progressListeners != null) progressListeners.remove(listener);
}

/**	 
 * Removes the listener.
 *
 * @param listener the listener
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 * 
 * @since 3.0
 */
public void removeStatusTextListener(StatusTextListener listener) {
	checkWidget();
	
	if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	if (statusListeners != null) statusListeners.remove(listener);
}

/**	 
 * Removes the listener.
 *
 * @param listener the listener
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 * 
 * @since 3.0
 */
public void removeTitleListener(TitleListener listener) {
	checkWidget();
	
	if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	if (titleListeners != null) titleListeners.remove(listener);
}

/**
 * Renders HTML.
 * <p>
 * The html parameter is Unicode encoded since it is a java <code>String</code>.
 * As a result, the HTML meta tag charset should not be set. The charset is implied
 * by the <code>String</code> itself.
 * 
 * @param html the HTML content to be rendered
 *
 * @return true if the operation was successful and false otherwise.
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the html is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *  
 * @see #setUrl
 * 
 * @since 3.0
 */
public boolean setText(String html) {
	checkWidget();
	if (html == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

	String comp = html.toLowerCase();
	int idx; 
	idx = comp.indexOf("<html>");
	if(idx == -1)
		return false;
	idx = comp.indexOf("<body", idx+6);		// skip "<html>"
	int idx2 = comp.indexOf("<", idx+5);	// skip "<body"
	int idx3 = comp.indexOf(">", idx+5);
	if(idx2<idx3)
		return false;
	if(idx == -1)
		return false;
	idx = idx3;
	idx = comp.indexOf("</body>", idx+1);	// skip ">"
	if(idx == -1)
		return false;
	idx = comp.indexOf("</html>", idx+7);	// skip "</body>"
	if(idx == -1)
		return false;

	comp = null;

	return OS.Browser_SetText(internal_handle, html);
}

/**
 * Loads a URL.
 * 
 * @param url the URL to be loaded
 *
 * @return true if the operation was successful and false otherwise.
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the url is null</li>
 * </ul>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *  
 * @see #getUrl
 * 
 * @since 3.0
 */
public boolean setUrl(String url) {
	checkWidget();
	
	if (url == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	return OS.Browser_SetURL(internal_handle, url);
}

/**
 * Stop any loading and rendering activity.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS when called from the wrong thread</li>
 *    <li>ERROR_WIDGET_DISPOSED when the widget has been disposed</li>
 * </ul>
 *
 * @since 3.0
 */
public void stop() {
	checkWidget();
	
	OS.Browser_Stop(internal_handle);
}



protected void removeInternalFilter(){
	getDisplay().removeFilter(SWT.Dispose, disposeListener);
}

}