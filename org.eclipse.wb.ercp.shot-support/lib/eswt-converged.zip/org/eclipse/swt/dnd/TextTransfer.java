/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;

import com.ibm.ugl.eswt.OS;

/**
 * The class <code>TextTransfer</code> provides a platform specific mechanism 
 * for converting plain text represented as a java <code>String</code> 
 * to a platform specific representation of the data and vice versa.
 * 
 * <p>An example of a java <code>String</code> containing plain text is shown 
 * below:</p>
 * 
 * <code><pre>
 *     String textData = "Hello World";
 * </code></pre>
 * 
 * @see Transfer
 */
public class TextTransfer extends ByteArrayTransfer {

	private static TextTransfer instance;
	private int[] ids;
	
/**
 * Returns the singleton instance of the TextTransfer class.
 *
 * @return the singleton instance of the TextTransfer class
 */
public static TextTransfer getInstance() {
	if (instance == null) {
		instance = new TextTransfer();
	} 
	return instance;
}

private TextTransfer() {
	
}

/**
 * This implementation of <code>javaToNative</code> converts plain text
 * represented by a java <code>String</code> to a platform specific representation.
 * 
 * @param object a java <code>String</code> containing text
 * @param transferData an empty <code>TransferData</code> object; this object
 *  will be filled in on return with the platform specific format of the data
 *  
 * @see Transfer#javaToNative
 */
public void javaToNative (Object object, TransferData transferData){
	if (isSupportedType(transferData) && (object instanceof String)) {
		transferData.result = 1;
		transferData.data = object;
	}
}

/**
 * This implementation of <code>nativeToJava</code> converts a platform specific 
 * representation of plain text to a java <code>String</code>.
 * 
 * @param transferData the platform specific representation of the data to be converted
 * @return a java <code>String</code> containing text if the conversion was successful; otherwise null
 * 
 * @see Transfer#nativeToJava
 */
public Object nativeToJava(TransferData transferData){
	if (isSupportedType(transferData) && (transferData.data instanceof String)) {
		transferData.result = 1;
		return transferData.data;
	} else {
		return null;
	}
}

protected int[] getTypeIds(){
	if (ids == null) {
		ids = com.ibm.ugl.eswt.expanded.OS.Clipboard_GetStringIds();
	}
	return ids;
}

protected String[] getTypeNames(){
	SWT.error(SWT.ERROR_NOT_IMPLEMENTED);
	return null;
}

boolean getNativeData(TransferData data) {
	String string = OS.Clipboard_GetText();
	if (data != null) {
		data.data = string;
		return true;
	}
	return false;
}

void setNativeData(TransferData tranfer) {
	if (tranfer.data instanceof String) {
		OS.Clipboard_SetText((String)tranfer.data);
	}
}

}
