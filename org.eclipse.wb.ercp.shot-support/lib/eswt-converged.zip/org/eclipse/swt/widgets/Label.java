/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

 
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;

import com.ibm.ugl.eswt.OS;

/**
 * Instances of this class represent a non-selectable
 * user interface object that displays a string or image.
 * When SEPARATOR is specified, displays a single
 * vertical or horizontal line.
 * <dl>
 * <dt><b>Styles:</b></dt>
 * <dd>SEPARATOR, HORIZONTAL, VERTICAL</dd>
 * <dd>SHADOW_IN, SHADOW_OUT, SHADOW_NONE</dd>
 * <dd>CENTER, LEFT, RIGHT, WRAP</dd>
 * <dt><b>Events:</b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * Note: Only one of SHADOW_IN, SHADOW_OUT and SHADOW_NONE may be specified.
 * SHADOW_NONE is a HINT. Only one of HORIZONTAL and VERTICAL may be specified.
 * Only one of CENTER, LEFT and RIGHT may be specified.
 * </p><p>
 * IMPORTANT: This class is intended to be subclassed <em>only</em>
 * within the SWT implementation.
 * </p>
 */

public class Label extends Control {
	
	private Image image;
	private String text;
	
/**
 * Constructs a new instance of this class given its parent
 * and a style value describing its behavior and appearance.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a composite control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT#SEPARATOR
 * @see SWT#HORIZONTAL
 * @see SWT#VERTICAL
 * @see SWT#SHADOW_IN
 * @see SWT#SHADOW_OUT
 * @see SWT#SHADOW_NONE
 * @see SWT#CENTER
 * @see SWT#LEFT
 * @see SWT#RIGHT
 * @see SWT#WRAP
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public Label(Composite parent, int style) {
	super(parent, checkStyle(style));
	text = "";
}

static int checkStyle(int style) {
	if ((style & SWT.SEPARATOR) != 0) {
		style = checkBits (style, SWT.VERTICAL, SWT.HORIZONTAL, 0, 0, 0, 0);
		return checkBits (style, SWT.SHADOW_OUT, SWT.SHADOW_IN, SWT.SHADOW_NONE, 0, 0, 0);
	}
	return checkBits(style, SWT.LEFT, SWT.CENTER, SWT.RIGHT, 0, 0, 0);
}

protected int internal_getNativeStyle(){
    
    int nativeStyle = super.internal_getNativeStyle();
    
	if ((internal_style & SWT.SEPARATOR) != 0) {

		// SWT.VERTICAL, SWT.HORIZONTAL
		if ((internal_style & SWT.VERTICAL) != 0) {
			nativeStyle |= OS.STYLE_VERTICAL;
		}
		else if ((internal_style & SWT.HORIZONTAL) != 0) {
			nativeStyle |= OS.STYLE_HORIZONTAL;
		}
		
		// SWT.SHADOW_OUT, SWT.SHADOW_IN, SWT.SHADOW_NONE
		if ((internal_style & SWT.SHADOW_IN) != 0) {
			nativeStyle |= OS.STYLE_SHADOW_IN;
		}
		else if ((internal_style & SWT.SHADOW_OUT) != 0) {
			nativeStyle |= OS.STYLE_SHADOW_OUT;
		}
		else if ((internal_style & SWT.SHADOW_NONE) != 0) {
			nativeStyle |= OS.STYLE_SHADOW_NONE;
		}
		
	}
	else {
		
		// Always top-align label text.
		nativeStyle |= OS.STYLE_TOP;
		
		// SWT.WRAP
		if ((internal_style & SWT.WRAP) != 0) {
			nativeStyle |= OS.STYLE_WRAP;
		}
		
	}
	return nativeStyle;
    
}

protected void internal_createHandle(int index) {

	int nativeStyle = internal_getNativeStyle();

	if ((internal_style & SWT.SEPARATOR) != 0) {
		
		internal_handle = OS.Separator_New(internal_parent.internal_handle,nativeStyle);
	}
	else {
		
		internal_handle = OS.Label_New(internal_parent.internal_handle,nativeStyle);

		// SWT.LEFT, SWT.CENTER, SWT.RIGHT
		setNativeAlignment();
	}
}

/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Control#computeSize(int, int, boolean)
 */
public Point computeSize(int wHint, int hHint, boolean changed) {
	if ((wHint != SWT.DEFAULT) && ((internal_style & SWT.WRAP) == SWT.WRAP)) {
		checkWidget();
		int[] pointArray = OS.Label_GetMinimumSize(internal_handle, wHint);
		return new Point(pointArray[OS.INDEX_X],pointArray[OS.INDEX_Y]);
	} else {
		return super.computeSize(wHint, hHint, changed);
	}
}

/**
 * Returns a value which describes the position of the
 * text or image in the receiver. The value will be one of
 * <code>LEFT</code>, <code>RIGHT</code> or <code>CENTER</code>
 * unless the receiver is a <code>SEPARATOR</code> label, in 
 * which case, <code>NONE</code> is returned.
 *
 * @return the alignment 
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getAlignment() {
	checkWidget();
	if ((internal_style & SWT.SEPARATOR) != 0) return SWT.NONE;
	return (internal_style & (SWT.LEFT | SWT.CENTER | SWT.RIGHT));
}

/**
 * Returns the receiver's image if it has one, or null
 * if it does not.
 *
 * @return the receiver's image
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Image getImage() {
	checkWidget();
	return image;
}

/**
 * Returns the receiver's text, which will be an empty
 * string if it has never been set or if the receiver is
 * a <code>SEPARATOR</code> label.
 *
 * @return the receiver's text
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public String getText() {
	checkWidget();
	if ((internal_style & SWT.SEPARATOR) != 0) return "";
	return text;
}

protected void releaseWidget() {
	super.releaseWidget();
	image = null;
}

/**
 * Controls how text and images will be displayed in the receiver.
 * The argument should be one of <code>LEFT</code>, <code>RIGHT</code>
 * or <code>CENTER</code>.  If the receiver is a <code>SEPARATOR</code>
 * label, the argument is ignored and the alignment is not changed.
 *
 * @param alignment the new alignment 
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setAlignment(int alignment) {
	checkWidget();
	if ((internal_style & SWT.SEPARATOR) != 0) return;
	if ((alignment & (SWT.LEFT | SWT.RIGHT | SWT.CENTER)) == 0) return;
	internal_style &= ~(SWT.LEFT | SWT.RIGHT | SWT.CENTER);
	internal_style |= alignment & (SWT.LEFT | SWT.RIGHT | SWT.CENTER);
	setNativeAlignment();
}

private void setNativeAlignment() {
	int alignment = OS.STYLE_LEAD;
	if ((internal_style & SWT.RIGHT) == SWT.RIGHT) alignment = OS.STYLE_TRAIL;
	if ((internal_style & SWT.CENTER) == SWT.CENTER) alignment = OS.STYLE_CENTER;
	OS.Label_SetAlignment(internal_handle,alignment);
}

public boolean setFocus() {
	checkWidget();
	return false;
}

/**
 * Sets the receiver's image to the argument, which may be
 * null indicating that no image should be displayed.
 *
 * @param image the image to display on the receiver (may be null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the image has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setImage(Image image) {
	checkWidget();
	this.image = image;
	int imageHandle = (image == null) ? 0 : image.internal_handle;
	// Passing 0 tells the native widget to stop displaying the image,
	// which is appropriate when the new image is null.
	OS.Label_SetImage(internal_handle,imageHandle);  
}

/**
 * Sets the receiver's text.
 * <p>
 * This method sets the widget label.  The label may include
 * the mnemonic character and line delimiters.
 * </p>
 * <p>
 * Mnemonics are indicated by an '&amp' that causes the next
 * character to be the mnemonic.  When the user presses a
 * key sequence that matches the mnemonic, focus is assigned
 * to the control that follows the label. On most platforms,
 * the mnemonic appears underlined but may be emphasised in a
 * platform specific manner.  The mnemonic indicator character
 *'&amp' can be escaped by doubling it in the string, causing
 * a single '&amp' to be displayed.
 * </p>
 * 
 * @param string the new text
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the text is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setText(String string) {
	checkWidget();
	if (string == null) error(SWT.ERROR_NULL_ARGUMENT);
	if ((internal_style & SWT.SEPARATOR) != 0) return;
	text = string;
	OS.Label_SetText(internal_handle,string);
	// Passing 0 tells the native widget to stop displaying the image,
	// and since setText is the last call made, we should display text.
	OS.Label_SetImage(internal_handle,0);  
}

boolean isTabGroup() {
	return false;
}
boolean isTabItem () {
	return false;
}

}
