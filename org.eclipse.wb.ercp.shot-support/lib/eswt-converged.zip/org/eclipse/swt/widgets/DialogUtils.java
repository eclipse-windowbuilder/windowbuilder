/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

import org.eclipse.swt.SWT;

import com.ibm.ugl.eswt.OS;

class DialogUtils {
	
	static String getNativeTitle(Dialog dialog) {
		synchronized (dialog) {
			if ((dialog.title == null) || dialog.title.equals("")) {
				return null;
			} else {
				return dialog.title;
			}
		}	
	}
	
	static int getNativeModalityStyle(Dialog dialog) {
		// Convert the modality style
		if ((dialog.style & SWT.SYSTEM_MODAL) == SWT.SYSTEM_MODAL) return OS.STYLE_SYSTEM_MODAL;
		if ((dialog.style & SWT.APPLICATION_MODAL) == SWT.APPLICATION_MODAL) return OS.STYLE_APPLICATION_MODAL;
		if ((dialog.style & SWT.PRIMARY_MODAL) == SWT.PRIMARY_MODAL) return OS.STYLE_PRIMARY_MODAL;
		return OS.STYLE_MODELESS;		
	}

}
