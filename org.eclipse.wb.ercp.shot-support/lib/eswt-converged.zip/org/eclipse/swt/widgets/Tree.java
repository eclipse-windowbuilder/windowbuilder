/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

import java.util.Vector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.Point;

import com.ibm.ugl.eswt.expanded.OS;

/**
 * Instances of this class provide a selectable user interface object
 * that displays a hierarchy of items and issue notification when an
 * item in the hierarchy is selected.
 * <p>
 * The item children that may be added to instances of this class
 * must be of type <code>TreeItem</code>.
 * </p><p>
 * Note that although this class is a subclass of <code>Composite</code>,
 * it does not make sense to add <code>Control</code> children to it,
 * or set a layout on it.
 * </p><p>
 * <dl>
 * <dt><b>Styles:</b></dt>
 * <dd>SINGLE, MULTI, CHECK</dd>
 * <dt><b>Events:</b></dt>
 * <dd>Selection, DefaultSelection, Collapse, Expand</dd>
 * </dl>
 * <p>
 * Note: Only one of the styles SINGLE and MULTI may be specified.
 * </p><p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */
public class Tree extends Composite {

	// All the items in the tree, stored by their id.
	TreeItem[] treeItems = new TreeItem[4];
	// The root items of the Tree.
	TreeItem[] children = new TreeItem[4];
	// Counter for assinging unique ids to TreeItems.
	static int idCounter = 0;
	
	static boolean eventsRegistered = false;

	// SWT.VIRTUAL Style support
	boolean isVirtual = false;
	private int itemCount = 0;

/**
 * Constructs a new instance of this class given its parent
 * and a style value describing its behavior and appearance.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a composite control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT#SINGLE
 * @see SWT#MULTI
 * @see SWT#CHECK
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public Tree (Composite parent, int style) {
	super(parent, checkStyle(style));
	if((style & SWT.VIRTUAL) != 0)
		isVirtual = true;
}

/**
 * Add a new child to the Tree's list of children.  Add the item at the
 * given index.  An index of -1 implies that the child should be added
 * to the end of the Tree's list of children.
 */
void addChild(TreeItem item, int index) {
	if(this.isVirtual) {
		return;
	}
	int size = children.length;
	if (getNumChildren() == size) {
		// need to expand the children array
		TreeItem [] newItems = new TreeItem [size + 4];
		System.arraycopy (children, 0, newItems, 0, size);
		children = newItems;
	}
	if (index == -1) {
		// add the item as the last item
		int i = getNumChildren();
		children[i] = item;
	} else if (children[index] == null) {
		// the current index is free in the children array
		children[index] = item;
	} else {
		// shift the items so that the new item is at the
		// appropriate index
		int num = getNumChildren();
		for (int i=num-1; i>=index; i--) {
			children[i+1] = children[i];
		}
		children[index] = item;
	}
}

/**
 * Adds the listener to the collection of listeners who will
 * be notified when the receiver's selection changes, by sending
 * it one of the messages defined in the <code>SelectionListener</code>
 * interface.
 * <p>
 * When <code>widgetSelected</code> is called, the item field of the event object is valid.
 * If the reciever has <code>SWT.CHECK</code> style set and the check selection changes,
 * the event object detail field contains the value <code>SWT.CHECK</code>.
 * <code>widgetDefaultSelected</code> is typically called when an item is double-clicked.
 * The item field of the event object is valid for default selection, but the detail field is not used.
 * </p>
 *
 * @param listener the listener which should be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SelectionListener
 * @see #removeSelectionListener
 * @see SelectionEvent
 */
public void addSelectionListener(SelectionListener listener) {
	checkWidget ();
	if (listener == null) error (SWT.ERROR_NULL_ARGUMENT);
	TypedListener typedListener = new TypedListener (listener);
	addListener (SWT.Selection, typedListener);
	addListener (SWT.DefaultSelection, typedListener);
}

/**
 * Adds the listener to the collection of listeners who will
 * be notified when an item in the receiver is expanded or collapsed
 * by sending it one of the messages defined in the <code>TreeListener</code>
 * interface.
 *
 * @param listener the listener which should be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see TreeListener
 * @see #removeTreeListener
 */
public void addTreeListener(TreeListener listener) {
	checkWidget ();
	if (listener == null) error (SWT.ERROR_NULL_ARGUMENT);
	TypedListener typedListener = new TypedListener (listener);
	addListener (SWT.Expand, typedListener);
	addListener (SWT.Collapse, typedListener);
}

/**
 * Adjust the specified style so that it contains only valid styles
 * for this widget.
 */
static int checkStyle(int style) {
	/*
	* In Windows, it is not possible to create a tree that scrolls 
	* and does not have scroll bars, so override the style to include 
	* the H_SCROLL and V_SCROLL bits so that the SWT style will match 
	* the widget that Windows creates.
	*/
	if (OS.Tree_IncludeScrollbars()) style |= SWT.H_SCROLL | SWT.V_SCROLL;
	style = checkBits (style, SWT.SINGLE, SWT.MULTI, 0, 0, 0, 0);
	return style;
}

/**
 * Create the widget.
 */
protected void internal_createHandle (int index) {
	if (!eventsRegistered) {
		Display d = getDisplay();
		com.ibm.ugl.p3ml.OS.Display_RegisterCallback(d.internal_handle, OS.CALLBACK_TREE, "org/eclipse/swt/widgets/Tree", "treeCallback");
		eventsRegistered = true;
	}
	
	internal_handle = OS.Tree_New(internal_parent.internal_handle, internal_getNativeStyle());
}
protected int internal_getNativeStyle() {
	int nativeStyle = super.internal_getNativeStyle();
		
	if ((internal_style & SWT.SINGLE) != 0) {
		nativeStyle |= OS.STYLE_SINGLE;
	}
	if ((internal_style & SWT.MULTI) != 0) {
		nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_MULTI;
	}
	if ((internal_style & SWT.CHECK) != 0) {
		nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_CHECK;
	}
	if ((internal_style & SWT.VIRTUAL) != 0) {
		nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_VIRTUAL;
	}
	return nativeStyle;
}
/**
 * Return whether or not the Tree is in single select mode.
 */
boolean isSingleSelect() {
	return (internal_style & SWT.SINGLE) != 0;
}
/**
 * Return whether or not the Tree is in multi select mode.
 */
boolean isMultiSelect() {
	return (internal_style & SWT.MULTI) != 0;
}

/**
 * Deselects all selected items in the receiver.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void deselectAll () {
	checkWidget ();
	if (isSingleSelect()) {
		TreeItem[] items = getSelection();
		if (items.length == 0) return;
		OS.TreeItem_SetSelected(items[0].internal_handle, false);
	} else {
		OS.Tree_SetAllSelected(internal_handle, false);
	}
}

/**
 * Returns the item at the given point in the receiver
 * or null if no such item exists. The point is in the
 * coordinate system of the receiver.
 *
 * @param point the point used to locate the item
 * @return the item at the given point
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the point is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TreeItem getItem (Point point) {
	checkWidget ();
	if (point == null) error (SWT.ERROR_NULL_ARGUMENT);
	int itemId = OS.Tree_GetItemAt(this.internal_handle, point.x, point.y);
	if (itemId == -1) return null;
	return treeItems[itemId];
}

/**
 * Returns the number of items contained in the receiver
 * that are direct item children of the receiver.  The
 * number that is returned is the number of roots in the
 * tree.
 *
 * @return the number of items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getItemCount () {
	return getNumChildren();
}

/**
 * Returns the height of the area which would be used to
 * display <em>one</em> of the items in the tree.
 *
 * @return the height of one item
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getItemHeight () {
	checkWidget();
	return OS.Tree_GetItemHeight(internal_handle);
}

/**
 * Returns a (possibly empty) array of items contained in the
 * receiver that are direct item children of the receiver.  These
 * <p>
 * Note: This is not the actual structure used by the receiver
 * to maintain its list of items, so modifying the array will
 * not affect the receiver. 
 * </p>
 *
 * @return the items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TreeItem [] getItems () {
	checkWidget();
	int size = getNumChildren();
	if (size == 0) return new TreeItem[0];
	TreeItem[] items = new TreeItem[size];
	System.arraycopy (children, 0, items, 0, size);
	return items;
}
TreeItem[] getTreeItems() {
	TreeItem[] treeItemsCopy = new TreeItem[treeItems.length];
	System.arraycopy (treeItems, 0, treeItemsCopy, 0, treeItems.length);
	return treeItemsCopy;
}
/**
 * Return the current number of root items that are defined for the Tree.
 */
int getNumChildren() {
	int size = 0;
	for (int i=0; i<children.length; i++) {
		if (children[i] == null) {
			break;
		}
		size++;
	}
	return size;
}
/**
 * TreeItems are assigned a unique id as a way to identify the items
 * to the platform.  For platform API calls that return items, the platform
 * will return item ids and these ids will be mapped to particular TreeItems.
 */
void assignId(TreeItem item) {
	int id = 0;
	// look for the first available slot
	while (id < treeItems.length && treeItems [id] != null) id++;
	if (id == treeItems.length) {
		// need to expand the array
		TreeItem [] newItems = new TreeItem [treeItems.length + 4];
		System.arraycopy (treeItems, 0, newItems, 0, treeItems.length);
		treeItems = newItems;
	}
	treeItems[id] = item;
	item.id = id;
}

/**
 * Returns the receiver's parent item, which must be a
 * <code>TreeItem</code> or null when the receiver is a
 * root.
 *
 * @return the receiver's parent item
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TreeItem getParentItem () {
	checkWidget();
	return null;
}

/**
 * Returns an array of <code>TreeItem</code>s that are currently
 * selected in the receiver. The order of the items is unspecified.
 * An empty array indicates that no items are selected. 
 * <p>
 * Note: This is not the actual structure used by the receiver
 * to maintain its selection, so modifying the array will
 * not affect the receiver. 
 * </p>
 * @return an array representing the selection
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TreeItem [] getSelection () {
	checkWidget();
	Vector selectedItems = new Vector();
	for (int i=0; i<treeItems.length; i++) {
		if (treeItems[i] != null) {
			if (OS.TreeItem_IsSelected(treeItems[i].internal_handle)) {
				selectedItems.add(treeItems[i]);
				if (isSingleSelect()) {
					break;
				}
			}
		}
	}
	return (TreeItem[])selectedItems.toArray(new TreeItem[] {});
}

/**
 * Returns the number of selected items contained in the receiver.
 *
 * @return the number of selected items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getSelectionCount () {
	checkWidget();
	if (isSingleSelect()) {
		TreeItem[] items = getSelection();
		return items.length;
	} else {
		int count = 0;
		for (int i=0; i<treeItems.length; i++) {
			if (treeItems[i] != null) {
				if (OS.TreeItem_IsSelected(treeItems[i].internal_handle)) {
					count++;
				}
			}
		}
		return count;
	}
}

/**
 * Returns the item which is currently at the top of the receiver.
 * This item can change when items are expanded, collapsed, scrolled
 * or new items are added or removed.
 *
 * @return the item at the top of the receiver 
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.1
 */
public TreeItem getTopItem () {
	checkWidget ();
	int itemId = OS.Tree_GetTopItem(internal_handle);
	if (itemId == -1) return null;
	return treeItems[itemId];
}
/**
 * Remove the item from the Tree's list of treeItems. 
 */
void itemDeleted(TreeItem item) {
	treeItems[item.id] = null;
}
/**
 *  
 */
Point minimumSize() {
	int width = 0, height = 0;
	int[] pointArray = com.ibm.ugl.eswt.OS.Control_GetMinimumSize(internal_handle);
	width = pointArray[com.ibm.ugl.eswt.OS.INDEX_X];
	height = pointArray[com.ibm.ugl.eswt.OS.INDEX_Y];
	return new Point(width, height);
}
/**
 *  
 */
protected void releaseWidget () {
	for (int i=0; i<treeItems.length; i++) {
		TreeItem item = treeItems [i];
		if (item != null && !item.isDisposed ()) {
			item.remove ();
		}
	}
	super.releaseWidget();
}
/**
 * Removes all of the items from the receiver.
 * <p>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void removeAll () {
	checkWidget ();
	for (int i=0; i<treeItems.length; i++) {
		TreeItem item = treeItems [i];
		if (item != null) {
			item.remove();
		}
	}
	OS.Tree_RemoveAll(internal_handle);
	treeItems = new TreeItem[4];
	children = new TreeItem[4];
	idCounter = 0;
}
/**
 * Remove the item from the Tree's list of children. 
 */
void removeChild(TreeItem item) {
	int childIndex = -1;
	int numChildren = getNumChildren();
	for (int i=0; i<numChildren; i++) {
		if (children[i] == item) {
			childIndex = i;
			break;
		}
	}
	if (childIndex == -1) return; // child not found
	int size = children.length;
	TreeItem [] newItems = new TreeItem [size];
	System.arraycopy (children, 0, newItems, 0, childIndex);
	System.arraycopy (children, childIndex + 1, newItems, childIndex, size - (childIndex + 1));
	children = newItems;
}
/**
 * Removes the listener from the collection of listeners who will
 * be notified when the receiver's selection changes.
 *
 * @param listener the listener which should no longer be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SelectionListener
 * @see #addSelectionListener
 */
public void removeSelectionListener (SelectionListener listener) {
	checkWidget ();
	if (listener == null) error (SWT.ERROR_NULL_ARGUMENT);
	eventTable.unhook (SWT.Selection, listener);
	eventTable.unhook (SWT.DefaultSelection, listener);	
}

/**
 * Removes the listener from the collection of listeners who will
 * be notified when items in the receiver are expanded or collapsed..
 *
 * @param listener the listener which should no longer be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see TreeListener
 * @see #addTreeListener
 */
public void removeTreeListener(TreeListener listener) {
	checkWidget ();
	if (listener == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (eventTable == null) return;
	eventTable.unhook (SWT.Expand, listener);
	eventTable.unhook (SWT.Collapse, listener);
}

/**
 * Selects all of the items in the receiver.
 * <p>
 * If the receiver is single-select, do nothing.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void selectAll () {
	checkWidget();
	if (isSingleSelect()) return;
	OS.Tree_SetAllSelected(internal_handle, true);
}

/**
 * Sets the receiver's selection to be the given array of items.
 * The current selection is cleared before the new items are selected.
 * <p>
 * Items that are not in the receiver are ignored.
 * If the receiver is single-select and multiple items are specified,
 * then all items are ignored.
 *
 * @param items the array of items
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the array of items is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if one of the items has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Tree#deselectAll()
 */
public void setSelection (TreeItem [] items) {
	checkWidget ();
	if (items == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (items.length == 0 || (isSingleSelect() && items.length > 1)) {
		deselectAll();
		return;
	}
	if (items.length > 0) {
		OS.Tree_SetFocusItem(internal_handle, items[0].internal_handle);
	}
	for (int i=0; i<treeItems.length; i++) {
		TreeItem currentItem = treeItems[i];
		if (currentItem != null) {
			boolean selectItem = false;
			for (int j=0; j<items.length; j++) {
				if (items[j] == currentItem) {
					selectItem = true;
					break;
				}
			}
			boolean itemSelected = OS.TreeItem_IsSelected(currentItem.internal_handle);
			if (selectItem) {
				if (!itemSelected) {
					OS.TreeItem_SetSelected(currentItem.internal_handle, true);
				}
			} else {
				if (itemSelected) {
					OS.TreeItem_SetSelected(currentItem.internal_handle, false);
				}
			}
		}
	}
}

/**
 * Sets the item which is currently at the top of the receiver.
 * This item can change when items are expanded, collapsed, scrolled
 * or new items are added or removed.
 *
 * @param item the item to be shown
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the item is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if the item has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Tree#getTopItem()
 * 
 * @since 2.1
 */
public void setTopItem (TreeItem item) {
	checkWidget ();
	if (item == null) SWT.error (SWT.ERROR_NULL_ARGUMENT);
	if (item.isDisposed ()) SWT.error (SWT.ERROR_INVALID_ARGUMENT);
	OS.Tree_SetTopItem(internal_handle, item.internal_handle);
}

/**
 * Shows the item.  If the item is already showing in the receiver,
 * this method simply returns.  Otherwise, the items are scrolled
 * and expanded until the item is visible.
 *
 * @param item the item to be shown
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the item is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if the item has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Tree#showSelection()
 */
public void showItem (TreeItem item) {
	checkWidget ();
	if (item == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (item.isDisposed ()) error(SWT.ERROR_INVALID_ARGUMENT);
	OS.Tree_ShowItem(internal_handle, item.internal_handle);
}

/**
 * Shows the selection.  If the selection is already showing in the receiver,
 * this method simply returns.  Otherwise, the items are scrolled until
 * the selection is visible.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Tree#showItem(TreeItem)
 */
public void showSelection () {
	// Show the visibly first selected item in the Tree.
	checkWidget ();
	TreeItem itemToShow = null;
	if (isSingleSelect()) {
		TreeItem[] selected = getSelection();
		if (selected.length == 0) return;
		itemToShow = selected[0];
	} else {
		// In the multi-select case, show the item that
		// has focus if it is selected.
		int id = OS.Tree_GetFocusItem(internal_handle);
		if (id != -1) {
			TreeItem item = treeItems[id];
			if (OS.TreeItem_IsSelected(item.internal_handle)) {
				itemToShow = item;
			}
		} 
		if (itemToShow == null) {
			TreeItem[] selected = getSelection();
			if (selected.length == 0) return;
			itemToShow = selected[0];
		}
	}
	if (itemToShow != null) showItem(itemToShow);
}

/**
 * Sets the number of root-level items contained in the receiver.
 *
 * @param count the number of items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 3.2
 */
public void setItemCount (int count) {
	checkWidget ();
	if(!isVirtual) {
		return;
	}
	
	int itemCount;
	itemCount = this.itemCount;
	if (count == itemCount) return;

	int index = count;
	while (index < itemCount) {
		TreeItem item = children [index];
		if (item != null && !item.isDisposed())
			item.dispose();
		index++;
	}
	int length = Math.max (4, (count + 3) / 4 * 4);
	TreeItem [] newItems = new TreeItem [length];
	System.arraycopy (children, 0, newItems, 0, Math.min (count, itemCount));
	children = newItems;
	
	index = this.itemCount;
	while (index < count) {
		children [index] = new TreeItem(this, SWT.BORDER);
		index++;
	}
	
	this.itemCount = count;
}

/**
 * Searches the receiver's list starting at the first item
 * (index 0) until an item is found that is equal to the 
 * argument, and returns the index of that item. If no item
 * is found, returns -1.
 *
 * @param item the search item
 * @return the index of the item
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the item is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if the item has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since eRCP 1.3
 */
public int indexOf(TreeItem item) {
	checkWidget ();
	if (item == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (item.isDisposed()) error(SWT.ERROR_INVALID_ARGUMENT);

	int idx = -1;
	for(int i=0; i<children.length && idx == -1; i++) {
		if(children[i] == null)
			continue;
		TreeItem child = children[i];
		if(child.id == item.id)
			return i;
		idx = child.indexOf(item);
	}
	
	return idx;
}

/*
 * Handle tree events. 
 */
private void treeCallback(int itemId, int detail, int type) {
	Event event = new Event();
	if (itemId != -1) event.item = treeItems[itemId];
	else event.item = null;
	switch (type) {
		case OS.EVENT_TREE_SELECTION:
			if (detail != 0) event.detail = SWT.CHECK;
			postEvent(SWT.Selection, event);
			break;

		case OS.EVENT_TREE_ACTION:
			if (detail != 0) event.detail = SWT.CHECK;
			postEvent(SWT.DefaultSelection, event);
			break;

		case OS.EVENT_TREE_COLLAPSE:
			sendEvent(SWT.Collapse, event);
			break;

		case OS.EVENT_TREE_EXPAND:
			if(isVirtual) {
				if(treeItems[itemId] != null) {
					treeItems[itemId].createRemainItem();
				}
			}
			sendEvent(SWT.Expand, event);
			break;
		case OS.EVENT_TREE_GETDISPINFO:
			if(treeItems[itemId].getText() == null || treeItems[itemId].getText().equals("")) {
				event.index = indexOf(treeItems[itemId]);
				if(event.index != -1) {
					sendEvent(SWT.SetData, event);
				}
			}
			break;
	}
}
boolean isTrueComposite() {
	return false;
}

// for smartphone traverse
private TreeItem getFirstRootTreeItem() {
	for(int i=0; i<children.length; i++) {
		if(children[i] != null) {
			return children[i];
		}
	}
	return null;
}
private TreeItem getLastRootTreeItem() {
	for(int i=children.length-1; i>=0; i--) {
		if(children[i] != null) {
			return children[i];
		}
	}
	return null;
}
private boolean isExpandedLastNode(TreeItem root, TreeItem focusItem) {
	if(root == null || focusItem == null)
		return false;

	TreeItem lastNode = root;
	while(lastNode.getExpanded()) {
		TreeItem item = null;
		TreeItem[] items = lastNode.getItems();
		for(int i=items.length-1; i>=0; i--) {
			if(items[i] != null) {
				item = items[i];
				break;
			}
		}
		if(item == null) {
			break;
		}
		lastNode = item;
	}
	if(lastNode == focusItem)
		return true;
	else
		return false;
}

public boolean allowTraverseByArrowKey(Event event) {
	int focus;
	switch (event.keyCode) {
		case SWT.ARROW_UP :
			focus = OS.Tree_GetFocusItem(internal_handle);
			if (focus == -1) {
				return true;
			} 
			if (focus >= treeItems.length) {
				return false;
			}
			TreeItem first = getFirstRootTreeItem();
			if(treeItems[focus] == null || treeItems[focus] == first) {
				return true;
			}
			break;
//		case SWT.ARROW_LEFT :
//			if(selection == null)
//				return true;
//			if(selection.getExpanded())
//				return false;
//			if(selection.getParentItem() == null)
//				return true;
//			break;
		case SWT.ARROW_DOWN :
			focus = OS.Tree_GetFocusItem(internal_handle);
			if (focus == -1) {
				if(getNumChildren() == 0)
					return true;
				else
					return false;
			} 
			if (focus >= treeItems.length) {
				return false;
			}
			TreeItem last = getLastRootTreeItem();
			if(isExpandedLastNode(last, treeItems[focus])) {
				return true;
			}
			break;
//		case SWT.ARROW_RIGHT :
//			if(selection == null)
//				return true;
//			if(selection.getItemCount() == 0)
//				return true;
//			break;
	}
	return false;
}

protected boolean traverse(Event event) {
	if (isDisposed()) return false;
	if(allowTraverseByArrowKey(event)) {
		return traverseByArrowKey(event);
	}
	return super.traverse(event);
}

}
