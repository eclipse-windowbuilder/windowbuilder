/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

import org.eclipse.swt.SWT;

import com.ibm.ugl.eswt.OS;

/**
 * A native scrollbar wrapper which is used by ScrollBar
 * and Slider.  It allows the two very similar classes
 * to share functionality.  This class is for internal use only.
 */
class NativeScrollbar {
	
	private int handle;
	private boolean ownsNativeWidget;
	
	NativeScrollbar(Widget widget, int parentHandle, int widgetHandle) {
		if (widgetHandle == 0) {
			handle = OS.Scrollbar_New(parentHandle);

			int orientation = 0;
			if ((widget.internal_style & SWT.HORIZONTAL) != 0) {
				orientation = OS.STYLE_HORIZONTAL;
			}
			else if ((widget.internal_style & SWT.VERTICAL) != 0) {
				orientation = OS.STYLE_VERTICAL;
			}
			OS.Scrollbar_SetOrientation(handle,orientation);	
			ownsNativeWidget = true;
		}
		else {
			handle = widgetHandle;
			ownsNativeWidget = false;
		}
	}
	
	/*
	 * Allows this class to be shared by ScrollBar and Slider.
	 * Every ScrollBar instance is owned by a Scrollable, while
	 * a Slider instance can be owned by anything.
	 */
	void releaseNativeWidget() {
		if (ownsNativeWidget) {
			OS.Widget_Dispose(handle);
			handle = 0;
		}
	}
	
	int getHandle() {
		return handle;
	}
	
	int getIncrement() {
		return OS.Adjustable_GetUnitIncrement(handle);
	}
	
	int getMaximum() {
		return OS.Adjustable_GetMaximum(handle);
	}
	
	int getMinimum() {
		return OS.Adjustable_GetMinimum(handle);
	}
	
	int getPageIncrement() {
		return OS.Adjustable_GetBlockIncrement(handle);
	}
	
	int getSelection() {
		return OS.Adjustable_GetValue(handle);
	}
	
	int getThumb() {
		return OS.Adjustable_GetVisibleAmount(handle);
	}
	
	void setIncrement(int value) {
		OS.Adjustable_SetUnitIncrement(handle,value);
	}
	
	void setMaximum(int value) {
		if (value < 0) return;
		int min = OS.Adjustable_GetMinimum(handle);
		if (value <= min) return;
		
		// Adjust the thumb size to be consistent
		// with the new minimum
		int thumb = OS.Adjustable_GetVisibleAmount(handle);
		if (min + thumb > value) {
			thumb = value - min;
			OS.Adjustable_SetVisibleAmount(handle, thumb);
		}
		
		// Adjust the value to be consistent with 
		// with the new minimum
		int sel = OS.Adjustable_GetValue(handle);
		int selMax = value - thumb;
		if (sel > selMax) OS.Adjustable_SetValue(handle, selMax);

		OS.Adjustable_SetMaximum(handle,value);
	}
	
	void setMinimum(int value) {
		if (value < 0) return;
		int max = OS.Adjustable_GetMaximum(handle);
		if (value >= max) return;

		// Adjust the thumb to be consistent with
		// the new maximum
		if (value + OS.Adjustable_GetVisibleAmount(handle) > max) {
			OS.Adjustable_SetVisibleAmount(handle, max - value);
		}

		// Adjust the selection to be consistent with
		// the new maximum
		if (OS.Adjustable_GetValue(handle) < value) {
			OS.Adjustable_SetValue(handle, value);
		}
		
		OS.Adjustable_SetMinimum(handle,value);
	}
	
	void setPageIncrement(int value) {
		OS.Adjustable_SetBlockIncrement(handle,value);
	}
	
	void setSelection(int value) {
		// Make sure the selection is not too
		// small
		int min = OS.Adjustable_GetMinimum(handle);
		if (value < min) value = min;
		
		// Make sure the new selection is not too 
		// large
		int thumb = OS.Adjustable_GetVisibleAmount(handle);
		int max = OS.Adjustable_GetMaximum(handle);
		int maxSel = max - thumb;
		if (value > maxSel) value = maxSel;
		
		OS.Adjustable_SetValue(handle,value);
	}
	
	void setThumb(int value) {
		if (value < 1) return;
		
		// Make sure the thumb is 
		// not too big
		int min = OS.Adjustable_GetMinimum(handle);
		int max = OS.Adjustable_GetMaximum(handle);
		if (value > (max - min)) {
			value = (max - min);
		}
		
		OS.Adjustable_SetVisibleAmount(handle,value);
		
		// Adjust the selection to be consistant with
		// the new thumb value
		int sel = OS.Adjustable_GetValue(handle);
		if (sel > (max - value)) {
			OS.Adjustable_SetValue(handle, max-value);
		}
	}
	
	void setValues(int selection, int minimum, int maximum, int thumb, int increment, int pageIncrement) {
		setMaximum(maximum);
		setMinimum(minimum);
		setThumb(thumb);
		setSelection(selection);
		setIncrement(increment);
		setPageIncrement(pageIncrement);
	}
	
}
