/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

 
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.graphics.*;

import com.ibm.ugl.eswt.expanded.OS;

/**
 * Instances of this class represent a selectable user interface object
 * that represents a hierarchy of tree items in a tree widget.
 * 
 * <dl>
 * <dt><b>Styles:</b></dt>
 * <dd>(none)</dd>
 * <dt><b>Events:</b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */

public class TreeItem extends Item {
	Tree tree;
	TreeItem parentItem;
	int id;
	TreeItem[] children = new TreeItem[0];
	Font font = null;
	int fgRGB = -1;
	int bgRGB = -1;

	// SWT.VIRTUAL Style support
	private int remainStart = 0;
	private int itemCount = 0;

/**
 * Constructs a new instance of this class given its parent
 * (which must be a <code>Tree</code> or a <code>TreeItem</code>)
 * and a style value describing its behavior and appearance.
 * The item is added to the end of the items maintained by its parent.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a tree control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public TreeItem (Tree parent, int style) {
	super (parent, style);
	this.tree = parent;
	createWidget(-1);
	parent.addChild(this, -1);
}

/**
 * Constructs a new instance of this class given its parent
 * (which must be a <code>Tree</code> or a <code>TreeItem</code>),
 * a style value describing its behavior and appearance, and the index
 * at which to place it in the items maintained by its parent.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a tree control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 * @param index the index to store the receiver in its parent
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public TreeItem (Tree parent, int style, int index) {
	super (parent, style);
	if (index < 0) error (SWT.ERROR_INVALID_RANGE);
	if (index > parent.getNumChildren()) error (SWT.ERROR_INVALID_RANGE);
	this.tree = parent;
	createWidget(index);
	parent.addChild(this, index);
}

/**
 * Constructs a new instance of this class given its parent
 * (which must be a <code>Tree</code> or a <code>TreeItem</code>)
 * and a style value describing its behavior and appearance.
 * The item is added to the end of the items maintained by its parent.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parentItem a tree control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public TreeItem (TreeItem parent, int style) {
	super (checkNull (parent), style);
	this.parentItem = parent;
	this.tree = parentItem.tree;
	createWidget(-1);
	parentItem.addChild(this, -1);
}

static TreeItem checkNull(TreeItem item) {
    if (item == null) error(SWT.ERROR_NULL_ARGUMENT);
    return item;
}

static Control checkNull(Control tree) {
    if (tree == null) error(SWT.ERROR_NULL_ARGUMENT);
    return tree;
}

/**
 * Constructs a new instance of this class given its parent
 * (which must be a <code>Tree</code> or a <code>TreeItem</code>),
 * a style value describing its behavior and appearance, and the index
 * at which to place it in the items maintained by its parent.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parentItem a tree control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 * @param index the index to store the receiver in its parent
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public TreeItem (TreeItem parent, int style, int index) {
	super (checkNull (parent), style);
	if (index < 0) error (SWT.ERROR_INVALID_RANGE);
	if (index > parent.getNumChildren()) error (SWT.ERROR_INVALID_RANGE);
	this.parentItem = parent;
	this.tree = parentItem.tree;
	createWidget(index);
	parentItem.addChild(this, index);
}
/**
 * Add a new child to the TreeItem's list of children.  Add the item at the
 * given index.  An index of -1 implies that the child should be added
 * to the end of the TreeItem's list of children.
 */
void addChild(TreeItem item, int index) {
	int size = children.length;
	if (getNumChildren() == size) {
		// need to expand the children array
		TreeItem [] newItems = new TreeItem [size + 4];
		System.arraycopy (children, 0, newItems, 0, size);
		children = newItems;
	}
	if (index == -1) {
		// add the item as the last item
		int i = getNumChildren();
		children[i] = item;
	} else if (children[index] == null) {
		// the current index is free in the children array
		children[index] = item;
	} else {
		// shift the items so that the new item is at the
		// appropriate index
		int num = getNumChildren();
		for (int i=num-1; i>=index; i--) {
			children[i+1] = children[i];
		}
		children[index] = item;
	}
}
/**
 * 
 */
void destroy () {
	destroyChildren ();
	OS.TreeItem_Delete(internal_handle);
	TreeItem parent = getParentItem();
	if (parent == null) {
		getTree().removeChild(this);
	} else {
		parent.removeChild(this);
	}
	tree.itemDeleted(this);
}
/**
 * 
 */
void destroyChildren () {
	TreeItem[] childItems = getItems();
	for (int i=0; i<childItems.length; i++) {
		TreeItem item = childItems [i];
		item.dispose();
	}
}

/**
 * Returns the receiver's background color.
 *
 * @return the background color
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0
 * 
 */
public Color getBackground () {
	checkWidget();
	if (bgRGB == -1) return tree.getBackground();
	RGB rgbObject = RGBUtils.fromRGBInt(bgRGB);
	return new Color(getDisplay(),rgbObject);
}

/**
 * Returns a rectangle describing the receiver's size and location
 * relative to its parent.
 *
 * @return the receiver's bounding rectangle
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Rectangle getBounds () {
	checkWidget ();
	int[] rect = OS.TreeItem_GetTextBounds(internal_handle);
	return new Rectangle(rect[com.ibm.ugl.p3ml.OS.INDEX_X],rect[com.ibm.ugl.p3ml.OS.INDEX_Y],rect[com.ibm.ugl.p3ml.OS.INDEX_WIDTH],rect[com.ibm.ugl.p3ml.OS.INDEX_HEIGHT]); 
}

/**
 * Returns <code>true</code> if the receiver is checked,
 * and false otherwise.  When the parent does not have
 * the <code>CHECK style, return false.
 * <p>
 *
 * @return the checked state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getChecked () {
	checkWidget ();
	if ((tree.internal_style & SWT.CHECK) == 0) return false;
	return OS.TreeItem_IsChecked(internal_handle);
}

/**
 * Returns <code>true</code> if the receiver is expanded,
 * and false otherwise.
 * <p>
 *
 * @return the expanded state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getExpanded () {
	checkWidget ();
	return OS.TreeItem_IsExpanded(internal_handle);
}

/**
 * Returns the font that the receiver will use to paint textual information for this item.
 *
 * @return the receiver's font
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 3.0
 */
public Font getFont () {
	checkWidget ();
	return (this.font == null) ? getParent().getFont () : this.font;
}

/**
 * Returns the foreground color that the receiver will use to draw.
 *
 * @return the receiver's foreground color
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0
 * 
 */
public Color getForeground () {
	checkWidget();
	if (fgRGB == -1) return tree.getForeground();
	RGB rgbObject = RGBUtils.fromRGBInt(fgRGB);
	return new Color(getDisplay(),rgbObject);
}

/**
 * Returns <code>true</code> if the receiver is grayed,
 * and false otherwise. When the parent does not have
 * the <code>CHECK style, return false.
 * <p>
 *
 * @return the grayed state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getGrayed () {
	checkWidget ();
	if ((tree.internal_style & SWT.CHECK) == 0) return false;
	return OS.TreeItem_IsGrayed(internal_handle);
}

/**
 * Returns the number of items contained in the receiver
 * that are direct item children of the receiver.
 *
 * @return the number of items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getItemCount () {
	checkWidget();
	if(tree.isVirtual)
		return this.itemCount;
	return getNumChildren();
}

/**
 * Returns a (possibly empty) array of <code>TreeItem</code>s which
 * are the direct item children of the receiver.
 * <p>
 * Note: This is not the actual structure used by the receiver
 * to maintain its list of items, so modifying the array will
 * not affect the receiver. 
 * </p>
 *
 * @return the receiver's items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TreeItem [] getItems () {
	checkWidget();
	int size = getNumChildren();
	if (size == 0) return new TreeItem[0];
	TreeItem[] items = new TreeItem[size];
	System.arraycopy (children, 0, items, 0, size);
	return items;
}
/**
 * Return the current number of child items that are defined for 
 * this TreeItem.
 */
int getNumChildren() {
	int size = 0;
	for (int i=0; i<children.length; i++) {
		if (children[i] == null) {
			break;
		} else {
			size++;
		}
	}
	return size;
}
/**
 * Returns the receiver's parent, which must be a <code>Tree</code>.
 *
 * @return the receiver's parent
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Tree getParent () {
	checkWidget();
	return tree;
}
/**
 * Return the Tree that contains this TreeItem.
 */
Tree getTree () {
	return tree;
}
boolean hasNativeEvents() {
	return false;
}
protected void internal_createHandle(int index) {
	int parentHandle;
	tree.assignId(this);
	if (parentItem == null) {
		parentHandle = tree.internal_handle;
	} else {
		parentHandle = parentItem.internal_handle;
	}
	internal_handle = OS.TreeItem_New(tree.internal_handle, parentHandle, id, index);
}
/**
 * Returns the receiver's parent item, which must be a
 * <code>TreeItem</code> or null when the receiver is a
 * root.
 *
 * @return the receiver's parent item
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TreeItem getParentItem () {
	checkWidget();
	return parentItem;
}
void internalClear() {
	parentItem = null;
	tree = null;
	image = null;
	releaseHandle ();
}
void remove() {
	super.releaseWidget ();
	destroy();
	internalClear();
}
protected void releaseHandle () {
	internal_handle = 0;
	display = null;
}
/**
 * 
 */
protected void releaseWidget () {
	super.releaseWidget ();
	destroy();
	internalClear();
}
/**
 * Remove the item from the TreeItem's list of children. 
 */
void removeChild(TreeItem item) {
	int childIndex = -1;
	int numChildren = getNumChildren();
	for (int i=0; i<numChildren; i++) {
		if (children[i] == item) {
			childIndex = i;
			break;
		}
	}
	if (childIndex == -1) return;
	int size = children.length;
	TreeItem [] newItems = new TreeItem [size];
	System.arraycopy (children, 0, newItems, 0, childIndex);
	System.arraycopy (children, childIndex + 1, newItems, childIndex, size - (childIndex + 1));
	children = newItems;
}

/**
 * Sets the receiver's background color to the color specified
 * by the argument, or to the default system color for the item
 * if the argument is null.
 *
 * @param color the new color (or null)
 * 
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0
 * 
 */
public void setBackground (Color color) {
	checkWidget ();
	if (color != null && color.isDisposed ()) {
		SWT.error (SWT.ERROR_INVALID_ARGUMENT);
	}
	if (color == null) bgRGB = -1;
	else bgRGB = RGBUtils.toRGBInt(color.getRGB());
	if (color == null) {
		OS.TreeItem_SetBackground(internal_handle, 0);
	}
	else {
	    OS.TreeItem_SetBackground(internal_handle,color.internal_handle);
	}
}

/**
 * Sets the checked state of the receiver.
 * <p>
 *
 * @param checked the new checked state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setChecked (boolean checked) {
	checkWidget();
	if ((tree.getStyle() & SWT.CHECK) == 0) return;
	OS.TreeItem_SetChecked(internal_handle, checked);
}

/**
 * Sets the expanded state of the receiver.
 * <p>
 *
 * @param expanded the new expanded state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setExpanded (boolean expanded) {
	checkWidget();
	OS.TreeItem_SetExpanded(internal_handle, expanded);
}

/**
 * Sets the font that the receiver will use to paint textual information
 * for this item to the font specified by the argument, or to the default font
 * for that kind of control if the argument is null.
 *
 * @param font the new font (or null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 3.0
 */
public void setFont (Font font){
	int fontHandle;
	if (font != null) {
		if (font.isDisposed()) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		fontHandle = font.internal_handle;
	} else {
		fontHandle = 0;
	}
	OS.TreeItem_SetFont(internal_handle, fontHandle);
	this.font = font;
	
}

/**
 * Sets the receiver's foreground color to the color specified
 * by the argument, or to the default system color for the item
 * if the argument is null.
 *
 * @param color the new color (or null)
 *
 * @since 2.0
 * 
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0
 * 
 */
public void setForeground (Color color) {
	checkWidget ();
	if (color != null && color.isDisposed ()) {
		SWT.error (SWT.ERROR_INVALID_ARGUMENT);
	}
	if (color == null) fgRGB = -1;
	else fgRGB = RGBUtils.toRGBInt(color.getRGB());
	if (color == null) {
		OS.TreeItem_SetForeground(internal_handle, 0);
	}
	else {
	    OS.TreeItem_SetForeground(internal_handle,color.internal_handle);
	}
}

/**
 * Sets the grayed state of the receiver.
 * <p>
 *
 * @param grayed the new grayed state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setGrayed (boolean grayed) {
	checkWidget();
	if ((tree.getStyle() & SWT.CHECK) == 0) return;
	OS.TreeItem_SetGrayed(internal_handle, grayed);
}


public void setImage (Image image) {
	checkWidget ();
	if (image != null && image.isDisposed()) error(SWT.ERROR_INVALID_ARGUMENT);
	int imageHandle = (image == null) ? 0 : image.internal_handle;
	OS.TreeItem_SetImage(internal_handle, imageHandle);
	super.setImage (image);
}


public void setText (String string) {
	checkWidget();
	if (string == null) error (SWT.ERROR_NULL_ARGUMENT);
	OS.TreeItem_SetText(internal_handle, string);
	super.setText (string);
}

/**
 * Sets the number of items contained in the receiver.
 *
 * @param count the number of items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 3.2
 */
public void setItemCount (int count) {
	checkWidget();

	int itemCount;
	itemCount = this.itemCount;
	if (count == itemCount) return;

	int index = count;
	while (index < itemCount) {
		TreeItem item = children [index];
		if (item != null && !item.isDisposed())
			item.dispose();
		index++;
	}
	int length = Math.max (4, (count + 3) / 4 * 4);
	TreeItem [] newItems = new TreeItem [length];
	System.arraycopy (children, 0, newItems, 0, Math.min (count, itemCount));
	children = newItems;
	
	if(tree.isVirtual) {
		OS.TreeItem_SetItemCount(internal_handle, count);
		remainStart = itemCount;
	}
	
	this.itemCount = count;
}

void createRemainItem() {
	if(!tree.isVirtual) {
		return;
	}
	while (remainStart < itemCount) {
		children [remainStart] = new TreeItem(this, SWT.BORDER);
		remainStart++;
	}
}

/**
 * Searches the receiver's list starting at the first item
 * (index 0) until an item is found that is equal to the 
 * argument, and returns the index of that item. If no item
 * is found, returns -1.
 *
 * @param item the search item
 * @return the index of the item
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the item is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if the item has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since eRCP 1.3
 */
public int indexOf(TreeItem item) {
	checkWidget ();
	if (item == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (item.isDisposed()) error(SWT.ERROR_INVALID_ARGUMENT);

	int idx = -1;
	for(int i=0; i<children.length && idx == -1; i++) {
		if(children[i] == null)
			continue;
		TreeItem child = children[i];
		if(child.id == item.id)
			return i;
		idx = child.indexOf(item);
	}
	
	return idx;
}
}
