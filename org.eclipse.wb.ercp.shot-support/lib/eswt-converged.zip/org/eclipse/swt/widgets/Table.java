/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

 
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.events.*;

import com.ibm.ugl.eswt.expanded.OS;

/** 
 * Instances of this class implement a selectable user interface
 * object that displays a list of images and strings and issue
 * notificiation when selected.
 * <p>
 * The item children that may be added to instances of this class
 * must be of type <code>TableItem</code>.
 * </p><p>
 * Style <code>VIRTUAL</code> is used to create a <code>Table</code> whose
 * <code>TableItem</code>s are to be populated by the client on an on-demand basis
 * instead of up-front.  This can provide significant performance improvements for
 * tables that are very large or for which <code>TableItem</code> population is
 * expensive (for example, retrieving values from an external source).
 * </p><p>
 * Here is an example of using a <code>Table</code> with style <code>VIRTUAL</code>:
 * <code><pre>
 *  final Table table = new Table (parent, SWT.VIRTUAL | SWT.BORDER);
 *  table.setItemCount (1000000);
 *  table.addListener (SWT.SetData, new Listener () {
 *      public void handleEvent (Event event) {
 *          TableItem item = (TableItem) event.item;
 *          int index = table.indexOf (item);
 *          item.setText ("Item " + index);
 *          System.out.println (item.getText ());
 *      }
 *  }); 
 * </pre></code>
 * </p><p>
 * Note that although this class is a subclass of <code>Composite</code>,
 * it does not normally make sense to add <code>Control</code> children to
 * it, or set a layout on it, unless implementing something like a cell
 * editor.
 * </p><p>
 * <dl>
 * <dt><b>Styles:</b></dt>
 * <dd>SINGLE, MULTI, CHECK, FULL_SELECTION, HIDE_SELECTION, VIRTUAL</dd>
 * <dt><b>Events:</b></dt>
 * <dd>Selection, DefaultSelection, SetData</dd>
 * </dl>
 * </p><p>
 * Note: Only one of the styles SINGLE, and MULTI may be specified.
 * </p><p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */

public class Table extends Composite {
	
	static boolean eventsRegistered = false;
	TableColumn [] columns = new TableColumn[0];
	TableItem [] items = new TableItem[0];
	// special flag when SWT creates to handle treating the Table
	// like a List, this is done when the user adds items without
	// creating columns
	boolean isList = false; 
	boolean visible_or_not; //Eric, record if columnheader is visible.
	int border_height = 1;

	// SWT.VIRTUAL Style support
	private boolean isVirtual = false;
	private int itemCount = 0;
/**
 * Constructs a new instance of this class given its parent
 * and a style value describing its behavior and appearance.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a composite control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT#SINGLE
 * @see SWT#MULTI
 * @see SWT#CHECK
 * @see SWT#FULL_SELECTION
 * @see SWT#HIDE_SELECTION
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public Table (Composite parent, int style) {
	super(parent, checkStyle(style));
	if((style & SWT.VIRTUAL) != 0)
		isVirtual = true;
}

/**
 * Adds the listener to the collection of listeners who will
 * be notified when the receiver's selection changes, by sending
 * it one of the messages defined in the <code>SelectionListener</code>
 * interface.
 * <p>
 * When <code>widgetSelected</code> is called, the item field of the event object is valid.
 * If the reciever has <code>SWT.CHECK</code> style set and the check selection changes,
 * the event object detail field contains the value <code>SWT.CHECK</code>.
 * <code>widgetDefaultSelected</code> is typically called when an item is double-clicked.
 * The item field of the event object is valid for default selection, but the detail field is not used.
 * </p>
 *
 * @param listener the listener which should be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SelectionListener
 * @see #removeSelectionListener
 * @see SelectionEvent
 */
public void addSelectionListener (SelectionListener listener) {
	checkWidget ();
	if (listener == null) error (SWT.ERROR_NULL_ARGUMENT);
	TypedListener typedListener = new TypedListener (listener);
	addListener (SWT.Selection,typedListener);
	addListener (SWT.DefaultSelection,typedListener);
}

public Point computeSize(int wHint, int hHint, boolean changed) {
	checkWidget();
	Point size;
	Point minsize = minimumSize();
	if (layout != null) {
		if (wHint == SWT.DEFAULT || hHint == SWT.DEFAULT) {
			size = layout.computeSize(this, wHint, hHint, changed);
		} else {
			size = new Point(wHint, hHint);
		}
	} else {
		size = minimumSize();
	}

	if (size.x == 0) size.x = DEFAULT_WIDTH;
	if (size.y == 0) size.y = DEFAULT_HEIGHT;
	if (wHint != SWT.DEFAULT) size.x = wHint;
	if (hHint != SWT.DEFAULT) size.y = hHint;
	
	
	// fix for Bug 132539 the table has phantom row... if table is set to smaller than
	// the size of (header height + all item height + 2) then there could present a 
	// "phantom row problem"  the remainder of the height not enough to make the item height
	// will show in the end of the widget when it's scrolled to the bottom.  the code below
	// make sure that when user uses computeSize to compute the size of the table, he will
	// not get a "phantom row problem"
	int itemHeights = 0;
	int remainingPixels = 0;
	if(visible_or_not){
		itemHeights = size.y - getHeaderHeight() - (2 * border_height);
	} else {
		itemHeights = size.y - (2 * border_height);
	}
	remainingPixels = itemHeights % getItemHeight();
	if(remainingPixels != 0){
		if(itemHeights/getItemHeight() < getItemCount()){
			size.y += (getItemHeight() - remainingPixels);
		}
	}
	// computes if scroll bars are needed, if so, add the trim to the widget so we can 
	// display the desired client area.
	int scrollbarWidth = ("Windows CE".equalsIgnoreCase(System.getProperty("os.name"))?13:17);
	boolean needscrolly = false;
	if(size.x < minsize.x){
		needscrolly = true;
	}
	if(size.y < minsize.y){
		size.x+=scrollbarWidth;
	}
	if(needscrolly){
		size.y+=scrollbarWidth;
	}
	return new Point(size.x, size.y);
}

/**
 * Adjust the specified style so that it contains only valid styles
 * for this widget.
 */
static int checkStyle(int style) {
	/*
	* In Windows, it is not possible to create a table that scrolls 
	* and does not have scroll bars, so override the style to include 
	* the H_SCROLL and V_SCROLL bits so that the SWT style will match 
	* the widget that Windows creates.
	*/
	if (OS.Table_IncludeScrollbars()) style |= SWT.H_SCROLL | SWT.V_SCROLL;
	style = checkBits (style, SWT.SINGLE, SWT.MULTI, 0, 0, 0, 0);
	return style;
}

void addItem (TableItem item, int index) {
	// handle the special case where SWT allows the Table to be
	// treated like a List (i.e., items are added without creating
	// columns)
	if (internal_getColumnCount() == 0) {
		new TableColumn(this, SWT.LEFT);
		isList = true;
	}
	if(isVirtual) {
		items[index] = item;
		return;
	}
		
	int numItems = getItemCount();
	// Make room for the new item.
	if (numItems == items.length) {
		TableItem [] newItems = new TableItem [items.length + 4];
		System.arraycopy (items, 0, newItems, 0, items.length);
		items = newItems;
	}
	if (items[index] != null) {
		System.arraycopy (items, index, items, index+1, getItemCount() - index);
	}
	items[index]=item;
	if (isList()) columns[0].pack();
}
void checkColumnIndex(int index) {
	// if the Table is being treated like a List, indexed access to columns 
	// is not allowed
	if (isList()) error (SWT.ERROR_INVALID_RANGE);
	int count = internal_getColumnCount();
	if (index < 0 || (index > count - 1)) error (SWT.ERROR_INVALID_RANGE);
}
void checkItemIndex(int index) {
	int count = getItemCount();
	if (index < 0 || (index > count - 1)) error (SWT.ERROR_INVALID_RANGE);
}
void addColumn (TableColumn column, int index) {
	if (isList()) {
		// copy item data from listColumn to new column
		columns = new TableColumn[4];
		columns[0] = column;
		int itemCount = getItemCount();
		for (int i=0; i<itemCount; i++) {
			TableItem item = items [i];
			item.setText(1, item.getText(0));
			item.setImage(1, item.getImage(0));
			item.setFont(1, item.getFont(0));
			item.setBackground(1, item.getBackground(0));
			item.setForeground(1, item.getForeground(0));
		}
	}
	int numColumns = internal_getColumnCount();
	// Make room for the new column.
	if (numColumns == columns.length) {
		TableColumn [] newColumns = new TableColumn [columns.length + 4];
		System.arraycopy (columns, 0, newColumns, 0, columns.length);
		columns = newColumns;
	}
	int itemCount = getItemCount();
	int columnCount = numColumns + 1;
	for (int i=0; i<itemCount; i++) {
		TableItem item = items [i];
		String [] strings = item.texts;
		if (strings != null) {
			String [] temp = new String [columnCount];
				System.arraycopy (strings, 0, temp, 0, index);
				System.arraycopy (strings, index, temp, index+1, columnCount-index-1);
				item.texts = temp;
		}
		Image [] images = item.images;
		if (images != null) {
			Image [] temp = new Image [columnCount];
			System.arraycopy (images, 0, temp, 0, index);
			System.arraycopy (images, index, temp, index+1, columnCount-index-1);
			item.images = temp;
		}
		int [] cellBgRGBs = item.cellBgRGBs;
		if (cellBgRGBs != null) {
			int [] temp = new int [columnCount];
			System.arraycopy (cellBgRGBs, 0, temp, 0, index);
			System.arraycopy (cellBgRGBs, index, temp, index+1, columnCount-index-1);
			temp [index] = -1;
			item.cellBgRGBs = temp;
		}
		int [] cellFgRGBs = item.cellFgRGBs;
		if (cellFgRGBs != null) {
			int [] temp = new int [columnCount];
			System.arraycopy (cellFgRGBs, 0, temp, 0, index);
			System.arraycopy (cellFgRGBs, index, temp, index+1, columnCount-index-1);
			temp [index] = -1;
			item.cellFgRGBs = temp;
		}
	}
	if (columns[index] != null) {
		System.arraycopy (columns, index, columns, index+1, getColumnCount() - index);
	}
	columns[index]=column;
	if (isList) {
		TableColumn removeCol = columns[0];
		removeCol.dispose();
		isList = false;
	}
}

/**
 * Deselects the items at the given zero-relative indices in the receiver.
 * If the item at the given zero-relative index in the receiver 
 * is selected, it is deselected.  If the item at the index
 * was not selected, it remains deselected. Indices that are out
 * of range and duplicate indices are ignored.
 *
 * @param indices the array of indices for the items to deselect
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the set of indices is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void deselect (int [] indices) {
	checkWidget ();
	if (indices == null) error (SWT.ERROR_INVALID_ARGUMENT);
	int itemCount = getItemCount();
	int length = indices.length;
	if (length == 0 || ((getStyle() & SWT.SINGLE) != 0 && length > 1)) return;
	for (int i=length-1; i>=0; --i) {
		/*
		* An index of -1 will apply the change to all
	 	* items.  Ensure that indices are greater than -1.
	 	*/
		int index = indices[i];
		if ((index >= 0) && (index < itemCount)) {
			TableItem item = getItem(indices[i]);
			item.setSelected(false);
		}
	}
}

/**
 * Deselects the item at the given zero-relative index in the receiver.
 * If the item at the index was already deselected, it remains
 * deselected. Indices that are out of range are ignored.
 *
 * @param index the index of the item to deselect
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void deselect (int index) {
	checkWidget ();
	int itemCount = getItemCount();
	if ((index < 0) || (index >= itemCount)) return;
	TableItem item = getItem(index);
	item.setSelected(false);
}

/**
 * Deselects the items at the given zero-relative indices in the receiver.
 * If the item at the given zero-relative index in the receiver 
 * is selected, it is deselected.  If the item at the index
 * was not selected, it remains deselected.  The range of the
 * indices is inclusive. Indices that are out of range are ignored.
 *
 * @param start the start index of the items to deselect
 * @param end the end index of the items to deselect
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void deselect (int start, int end) {
	checkWidget ();
	if (end < 0 || start > end || ((getStyle() & SWT.SINGLE) != 0 && start != end)) return;
	int count = getItemCount();
	if (count == 0 || start >= count) return;
	start = Math.max (0, start);
	end = Math.min (end, count - 1);
	if (start == 0 && end == count - 1) {
		deselectAll ();
	} else {
		for (int i=start; i<=end; i++) {
			TableItem item = getItem(i);
			item.setSelected(false);
		}
	}
}

/**
 * Deselects all selected items in the receiver.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void deselectAll () {
	checkWidget ();
	OS.Table_SetAllSelected(internal_handle, false);
}

void destroyColumn (TableColumn column) {
	int columnCount = internal_getColumnCount();
	int index = indexOf(column);
	OS.TableColumn_Delete(column.internal_handle);
	TableColumn [] newColumns = new TableColumn [columnCount-1];
	System.arraycopy (columns, 0, newColumns, 0, index);
	System.arraycopy (columns, index + 1, newColumns, index, columnCount - index - 1);
	columns = newColumns;
	int itemCount = getItemCount();
	for (int i=0; i<itemCount; i++) {
		TableItem item = items [i];
		if (item != null) {
			String [] strings = item.texts;
			if (strings != null) {
				if (columnCount == 0) {
					item.texts = null;
				} else {
					if (index == 0) item.text = strings [1];
					String [] temp = new String [columnCount];
					System.arraycopy (strings, 0, temp, 0, index);
					System.arraycopy (strings, index + 1, temp, index, columnCount - index - 1);
					item.texts = temp;
				}
			}
			Image [] images = item.images;
			if (images != null) {
				if (columnCount == 0) {
					item.images = null;
				} else {
					if (index == 0) item.image = images [1];
					Image [] temp = new Image [columnCount];
					System.arraycopy (images, 0, temp, 0, index);
					System.arraycopy (images, index + 1, temp, index, columnCount - index - 1);
					item.images = temp;
				}
			}
			if (item.cellBgRGBs != null) {
				if (columnCount == 0) {
					item.cellBgRGBs = null;
				} else {
					int [] cellBackground = item.cellBgRGBs;
					int [] temp = new int [columnCount];
					System.arraycopy (cellBackground, 0, temp, 0, index);
					System.arraycopy (cellBackground, index + 1, temp, index, columnCount - index - 1);
					item.cellBgRGBs = temp;
				}
			}
			if (item.cellFgRGBs != null) {
				if (columnCount == 0) {
					item.cellFgRGBs = null;
				} else {
					int [] cellForeground = item.cellFgRGBs;
					int [] temp = new int [columnCount];
					System.arraycopy (cellForeground, 0, temp, 0, index);
					System.arraycopy (cellForeground, index + 1, temp, index, columnCount - index - 1);
					item.cellFgRGBs = temp;
				}
			}
			if (item.cellFonts != null) {
				if (columnCount == 0) {
					item.cellFonts = null;
				} else {
					Font [] cellFont = item.cellFonts;
					Font [] temp = new Font [columnCount];
					System.arraycopy (cellFont, 0, temp, 0, index);
					System.arraycopy (cellFont, index + 1, temp, index, columnCount - index - 1);
					item.cellFonts = temp;
				}
			}
		}
	}
}
void destroyItem (TableItem item) {
	int index = indexOf(item);
	if(isVirtual) {
		OS.TableItem_Delete(internal_handle, items[index].internal_handle, index);
		items[index] = null;
		return;
	}

	int count = getItemCount();
	if (index == count) return;
	OS.TableItem_Delete(internal_handle, items[index].internal_handle, index);
	System.arraycopy (items, index + 1, items, index, --count - index);
	items [count] = null;
}

/**
 * Returns the column at the given, zero-relative index in the
 * receiver. Throws an exception if the index is out of range.
 * If no <code>TableColumn</code>s were created by the programmer,
 * this method will throw <code>ERROR_INVALID_RANGE</code> despite
 * the fact that a single column of data may be visible in the table.
 * This occurs when the programmer uses the table like a list, adding
 * items but never creating a column.
 *
 * @param index the index of the column to return
 * @return the column at the given index
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_RANGE - if the index is not between 0 and the number of elements in the list minus 1 (inclusive)</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TableColumn getColumn (int index) {
	checkWidget ();
	checkColumnIndex(index);
	return columns [index];
}

/**
 * Returns the number of columns contained in the receiver.
 * If no <code>TableColumn</code>s were created by the programmer,
 * this value is zero, despite the fact that visually, one column
 * of items may be visible. This occurs when the programmer uses
 * the table like a list, adding items but never creating a column.
 *
 * @return the number of columns
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getColumnCount () {
	if (isList()) return 0;
	return internal_getColumnCount();
}
protected int internal_getColumnCount () {
	for (int i=0; i<columns.length; i++) {
		if (columns[i] == null) return i;
	}
	return columns.length;
}
/**
 * Returns an array of <code>TableColumn</code>s which are the
 * columns in the receiver. If no <code>TableColumn</code>s were
 * created by the programmer, the array is empty, despite the fact
 * that visually, one column of items may be visible. This occurs
 * when the programmer uses the table like a list, adding items but
 * never creating a column.
 * <p>
 * Note: This is not the actual structure used by the receiver
 * to maintain its list of items, so modifying the array will
 * not affect the receiver. 
 * </p>
 *
 * @return the items in the receiver
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TableColumn [] getColumns () {
	checkWidget();
	int size = getColumnCount();
	if (size == 0) return new TableColumn[0];
	TableColumn[] cols = new TableColumn[size];
	System.arraycopy (columns, 0, cols, 0, size);
	return cols;
}

/**
 * Returns the width in pixels of a grid line.
 *
 * @return the width of a grid line in pixels
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getGridLineWidth () {
	checkWidget ();
	return OS.Table_GetGridLineWidth(internal_handle);
}

/**
 * Returns the height of the receiver's header 
 *
 * @return the height of the header or zero if the header is not visible
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0 
 */
public int getHeaderHeight () {
	checkWidget ();
	if (visible_or_not == false)
		return 0;
	else
	    return (OS.Table_GetHeaderHeight(internal_handle) != 0)? OS.Table_GetHeaderHeight(internal_handle) : (getItemHeight()+5); 
}

/**
 * Returns <code>true</code> if the receiver's header is visible,
 * and <code>false</code> otherwise.
 * <p>
 * If one of the receiver's ancestors is not visible or some
 * other condition makes the receiver not visible, this method
 * may still indicate that it is considered visible even though
 * it may not actually be showing.
 * </p>
 *
 * @return the receiver's header's visibility state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getHeaderVisible () {
	checkWidget ();
	return OS.Table_GetHeaderVisible(internal_handle);
}

/**
 * Returns the item at the given, zero-relative index in the
 * receiver. Throws an exception if the index is out of range.
 *
 * @param index the index of the item to return
 * @return the item at the given index
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_RANGE - if the index is not between 0 and the number of elements in the list minus 1 (inclusive)</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TableItem getItem (int index) {
	checkWidget ();
	checkItemIndex(index);
	return items[index];
}

/**
 * Returns the item at the given point in the receiver
 * or null if no such item exists. The point is in the
 * coordinate system of the receiver.
 *
 * @param point the point used to locate the item
 * @return the item at the given point
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the point is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TableItem getItem (Point point) {
	checkWidget ();
	if (point == null) error (SWT.ERROR_NULL_ARGUMENT);
	int index = OS.Table_GetItemAt(internal_handle, point.x, point.y);
	if (index == -1) return null;
	return items[index];
}

/**
 * Returns the number of items contained in the receiver.
 *
 * @return the number of items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getItemCount () {
	if(isVirtual) {
		return itemCount;
	}
	for (int i=items.length - 1; i>=0; i--) {
		if (items[i] != null) return i + 1;
	}
	return 0;
}

/**
 * Returns the height of the area which would be used to
 * display <em>one</em> of the items in the receiver's.
 *
 * @return the height of one item
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getItemHeight () {
	checkWidget ();
	return OS.Table_GetItemHeight(internal_handle);
}

/**
 * Returns a (possibly empty) array of <code>TableItem</code>s which
 * are the items in the receiver. 
 * <p>
 * Note: This is not the actual structure used by the receiver
 * to maintain its list of items, so modifying the array will
 * not affect the receiver. 
 * </p>
 *
 * @return the items in the receiver
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TableItem [] getItems () {
	checkWidget();
	int size = getItemCount();
	if (size == 0) return new TableItem[0];
	TableItem[] newItems = new TableItem[size];
	System.arraycopy (items, 0, newItems, 0, size);
	return newItems;
}

/**
 * Returns <code>true</code> if the receiver's lines are visible,
 * and <code>false</code> otherwise.
 * <p>
 * If one of the receiver's ancestors is not visible or some
 * other condition makes the receiver not visible, this method
 * may still indicate that it is considered visible even though
 * it may not actually be showing.
 * </p>
 *
 * @return the visibility state of the lines
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getLinesVisible () {
	checkWidget ();
	return OS.Table_GetLinesVisible(internal_handle);
}
/**
 * Returns an array of <code>TableItem</code>s that are currently
 * selected in the receiver. The order of the items is unspecified.
 * An empty array indicates that no items are selected.
 * <p>
 * Note: This is not the actual structure used by the receiver
 * to maintain its selection, so modifying the array will
 * not affect the receiver. 
 * </p>
 * @return an array representing the selection
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public TableItem [] getSelection () {
	checkWidget ();
	int[] indices = OS.Table_GetSelectionIndices(internal_handle);
	TableItem[] tableItems = new TableItem[indices.length];
	for (int i=0; i<indices.length; i++) {
		tableItems[i] = getItem(indices[i]);
	}
	return tableItems;
}

/**
 * Returns the number of selected items contained in the receiver.
 *
 * @return the number of selected items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getSelectionCount () {
	checkWidget ();
	return getSelectionIndices().length;
}

/**
 * Returns the zero-relative index of the item which is currently
 * selected in the receiver, or -1 if no item is selected.
 *
 * @return the index of the selected item
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getSelectionIndex () {
	checkWidget ();
	int[] indices = OS.Table_GetSelectionIndices(internal_handle);
	if (indices.length == 0) return -1;
	else return indices[0];
}

/**
 * Returns the zero-relative indices of the items which are currently
 * selected in the receiver. The order of the indices is unspecified.
 * The array is empty if no items are selected.
 * <p>
 * Note: This is not the actual structure used by the receiver
 * to maintain its selection, so modifying the array will
 * not affect the receiver. 
 * </p>
 * @return the array of indices of the selected items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int [] getSelectionIndices () {
	checkWidget ();
	int[] indices = OS.Table_GetSelectionIndices(internal_handle);
	return indices;
}

/**
 * Returns the zero-relative index of the item which is currently
 * at the top of the receiver. This index can change when items are
 * scrolled or new items are added or removed.
 *
 * @return the index of the top item
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getTopIndex () {
	checkWidget ();
	return OS.Table_GetTopItemIndex(internal_handle);
}

/**
 * Searches the receiver's list starting at the first column
 * (index 0) until a column is found that is equal to the 
 * argument, and returns the index of that column. If no column
 * is found, returns -1.
 *
 * @param column the search column
 * @return the index of the column
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the string is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int indexOf (TableColumn column) {
	checkWidget ();
	if (column == null) error (SWT.ERROR_NULL_ARGUMENT);
	for (int i=0; i<columns.length; i++) {
		if (column == columns[i]) return i;
	}
	return -1;
}

/**
 * Searches the receiver's list starting at the first item
 * (index 0) until an item is found that is equal to the 
 * argument, and returns the index of that item. If no item
 * is found, returns -1.
 *
 * @param item the search item
 * @return the index of the item
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the string is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int indexOf (TableItem item) {
	checkWidget ();
	if (item == null) error (SWT.ERROR_NULL_ARGUMENT);
	for (int i=0; i<items.length; i++) {
		if (item == items[i]) return i;
	}
	return -1;
}
/**
 * Create the widget.
 */
protected void internal_createHandle (int index) {
	if (!eventsRegistered) {
		Display d = getDisplay();
		com.ibm.ugl.p3ml.OS.Display_RegisterCallback(d.internal_handle, OS.CALLBACK_TABLE, "org/eclipse/swt/widgets/Table", "tableCallback");
		eventsRegistered = true;
	}
	
	internal_handle = OS.Table_New(internal_parent.internal_handle, internal_getNativeStyle());
	columns = new TableColumn [4];
}
protected int internal_getNativeStyle() {
	int nativeStyle = super.internal_getNativeStyle();
		
	if ((internal_style & SWT.SINGLE) != 0) {
		nativeStyle |= OS.STYLE_SINGLE;
	}
	if ((internal_style & SWT.MULTI) != 0) {
		nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_MULTI;
	}
	if ((internal_style & SWT.CHECK) != 0) {
		nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_CHECK;
	}
	if ((internal_style & SWT.FULL_SELECTION) != 0) {
		nativeStyle |= OS.STYLE_FULLSELECTION;
	}
	if ((internal_style & SWT.HIDE_SELECTION) != 0) {
		nativeStyle |= OS.STYLE_HIDESELECTION;
	}
	if ((internal_style & SWT.VIRTUAL) != 0) {
		nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_VIRTUAL;
	}
	return nativeStyle;
}
/**
 * Returns <code>true</code> if the item is selected,
 * and <code>false</code> otherwise.  Indices out of
 * range are ignored.
 *
 * @param index the index of the item
 * @return the visibility state of the item at the index
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean isSelected (int index) {
	checkWidget();
	int count = getItemCount();
	if ((index < 0) || (index > count - 1)) return false;
	return getItem(index).isSelected();
}
boolean isList() {
	return isList;
}
/**
 *  
 */
Point minimumSize() {
	int width = 0, height = 0;
	int[] pointArray = com.ibm.ugl.eswt.OS.Control_GetMinimumSize(internal_handle);
	width = pointArray[com.ibm.ugl.eswt.OS.INDEX_X];
	height = pointArray[com.ibm.ugl.eswt.OS.INDEX_Y];
	return new Point(width, height);
}

/**
 * Removes the items from the receiver's list at the given
 * zero-relative indices.
 *
 * @param indices the array of indices of the items
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_RANGE - if the index is not between 0 and the number of elements in the list minus 1 (inclusive)</li>
 *    <li>ERROR_NULL_ARGUMENT - if the indices array is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void remove (int [] indices) {
	checkWidget ();
	if (indices == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (indices.length == 0) return;

	if(isVirtual) {
		for (int i=0; i<indices.length; i++) {
			int idx = indices[i];
			if ((idx < 0) || (idx > itemCount)) {
				error (SWT.ERROR_INVALID_RANGE);
			}
			if(items[i] != null && !items[idx].isDisposed())
				items[idx].dispose();
			items[idx] = null;
		}
		return;
	}
	
	int [] newIndices = new int [indices.length];
	System.arraycopy (indices, 0, newIndices, 0, indices.length);
	sort (newIndices);
	int start = newIndices [newIndices.length - 1];
	int end = newIndices [0];
	int count = getItemCount();
	if ((start < 0) || (start > end) || (end > count - 1)) {
		error (SWT.ERROR_INVALID_RANGE);
	}
	// handle duplicate indices
	int last = -1;
	for (int i=0; i<newIndices.length; i++) {
		int index = newIndices [i];
		if (index != last) {
			items[index].dispose();
			last = index;
		}
	}
}

protected void releaseWidget () {
	super.releaseWidget ();
	int count = getItemCount();
	for (int i=count-1 ; i>=0; i--) {
		if(items [i] == null)
			continue;
		TableItem item = items [i];
		if (!item.isDisposed ()) item.releaseWidget ();
	}
	if(!this.isVirtual )
	 items = new TableItem[] {};
	count = internal_getColumnCount();
	for (int i=count-1 ; i>=0; i--) {
		TableColumn column = columns [i];
		if (!column.isDisposed ()) column.releaseWidget ();
	}
	columns = new TableColumn[] {};
	isList = false;
}

/**
 * Removes the item from the receiver at the given
 * zero-relative index.
 *
 * @param index the index for the item
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_RANGE - if the index is not between 0 and the number of elements in the list minus 1 (inclusive)</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void remove (int index) {
	checkWidget ();
	checkItemIndex(index);
	items[index].dispose();
}

/**
 * Removes the items from the receiver which are
 * between the given zero-relative start and end 
 * indices (inclusive).
 *
 * @param start the start of the range
 * @param end the end of the range
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_RANGE - if either the start or end are not between 0 and the number of elements in the list minus 1 (inclusive)</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void remove (int start, int end) {
	checkWidget ();
	if (start > end) return;
	int count = getItemCount();
	if (!(0 <= start && start <= end && end < count)) {
		error (SWT.ERROR_INVALID_RANGE);
	}
	if(isVirtual) {
		for (int i=start; i<end; i++) {
			if (items[i] != null && !items[i].isDisposed ()) {
				items[i].dispose();
			}
			items[i] = null;
		}
		return;
	}
	
	if (start == 0 && end == count - 1) {
		removeAll ();
	} else {
		int index = end;
		while (index >= start) {
			TableItem item = items [index];
			OS.TableItem_Delete(internal_handle, item.internal_handle, index);
			if (item != null && !item.isDisposed ()) {
				item.remove ();
			}
			index--;
		}
		System.arraycopy (items, end + 1, items, start, count - end - 1);
		for (int i=1; i<=end-start+1; i++) {
			items[count-i]=null;
		}
	}
}

/**
 * Removes all of the items from the receiver.
 * <p>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void removeAll () {
	checkWidget();
	int count = getItemCount();
	if(isVirtual) {
		for (int i=0; i<count; i++) {
			if (items[i] != null && !items[i].isDisposed ())
				items[i].dispose();
			items[i] = null;
		}
		return;
	}
	OS.Table_DeleteAllItems(internal_handle);
	for (int i=0; i<count; i++) {
		TableItem item = items [i];
		if (item != null && !item.isDisposed ()) item.remove ();
	}
	items = new TableItem[4];
}

/**
 * Removes the listener from the collection of listeners who will
 * be notified when the receiver's selection changes.
 *
 * @param listener the listener which should no longer be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SelectionListener
 * @see #addSelectionListener(SelectionListener)
 */
public void removeSelectionListener(SelectionListener listener) {
	checkWidget ();
	if (listener == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (eventTable == null) return;
	eventTable.unhook (SWT.Selection, listener);
	eventTable.unhook (SWT.DefaultSelection,listener);	
}

/**
 * Selects the items at the given zero-relative indices in the receiver.
 * The current selection is not cleared before the new items are selected.
 * <p>
 * If the item at a given index is not selected, it is selected.
 * If the item at a given index was already selected, it remains selected.
 * Indices that are out of range and duplicate indices are ignored.
 * If the receiver is single-select and multiple indices are specified,
 * then all indices are ignored.
 *
 * @param indices the array of indices for the items to select
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the array of indices is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @see Table#setSelection(int[])
 */
public void select (int [] indices) {
	checkWidget ();
	if (indices == null) error (SWT.ERROR_NULL_ARGUMENT);
	int itemCount = getItemCount();
	int length = indices.length;
	boolean singleSelect = (getStyle() & SWT.SINGLE) != 0;
	if (length == 0 || (singleSelect && length > 1)) return;
	if (singleSelect) deselectAll();
	for (int i=length-1; i>=0; --i) {
		/*
		* An index of -1 will apply the change to all
	 	* items.  Ensure that indices are greater than -1.
	 	*/
		int index = indices[i];
		if ((index >= 0) && (index < itemCount)) {
			TableItem item = getItem(index);
			item.setSelected(true);
		}
	}
}

/**
 * Selects the item at the given zero-relative index in the receiver. 
 * If the item at the index was already selected, it remains
 * selected. Indices that are out of range are ignored.
 *
 * @param index the index of the item to select
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void select (int index) {
	checkWidget ();
	int count = getItemCount();
	if ((index < 0) || (index >= count)) return;
	boolean singleSelect = (getStyle() & SWT.SINGLE) != 0;
	if (singleSelect) deselectAll();
	TableItem item = getItem(index);
	item.setSelected(true);
}

/**
 * Selects the items in the range specified by the given zero-relative
 * indices in the receiver. The range of indices is inclusive.
 * The current selection is not cleared before the new items are selected.
 * <p>
 * If an item in the given range is not selected, it is selected.
 * If an item in the given range was already selected, it remains selected.
 * Indices that are out of range are ignored and no items will be selected
 * if start is greater than end.
 * If the receiver is single-select and there is more than one item in the
 * given range, then all indices are ignored.
 *
 * @param start the start of the range
 * @param end the end of the range
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @see Table#setSelection(int,int)
 */
public void select (int start, int end) {
	checkWidget ();
	boolean singleSelect = (getStyle() & SWT.SINGLE) != 0;
	if (end < 0 || start > end || (singleSelect && (start != end))) return;
	int count = getItemCount();
	if (count == 0 || start >= count) return;
	start = Math.max (0, start);
	end = Math.min (end, count - 1);
	if (start == 0 && end == count - 1) {
		selectAll ();
	} else {
		if (singleSelect) deselectAll();
		for (int i=start; i<=end; i++) {
			TableItem item = getItem(i);
			item.setSelected(true);
		}
	}
}

/**
 * Selects all of the items in the receiver.
 * <p>
 * If the receiver is single-select, do nothing.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void selectAll () {
	checkWidget ();
	if ((getStyle() & SWT.SINGLE) != 0) return;
	OS.Table_SetAllSelected(internal_handle, true);
}

/**
 * Marks the receiver's header as visible if the argument is <code>true</code>,
 * and marks it invisible otherwise. 
 * <p>
 * If one of the receiver's ancestors is not visible or some
 * other condition makes the receiver not visible, marking
 * it visible may not actually cause it to be displayed.
 * </p>
 *
 * @param show the new visibility state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setHeaderVisible (boolean show) {
	checkWidget ();
	visible_or_not = show;
	OS.Table_SetColumnHeadersVisible(internal_handle, show);
}

/**
 * Sets the number of items contained in the receiver.
 *
 * @param count the number of items
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 3.0
 */
public void setItemCount (int count) {
	checkWidget ();
	int itemCount;
	if(isVirtual) {
		itemCount = this.itemCount;
	} else {
		itemCount = getItemCount();
	}
	if (count == itemCount) return;

	if (!isVirtual) setRedraw (false);
	int index = count;
	while (index < itemCount) {
		TableItem item = items [index];
		if (item != null && !item.isDisposed())
			item.dispose();
		index++;
	}
	int length = Math.max (4, (count + 3) / 4 * 4);
	TableItem [] newItems = new TableItem [length];
	System.arraycopy (items, 0, newItems, 0, Math.min (count, itemCount));
	items = newItems;
	if (isVirtual) {
		this.itemCount = count;
		OS.Table_SetItemCount(internal_handle, count);
	}
	if (!isVirtual) setRedraw (true);
}

/**
 * Marks the receiver's lines as visible if the argument is <code>true</code>,
 * and marks it invisible otherwise. 
 * <p>
 * If one of the receiver's ancestors is not visible or some
 * other condition makes the receiver not visible, marking
 * it visible may not actually cause it to be displayed.
 * </p>
 *
 * @param show the new visibility state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setLinesVisible (boolean show) {
	checkWidget ();
	OS.Table_SetLinesVisible(internal_handle, show);
}

/**
 * Selects the items at the given zero-relative indices in the receiver.
 * The current selection is cleared before the new items are selected.
 * <p>
 * Indices that are out of range and duplicate indices are ignored.
 * If the receiver is single-select and multiple indices are specified,
 * then all indices are ignored.
 *
 * @param indices the indices of the items to select
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the array of indices is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Table#deselectAll()
 * @see Table#select(int[])
 */
public void setSelection (int [] indices) {
	checkWidget ();
	if (indices == null) error (SWT.ERROR_NULL_ARGUMENT);
	deselectAll ();
	int length = indices.length;
	if (length == 0 || ((getStyle() & SWT.SINGLE) != 0 && length > 1)) return;
	select (indices);
	int focusIndex = indices [0];
	if (focusIndex == -1) return;
	OS.Table_SetFocusIndex (internal_handle, focusIndex);
	OS.Table_ShowItemIndex (internal_handle, focusIndex);
}

/**
 * Sets the receiver's selection to be the given array of items.
 * The current selection is cleared before the new items are selected.
 * <p>
 * Items that are not in the receiver are ignored.
 * If the receiver is single-select and multiple items are specified,
 * then all items are ignored.
 *
 * @param items the array of items
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the array of items is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if one of the items has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Table#deselectAll()
 * @see Table#select(int[])
 * @see Table#setSelection(int[])
 */
public void setSelection (TableItem [] items) {
	checkWidget ();
	if (items == null) error (SWT.ERROR_NULL_ARGUMENT);
	deselectAll ();
	int length = items.length;
	if (length == 0 || ((getStyle() & SWT.SINGLE) != 0 && length > 1)) return;
	int focusIndex = -1;
	for (int i=length-1; i>=0; --i) {
		int index = indexOf (items [i]);
		if (index != -1) {
			select (focusIndex = index);
		}
	}
	if (focusIndex == -1) return;
	OS.Table_SetFocusIndex (internal_handle, focusIndex);
	OS.Table_ShowItemIndex(internal_handle, focusIndex);
}

/**
 * Selects the item at the given zero-relative index in the receiver. 
 * The current selection is first cleared, then the new item is selected.
 *
 * @param index the index of the item to select
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Table#deselectAll()
 * @see Table#select(int)
 */
public void setSelection (int index) {
	checkWidget ();
	int count = getItemCount();
	if ((index < 0) || (index >= count)) return;
	deselectAll ();
	select (index);
	if (index == -1) return;
	OS.Table_SetFocusIndex (internal_handle, index);
	OS.Table_ShowItemIndex(internal_handle, index);
}

/**
 * Selects the items in the range specified by the given zero-relative
 * indices in the receiver. The range of indices is inclusive.
 * The current selection is cleared before the new items are selected.
 * <p>
 * Indices that are out of range are ignored and no items will be selected
 * if start is greater than end.
 * If the receiver is single-select and there is more than one item in the
 * given range, then all indices are ignored.
 * 
 * @param start the start index of the items to select
 * @param end the end index of the items to select
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Table#deselectAll()
 * @see Table#select(int,int)
 */
public void setSelection (int start, int end) {
	checkWidget ();
	deselectAll ();
	if (end < 0 || start > end || ((getStyle() & SWT.SINGLE) != 0 && start != end)) return;
	int count = getItemCount();
	if (count == 0 || start >= count) return;
	start = Math.max (0, start);
	end = Math.min (end, count - 1);
	select (start, end);
	OS.Table_SetFocusIndex (internal_handle, start);
	OS.Table_ShowItemIndex(internal_handle, start);
}

/**
 * Sets the zero-relative index of the item which is currently
 * at the top of the receiver. This index can change when items
 * are scrolled or new items are added and removed.
 *
 * @param index the index of the top item
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setTopIndex (int index) {
	checkWidget (); 
	OS.Table_SetTopItemIndex(internal_handle, index);
}

/**
 * Shows the column.  If the column is already showing in the receiver,
 * this method simply returns.  Otherwise, the columns are scrolled until
 * the column is visible.
 *
 * @param column the column to be shown
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the column is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if the column has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 3.0
 */
public void showColumn (TableColumn column) {
	checkWidget ();
	if (column == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (column.isDisposed()) error(SWT.ERROR_INVALID_ARGUMENT);
	if (column.parent != this) return;
	int index = indexOf (column);
	if (index == -1) return;
	int count = getColumnCount();
	if (count <= 1) return;
	if ((index < 0 )|| (index >= count)) return;
	OS.Table_ShowColumnIndex(internal_handle, index);
}

/**
 * Shows the item.  If the item is already showing in the receiver,
 * this method simply returns.  Otherwise, the items are scrolled until
 * the item is visible.
 *
 * @param item the item to be shown
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the item is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if the item has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Table#showSelection()
 */
public void showItem (TableItem item) {
	checkWidget ();
	if (item == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (item.isDisposed()) error(SWT.ERROR_INVALID_ARGUMENT);
	int index = indexOf (item);
	OS.Table_ShowItemIndex(internal_handle, index);
}

/**
 * Shows the selection.  If the selection is already showing in the receiver,
 * this method simply returns.  Otherwise, the items are scrolled until
 * the selection is visible.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Table#showItem(TableItem)
 */
public void showSelection () {
	int index = getSelectionIndex();
	if (index != -1) showItem(getItem(index));
}
void sort (int [] items) {
	int length = items.length;
	for (int gap=length/2; gap>0; gap/=2) {
		for (int i=gap; i<length; i++) {
			for (int j=i-gap; j>=0; j-=gap) {
		   		if (items [j] <= items [j + gap]) {
					int swap = items [j];
					items [j] = items [j + gap];
					items [j + gap] = swap;
		   		}
	    	}
	    }
	}
}
/*
 * Handle table events. 
 */
private int tableCallback(int itemIndex, int detail, int type) {
	int result = 0;
	Event event = new Event();
	boolean sendSetDataEvent = false;
	if (itemIndex != -1) {
		if(isVirtual) {
			if (items [itemIndex] == null) {
				items [itemIndex] = new TableItem (this, SWT.NONE, itemIndex);
				sendSetDataEvent = true;
			}
			result = items[itemIndex].internal_handle;
		}
		event.item = items[itemIndex];
	} else { 
		event.item = null;
	}
	switch (type) {
		case OS.EVENT_TABLE_SELECTION:
			if (detail != 0) event.detail = SWT.CHECK;
			postEvent(SWT.Selection, event);
			break;
		case OS.EVENT_TABLE_ACTION:
			if (detail != 0) event.detail = SWT.CHECK;
			postEvent(SWT.DefaultSelection, event);
			break;
		case OS.EVENT_TABLE_GETDISPINFO:
			if(sendSetDataEvent && detail == 0) {
				event.index = itemIndex;
				sendEvent(SWT.SetData, event, true);
			}
			break;
	}
	return result;

}
boolean isTrueComposite() {
	return false;
}

public boolean allowTraverseByArrowKey(Event event) {
	int focus = OS.Table_GetFocusIndex(internal_handle);
	switch (event.keyCode) {
		case SWT.ARROW_LEFT :
		case SWT.ARROW_RIGHT :	
			return true;
		case SWT.ARROW_UP :
			if(focus <= 0) {
				return true;
			}
			break;
		case SWT.ARROW_DOWN :	
			if(focus == -1 || focus >= this.getItemCount()-1) {
				return true;
			}
			break;
	}
	return false;
}

protected boolean traverse(Event event) {
	if (isDisposed()) return false;
	if(allowTraverseByArrowKey(event)) {
		return traverseByArrowKey(event);
	}
	return super.traverse(event);
}

}
