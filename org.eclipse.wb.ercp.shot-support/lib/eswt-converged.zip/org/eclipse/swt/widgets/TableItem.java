/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

 
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.internal.Platform;

import com.ibm.ugl.eswt.expanded.OS;

/**
 * Instances of this class represent a selectable user interface object
 * that represents an item in a table.
 * <dl>
 * <dt><b>Styles:</b></dt>
 * <dd>(none)</dd>
 * <dt><b>Events:</b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */

public class TableItem extends Item {
	Table parent;
	String [] texts;
	Image [] images;
	int fgRGB = -1;
	int bgRGB = -1;
	int[] cellFgRGBs = null;
	int[] cellBgRGBs = null;
	Font[] cellFonts = null;
	Font font = null;

/**
 * Constructs a new instance of this class given its parent
 * (which must be a <code>Table</code>) and a style value
 * describing its behavior and appearance. The item is added
 * to the end of the items maintained by its parent.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a composite control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public TableItem (Table parent, int style) {
	super(parent, style);
	int index = parent.getItemCount();
	parent.addItem(this, index);
	this.parent = parent;
	createWidget(index);
}

/**
 * Constructs a new instance of this class given its parent
 * (which must be a <code>Table</code>), a style value
 * describing its behavior and appearance, and the index
 * at which to place it in the items maintained by its parent.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a composite control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 * @param index the index to store the receiver in its parent
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public TableItem (Table parent, int style, int index) {
	super(parent, style);
	int numItems = parent.getItemCount();
	if (index < 0) error (SWT.ERROR_INVALID_RANGE);
	if (index > numItems) error (SWT.ERROR_INVALID_RANGE);
	parent.addItem(this, index);
	this.parent = parent;
	createWidget(index);
}
void adjustListWidth() {
	int row = parent.indexOf(this);
	TableColumn col = parent.columns[0];
	int newWidth = OS.TableColumn_GetMinimumWidth(col.internal_handle, row);
	int width = OS.TableColumn_GetWidth(col.internal_handle);
	if (newWidth > width) OS.TableColumn_SetWidth(col.internal_handle, newWidth);	
}
/**
 * Returns the receiver's background color.
 *
 * @return the background color
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0
 * 
 */
public Color getBackground () {
	checkWidget();
	if (bgRGB == -1) return getParent().getBackground();
	RGB rgbObject = RGBUtils.fromRGBInt(bgRGB);
	return new Color(getDisplay(),rgbObject);
}

/**
 * Returns the background color at the given column index in the receiver.
 *
 * @param index the column index
 * @return the background color
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 3.0
 */
public Color getBackground (int index) {
	checkWidget ();
	if (!isValidColumnIndex(index)) return getBackground ();
	if (cellBgRGBs == null) return getBackground();
	if (cellBgRGBs[index] == -1) return getBackground();
	RGB rgbObject = RGBUtils.fromRGBInt(cellBgRGBs[index]);
	return new Color(getDisplay(),rgbObject);
}

/**
 * Returns a rectangle describing the receiver's size and location
 * relative to its parent at a column in the table.
 *
 * @param index the index that specifies the column
 * @return the receiver's bounding column rectangle
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Rectangle getBounds (int index) {
	checkWidget ();
	if (index == -1) return new Rectangle (0, 0, 0, 0);
	if (!isValidColumnIndex(index)) return new Rectangle (0, 0, 0, 0);
	int itemIndex = parent.indexOf (this);
	int[] rect = OS.TableItem_GetBounds(getParent().internal_handle, itemIndex, index);
	return new Rectangle(rect[com.ibm.ugl.p3ml.OS.INDEX_X],rect[com.ibm.ugl.p3ml.OS.INDEX_Y],rect[com.ibm.ugl.p3ml.OS.INDEX_WIDTH],rect[com.ibm.ugl.p3ml.OS.INDEX_HEIGHT]); 
}

/**
 * Returns <code>true</code> if the receiver is checked,
 * and false otherwise.  When the parent does not have
 * the <code>CHECK</code> style, return false.
 *
 * @return the checked state of the checkbox
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getChecked () {
	checkWidget ();
	if ((parent.getStyle() & SWT.CHECK) == 0) return false;
	int itemIndex = parent.indexOf (this);
	return OS.TableItem_IsChecked(getParent().internal_handle, itemIndex);
}

/**
 * Returns the font that the receiver will use to paint textual information for this item.
 *
 * @return the receiver's font
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 3.0
 */
public Font getFont () {
	checkWidget ();
	return (this.font == null) ? getParent().getFont () : this.font;
}

/**
 * Returns the font that the receiver will use to paint textual information
 * for the specified cell in this item.
 *
 * @param index the column index
 * @return the receiver's font
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 3.0
 */
public Font getFont (int index) {
	checkWidget ();
	if (!isValidColumnIndex(index)) return getFont();
	Font cellFont = (cellFonts != null) ? cellFonts [index] : getFont();
	if (cellFont == null) cellFont = getFont();
	return cellFont;
}

/**
 * Returns the foreground color that the receiver will use to draw.
 *
 * @return the receiver's foreground color
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0
 * 
 */
public Color getForeground () {
	checkWidget();
	if (fgRGB == -1) return getParent().getForeground();
	RGB rgbObject = RGBUtils.fromRGBInt(fgRGB);
	return new Color(getDisplay(),rgbObject);
}

/**
 * 
 * Returns the foreground color at the given column index in the receiver.
 *
 * @param index the column index
 * @return the foreground color
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 3.0
 */
public Color getForeground (int index) {
	checkWidget ();
	if (!isValidColumnIndex(index)) return getForeground();
	if (cellFgRGBs == null) return getForeground();
	if (cellFgRGBs[index] == -1) return getForeground();
	RGB rgbObject = RGBUtils.fromRGBInt(cellFgRGBs[index]);
	return new Color(getDisplay(),rgbObject);
}

/**
 * Returns <code>true</code> if the receiver is grayed,
 * and false otherwise. When the parent does not have
 * the <code>CHECK</code> style, return false.
 *
 * @return the grayed state of the checkbox
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getGrayed () {
	checkWidget ();
	if ((parent.getStyle() & SWT.CHECK) == 0) return false;
	int itemIndex = parent.indexOf (this);
	return OS.TableItem_IsGrayed(getParent().internal_handle, itemIndex);
}

/**
 * Returns the image stored at the given column index in the receiver,
 * or null if the image has not been set or if the column does not exist.
 *
 * @param index the column index
 * @return the image stored at the given column index in the receiver
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Image getImage (int index) {
	checkWidget();
	if (!isValidColumnIndex(index)) return null;
	if (images != null) {
		if (0 <= index && index < images.length) return images [index];
	} else {
		return getImage();
	}
	return null;
}

/**
 * Returns a rectangle describing the size and location
 * relative to its parent of an image at a column in the
 * table.  An empty rectangle is returned if index exceeds
 * the index of the table's last column.
 *
 * @param index the index that specifies the column
 * @return the receiver's bounding image rectangle
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Rectangle getImageBounds (int index) {
	checkWidget ();
	if (index == -1) return new Rectangle (0, 0, 0, 0);
	if ((index < 0) || (index >= parent.getItemCount())) return new Rectangle (0, 0, 0, 0);
	int itemIndex = parent.indexOf (this);
	int[] rect = OS.TableItem_GetImageBounds(getParent().internal_handle, itemIndex, index);
	return new Rectangle(rect[com.ibm.ugl.p3ml.OS.INDEX_X],rect[com.ibm.ugl.p3ml.OS.INDEX_Y],rect[com.ibm.ugl.p3ml.OS.INDEX_WIDTH],rect[com.ibm.ugl.p3ml.OS.INDEX_HEIGHT]); 
}

/**
 * Returns the receiver's parent, which must be a <code>Table</code>.
 *
 * @return the receiver's parent
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Table getParent () {
	return parent;
}

/**
 * Returns the text stored at the given column index in the receiver,
 * or empty string if the text has not been set.
 *
 * @param index the column index
 * @return the text stored at the given column index in the receiver
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public String getText (int index) {
	checkWidget ();
	if (!isValidColumnIndex(index)) return "";
	if (texts != null) {
		if (0 <= index && index < texts.length) {
			String string = texts [index];
			return string != null ? string : "";
		}
	}
	return "";
}
boolean hasNativeEvents() {
	return false;
}
protected void internal_createHandle(int index) {
	internal_handle = OS.TableItem_New(parent.internal_handle, index);
}
boolean isSelected() {
	int itemIndex = parent.indexOf (this);
	return OS.TableItem_IsSelected(getParent().internal_handle, itemIndex);
}
private boolean isValidColumnIndex(int index) {
	int count = getParent().internal_getColumnCount ();
	if (index < 0 || (index > count - 1)) return false;
	return true;
}
void internalClear() {
	parent = null;
	texts = null;
	images = null;
	cellBgRGBs = cellFgRGBs = null;
	image = null;
	releaseHandle ();
}
void remove() {
	super.releaseWidget ();
	internalClear();
}
protected void releaseHandle () {
	internal_handle = 0;
	display = null;
}
protected void releaseWidget () {
	super.releaseWidget ();
	parent.destroyItem (this);
	internalClear();
}
/**
 * Sets the receiver's background color to the color specified
 * by the argument, or to the default system color for the item
 * if the argument is null.
 *
 * @param color the new color (or null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0
 * 
 */
public void setBackground (Color color) {
	checkWidget ();
	if (color != null && color.isDisposed ()) {
		SWT.error (SWT.ERROR_INVALID_ARGUMENT);
	}
	int itemIndex = parent.indexOf (this);
	if (color == null) bgRGB = -1;
	else bgRGB = RGBUtils.toRGBInt(color.getRGB());
	if (color == null) {
		OS.TableItem_SetBackground(getParent().internal_handle, itemIndex, 0);
	}
	else {
	    OS.TableItem_SetBackground(getParent().internal_handle, itemIndex,color.internal_handle);
	}
}

/**
 * Sets the background color at the given column index in the receiver 
 * to the color specified by the argument, or to the default system color for the item
 * if the argument is null.
 *
 * @param index the column index
 * @param color the new color (or null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 3.0
 * 
 */
public void setBackground (int index, Color color) {
	checkWidget ();
	if (color != null && color.isDisposed ()) {
		SWT.error (SWT.ERROR_INVALID_ARGUMENT);
	}
	if (!isValidColumnIndex(index)) return;
	int itemIndex = parent.indexOf (this);
	int count = getParent().internal_getColumnCount();
	int rgb;
	if (color == null) rgb = -1;
	else rgb = RGBUtils.toRGBInt(color.getRGB());
	if (cellBgRGBs == null) {
		cellBgRGBs = new int [count];
		for (int i = 0; i < count; i++) {
			cellBgRGBs [i] = -1;
		}
	}
	if (cellBgRGBs [index] == rgb) return;
	cellBgRGBs [index] = rgb;
	if (color == null) {
		OS.TableItem_SetCellBackground(getParent().internal_handle, itemIndex, index, 0);
	} else {
		OS.TableItem_SetCellBackground(getParent().internal_handle, itemIndex, index, color.internal_handle);
	}
}

/**
 * Sets the checked state of the checkbox for this item.  This state change 
 * only applies if the Table was created with the SWT.CHECK style.
 *
 * @param checked the new checked state of the checkbox
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setChecked (boolean checked) {
	checkWidget();
	if ((parent.getStyle() & SWT.CHECK) == 0) return;
	int itemIndex = parent.indexOf (this);
	OS.TableItem_SetChecked(getParent().internal_handle, itemIndex, checked);
}

/**
 * Sets the font that the receiver will use to paint textual information
 * for this item to the font specified by the argument, or to the default font
 * for that kind of control if the argument is null.
 *
 * @param font the new font (or null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 3.0
 */
public void setFont (Font font){
	int fontHandle;
	if (font != null) {
		if (font.isDisposed()) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		fontHandle = font.internal_handle;
	} else {
		fontHandle = 0;
	}
	int itemIndex = parent.indexOf (this);
	OS.TableItem_SetFont(getParent().internal_handle, itemIndex, fontHandle);
	this.font = font;
	if (parent.isList()) adjustListWidth();
}

/**
 * Sets the font that the receiver will use to paint textual information
 * for the specified cell in this item to the font specified by the 
 * argument, or to the default font for that kind of control if the 
 * argument is null.
 *
 * @param index the column index
 * @param font the new font (or null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 3.0
 */
public void setFont (int index, Font font) {
	checkWidget ();
	if (font != null && font.isDisposed ()) {
		SWT.error (SWT.ERROR_INVALID_ARGUMENT);
	}
	if (!isValidColumnIndex(index)) return;
	int itemIndex = parent.indexOf (this);
	int count = getParent().internal_getColumnCount();
	if (cellFonts == null) {
		cellFonts = new Font [count];
	}
	if (cellFonts [index] == font) return;
	cellFonts [index] = font;
	if (font == null) {
		OS.TableItem_SetCellFont(getParent().internal_handle, itemIndex, index, 0);
	} else {
		OS.TableItem_SetCellFont(getParent().internal_handle, itemIndex, index, font.internal_handle);
	}
	if (parent.isList()) adjustListWidth();
}
/**
 * Sets the receiver's foreground color to the color specified
 * by the argument, or to the default system color for the item
 * if the argument is null.
 *
 * @param color the new color (or null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.0
 * 
 */
public void setForeground (Color color){
	checkWidget ();
	if (color != null && color.isDisposed ()) {
		SWT.error (SWT.ERROR_INVALID_ARGUMENT);
	}
	int itemIndex = parent.indexOf (this);
	if (color == null) fgRGB = -1;
	else fgRGB = RGBUtils.toRGBInt(color.getRGB());
	if (color == null) {
		OS.TableItem_SetForeground(getParent().internal_handle, itemIndex, 0);
	}
	else {
	    OS.TableItem_SetForeground(getParent().internal_handle, itemIndex, color.internal_handle);
	}
}

/**
 * Sets the foreground color at the given column index in the receiver 
 * to the color specified by the argument, or to the default system color for the item
 * if the argument is null.
 *
 * @param index the column index
 * @param color the new color (or null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 3.0
 * 
 */
public void setForeground (int index, Color color){
	checkWidget ();
	if (color != null && color.isDisposed ()) {
		SWT.error (SWT.ERROR_INVALID_ARGUMENT);
	}
	if (!isValidColumnIndex(index)) return;
	int itemIndex = parent.indexOf (this);
	int count = getParent().internal_getColumnCount();
	int rgb;
	if (color == null) rgb = -1;
	else rgb = RGBUtils.toRGBInt(color.getRGB());
	if (cellFgRGBs == null) {
		cellFgRGBs = new int [count];
		for (int i = 0; i < count; i++) {
			cellFgRGBs [i] = -1;
		}
	}
	if (cellFgRGBs [index] == rgb) return;
	cellFgRGBs [index] = rgb;
	if (color == null) {
		OS.TableItem_SetCellForeground(getParent().internal_handle, itemIndex, index, 0);
	} else {
		OS.TableItem_SetCellForeground(getParent().internal_handle, itemIndex, index, color.internal_handle);
	}
}

/**
 * Sets the grayed state of the checkbox for this item.  This state change 
 * only applies if the Table was created with the SWT.CHECK style.
 *
 * @param grayed the new grayed state of the checkbox; 
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setGrayed (boolean grayed) {
	checkWidget();
	if ((parent.getStyle() & SWT.CHECK) == 0) return;
	int itemIndex = parent.indexOf (this);
	OS.TableItem_SetGrayed(getParent().internal_handle, itemIndex, grayed);
}

/**
 * Sets the image for multiple columns in the Table. 
 * 
 * @param images the array of new images
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the array of images is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if one of the images has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setImage (Image [] images) {
	checkWidget();
	if (images == null) error (SWT.ERROR_NULL_ARGUMENT);
	for (int i=0; i<images.length; i++) {
		setImage (i, images [i]);
	}
}

/**
 * Sets the receiver's image at a column.
 *
 * @param index the column index
 * @param image the new image
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the image has been disposed</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setImage (int index, Image image) {
	checkWidget();
	if (image != null && image.isDisposed ()) {
		error(SWT.ERROR_INVALID_ARGUMENT);
	}
	super.setImage (image);
	int itemIndex = parent.indexOf (this);
	if (!isValidColumnIndex(index)) return;
	int count = getParent().internal_getColumnCount();
	if (images == null) images = new Image [count];
	if ((image != null) && image.equals(images[index])) return;
	images [index] = image;
	int imageHandle = (image == null) ? 0 : image.internal_handle;
	OS.TableItem_SetImage(getParent().internal_handle, internal_handle, itemIndex, index, imageHandle);
	if (parent.isList()) adjustListWidth();
}

public void setImage (Image image) {
	checkWidget();
	setImage (0, image);
	if (parent.isList()) adjustListWidth();
}
void setSelected(boolean selected) {
	int itemIndex = parent.indexOf (this);
	OS.TableItem_SetSelected(getParent().internal_handle, itemIndex, selected);
}
/**
 * Sets the text for multiple columns in the table. 
 * 
 * @param strings the array of new strings
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the text is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setText (String [] strings) {
	checkWidget();
	if (strings == null) error (SWT.ERROR_NULL_ARGUMENT);
	for (int i=0; i<strings.length; i++) {
		String string = strings [i];
		if (string != null) setText (i, string);
	}
}

/**
 * Sets the receiver's text at a column
 *
 * @param index the column index
 * @param string the new text
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the text is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setText (int index, String string) {
	checkWidget();
	if (string == null) error (SWT.ERROR_NULL_ARGUMENT);
	if (!isValidColumnIndex(index)) return;
	int itemIndex = parent.indexOf (this);
	int count = getParent().internal_getColumnCount();
	if (texts == null) texts = new String [count];
	if (texts != null) {
		if (index == 0) super.setText(string);
		if (string.equals (texts [index])) return;
		texts [index] = string;
	}
	
	//fix bug 284073
	if(!Platform.isWin32()){
		while(string.indexOf("\n")!=-1){
			string = string.replace('\n', ' ');
		}
		while(string.indexOf("\r")!=-1){
			string = string.replace('\r', ' ');
		}
	}
	
	
	OS.TableItem_SetCellText(getParent().internal_handle, internal_handle, itemIndex, index, string);
	if (parent.isList()) adjustListWidth();
}

public void setText (String string) {
	checkWidget();
	setText (0, string);
	if (parent.isList()) adjustListWidth();
}

}
