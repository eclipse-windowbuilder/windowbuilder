/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

import org.eclipse.swt.graphics.RGB;

class RGBUtils {

	public static final int toRGBInt(RGB rgb) {
		if (rgb == null) return -1;
		
		int rgbInt = (rgb.red & 0xFF) << 16;
		rgbInt |= (rgb.green & 0xFF) << 8;
		rgbInt |= (rgb.blue & 0xFF);
		return rgbInt;
	}
	
	public static final RGB fromRGBInt(int rgb) {
		return new RGB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
	}
	
}
