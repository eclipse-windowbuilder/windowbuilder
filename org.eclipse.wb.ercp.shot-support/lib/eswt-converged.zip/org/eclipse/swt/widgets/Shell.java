/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

 
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.events.ShellListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.internal.Messages;
import org.eclipse.swt.internal.Platform;

import com.ibm.ugl.eswt.OS;

/**
 * Instances of this class represent the "windows"
 * which the desktop or "window manager" is managing.
 * Instances that do not have a parent (that is, they
 * are built using the constructor, which takes a 
 * <code>Display</code> as the argument) are described
 * as <em>top level</em> shells. Instances that do have
 * a parent are described as <em>secondary</em> or
 * <em>dialog</em> shells.
 * <p>
 * Instances are always displayed in one of the maximized, 
 * minimized or normal states:
 * <ul>
 * <li>
 * When an instance is marked as <em>maximized</em>, the
 * window manager will typically resize it to fill the
 * entire visible area of the display, and the instance
 * is usually put in a state where it can not be resized 
 * (even if it has style <code>RESIZE</code>) until it is
 * no longer maximized.
 * </li><li>
 * When an instance is in the <em>normal</em> state (neither
 * maximized or minimized), its appearance is controlled by
 * the style constants which were specified when it was created
 * and the restrictions of the window manager (see below).
 * </li><li>
 * When an instance has been marked as <em>minimized</em>,
 * its contents (client area) will usually not be visible,
 * and depending on the window manager, it may be
 * "iconified" (that is, replaced on the desktop by a small
 * simplified representation of itself), relocated to a
 * distinguished area of the screen, or hidden. Combinations
 * of these changes are also possible.
 * </li>
 * </ul>
 * </p>
 * <p>
 * Note: The styles supported by this class must be treated
 * as <em>HINT</em>s, since the window manager for the
 * desktop on which the instance is visible has ultimate
 * control over the appearance and behavior of decorations
 * and modality. For example, some window managers only
 * support resizable windows and will always assume the
 * RESIZE style, even if it is not set. In addition, if a
 * modality style is not supported, it is "upgraded" to a
 * more restrictive modality style that is supported. For
 * example, if <code>PRIMARY_MODAL</code> is not supported,
 * it would be upgraded to <code>APPLICATION_MODAL</code>.
 * <dl>
 * <dt><b>Styles:</b></dt>
 * <dd>BORDER, CLOSE, MIN, MAX, NO_TRIM, RESIZE, TITLE</dd>
 * <dd>APPLICATION_MODAL, MODELESS, PRIMARY_MODAL, SYSTEM_MODAL</dd>
 * <dt><b>Events:</b></dt>
 * <dd>Activate, Close, Deactivate, Deiconify, Iconify</dd>
 * </dl>
 * Class <code>SWT</code> provides two "convenience constants"
 * for the most commonly required style combinations:
 * <dl>
 * <dt><code>SHELL_TRIM</code></dt>
 * <dd>
 * the result of combining the constants which are required
 * to produce a typical application top level shell: (that 
 * is, <code>CLOSE | TITLE | MIN | MAX | RESIZE</code>)
 * </dd>
 * <dt><code>DIALOG_TRIM</code></dt>
 * <dd>
 * the result of combining the constants which are required
 * to produce a typical application dialog shell: (that 
 * is, <code>TITLE | CLOSE | BORDER</code>)
 * </dd>
 * </dl>
 * </p>
 * <p>
 * Note: Only one of the styles APPLICATION_MODAL, MODELESS, 
 * PRIMARY_MODAL and SYSTEM_MODAL may be specified.
 * </p><p>
 * IMPORTANT: This class is not intended to be subclassed.
 * </p>
 *
 * @see Decorations
 * @see SWT
 */
public class Shell extends Decorations {
	boolean trimAdjusted;
	int oldWidth, oldHeight;
	boolean exposed = false;
	int minWidth = -1;
	int minHeight = -1;
	Control lastFocusedControl = null;
	
	private ShellListener shellListener = null;	// for smartphone
	private MenuItem closeMenuItem = null;		// for smartphone
	Class CommandClass = null;			// for WM related platforms
	boolean closeStyle = false;
	
/**
 * Constructs a new instance of this class. This is equivalent
 * to calling <code>Shell((Display) null)</code>.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 */
public Shell() {
	this((Display) null);
}
/**
 * Constructs a new instance of this class given only the style
 * value describing its behavior and appearance. This is equivalent
 * to calling <code>Shell((Display) null, style)</code>.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param style the style of control to construct
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 * 
 * @see SWT#BORDER
 * @see SWT#CLOSE
 * @see SWT#MIN
 * @see SWT#MAX
 * @see SWT#RESIZE
 * @see SWT#TITLE
 * @see SWT#NO_TRIM
 * @see SWT#SHELL_TRIM
 * @see SWT#DIALOG_TRIM
 * @see SWT#MODELESS
 * @see SWT#PRIMARY_MODAL
 * @see SWT#APPLICATION_MODAL
 * @see SWT#SYSTEM_MODAL
 */
public Shell(int style) {
	this((Display) null, style);
}
/**
 * Constructs a new instance of this class given only the display
 * to create it on. It is created with style <code>SWT.SHELL_TRIM</code>.
 * <p>
 * Note: Currently, null can be passed in for the display argument.
 * This has the effect of creating the shell on the currently active
 * display if there is one. If there is no current display, the 
 * shell is created on a "default" display. <b>Passing in null as
 * the display argument is not considered to be good coding style,
 * and may not be supported in a future release of SWT.</b>
 * </p>
 *
 * @param display the display to create the shell on
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 */
public Shell(Display display) {
	this(display, SWT.SHELL_TRIM);
}
/**
 * Constructs a new instance of this class given the display
 * to create it on and a style value describing its behavior
 * and appearance.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p><p>
 * Note: Currently, null can be passed in for the display argument.
 * This has the effect of creating the shell on the currently active
 * display if there is one. If there is no current display, the 
 * shell is created on a "default" display. <b>Passing in null as
 * the display argument is not considered to be good coding style,
 * and may not be supported in a future release of SWT.</b>
 * </p>
 *
 * @param display the display to create the shell on
 * @param style the style of control to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the parent is disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 * 
 * @see SWT#BORDER
 * @see SWT#CLOSE
 * @see SWT#MIN
 * @see SWT#MAX
 * @see SWT#RESIZE
 * @see SWT#TITLE
 * @see SWT#NO_TRIM
 * @see SWT#SHELL_TRIM
 * @see SWT#DIALOG_TRIM
 * @see SWT#MODELESS
 * @see SWT#PRIMARY_MODAL
 * @see SWT#APPLICATION_MODAL
 * @see SWT#SYSTEM_MODAL
 */
public Shell(Display display, int style) {
	this(display, null, style, 0);
}
Shell(Display display, Shell parent, int style, int handle) {
	super();
	checkSubclass();
	if(!isValidSubclass()){
		error(SWT.ERROR_INVALID_SUBCLASS);
	}
	if (display == null) display = Display.getCurrent();
	if (display == null) display = Display.getDefault();
	if (!display.isValidThread()) {
		error(SWT.ERROR_THREAD_INVALID_ACCESS);
	}
	if (parent != null && parent.isDisposed ()) {
		error (SWT.ERROR_INVALID_ARGUMENT);	
	}

	//For WM related devices, make right-upper ok button to disable replacing with X button for minimizing shell only.
	if((Platform.isWindowMobile() || Platform.isSmartPhone() ) && (style & SWT.CLOSE) != 0) {
		style &= ~SWT.CLOSE;
		closeStyle = true;
	}

	this.internal_style = checkStyle(style);
	this.internal_parent = parent;
	this.display = display;
	this.internal_handle = handle;
	this.visible = false;
	createWidget(0);
	
	
	if( (Platform.isWindowMobile() || Platform.isSmartPhone() ) && closeStyle) {
		this.internal_style |= SWT.CLOSE;				
		try {
			CommandClass = Class.forName("org.eclipse.ercp.swt.mobile.Command");			
		} catch (ClassNotFoundException e1) {
			CommandClass = null;
		}
	}
	if(parent == null) {
		if((Platform.isWindowMobile() || Platform.isSmartPhone() ) && CommandClass != null) {
				//Implement close softkey by Mobile Extension -> Command widget without any mobile extension dependency 
	    		//However, the jvm must have java.lang.reflect related functionality to compile 
				try {
			        Constructor constructor;
					constructor = CommandClass.getConstructor(new Class[]{ Control.class, int.class, int.class});
					Object closeCMD = constructor.newInstance(new Object[] {this, new Integer(7), new Integer(-1)});
					Method method = CommandClass.getDeclaredMethod("setText", new Class[] { String.class });
					method.invoke(closeCMD, new Object[] { Messages.getString("Shell.0")});
					method = CommandClass.getDeclaredMethod("addSelectionListener", new Class[] { SelectionListener.class });
					SelectionListener closeCMDListener = new SelectionListener() {
	        	        public void widgetSelected(SelectionEvent e) {
	        	        	close();
	        	        }
	
						public void widgetDefaultSelected(SelectionEvent e) {						
						}
					};
					method.invoke(closeCMD, new Object[] { closeCMDListener});				
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (InstantiationException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}	        
		} else if ((Platform.isWindowMobile() || Platform.isSmartPhone() ) && CommandClass == null ){
				//Implement close softkey by menu widget while no Mobile Extension -> Command widget available.
					if(Platform.isSmartPhone() && (internal_style & SWT.CLOSE) != 0) {
						shellListener = new ShellListener() {
							public void shellActivated(ShellEvent e) {
								createCloseMenuItem();
							}
							public void shellClosed(ShellEvent e) {
							}
							public void shellDeactivated(ShellEvent e) {
								disposeCloseMenuItem();
							}
							public void shellDeiconified(ShellEvent e) {
							}
							public void shellIconified(ShellEvent e) {
							}
						};
						addShellListener(shellListener);
					}
			}	
	}
}

/**
 * Constructs a new instance of this class given only its
 * parent. It is created with style <code>SWT.DIALOG_TRIM</code>.
 * <p>
 * Note: Currently, null can be passed in for the parent.
 * This has the effect of creating the shell on the currently active
 * display if there is one. If there is no current display, the 
 * shell is created on a "default" display. <b>Passing in null as
 * the parent is not considered to be good coding style,
 * and may not be supported in a future release of SWT.</b>
 * </p>
 *
 * @param parent a shell which will be the parent of the new instance
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the parent is disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 */
public Shell(Shell parent) {
	this(parent, SWT.DIALOG_TRIM);
}
/**
 * Constructs a new instance of this class given its parent
 * and a style value describing its behavior and appearance.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p><p>
 * Note: Currently, null can be passed in for the parent.
 * This has the effect of creating the shell on the currently active
 * display if there is one. If there is no current display, the 
 * shell is created on a "default" display. <b>Passing in null as
 * the parent is not considered to be good coding style,
 * and may not be supported in a future release of SWT.</b>
 * </p>
 *
 * @param parent a shell which will be the parent of the new instance
 * @param style the style of control to construct
 *
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 * 
 * @see SWT#BORDER
 * @see SWT#CLOSE
 * @see SWT#MIN
 * @see SWT#MAX
 * @see SWT#RESIZE
 * @see SWT#TITLE
 * @see SWT#NO_TRIM
 * @see SWT#SHELL_TRIM
 * @see SWT#DIALOG_TRIM
 * @see SWT#MODELESS
 * @see SWT#PRIMARY_MODAL
 * @see SWT#APPLICATION_MODAL
 */
public Shell(Shell parent, int style) {
	this(parent != null ? parent.getDisplay() : null, parent, style, 0);
}

void register() {
	display.addShell(this);
}

void deregister() {
	display.removeShell(this);
}

private void shellCallback(int event) {
	switch (event) {
		case OS.EVENT_SHELL_ACTIVATED:
//			if (lastFocusedControl != null) {
//				lastFocusedControl.setFocus();
//			}
//			else {
//				setFocus();
//			}
			getDisplay().activeShell = this;
			internal_sendEvent(SWT.Activate);
			break;
		case OS.EVENT_SHELL_DEACTIVATED:
			Control c = display.getFocusControl();
			if ((c == null) || c.isDisposed()|| (c.getShell() != this)) {
				lastFocusedControl = null;
			} else {
				lastFocusedControl = c;
			}
			internal_sendEvent(SWT.Deactivate);
			break;
		case OS.EVENT_SHELL_ICONIFIED:
			internal_sendEvent(SWT.Iconify);
			break;
		case OS.EVENT_SHELL_DEICONIFIED:
			internal_sendEvent(SWT.Deiconify);
			break;
		case OS.EVENT_SHELL_CLOSING:
			close();
			break;
	}
}

/**
 * Adds the listener to the collection of listeners who will
 * be notified when operations are performed on the receiver,
 * by sending the listener one of the messages defined in the
 * <code>ShellListener</code> interface.
 *
 * @param listener the listener which should be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see ShellListener
 * @see #removeShellListener
 */
public void addShellListener(ShellListener listener) {
	checkWidget();
	if (listener == null) error(SWT.ERROR_NULL_ARGUMENT);
	TypedListener typedListener = new TypedListener(listener);
	addListener(SWT.Close, typedListener);
	addListener(SWT.Iconify, typedListener);
	addListener(SWT.Deiconify, typedListener);
	addListener(SWT.Activate, typedListener);
	addListener(SWT.Deactivate, typedListener);
}

static int checkStyle(int style) {
	style = Decorations.checkStyle(style);
	int mask = SWT.APPLICATION_MODAL | SWT.PRIMARY_MODAL;
	int bits = style & ~mask;
	if ((style & SWT.APPLICATION_MODAL) != 0) return bits | SWT.APPLICATION_MODAL;
	if ((style & SWT.PRIMARY_MODAL) != 0) return bits | SWT.PRIMARY_MODAL;
	return bits;
}
/**	 
 * Requests that the window manager close the receiver in
 * the same way it would be closed when the user clicks on
 * the "close box" or performs some other platform specific
 * key or mouse combination that indicates the window
 * should be removed.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SWT#Close
 * @see #dispose
 */
public void close() {
	checkWidget();
	closeWidget();
}

void closeWidget() {
	if (!isEnabled()) return;
	Control widget = internal_parent;
	// Find the highest modal parent.
	while (widget != null && !(widget.getShell().isModal())) {
		widget = widget.internal_parent;
	}
	// If no modal parent was found, find the first modal 
	// and visible child Shell, bring it to the top, and
	// return without disposing this Shell.
	if (widget == null) {
		Shell[] shells = getShells();
		for (int i = 0; i < shells.length; i++) {
			Shell shell = shells[i];
			if (shell != this && shell.isModal() && shell.isVisible()) {
				shell.bringToTop();
				return;
			}
		}
	}
	Event event = new Event();
	sendEvent(SWT.Close, event);
	if (event.doit && !isDisposed()) dispose();
}

protected void internal_createHandle(int index) {
	if(internal_parent == null)
		internal_handle = OS.Shell_New(display.internal_handle, internal_getNativeStyle());
	else
		internal_handle = OS.Shell_NewChild(internal_parent.internal_handle, internal_getNativeStyle());
	if (internal_handle == 0) error(SWT.ERROR_NO_HANDLES);
	
	boolean resizable = false;
	if ((internal_style & SWT.RESIZE) == SWT.RESIZE) {
		resizable = true;
	}
	OS.Shell_SetResizable(internal_handle, resizable);
	
	trimAdjusted = false;
}

/**
 * If the receiver is visible, moves it to the top of the 
 * drawing order for the display on which it was created 
 * (so that all other shells on that display, which are not 
 * the receiver's children will be drawn behind it) and forces 
 * the window manager to make the shell active.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 2.0
 * @see Control#moveAbove
 * @see Control#setFocus
 * @see Control#setVisible
 * @see Display#getActiveShell
 * @see Decorations#setDefaultButton
 * @see Shell#open
 * @see Shell#setActive
 */
public void forceActive () {
	checkWidget();
	bringToTop();
}

/**
 * Returns the receiver's input method editor mode. This
 * will be the result of bitwise OR'ing together one or
 * more of the following constants defined in class
 * <code>SWT</code>:
 * <code>NONE</code>, <code>ROMAN</code>, <code>DBCS</code>, 
 * <code>PHONETIC</code>, <code>NATIVE</code>, <code>ALPHA</code>.
 *
 * @return the IME mode
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SWT
 */
public int getImeInputMode() {
	checkWidget();
	return SWT.NONE;
}

protected int internal_getNativeStyle() {
	int nativeStyle = super.internal_getNativeStyle();
	
	if ((internal_style & SWT.APPLICATION_MODAL) == SWT.APPLICATION_MODAL) {
		nativeStyle |= OS.STYLE_APPLICATION_MODAL;
	}
	if ((internal_style & SWT.MODELESS) == SWT.MODELESS) {
		nativeStyle |= OS.STYLE_MODELESS;
	}
	if ((internal_style & SWT.PRIMARY_MODAL) == SWT.PRIMARY_MODAL) {
		nativeStyle |= OS.STYLE_PRIMARY_MODAL;
	}
	if ((internal_style & SWT.BORDER) == SWT.BORDER) {
		nativeStyle |= OS.STYLE_BORDER;
	}
	if ((internal_style & SWT.CLOSE) == SWT.CLOSE) {
		nativeStyle |= OS.STYLE_CLOSE;
	}
	if ((internal_style & SWT.MIN) == SWT.MIN) {
		nativeStyle |= OS.STYLE_MIN;
	}
	if ((internal_style & SWT.MAX) == SWT.MAX) {
		nativeStyle |= OS.STYLE_MAX;
	}
	if ((internal_style & SWT.NO_TRIM) == SWT.NO_TRIM) {
		nativeStyle |= OS.STYLE_NO_TRIM;
	}
	if ((internal_style & SWT.TITLE) == SWT.TITLE) {
		nativeStyle |= OS.STYLE_TITLE;
	}
	if ((internal_style & SWT.ON_TOP) == SWT.ON_TOP) {
	    nativeStyle |= OS.STYLE_ON_TOP;
	}
	
	return nativeStyle;
}

/**
 * Returns <code>true</code> if the receiver is currently
 * maximized, and false otherwise. 
 * <p>
 *
 * @return the maximized state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see #setMaximized
 */
public boolean getMaximized() {
	checkWidget();
	if (OS.Platform_GetCapability(OS.CAPABILITY_SHELL_MINMAX) != 0) {
		return OS.Shell_GetMaximized(internal_handle);
	}
	else {
		return super.getMaximized();
	}
}

/**
 * Returns <code>true</code> if the receiver is currently
 * minimized, and false otherwise. 
 * <p>
 *
 * @return the minimized state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see #setMinimized
 */
public boolean getMinimized() {
	checkWidget();
	if (OS.Platform_GetCapability(OS.CAPABILITY_SHELL_MINMAX) != 0) {
		return OS.Shell_GetMinimized(internal_handle);
	}
	else {
		return super.getMinimized();
	}
}

/**
 * Sets the receiver's image to the argument, which may
 * be null. The image is typically displayed by the window
 * manager when the instance is marked as iconified, and
 * may also be displayed somewhere in the trim when the
 * instance is in normal or maximized states.
 * 
 * @param image the new image (or null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if the image has been disposed</li> 
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setImage(Image image) {
	super.setImage(image);
	
	int imageHandle = image == null ? 0 : image.internal_handle;
	OS.Shell_SetImage(internal_handle, imageHandle);
}

/**
 * Returns the receiver's shell. For all controls other than
 * shells, this simply returns the control's nearest ancestor
 * shell. Shells return themselves, even if they are children
 * of other shells.
 *
 * @return the receiver's shell
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see #getParent
 */
public Shell getShell() {
	checkWidget();
	return this;
}
/** 
 * Returns an array containing all shells which are 
 * descendents of the receiver.
 * <p>
 * @return the dialog shells
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Shell[] getShells() {
	checkWidget();
	int count = 0;
	Shell[] shells = display.getShells();
	for (int i = 0; i < shells.length; i++) {
		Control shell = shells[i];
		do {
			shell = shell.internal_parent;
		} while (shell != null && shell != this);
		if (shell == this) count++;
	}
	int index = 0;
	Shell[] result = new Shell[count];
	for (int i = 0; i < shells.length; i++) {
		Control shell = shells[i];
		do {
			shell = shell.internal_parent;
		} while (shell != null && shell != this);
		if (shell == this) {
			result[index++] = shells[i];
		}
	}
	return result;
}

boolean isModal() {
	checkWidget();
	// TODO Is this correct?  The window manager may not have honored the style...
	return isStyleModal();
}

boolean isStyleModal() {
	boolean modal = (
		((internal_style & SWT.APPLICATION_MODAL) != 0) ||
		((internal_style & SWT.PRIMARY_MODAL) != 0)
	);
	return modal;
}

/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Control#isVisible()
 */
public boolean isVisible() {
    /*
     * Shell ancestry is different from normal Control ancestry 
     * because children can become visible even when the parent 
     * is not visible.
     */
    return getVisible();
}

/**
 * Moves the receiver to the top of the drawing order for
 * the display on which it was created (so that all other
 * shells on that display, which are not the receiver's
 * children will be drawn behind it), marks it visible,
 * sets the focus and asks the window manager to make the
 * shell active.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see Control#moveAbove
 * @see Control#setFocus
 * @see Control#setVisible
 * @see Display#getActiveShell
 * @see Decorations#setDefaultButton
 * @see Shell#setActive
 * @see Shell#forceActive
 */
public void open() {
	checkWidget();
	layout(true);
	// set initial focus before making shell visible to avoid 
	// flash. See bug 110131.
	// need to move the traverseGroup to after the Shell's been bring
	// to top for correct initial focusing.  cannot find the flashing
	// bug and do not see the flashing behavior
	setVisible(true);
	bringToTop();
	if (!restoreFocus () && !traverseGroup (true)) setFocus ();
//	traverseGroup(true);
	
}

void releaseShells() {
	Shell[] shells = getShells();
	for (int i = 0; i < shells.length; i++) {
		Shell shell = shells[i];
		if (!shell.isDisposed()) shell.releaseResources();
	}
}

protected void releaseWidget() {
	if ((Platform.isWindowMobile() || Platform.isSmartPhone() ) && CommandClass == null ) {
		if(shellListener != null) {
			removeShellListener(shellListener);
		}
	}
	releaseShells();
	super.releaseWidget();
	oldWidth = oldHeight = 0;
}
/**
 * Removes the listener from the collection of listeners who will
 * be notified when operations are performed on the receiver.
 *
 * @param listener the listener which should no longer be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see ShellListener
 * @see #addShellListener
 */
public void removeShellListener(ShellListener listener) {
	checkWidget();
	if (listener == null) error(SWT.ERROR_NULL_ARGUMENT);
	if (eventTable == null) return;
	eventTable.unhook(SWT.Close, listener);
	eventTable.unhook(SWT.Iconify, listener);
	eventTable.unhook(SWT.Deiconify, listener);
	eventTable.unhook(SWT.Activate, listener);
	eventTable.unhook(SWT.Deactivate, listener);
}
/**
 * If the receiver is visible, moves it to the top of the 
 * drawing order for the display on which it was created 
 * (so that all other shells on that display, which are not 
 * the receiver's children will be drawn behind it) and asks 
 * the window manager to make the shell active 
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @since 2.0
 * @see Control#moveAbove
 * @see Control#setFocus
 * @see Control#setVisible
 * @see Display#getActiveShell
 * @see Decorations#setDefaultButton
 * @see Shell#open
 * @see Shell#setActive
 */
public void setActive () {
	checkWidget ();
	if(!isVisible()) return;
	bringToTop();
}

void bringToTop() {
	getDisplay().activeShell = this;
	OS.Control_MoveAbove(internal_handle,0);
}

/**
 * Sets the input method editor mode to the argument which 
 * should be the result of bitwise OR'ing together one or more
 * of the following constants defined in class <code>SWT</code>:
 * <code>NONE</code>, <code>ROMAN</code>, <code>DBCS</code>, 
 * <code>PHONETIC</code>, <code>NATIVE</code>, <code>ALPHA</code>.
 *
 * @param mode the new IME mode
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SWT
 */
public void setImeInputMode(int mode) {
	checkWidget();
}

public void setMaximized(boolean maximized) {
	checkWidget();
	if (OS.Platform_GetCapability(OS.CAPABILITY_SHELL_MINMAX) != 0) {
		OS.Shell_SetMaximized(internal_handle, maximized);
	}
	else {
		super.setMaximized(maximized);
	}
}

public void setMinimized(boolean minimized) {
	checkWidget();
	if (OS.Platform_GetCapability(OS.CAPABILITY_SHELL_MINMAX) != 0) {
		OS.Shell_SetMinimized(internal_handle, minimized);
	}
	else {
		super.setMinimized(minimized);
	}
}

boolean traverseEscape () {
	if (internal_parent == null) return false;
	if (!isVisible() || !isEnabled()) return false;
	close();
	return true;
}
int windowHandle() {
	return internal_handle;
}

/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Decorations#setMenuBar(org.eclipse.swt.widgets.Menu)
 */
public void setMenuBar(Menu menu) {
	super.setMenuBar(menu);
	int menuHandle = (menu == null) ? 0 : menu.internal_handle;
	OS.Shell_SetMenuBar(internal_handle, menuHandle);
}

//for smartphone
private void createCloseMenuItem() {
	Menu menu = getMenuBar();
	if(menu == null) {
		menu = new Menu(this, SWT.BAR);
		setMenuBar(menu);
	}
	if(closeMenuItem == null || closeMenuItem.isDisposed()) {
		closeMenuItem = new MenuItem(menu, SWT.CASCADE, 0);
		closeMenuItem.setText(Messages.getString("Shell.0")); //$NON-NLS-1$
		closeMenuItem.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}
			public void widgetSelected(SelectionEvent e) {
				close();
			}
		});
	}
}
// for smartphone
private void disposeCloseMenuItem() {
	if(closeMenuItem != null && !closeMenuItem.isDisposed()) {
		closeMenuItem.dispose();
	}
	closeMenuItem = null;
}
	
/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Decorations#setText(java.lang.String)
 */
public void setText(String string) {
	super.setText(string);
	OS.Shell_SetText(internal_handle, string);
}

private void resizeCallback(int width, int height) {
	if (width == oldWidth && height == oldHeight) return;

	oldWidth = width;
	oldHeight = height;
	internal_sendEvent(SWT.Resize);
	layout(true);
}

private void moveCallback(int x, int y) {
	internal_sendEvent(SWT.Move);
}

/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Widget#toString()
 */
public String toString() {
	return "Shell {handle=" + internal_handle + "}";  //$NON-NLS-1$ //$NON-NLS-2$
}

protected boolean isValidSubclass() {
	return isValidClass(getClass());
}

boolean isValidClass(Class clazz) {
	String name = clazz.getName();
	if (name.equals("org.eclipse.swt.widgets.Shell")){ //$NON-NLS-1$
		return true;
	} else if(name.startsWith("org.eclipse.ercp.swt.mobile.MultiPageDialog")){ //$NON-NLS-1$
		return true;
	}
	return false;
}
boolean isTrueComposite() {
	return true;
}

}