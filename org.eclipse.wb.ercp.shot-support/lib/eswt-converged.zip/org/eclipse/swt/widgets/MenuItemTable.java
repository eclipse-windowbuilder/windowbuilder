/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

 
import java.util.*;

class MenuItemTable {
	static Hashtable items = new Hashtable(100);

public static synchronized MenuItem get(int id) {
	if (id == 0) return null;
	return (MenuItem) items.get(new Integer(id));
}
public synchronized static void put(int id, MenuItem item) {
	if (id == 0) return;
	items.put(new Integer(id), item);
}
public static synchronized MenuItem remove (int id) {
	if (id == 0) return null;
	return (MenuItem) items.remove(new Integer(id));
}
public static synchronized int size () {
	return items.size();
}
}


