/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;

 
import org.eclipse.swt.*;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.*;

import com.ibm.ugl.eswt.OS;

/**
 * Instances of this class are selectable user interface
 * objects that allow the user to enter and modify text.
 * <p>
 * <dl>
 * <dt><b>Styles:</b></dt>
 * <dd>CENTER, LEFT, MULTI, PASSWORD, SINGLE, RIGHT, READ_ONLY, WRAP</dd>
 * <dt><b>Events:</b></dt>
 * <dd>DefaultSelection, Modify, Verify</dd>
 * </dl>
 * <p>
 * Note: Only one of the styles MULTI and SINGLE may be specified. 
 * </p><p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */

public class Text extends Scrollable {
	/**
	* The maximum number of characters that can be entered
	* into a text widget.
	*/
	public static final int LIMIT;
	
	/**
	* The maximum number of characters that can be entered
	* into a text widget.
	* <p>
	* Note that this value is platform dependent, based upon
	* the native widget implementation.
	* </p>
	public static final int LIMIT  = 0x7FFFFFFF;
	
	/**
	* The delimiter used by multi-line text widgets.  When text
	* is queried and from the widget, it will be delimited using
	* this delimiter.
	*/
	public static final String DELIMITER;
	
	/**
	 * This indicates that Virtual keyboard should show/hide normally
	 */
	private static final int NORMAL = 1;
	
	/**
	 * This indicates that Virtual keyboard should always show
	 */
	private static final int ALWAYS_ON = 2;
	
	/**
	 * This indicates that Virtual keyboard should always hide
	 */
	private static final int ALWAYS_OFF = 3;
	
	/*
	* These values can be different on different platforms.
	* Therefore they are not initialized in the declaration
	* to stop the compiler from inlining.
	*/
	static {
		LIMIT = OS.AbstractTextComponent_GetDefaultTextLimit();	
		DELIMITER = OS.AbstractTextComponent_GetDelimiter();
	}
	
	
	char echoChar = 0;
	int orientation = SWT.LEFT_TO_RIGHT;
	boolean editable;
	
	boolean doubleClick = true;
	
	private int textLimit = LIMIT;
	
/**
 * Constructs a new instance of this class given its parent
 * and a style value describing its behavior and appearance.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a composite control which will be the parent of the new instance (cannot be null)
 * @param style the style of control to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 *    <li>ERROR_INVALID_SUBCLASS - if this class is not an allowed subclass</li>
 * </ul>
 *
 * @see SWT#SINGLE
 * @see SWT#MULTI
 * @see SWT#READ_ONLY
 * @see SWT#WRAP
 * @see Widget#checkSubclass
 * @see Widget#getStyle
 */
public Text(Composite parent, int style) {
	super(parent, checkStyle(style));
}
/**
 * Adds the listener to the collection of listeners who will
 * be notified when the receiver's text is modified, by sending
 * it one of the messages defined in the <code>ModifyListener</code>
 * interface.
 *
 * @param listener the listener which should be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see ModifyListener
 * @see #removeModifyListener
 */
public void addModifyListener(ModifyListener listener) {
	checkWidget();
	if (listener == null) error(SWT.ERROR_NULL_ARGUMENT);
	TypedListener typedListener = new TypedListener(listener);
	addListener(SWT.Modify, typedListener);
}
/**
 * Adds the listener to the collection of listeners who will
 * be notified when the control is selected, by sending
 * it one of the messages defined in the <code>SelectionListener</code>
 * interface.
 * <p>
 * <code>widgetSelected</code> is not called for texts.
 * <code>widgetDefaultSelected</code> is typically called when ENTER is pressed in a single-line text.
 * </p>
 *
 * @param listener the listener which should be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SelectionListener
 * @see #removeSelectionListener
 * @see SelectionEvent
 */
public void addSelectionListener(SelectionListener listener) {
	checkWidget();
	if (listener == null) error(SWT.ERROR_NULL_ARGUMENT);
	TypedListener typedListener = new TypedListener(listener);
	addListener(SWT.DefaultSelection, typedListener);
}

/**
 * Adds the listener to the collection of listeners who will
 * be notified when the receiver's text is verified, by sending
 * it one of the messages defined in the <code>VerifyListener</code>
 * interface.
 *
 * @param listener the listener which should be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see VerifyListener
 * @see #removeVerifyListener
 */
public void addVerifyListener(VerifyListener listener) {
	checkWidget();
	if (listener == null) error(SWT.ERROR_NULL_ARGUMENT);
	TypedListener typedListener = new TypedListener(listener);
	addListener(SWT.Verify, typedListener);
}

/**
 * Appends a string.
 * <p>
 * The new text is appended to the text at
 * the end of the widget.
 * </p>
 *
 * @param string the string to be appended
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the string is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void append(String string) {
	checkWidget();
	if (string == null) error(SWT.ERROR_NULL_ARGUMENT);
	else if(string.equals("")) return;
	String str = string;
	int length = getCharCount();
	if (hooks (SWT.Verify) || filters (SWT.Verify)) {
		str = verifyText (string, length, length, null);
		if (str == null) return;
	}
	OS.AbstractTextComponent_Replace(internal_handle, str, length, length);
	
	// Set the caret position based on the actual text in the widget,
	// not str.  This allows us to correctly handle newline conversion.
	int newLength = OS.AbstractTextComponent_GetText(internal_handle).length();
	OS.AbstractTextComponent_SetCaretPosition(internal_handle,newLength);
	internal_sendEvent(SWT.Modify);	
}
static int checkStyle(int style) {
	style = checkBits (style, SWT.LEFT, SWT.CENTER, SWT.RIGHT, 0, 0, 0);
	if ((style & SWT.SINGLE) != 0) style &= ~(SWT.H_SCROLL | SWT.V_SCROLL | SWT.WRAP);
	if ((style & SWT.WRAP) != 0) {
	    style |= SWT.MULTI;
	    style &= ~SWT.H_SCROLL;
	}
	if ((style & SWT.MULTI) != 0) style &= ~SWT.PASSWORD;
	if ((style & (SWT.SINGLE | SWT.MULTI)) != 0) return style;
	if ((style & (SWT.H_SCROLL | SWT.V_SCROLL)) != 0) {
		return style | SWT.MULTI;
	}
	return style | SWT.SINGLE;
}
/**
 * Clears the selection.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void clearSelection() {
	checkWidget();
	Point sel = getSelection();
	OS.AbstractTextComponent_SetSelection(internal_handle,sel.y,sel.y);
}

/**
 * Copies the selected text.
 * <p>
 * The current selection is copied to the clipboard.
 * </p>
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void copy() {
	checkWidget();
	String text = getSelectionText();
	if (text.length() > 0) {
		// Expected SWT behavior
		OS.Clipboard_SetText(text);
	}
}
protected void internal_createHandle(int index) {
	int parentHandle = internal_parent.internal_handle;
	int nativeStyle = internal_getNativeStyle();
	if ((internal_style & SWT.SINGLE) != 0) {
		internal_handle = OS.TextField_New(parentHandle,nativeStyle);
		if ((internal_style & SWT.PASSWORD) != 0) OS.AbstractTextComponent_SetEchoChar(internal_handle, '*');
	} else {
		internal_handle = OS.TextArea_New(parentHandle,nativeStyle);
	}		
	if (internal_handle == 0) error(SWT.ERROR_NO_HANDLES);
	
	setEditable((internal_style & SWT.READ_ONLY) == 0);
}

void createWidget(int i) {
	super.createWidget(i);
	if (getCaretPosition() == 0) {
		// Need to only do this if the caret position hasn't already been set
		setSelection(0);
	}
}

/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Scrollable#computeSize(int, int, boolean)
 */
public Point computeSize(int wHint, int hHint, boolean changed) {
	if ((wHint != SWT.DEFAULT) && ((internal_style & SWT.WRAP) == SWT.WRAP)) {
		checkWidget();
		int[] pointArray = OS.AbstractTextComponent_GetMinimumSize(internal_handle, wHint);
		return new Point(pointArray[OS.INDEX_X],pointArray[OS.INDEX_Y]);
	} else {
		return super.computeSize(wHint, hHint, changed);
	}	
}

//take out for Bug 177106, changing Text focus traversal to 'Tab' only
//int computeTabTraversal(int modifiers){	
//    if ((getStyle() & SWT.SINGLE) == SWT.SINGLE){
//   	return super.computeTabTraversal(modifiers);
//    }
    //SWT gives them preference in this order
//    if ((modifiers & OS.MODIFIER_MASK_CONTROL) != 0) return SWT.TRAVERSE_TAB_NEXT;
//    if ((modifiers & OS.MODIFIER_MASK_SHIFT) != 0) return SWT.TRAVERSE_TAB_PREVIOUS;
//    return SWT.TRAVERSE_NONE;
//}

//removing for bug 165111 Text widget's getVerticalBar() returning null for the existing scrollbar 
//void createScrollBars() {
//    horizontalBar = null;
//    verticalBar = null;
//}

protected int internal_getNativeStyle(){
    int nativeStyle = super.internal_getNativeStyle();
	if ((internal_style & SWT.WRAP) == SWT.WRAP) {
		nativeStyle |= OS.STYLE_WRAP;
		nativeStyle |= OS.STYLE_MULTI;
	}
	return nativeStyle;
}

/**
 * Cuts the selected text.
 * <p>
 * The current selection is first copied to the
 * clipboard and then deleted from the widget.
 * </p>
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void cut() {
	checkWidget();
		
	String text = getSelectionText();
	if(text.equals("")) return;
	String newText = "";
	
	int[] sel = OS.AbstractTextComponent_GetSelection(internal_handle);
	
	if (hooks (SWT.Verify) || filters (SWT.Verify)) {
		newText = verifyText ("", sel[0],sel[1], null);
		if (newText == null) return;
	}
	
	OS.Clipboard_SetText(text);
	OS.AbstractTextComponent_Replace(internal_handle,newText,sel[0],sel[1]);
	OS.AbstractTextComponent_SetSelection(internal_handle,sel[0],sel[0]);
	
	internal_sendEvent(SWT.Modify);	
}

/**
 * Returns the line number of the caret.
 * <p>
 * The line number of the caret is returned.
 * </p>
 *
 * @return the line number
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getCaretLineNumber() {
	checkWidget();
	if ((internal_style & SWT.SINGLE) == SWT.SINGLE) return 0;
	return OS.TextArea_GetCaretLineNumber(internal_handle);
}
/**
 * Returns a point describing the receiver's location relative
 * to its parent (or its display if its parent is null).
 * <p>
 * The location of the caret is returned.
 * </p>
 *
 * @return a point, the location of the caret
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Point getCaretLocation() {
	checkWidget();
	int[] pos = OS.AbstractTextComponent_GetCaretPosition(internal_handle);
	return new Point(pos[OS.INDEX_X],pos[OS.INDEX_Y]);
}
/**
 * Returns the character position of the caret.
 * <p>
 * Indexing is zero based.
 * </p>
 *
 * @return the position of the caret
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getCaretPosition() {
	checkWidget();
	
	int selection[] = OS.AbstractTextComponent_GetSelection(internal_handle);
	return selection[OS.INDEX_Y];
}
/**
 * Returns the number of characters.
 *
 * @return number of characters in the widget
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getCharCount() {
	checkWidget();

	return OS.AbstractTextComponent_GetCharCount(internal_handle);
}
/**
 * Returns the double click enabled flag.
 * <p>
 * The double click flag enables or disables the
 * default action of the text widget when the user
 * double clicks.
 * </p>
 * 
 * @return whether or not double click is enabled
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getDoubleClickEnabled() {
	checkWidget();
	return doubleClick;
}
/**
 * Returns the echo character.
 * <p>
 * The echo character is the character that is
 * displayed when the user enters text or the
 * text is changed by the programmer.
 * </p>
 * 
 * @return the echo character
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @see #setEchoChar
 */
public char getEchoChar() {
	checkWidget();
	return echoChar;	
}
/**
 * Returns the editable state.
 *
 * @return whether or not the reciever is editable
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public boolean getEditable() {
	checkWidget();
	return editable;
}

/**
 * Returns the number of lines.
 *
 * @return the number of lines in the widget
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getLineCount() {
	checkWidget();
	if ((internal_style & SWT.SINGLE) == SWT.SINGLE) return 1;
	return OS.TextArea_GetLineCount(internal_handle);
}
/**
 * Returns the line delimiter.
 *
 * @return a string that is the line delimiter
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @see #DELIMITER
 */
public String getLineDelimiter() {
	checkWidget();
	return DELIMITER;
}
/**
 * Returns the height of a line.
 *
 * @return the height of a row of text
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getLineHeight() {
	checkWidget();
	return OS.AbstractTextComponent_GetLineHeight(internal_handle);
}

/**
 * Returns the orientation of the receiver, which will be one of the
 * constants <code>SWT.LEFT_TO_RIGHT</code> or <code>SWT.RIGHT_TO_LEFT</code>.
 *
 * @return the orientation style
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.1.2
 */
public int getOrientation () {
	checkWidget();
	return orientation;
}

/**
 * Returns a <code>Point</code> whose x coordinate is the
 * character position representing the start of the selected
 * text, and whose y coordinate is the character position
 * representing the end of the selection. An "empty" selection
 * is indicated by the x and y coordinates having the same value.
 * <p>
 * Indexing is zero based.  The range of a selection is from
 * 0..N where N is the number of characters in the widget.
 * </p>
 *
 * @return a point representing the selection start and end
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Point getSelection() {
	checkWidget();
	int[] selection = OS.AbstractTextComponent_GetSelection(internal_handle);
	return new Point(selection[0], selection[1]);
}

/**
 * Returns the number of selected characters.
 *
 * @return the number of selected characters.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getSelectionCount() {
	checkWidget();

	int[] selection = OS.AbstractTextComponent_GetSelection(internal_handle);
	return selection[1] - selection[0];
}

/**
 * Gets the selected text, or an empty string if there is no current selection.
 *
 * @return the selected text
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public String getSelectionText() {
	checkWidget();
	return OS.AbstractTextComponent_GetSelectionText(internal_handle);
}

/**
 * Returns the widget text.
 * <p>
 * The text for a text widget is the characters in the widget, or
 * an empty string if this has never been set.
 * </p>
 *
 * @return the widget text
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public String getText() {
	checkWidget();
	return OS.AbstractTextComponent_GetText(internal_handle);
}
/**
 * Returns a range of text.  Returns an empty string if the
 * start of the range is greater than the end.
 * <p>
 * Indexing is zero based.  The range of
 * a selection is from 0..N-1 where N is
 * the number of characters in the widget.
 * </p>
 *
 * @param start the start of the range
 * @param end the end of the range
 * @return the range of text
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public String getText(int start, int end) {
	checkWidget();
	if (!(start <= end && 0 <= end)) return "";
	String fullText = OS.AbstractTextComponent_GetText(internal_handle);
	int length = fullText.length();
	start = Math.max (0, start);
	end = Math.min (end, length - 1);
	if (start >= length) return "";
	return fullText.substring(start,end+1);
}

/**
 * Returns the maximum number of characters that the receiver is capable of holding. 
 * <p>
 * If this has not been changed by <code>setTextLimit()</code>,
 * it will be the constant <code>Text.LIMIT</code>.
 * </p>
 * 
 * @return the text limit
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @see #LIMIT
 */
public int getTextLimit() {
	checkWidget();
	return textLimit;
}
/**
 * Returns the zero-relative index of the line which is currently
 * at the top of the receiver.
 * <p>
 * This index can change when lines are scrolled or new lines are added or removed.
 * </p>
 *
 * @return the index of the top line
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getTopIndex() {
	checkWidget();
	if ((internal_style & SWT.SINGLE) != 0) return 0;
	return OS.TextArea_GetTopLine(internal_handle);
}
/**
 * Returns the top pixel.
 * <p>
 * The top pixel is the pixel position of the line
 * that is currently at the top of the widget.  On
 * some platforms, a text widget can be scrolled by
 * pixels instead of lines so that a partial line
 * is displayed at the top of the widget.
 * </p><p>
 * The top pixel changes when the widget is scrolled.
 * The top pixel does not include the widget trimming.
 * </p>
 *
 * @return the pixel position of the top line
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public int getTopPixel() {
	checkWidget();
	// TODO Remove this API, because it is confusing, and its usefulness is not obvious.
	int top = getTopIndex();
	int lineHeight = getLineHeight();
	return (top * lineHeight);
}
boolean handleDoubleClick(int event) {
	return doubleClick;
}
/**
 * Inserts a string.
 * <p>
 * The old selection is replaced with the new text.
 * </p>
 *
 * @param string the string
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the string is <code>null</code></li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void insert(String string) {
	checkWidget();
	if (string == null) error(SWT.ERROR_NULL_ARGUMENT);
	else if(string.equals("")) return;
	String str = string;
	int[] selection = OS.AbstractTextComponent_GetSelection(internal_handle);
	if (hooks (SWT.Verify) || filters (SWT.Verify)) {
		str = verifyText (string, selection[OS.INDEX_X], selection[OS.INDEX_Y], null);
		if (str == null) return;
	}

	OS.AbstractTextComponent_Replace(internal_handle, str, selection[OS.INDEX_X], selection[OS.INDEX_Y]);
	OS.AbstractTextComponent_SetCaretPosition(internal_handle,selection[OS.INDEX_X]+str.length());
	internal_sendEvent(SWT.Modify);
}

/**
 * Pastes text from clipboard.
 * <p>
 * The selected text is deleted from the widget
 * and new text inserted from the clipboard.
 * </p>
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void paste() {
	checkWidget();
	String text = OS.Clipboard_GetText();
	
	int[] selection = OS.AbstractTextComponent_GetSelection(internal_handle);
	if (hooks (SWT.Verify) || filters (SWT.Verify)) {
		text = verifyText (text, selection[OS.INDEX_X], selection[OS.INDEX_Y], null);
		if (text == null) return;
	}

	OS.AbstractTextComponent_Replace(internal_handle, text, selection[OS.INDEX_X], selection[OS.INDEX_Y]);
	OS.AbstractTextComponent_SetCaretPosition(internal_handle,selection[OS.INDEX_X]+text.length());
	internal_sendEvent(SWT.Modify);
}

/**
 * Removes the listener from the collection of listeners who will
 * be notified when the receiver's text is modified.
 *
 * @param listener the listener which should no longer be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see ModifyListener
 * @see #addModifyListener
 */
public void removeModifyListener(ModifyListener listener) {
	checkWidget();
	if (listener == null) error(SWT.ERROR_NULL_ARGUMENT);
	if (eventTable == null) return;
	eventTable.unhook(SWT.Modify, listener);
}

/**
 * Removes the listener from the collection of listeners who will
 * be notified when the control is selected.
 *
 * @param listener the listener which should no longer be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see SelectionListener
 * @see #addSelectionListener
 */
public void removeSelectionListener(SelectionListener listener) {
	checkWidget();
	if (listener == null) error(SWT.ERROR_NULL_ARGUMENT);
	if (eventTable == null) return;
	eventTable.unhook(SWT.Selection, listener);
	eventTable.unhook(SWT.DefaultSelection, listener);
}

/**
 * Removes the listener from the collection of listeners who will
 * be notified when the control is verified.
 *
 * @param listener the listener which should no longer be notified
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 *
 * @see VerifyListener
 * @see #addVerifyListener
 */
public void removeVerifyListener(VerifyListener listener) {
	checkWidget();
	if (listener == null) error(SWT.ERROR_NULL_ARGUMENT);
	if (eventTable == null) return;
	eventTable.unhook(SWT.Verify, listener);
}

/**
 * Selects all the text in the receiver.
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void selectAll() {
	checkWidget();
	OS.AbstractTextComponent_SelectAll(internal_handle);
	
//	int last = OS.AbstractTextComponent_GetCharCount(handle);
//	OS.AbstractTextComponent_SetSelection(handle,0,last);
}

/**
 * Sets the double click enabled flag.
 * <p>
 * The double click flag enables or disables the
 * default action of the text widget when the user
 * double clicks.
 * </p><p>
 * Note: This operation is a hint and is not supported on
 * platforms that do not have this concept.
 * 
 * @param doubleClick the new double click flag
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setDoubleClickEnabled(boolean doubleClick) {
	checkWidget();
	this.doubleClick = doubleClick;
	OS.AbstractTextComponent_SetDoubleClickEnabled(internal_handle,doubleClick);
}

/**
 * Sets the echo character.
 * <p>
 * The echo character is the character that is
 * displayed when the user enters text or the
 * text is changed by the programmer. Setting
 * the echo character to '\0' clears the echo
 * character and redraws the original text.
 * If for any reason the echo character is invalid,
 * or if the platform does not allow modification
 * of the echo character, the default echo character
 * for the platform is used.
 * </p>
 *
 * @param echo the new echo character
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setEchoChar(char echo) {
	checkWidget();
	this.echoChar = echo;
	OS.AbstractTextComponent_SetEchoChar(internal_handle, echo);
}
/**
 * Sets the editable state.
 *
 * @param editable the new editable state
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setEditable(boolean editable) {
	checkWidget();
	this.editable = editable;
	OS.AbstractTextComponent_SetEditable(internal_handle, editable);
}

/**
 * Sets the orientation of the receiver, which must be one
 * of the constants <code>SWT.LEFT_TO_RIGHT</code> or <code>SWT.RIGHT_TO_LEFT</code>.
 * <p>
 * Note: This operation is a hint and is not supported on
 * platforms that do not have this concept.
 * </p>
 * @param orientation new orientation style
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @since 2.1.2
 */
public void setOrientation (int orientation) {
	int flags = SWT.RIGHT_TO_LEFT | SWT.LEFT_TO_RIGHT;
	if ((orientation & flags) == 0 || (orientation & flags) == flags) return;
	this.orientation = orientation;
}

/**
 * Sets the selection.
 * <p>
 * Indexing is zero based.  The range of
 * a selection is from 0..N where N is
 * the number of characters in the widget.
 * </p><p>
 * Text selections are specified in terms of
 * caret positions.  In a text widget that
 * contains N characters, there are N+1 caret
 * positions, ranging from 0..N.  This differs
 * from other functions that address character
 * position such as getText () that use the
 * regular array indexing rules.
 * </p>
 *
 * @param start new caret position
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setSelection(int start) {
	checkWidget();
	
	int nStart = Math.max(start, 0);
	OS.AbstractTextComponent_SetCaretPosition(internal_handle, nStart);
}
/**
 * Sets the selection to the range specified
 * by the given start and end indices.
 * <p>
 * Indexing is zero based.  The range of
 * a selection is from 0..N where N is
 * the number of characters in the widget.
 * </p><p>
 * Text selections are specified in terms of
 * caret positions.  In a text widget that
 * contains N characters, there are N+1 caret
 * positions, ranging from 0..N.  This differs
 * from other functions that address character
 * position such as getText () that use the
 * usual array indexing rules.
 * </p>
 *
 * @param start the start of the range
 * @param end the end of the range
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setSelection(int start, int end) {
	checkWidget();
	int nStart = Math.max(Math.min(start, end), 0);
	int nEnd = Math.min(Math.max(start, end), getCharCount());
	OS.AbstractTextComponent_SetSelection(internal_handle, nStart, nEnd);
}
/**
 * Sets the selection to the range specified
 * by the given point, where the x coordinate
 * represents the start index and the y coordinate
 * represents the end index.
 * <p>
 * Indexing is zero based.  The range of
 * a selection is from 0..N where N is
 * the number of characters in the widget.
 * </p><p>
 * Text selections are specified in terms of
 * caret positions.  In a text widget that
 * contains N characters, there are N+1 caret
 * positions, ranging from 0..N.  This differs
 * from other functions that address character
 * position such as getText () that use the
 * usual array indexing rules.
 * </p>
 *
 * @param selection the point
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the point is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setSelection(Point selection) {
	checkWidget();
	if (selection == null) error (SWT.ERROR_NULL_ARGUMENT);
	setSelection(selection.x, selection.y);
}

/**
 * Sets the contents of the receiver to the given string. If the receiver has style
 * SINGLE and the argument contains multiple lines of text, the result of this
 * operation is undefined and may vary from platform to platform.
 *
 * @param string the new text
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the string is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setText(String string) {
	checkWidget();
	if (string == null) error(SWT.ERROR_NULL_ARGUMENT);
	else if(string.equals("") && string.equals(getText())) return;
	String str = string;
	if (hooks (SWT.Verify) || filters (SWT.Verify)) {
		int length = getCharCount();
		str = verifyText (string, 0, length, null);
		if (str == null) return;
	}
	OS.AbstractTextComponent_SetText(internal_handle, str);
	OS.AbstractTextComponent_SetCaretPosition(internal_handle,0);
	internal_sendEvent(SWT.Modify);
}
/**
 * Sets the maximum number of characters that the receiver
 * is capable of holding to be the argument.
 * <p>
 * Instead of trying to set the text limit to zero, consider
 * creating a read-only text widget.
 * </p><p>
 * Specifying a limit value larger than <code>Text.LIMIT</code> sets the
 * receiver's limit to <code>Text.LIMIT</code>.
 * </p>
 *
 * @param limit new text limit
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_CANNOT_BE_ZERO - if the limit is zero</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setTextLimit(int limit) {
	checkWidget();
	if (limit < 0) return;
	if (limit == 0) error (SWT.ERROR_CANNOT_BE_ZERO);
	textLimit = limit;
	OS.AbstractTextComponent_SetTextLimit(internal_handle,limit);
}
/**
 * Sets the zero-relative index of the line which is currently
 * at the top of the receiver. This index can change when lines
 * are scrolled or new lines are added and removed.
 *
 * @param index the index of the top item
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setTopIndex(int index) {
	checkWidget();
	if ((internal_style & SWT.SINGLE) != 0) return;
	if (index < 0) index = 0;
	OS.TextArea_SetTopLine(internal_handle,index);
}
/**
 * Shows the selection.
 * <p>
 * If the selection is already showing
 * in the receiver, this method simply returns.  Otherwise,
 * lines are scrolled until the selection is visible.
 * </p>
 * 
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void showSelection() {
	checkWidget();
	Point sel = getSelection();
	// Qt doesn't support this, so reselect the text
	setSelection(sel.x, sel.y);
}

// remove for Bug 177106, changing Text focus traversal to 'Tab' only
//int traversalCode() {
//	int bits = super.traversalCode();
//
//	if ((internal_style & SWT.MULTI) != 0) {
//		bits &= ~SWT.TRAVERSE_RETURN;
//	}
//	return bits;
//}

/*
 * Override Control callback so we can send SWT.DefaultSelection.
 */
boolean keyCallback(int type, char character, int keycode, int modifiers) {
	boolean consumed = super.keyCallback(type,character,keycode,modifiers);
	if ((!consumed) && (type == OS.EVENT_KEY_DOWN)) {
		if ((keycode == OS.KEYCODE_ENTER) && ((internal_style & SWT.SINGLE) != 0)) {
			internal_sendEvent(SWT.DefaultSelection);
		}
	}
	return consumed;
}

/*
 * The text has been modified by the user.  This callback should
 * always be called after textVerifyCallback.
 */
void textModifyCallback() {
	internal_sendEvent(SWT.Modify);
}

/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Scrollable#getClientArea()
 */
public Rectangle getClientArea() {
	checkWidget();
	Rectangle r = getBounds();
	r.x = 0;
	r.y = 0;
	return r;
}

/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Scrollable#computeTrim(int, int, int, int)
 */
public Rectangle computeTrim(int x, int y, int width, int height) {
    return new Rectangle(x,y,width,height);
}

void focusCallback(int event){
	super.focusCallback(event);
	if(Device.internal_vkstatus == ALWAYS_ON){
		OS.AbstractTextComponent_SetVKStatus(true, internal_handle);
	} else if(Device.internal_vkstatus == ALWAYS_OFF){
		OS.AbstractTextComponent_SetVKStatus(false, internal_handle);
	} else if ( this.editable == false)              //Eric, disable VKB while text is non-editable.
	{
		OS.AbstractTextComponent_SetVKStatus(false, internal_handle);
	}
	else{
		
		if(event == OS.EVENT_FOCUS_IN){
			OS.AbstractTextComponent_SetVKStatus(true, internal_handle);
		} 
		if(event == OS.EVENT_FOCUS_OUT){
			OS.AbstractTextComponent_SetVKStatus(false, internal_handle);
		}
	}
	
}

public boolean allowTraverseByArrowKey(Event event) {
	switch (event.keyCode) {
		case SWT.ARROW_UP :
			if((internal_style & SWT.MULTI) == 0)
				return true; 
			if(getCaretLineNumber() == 0)
				return true;
			break;
		case SWT.ARROW_LEFT :
			if(getCaretPosition() == 0) {
				return true;
			}
			break;
		case SWT.ARROW_DOWN :	
			if((internal_style & SWT.MULTI) == 0)
				return true; 
			if(getCaretLineNumber() >= getLineCount()-1)
				return true;
			break;
		case SWT.ARROW_RIGHT :
			if(getCaretPosition() >= getCharCount()) {
				return true;
			}
			break;
	}
	return false;
}

protected boolean traverse(Event event) {
	if (isDisposed()) return false;
	if(allowTraverseByArrowKey(event)) {
		return traverseByArrowKey(event);
	}
	return super.traverse(event);
}

}
