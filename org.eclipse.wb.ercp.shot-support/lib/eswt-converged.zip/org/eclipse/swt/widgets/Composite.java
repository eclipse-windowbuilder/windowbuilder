/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.widgets;


import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;

import com.ibm.ugl.eswt.OS;

/**
 * Instances of this class are controls which are capable
 * of containing other controls.
 * <dl>
 * <dt><b>Styles:</b></dt>
 * <dd>NO_BACKGROUND, NO_FOCUS, NO_MERGE_PAINTS, NO_REDRAW_RESIZE, NO_RADIO_GROUP</dd>
 * <dt><b>Events:</b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * Note: The <code>NO_BACKGROUND</code>, <code>NO_FOCUS</code>, <code>NO_MERGE_PAINTS</code>,
 * and <code>NO_REDRAW_RESIZE</code> styles are intended for use with <code>Canvas</code>.
 * They can be used with <code>Composite</code> if you are drawing your own, but their
 * behavior is undefined if they are used with subclasses of <code>Composite</code> other
 * than <code>Canvas</code>.
 * </p><p>
 * This class may be subclassed by custom control implementors
 * who are building controls that are constructed from aggregates
 * of other controls.
 * </p>
 *
 * @see Canvas
 */
public class Composite extends Scrollable {
	Layout layout;
	Control[] tabList;
	Control[] children;
	int childCount;
	
Composite () {
	/* Do nothing */
}
	/**
 * Constructs a new instance of this class given its parent
 * and a style value describing its behavior and appearance.
 * <p>
 * The style value is either one of the style constants defined in
 * class <code>SWT</code> which is applicable to instances of this
 * class, or must be built by <em>bitwise OR</em>'ing together 
 * (that is, using the <code>int</code> "|" operator) two or more
 * of those <code>SWT</code> style constants. The class description
 * lists the style constants that are applicable to the class.
 * Style bits are also inherited from superclasses.
 * </p>
 *
 * @param parent a widget which will be the parent of the new instance (cannot be null)
 * @param style the style of widget to construct
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
 * </ul>
 *
 * @see SWT#NO_BACKGROUND
 * @see SWT#NO_FOCUS
 * @see SWT#NO_MERGE_PAINTS
 * @see SWT#NO_REDRAW_RESIZE
 * @see SWT#NO_RADIO_GROUP
 * @see Widget#getStyle
 */
public Composite(Composite parent, int style) {
	super(parent, style);
}

Control[] _getTabList () {
	if (tabList == null) return tabList;
	int index = 0, count = 0;
	while (index < tabList.length) {
		if (!tabList[index].isDisposed()) count++;
		index++;
	}
	if (index == count) return tabList;
	Control[] newList = new Control[count];
	index = 0;
	for (int i = 0; i < tabList.length; i++) {
		if (!tabList[index].isDisposed()) {
			newList[index++] = tabList[i];
		}
	}
	tabList = newList;
	return tabList;
}
protected void checkSubclass() {
	/* Do nothing - Subclassing is allowed */
}

// This method was made public so that the mobile extension
// group can use it. 
public void internal_removeChild(Control child) {
	if (child == null) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
	if (children == null) return;
	
	for (int i=0;i<childCount;i++) {
		if (children[i].equals(child)) {
			System.arraycopy(children, i+1, children, i, childCount-i-1);
			// free the last control which is no longer accessible
			children[childCount - 1] = null;
			childCount--;
		}
	}
}

void addChild(Control child) {
	if (child == null) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
	
	// Create the default array if this is the first child
	if (children == null) {
		children = new Control[5];
		childCount = 0;
	}
	
	// Grow the child array if more space is needed
	if (childCount == children.length) {
		Control[] newChildren = new Control[childCount * 2];
		System.arraycopy(children, 0, newChildren, 0, childCount);
		children = newChildren;
	}
	
	children[childCount++] = child;
}


public Point computeSize(int wHint, int hHint, boolean changed) {
	checkWidget();
	Point size;
	if (layout != null) {
		if (wHint == SWT.DEFAULT || hHint == SWT.DEFAULT) {
			size = layout.computeSize(this, wHint, hHint, changed);
		} else {
			size = new Point(wHint, hHint);
		}
	} else {
		size = minimumSize();
	}
	if (size.x == 0) size.x = DEFAULT_WIDTH;
	if (size.y == 0) size.y = DEFAULT_HEIGHT;
	if (wHint != SWT.DEFAULT) size.x = wHint;
	if (hHint != SWT.DEFAULT) size.y = hHint;
	Rectangle trim = computeTrim(0, 0, size.x, size.y);
	return new Point(trim.width, trim.height);
}
Control[] computeTabList() {
	Control result[] = super.computeTabList();
	if (result.length == 0) return result;
	
	int listCount;
	Control[] list;
	
	if (tabList != null) {
		list = _getTabList();
		listCount = list.length;
	} else { 
		list = children;
		listCount = childCount;
	}
	for (int i = 0; i < listCount; i++) {
		Control child = list[i];
		Control[] childList = child.computeTabList();
		int length = 0;
		for (int j = 0; j < childList.length; j++) {
			if((childList[j].internal_style & SWT.NO_FOCUS) == 0) {
				length++;
			}
		}
		if(length > 0) {
			Control[] newResult = new Control[result.length + length];
			System.arraycopy(result, 0, newResult, 0, result.length);
			for (int j=0, k=0; j<childList.length; j++) {
				if((childList[j].internal_style & SWT.NO_FOCUS) == 0) {
					System.arraycopy(childList, j, newResult, result.length + k, 1);
					k++;
				}
			}
			result = newResult;
		}
	}
	return result;
}
protected void internal_createHandle(int index) {
	internal_handle = OS.Composite_New(internal_parent.internal_handle, internal_getNativeStyle());
}

protected int internal_getNativeStyle() {
	int nativeStyle = super.internal_getNativeStyle();
	
	if ((internal_style & SWT.NO_BACKGROUND) == SWT.NO_BACKGROUND) {
		nativeStyle |= OS.STYLE_NO_BACKGROUND;
	}
	if ((internal_style & SWT.NO_FOCUS) == SWT.NO_FOCUS) {
		nativeStyle |= OS.STYLE_NO_FOCUS;
	}
	if ((internal_style & SWT.NO_MERGE_PAINTS) == SWT.NO_MERGE_PAINTS) {
		nativeStyle |= OS.STYLE_NO_MERGE_PAINTS;
	}
	if ((internal_style & SWT.NO_REDRAW_RESIZE) == SWT.NO_REDRAW_RESIZE) {
		nativeStyle |= OS.STYLE_NO_REDRAW_RESIZE;
	}
	return nativeStyle;
}
/**
 * Returns a (possibly empty) array containing the receiver's children.
 * Children are returned in the order that they are drawn.
 * <p>
 * Note: This is not the actual structure used by the receiver
 * to maintain its list of children, so modifying the array will
 * not affect the receiver. 
 * </p>
 *
 * @return an array of children
 * 
 * @see Control#moveAbove
 * @see Control#moveBelow
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Control[] getChildren() {
	checkWidget();
	Control[] childrenCopy = new Control[childCount];
	if (childCount > 0) {
		System.arraycopy(children, 0, childrenCopy, 0, childCount);
	}
	return childrenCopy;
}
/**
 * Returns layout which is associated with the receiver, or
 * null if one has not been set.
 *
 * @return the receiver's layout or null
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public Layout getLayout() {
	checkWidget();
	return layout;
}
/**
 * Gets the (possibly empty) tabbing order for the control.
 *
 * @return tabList the ordered list of controls representing the tab order
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 * 
 * @see #setTabList
 */
public Control[] getTabList() {
	checkWidget();
	Control[] tabList = _getTabList();
	if (tabList == null) {
		int count = 0;
		
		for (int i = 0; i < childCount; i++) {
			if (children[i].isTabGroup()) count++;
		}
		tabList = new Control[count];
		int index = 0;
		for (int i = 0; i < childCount; i++) {
			if (children[i].isTabGroup()) {
				tabList[index++] = children[i];
			}
		}
	}
	return tabList;
}
boolean hooksKeys() {
	return hooks(SWT.KeyDown) || hooks(SWT.KeyUp) || hooks(SWT.Traverse);
}
/**
 * If the receiver has a layout, asks the layout to <em>lay out</em>
 * (that is, set the size and location of) the receiver's children. 
 * If the receiver does not have a layout, do nothing.
 * <p>
 * This is equivalent to calling <code>layout(true)</code>.
 * </p>
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void layout() {
	checkWidget();
	layout(true);
}
/**
 * If the receiver has a layout, asks the layout to <em>lay out</em>
 * (that is, set the size and location of) the receiver's children. 
 * If the argument is <code>true</code> the layout must not rely
 * on any information it has cached about the immediate children. If it
 * is <code>false</code> the layout may (potentially) optimize the
 * work it is doing by assuming that none of the receiver's 
 * children has changed state since the last layout.
 * If the receiver does not have a layout, do nothing.
 * <p>
 * If a child is resized as a result of a call to layout, the 
 * resize event will invoke the layout of the child.  The layout
 * will cascade down through all child widgets in the receiver's widget 
 * tree until a child is encountered that does not resize.  Note that 
 * a layout due to a resize will not flush any cached information 
 * (same as <code>layout(false)</code>).</p>
 *
 * @param changed <code>true</code> if the layout must flush its caches, and <code>false</code> otherwise
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void layout(boolean changed) {
	checkWidget();
	if (layout == null) return;
	if (childCount > 0) {
		layout.layout(this,changed);
	}
}
Point minimumSize() {
	int width = 0, height = 0;
	for (int i = 0; i < childCount; i++) {
		Rectangle rect = children[i].getBounds();		
		width = Math.max(width, rect.x + rect.width);
		height = Math.max(height, rect.y + rect.height);
	}
	return new Point(width, height);
}
protected void releaseWidget() {
	// childCount will be modified as part of the 
	// release, so it cannot be the iterator.
	int temp = childCount;
	for (int i = 0; i < temp; i++) {
		// The children array will shrink as part of the release, so
		// the safest thing to do is always remove the first one.
		Control child = children[0];
		if(child!=null){
			if (!child.isDisposed()) {
//				child.dispose();
				child.releaseWidget();
				child.releaseHandle();
			}
			child = null;
		}
	}
	layout = null;
	
    if(tabList!=null){
    	tabList = null;
    }
	if(children!=null){
		children = null;
	}
	super.releaseWidget();
}
public void setBounds(int x, int y, int width, int height) {
	super.setBounds(x, y, width, height);
// not needed because CContainerPeer adjusts scroll bars?
//	resizeClientArea(width, height);
	if (layout != null) layout(false);
}
/**
 * Sets the layout which is associated with the receiver to be
 * the argument which may be null.
 *
 * @param layout the receiver's new layout or null
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setLayout(Layout layout) {
	checkWidget();
	this.layout = layout;
}
public void setSize(int width, int height) {
	super.setSize(width, height);
//	 not needed because CContainerPeer adjusts scroll bars?
//	resizeClientArea(width, height);
	if (layout != null) layout(false);
}
/**
 * Sets the tabbing order for the specified controls to
 * match the order that they occur in the argument list.
 *
 * @param tabList the ordered list of controls representing the tab order or null
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_INVALID_ARGUMENT - if a widget in the tabList is null or has been disposed</li> 
 *    <li>ERROR_INVALID_PARENT - if widget in the tabList is not in the same widget tree</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
 * </ul>
 */
public void setTabList(Control[] tabList) {
	checkWidget();
	if (tabList == null) error(SWT.ERROR_NULL_ARGUMENT);
	for (int i=0; i<tabList.length; i++) {
		Control control = tabList[i];
		if (control == null) error(SWT.ERROR_INVALID_ARGUMENT);
		if (control.isDisposed()) error(SWT.ERROR_INVALID_ARGUMENT);
		if (control.internal_parent != this) error(SWT.ERROR_INVALID_PARENT);
	}
	this.tabList = tabList;
}
boolean setTabGroupFocus() {
	if (isTabItem()) return setTabItemFocus();
	if ((internal_style & SWT.NO_FOCUS) == 0) {
		// Combo is the only Composite in eSWT which is excepted
		// from the hooksKeys() call because it does not behave like
		// other Composites.
		boolean takeFocus = true;
		if (isTrueComposite()) takeFocus = hooksKeys();
		if (takeFocus && setTabItemFocus()) return true;
	}
	for (int i=0; i<childCount; i++) {
		Control child = children[i];
		if (child.isTabItem() && child.setTabItemFocus())	return true;
	}
	return false;
}
boolean setTabItemFocus() {
	if ((internal_style & SWT.NO_FOCUS) == 0) {
		// Combo is the only Composite in eSWT which is excepted
		// from the hooksKeys() call because it does not behave like
		// other Composites.
		boolean takeFocus = true;
		if (isTrueComposite()) takeFocus = hooksKeys();
		if (takeFocus) {
			if (!isShowing()) return false;
			if (forceFocus()) return true;
		}
	}
	return super.setTabItemFocus();
}
int traversalCode() {
	if (isTrueComposite()) {
//		if ((internal_style & SWT.NO_FOCUS) != 0) return 0;
		if (hooks (SWT.KeyDown) || hooks (SWT.KeyUp)) return 0;
	}
	return super.traversalCode();
}

/*
 * See Combo.
 */
boolean isTrueComposite() {
	return true;
}

/* (non-Javadoc)
 * @see org.eclipse.swt.widgets.Control#setFocus()
 */
public boolean setFocus() {
	checkWidget();
	if (children != null) {
		for (int i=0; i<childCount; i++) {
			Control child = children[i];
			if (child.getVisible() && child.setFocus()) return true;
		}
	}
	return super.setFocus();
}

void clientAreaResized() {
	layout(); 
}

public boolean allowTraverseByArrowKey(Event event) {
	switch (event.keyCode) {
		case SWT.ARROW_LEFT :
		case SWT.ARROW_RIGHT :	
		case SWT.ARROW_UP :
		case SWT.ARROW_DOWN :	
			return true;
	}
	return false;
}

protected boolean traverse(Event event) {
	if (isDisposed()) return false;
	if(allowTraverseByArrowKey(event)) {
		return traverseByArrowKey(event);
	}
	return super.traverse(event);
}

}
