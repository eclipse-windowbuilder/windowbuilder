/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.graphics;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.image.FileFormat;
import org.eclipse.swt.internal.image.GIFFileFormat;
import org.eclipse.swt.internal.image.LEDataInputStream;
import org.eclipse.swt.widgets.Display;

import com.ibm.ugl.eswt.expanded.OS;
/**
 * Instances of this class are used to load images from,
 * and save images to, a file or stream.
 * <p>
 * Currently supported image formats are:
 * </p><ul>
 * <li>JPEG</li>
 * <li>GIF</li>
 * <li>PNG</li>
 * </ul>
 * <code>ImageLoaders</code> can be used to:
 * <ul>
 * <li>load single images in all formats</li>
 * <li>load multiple images (GIF)</li>
 * <li>load interlaced GIF/PNG images</li>
 * <li>load progressive JPEG images</li>
 * </ul>
 * 
 * <b>NOTE</b> that loading multiple images is platform-dependent. 
 */
 
public class ImageLoader {
	
	/**
	 * the array of ImageData objects in this ImageLoader.
	 * This array is read in when the load method is called,
	 * and it is written out when the save method is called
	 */
	public ImageData[] data;
	
	/**
	 * the width of the logical screen on which the images
	 * reside, in pixels (this corresponds to the GIF89a
	 * Logical Screen Width value)
	 */
	public int logicalScreenWidth;

	/**
	 * the height of the logical screen on which the images
	 * reside, in pixels (this corresponds to the GIF89a
	 * Logical Screen Height value)
	 */
	public int logicalScreenHeight;

	/**
	 * the background pixel for the logical screen (this 
	 * corresponds to the GIF89a Background Color Index value).
	 * The default is -1 which means 'unspecified background'
	 * 
	 */
	public int backgroundPixel;

	/**
	 * the number of times to repeat the display of a sequence
	 * of animated images (this corresponds to the commonly-used
	 * GIF application extension for "NETSCAPE 2.0 01").
	 * The default is 1. A value of 0 means 'display repeatedly'
	 */
	public int repeatCount;

/**
 * Construct a new empty ImageLoader.
 */
public ImageLoader() {
	reset();
}

/**
 * Resets the fields of the ImageLoader, except for the
 * <code>imageLoaderListeners</code> field.
 */
void reset() {
	data = null;
	logicalScreenWidth = 0;
	logicalScreenHeight = 0;
	backgroundPixel = -1;
}

/**
 * Get the Native Image Format value from the SWT Image Format.
 * @exception SWTException <ul>
 *	 <li>ERROR_UNSUPPORTED_FORMAT - if the image file contains an unrecognized format</li>
 * </ul>
 */
int nativeImageFormat(int format) {
	int imageFormat=0;
	switch (format) {
	  case SWT.IMAGE_GIF:		imageFormat = OS.IMAGE_FORMAT_GIF;		break;
	  case SWT.IMAGE_JPEG:		imageFormat = OS.IMAGE_FORMAT_JPEG;		break;
	  case SWT.IMAGE_PNG:		imageFormat = OS.IMAGE_FORMAT_PNG;		break;
	  default:
	    SWT.error(SWT.ERROR_UNSUPPORTED_FORMAT);
	}
	return imageFormat;
}


/**
 * Loads an array of <code>ImageData</code> objects from the
 * specified input stream. Throws an error if either an error
 * occurs while loading the images, or if the images are not
 * of a supported type. Returns the loaded image data array.
 *
 * @param stream the input stream to load the images from
 * @return an array of <code>ImageData</code> objects loaded from the specified input stream
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the stream is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_INVALID_IMAGE - if the image file contains invalid data</li>
 *    <li>ERROR_IO - if an input/output error occurs while reading data</li>
 *    <li>ERROR_UNSUPPORTED_FORMAT - if the image file contains an unrecognized format</li>
 * </ul>
 * 
 * <b>NOTE</b> If multiple images are not supported, only one ImageData will be returned
 * by this method. 
 */
public ImageData[] load(InputStream stream) {
	if (stream == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	reset();
	data = FileFormat.load(stream, this);
	if (data != null) return data; //GIF format
	else {
		try {
			stream.reset();
		} catch (IOException e) {
		}
		data = new ImageDataLoader().load(stream);
		return data;
	}

}

/**
 * Loads an array of <code>ImageData</code> objects from the
 * file with the specified name. Throws an error if either
 * an error occurs while loading the images, or if the images are
 * not of a supported type. Returns the loaded image data array.
 *
 * @param filename the name of the file to load the images from
 * @return an array of <code>ImageData</code> objects loaded from the specified file
 * @throws ConnectionNotFoundException 
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the file name is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_INVALID_IMAGE - if the image file contains invalid data</li>
 *    <li>ERROR_IO - if an IO error occurs while reading data</li>
 *    <li>ERROR_UNSUPPORTED_FORMAT - if the image file contains an unrecognized format</li>
 * </ul>
 * 
 * <b>NOTE</b> If multiple images are not supported, only one ImageData will be returned
 * by this method. 
 */
public ImageData[] load(String fileName) {
	if (fileName == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

	reset();
	InputStream is = null;
		try {
			 is = Compatibility.newFileInputStream(fileName);
		} catch (IOException e) {
			SWT.error(SWT.ERROR_IO, e);
		}
		LEDataInputStream lestream = new LEDataInputStream(is);
		try {
			if (is != null) is.close();
		} catch (IOException e) {
			// Ignore error
		}
		
		GIFFileFormat gifFileFormat = new GIFFileFormat();
		if (gifFileFormat.isFileFormat(lestream)) {
			try {
				is = Compatibility.newFileInputStream(fileName);
				return load(is);
			} catch (Exception e) {
			} finally {
				try {
					if (is != null) is.close();
				} catch (IOException e) {
					// Ignore error
				}
			}
		}	else {
			data = new ImageDataLoader().load(fileName);	
			return data;
		}	
	return null;	
}

/**
 * Saves the image data in this ImageLoader to the specified stream.
 * The format parameter can have one of the following values:
 * <dl>
 * <dt><code>IMAGE_GIF</code></dt>
 * <dd>GIF file format</dd>
 * <dt><code>IMAGE_JPEG</code></dt>
 * <dd>JPEG file format</dd>
 * <dt><code>IMAGE_PNG</code></dt>
 * <dd>PNG file format</dd>
 * </dl>
 *
 * @param stream the output stream to write the images to
 * @param format the format to write the images in
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the stream is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_INVALID_IMAGE if the image data contains invalid data</li>
 *    <li>ERROR_IO if an IO error occurs while writing to the file</li>
 *    <li>ERROR_UNSUPPORTED_FORMAT - if the image file contains an unrecognized format</li>
 * </ul>
 */
public void save(OutputStream stream, int format) {
	if (stream == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	
	if ((format != SWT.IMAGE_PNG) && (format != SWT.IMAGE_GIF) && (format != SWT.IMAGE_JPEG)) {
		SWT.error(SWT.ERROR_UNSUPPORTED_FORMAT);
	}
	FileFormat.save(stream, format, this);
}

/**
 * Saves the image data in this ImageLoader to a file with the specified name.
 * The format parameter can have one of the following values:
 * <dl>
 * <dt><code>IMAGE_GIF</code></dt>
 * <dd>GIF file format</dd>
 * <dt><code>IMAGE_JPEG</code></dt>
 * <dd>JPEG file format</dd>
 * <dt><code>IMAGE_PNG</code></dt>
 * <dd>PNG file format</dd>
 * </dl>
 *
 * @param filename the name of the file to write the images to
 * @param format the format to write the images in
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if the file name is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_INVALID_IMAGE if the image data contains invalid data</li>
 *    <li>ERROR_IO if an IO error occurs while writing to the file</li>
 *    <li>ERROR_UNSUPPORTED_FORMAT if the image data cannot be saved to the requested format</li>
 * </ul>
 */
public void save(String filename, int format) {
	if (filename == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	int image_format = nativeImageFormat(format);
	Image image = new Image(Display.getDefault(), data[0]);
	RGB[] rgbs;
	ImageData imgData = data[0];
	rgbs=imgData.getRGBs();
	int colorMap[] = new int[0];
	if (rgbs != null) {
	    colorMap  = new int[rgbs.length];
	    for (int i=0; i<colorMap.length; i++)
	      colorMap[i]=rgbs[i].hashCode();
	  }
	OS.Image_Save(image.internal_handle, filename, imgData.width, imgData.height, imgData.depth, imgData.bytesPerLine, imgData.alpha, imgData.alphaData, colorMap.length, colorMap, imgData.transparentPixel, imgData.data, image_format);
	image.dispose();
}

}
