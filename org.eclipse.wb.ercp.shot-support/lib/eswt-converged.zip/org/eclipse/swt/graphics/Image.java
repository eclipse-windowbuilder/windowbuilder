/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.graphics;

 
import org.eclipse.swt.*;
import org.eclipse.swt.internal.Compatibility;

import com.ibm.ugl.eswt.OS;

import java.io.*;
 
/**
 * Instances of this class are graphics which have been prepared
 * for display on a specific device. That is, they are ready
 * to paint using methods such as <code>GC.drawImage()</code>
 * and display on widgets with, for example, <code>Button.setImage()</code>.
 * <p>
 * If loaded from a file format that supports it, an
 * <code>Image</code> may have transparency, meaning that certain
 * pixels are specified as being transparent when drawn. Examples
 * of file formats that support transparency are GIF and PNG.
 * </p><p>
 * There are two primary ways to use <code>Images</code>. 
 * The first is to load a graphic file from disk and create an
 * <code>Image</code> from it. This is done using an <code>Image</code>
 * constructor, for example:
 * <pre>
 *    Image i = new Image(device, "C:\\graphic.png");
 * </pre>
 * A graphic file may contain a color table specifying which
 * colors the image was intended to possess. In the above example,
 * these colors will be mapped to the closest available color in
 * SWT. It is possible to get more control over the mapping of
 * colors as the image is being created, using code of the form:
 * <pre>
 *    ImageData data = new ImageData("C:\\graphic.png"); 
 *    RGB[] rgbs = data.getRGBs(); 
 *    // At this point, rgbs contains specifications of all
 *    // the colors contained within this image. You may
 *    // allocate as many of these colors as you wish by
 *    // using the Color constructor Color(RGB), then
 *    // create the image:
 *    Image i = new Image(device, data);
 * </pre>
 * <p>
 * Application code must explicitely invoke the <code>Image.dispose()</code> 
 * method to release the operating system resources managed by each instance
 * when those instances are no longer required.
 * </p>
 *
 * @see Color
 * @see ImageData
 */
public final class Image implements Drawable {
	/**
	 * specifies whether the receiver is a bitmap or an icon
	 * (one of <code>SWT.BITMAP</code>, <code>SWT.ICON</code>)
	 */
	public int type;
	
	/**
	 * the OS resource of the image
	 * (Warning: This field is platform dependent)
	 */
	public int internal_handle;
	 	
	/**
	 * The device where this image was created.
	 */
	Device device;
	
	/**
	 * Specifies the default scanline padding.
	 * Warning: This field is platform dependent.
	 */
	static final int DEFAULT_SCANLINE_PAD = 4;
	
	/**
	 * the GC which is drawing on the image
	 */
	GC memGC;


/**	 
 * Creates an ImageData object from the specified image handle
 * <p>
 *
 * @param handle the platform specific Image handle
 * @return ImageData object for the specified image handle.
 */
static ImageData createImageDataFromNativeImage(int handle) {
	ImageData imageData;
	int depth = OS.Image_GetDepth(handle);
	boolean isDirect = OS.Image_IsDirect(handle);
	PaletteData palette = null;
	int alphaMask = 0;
	int alphaShift = 0;
	
	if (isDirect) {
		int[] masks = OS.Image_GetDirectPaletteMasks(handle);
		palette = new PaletteData(masks[OS.PALETTE_MASK_RED], masks[OS.PALETTE_MASK_GREEN], masks[OS.PALETTE_MASK_BLUE]);
		alphaMask = masks[OS.PALETTE_MASK_ALPHA];
		alphaShift = countBits(alphaMask, 0);
	} else {
		int numColors = Compatibility.pow2(depth); // Avoid using Math.pow() because it is not in CLDC
		byte[] red = new byte[numColors];
		byte[] green = new byte[numColors];
		byte[] blue = new byte[numColors];
		OS.Image_GetIndexedPalette(handle, red, green, blue);
		
		RGB[] rgb = new RGB[numColors];
		for (int i = 0; i < numColors; i++) {
			rgb[i] = new RGB(red[i] & 0xFF, green[i] & 0xFF, blue[i] & 0xFF);
		}
		palette = new PaletteData(rgb);
	}
	int[] bounds = OS.Image_GetBounds(handle);
	int width = bounds[OS.INDEX_WIDTH];
	int height = bounds[OS.INDEX_HEIGHT];
		
	if (depth > 8) {
		int[] pixels = OS.Image_GetPixelsHighColor(handle);
		int pixelIndex = 0;
		
		imageData = new ImageData(width, height, depth, palette);
		if (alphaMask != 0) {
			for (int y = 0; y < height; y++) {
				for (int x = 0; x < width; x++, pixelIndex++) {
					int alpha = getPixelRGBComponent(pixels[pixelIndex], alphaMask, alphaShift);
					imageData.setAlpha(x, y, alpha);
					imageData.setPixel(x, y, pixels[pixelIndex]);				
				}
			}
		} else {
			imageData.setPixels(0, 0, pixels.length, pixels, 0);
		}
	} else {
		byte[] pixels = OS.Image_GetPixelsLowColor(handle);
		int bytesPerLine = pixels.length / height;
		int usedBytesPerLine = Compatibility.ceil(width * depth, 8);
		int scanlinePad = bytesPerLine - usedBytesPerLine + 1;
		
		while (bytesPerLine % scanlinePad > 0) {
			scanlinePad++;
		}		
		imageData = new ImageData(width, height, depth, palette, scanlinePad, pixels);
	}
	imageData.transparentPixel = OS.Image_GetTransparentColor(handle);

	return imageData;
}

static int getPixelRGBComponent(int pixel, int mask, int shift) {
	return ((pixel & mask) >>> shift);
}
static int imageFormat(String fileName) {
	InputStream stream = null;
	try {
		stream = Compatibility.newFileInputStream(fileName);
		byte[] buffer = new byte[32];
		stream.read(buffer, 0, buffer.length);
		stream.close();
		return Image.imageFormat(buffer);
	} catch (IOException e) {
		SWT.error(SWT.ERROR_IO, e);
	} finally {
		try {
			if (stream != null) stream.close();
		} catch (IOException e) {
			// Ignore error
		}
	}
	return SWT.IMAGE_UNDEFINED;
}
static int imageFormat(byte[] streamBytes) {
	if (isPNGFormat(streamBytes)) return SWT.IMAGE_PNG;
	if (isGIFFormat(streamBytes)) return SWT.IMAGE_GIF;
	if (isJPEGFormat(streamBytes)) return SWT.IMAGE_JPEG;
	return SWT.IMAGE_UNDEFINED;
}
static boolean isPNGFormat(byte[] streamBytes) {
	if (streamBytes.length < 8) return false;
	if ((streamBytes[0] & 0xFF) != 137) return false; //137
	if ((streamBytes[1] & 0xFF) != 80) return false; //P
	if ((streamBytes[2] & 0xFF) != 78) return false; //N
	if ((streamBytes[3] & 0xFF) != 71) return false; //G
	if ((streamBytes[4] & 0xFF) != 13) return false; //<RETURN>
	if ((streamBytes[5] & 0xFF) != 10) return false; //<LINEFEED>
	if ((streamBytes[6] & 0xFF) != 26) return false; //<CTRL/Z>
	if ((streamBytes[7] & 0xFF) != 10) return false; //<LINEFEED>		
	return true;
}
static boolean isGIFFormat(byte[] streamBytes) {
	if (streamBytes.length < 3) return false;
	if (streamBytes[0] != 'G') return false; 
	if (streamBytes[1]  != 'I') return false;
	if (streamBytes[2]  != 'F') return false; 
	return true;
}
static boolean isJPEGFormat(byte[] streamBytes) {
	if (streamBytes.length < 2) return false;
	if ((streamBytes[0] & 0xFF) != 0xFF) return false; 
	if ((streamBytes[1] & 0xFF) != 0xD8) return false; 
	return true;
}
/**
 * Reads the specified stream and returns the contents as a byte 
 * array.
 * 
 * @param stream the raw image data stream
 * @return image data buffer
 */
static byte[] readImageStream(InputStream stream) {
	byte[] buffer = new byte[512];
	ByteArrayOutputStream baoStream = new ByteArrayOutputStream();

	try {
		boolean done = false;
		while (!done) {
			int length = stream.read(buffer);
			if (-1 == length) {
				done = true;
			}
			else {
				baoStream.write(buffer,0,length);
			}
		}
	}
	catch (IOException e) {
		SWT.error(SWT.ERROR_IO, e);
	}
	finally {
		try {
			baoStream.close();
		} catch (IOException e) {
			// ignore for the close
		}		
	}
	
	return baoStream.toByteArray();	
}
static int countBits(int mask, int bit) {
	int count = 0;
	
	if (mask == 0) {
		return 0;
	}
	while (((mask >> count) & 0x1) == bit) {
		count++;
	}
	return count;
}

Image() {
}
/**
 * Constructs an instance of this class from the given
 * <code>ImageData</code>.
 *
 * @param device the device on which to create the image
 * @param data the image data to create the image from (must not be null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if device is null and there is no current device</li>
 *    <li>ERROR_NULL_ARGUMENT - if the image data is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_UNSUPPORTED_DEPTH - if the depth of the ImageData is not supported</li>
 * </ul>
 * @exception SWTError <ul>
 *    <li>ERROR_NO_HANDLES if a handle could not be obtained for image creation</li>
 * </ul>
 */
public Image(Device device, ImageData data) {
	init(device, data);
}
/**
 * Constructs an instance of this class by loading its representation
 * from the specified input stream. Throws an error if an error
 * occurs while loading the image, or if the result is an image
 * of an unsupported type.  Application code is still responsible
 * for closing the input stream.
 * <p>
 * This constructor may be used to load a resource as follows:
 * </p>
 * <pre>
 *     new Image(device, clazz.getResourceAsStream("file.png"));
 * </pre>
 *
 * @param device the device on which to create the image
 * @param stream the input stream to load the image from
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if device is null and there is no current device</li>
 *    <li>ERROR_NULL_ARGUMENT - if the stream is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_INVALID_IMAGE - if the image file contains invalid data </li>
 *    <li>ERROR_IO - if an IO error occurs while reading data</li>
 *    <li>ERROR_UNSUPPORTED_DEPTH - if the InputStream describes an image with an unsupported depth</li>
 *    <li>ERROR_UNSUPPORTED_FORMAT - if the image file contains an unrecognized format</li>
 *  * </ul>
 * </ul>
 * @exception SWTError <ul>
 *    <li>ERROR_NO_HANDLES if a handle could not be obtained for image creation</li>
 * </ul>
 */
public Image(Device device, InputStream stream) {
	init(device, stream);
	// testing purposes only
//	init(device, new ImageData(stream));	
}
/**
 * Constructs an empty instance of this class with the
 * specified width and height. The result may be drawn upon
 * by creating a GC and using any of its drawing operations,
 * as shown in the following example:
 * <pre>
 *    Image i = new Image(device, width, height);
 *    GC gc = new GC(i);
 *    gc.drawRectangle(0, 0, 50, 50);
 *    gc.dispose();
 * </pre>
 * <p>
 * Note: Some platforms may have a limitation on the size
 * of image that can be created (size depends on width, height,
 * and depth). For example, Windows 95, 98, and ME do not allow
 * images larger than 16M.
 * </p>
 *
 * @param device the device on which to create the image
 * @param width the width of the new image
 * @param height the height of the new image
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if device is null and there is no current device</li>
 *    <li>ERROR_INVALID_ARGUMENT - if either the width or height is negative or zero</li>
 * </ul>
 * @exception SWTError <ul>
 *    <li>ERROR_NO_HANDLES if a handle could not be obtained for image creation</li>
 * </ul>
 */
public Image(Device device, int width, int height) {
	init(device, width, height);
}
/**
 * Constructs an empty instance of this class with the
 * width and height of the specified rectangle. The result
 * may be drawn upon by creating a GC and using any of its
 * drawing operations, as shown in the following example:
 * <pre>
 *    Image i = new Image(device, boundsRectangle);
 *    GC gc = new GC(i);
 *    gc.drawRectangle(0, 0, 50, 50);
 *    gc.dispose();
 * </pre>
 * <p>
 * Note: Some platforms may have a limitation on the size
 * of image that can be created (size depends on width, height,
 * and depth). For example, Windows 95, 98, and ME do not allow
 * images larger than 16M.
 * </p>
 *
 * @param device the device on which to create the image
 * @param bounds a rectangle specifying the image's width and height (must not be null)
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if device is null and there is no current device</li>
 *    <li>ERROR_NULL_ARGUMENT - if the bounds rectangle is null</li>
 *    <li>ERROR_INVALID_ARGUMENT - if either the rectangle's width or height is negative</li>
 * </ul>
 * @exception SWTError <ul>
 *    <li>ERROR_NO_HANDLES if a handle could not be obtained for image creation</li>
 * </ul>
 */
public Image(Device device, Rectangle bounds) {
	if (bounds == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	init(device, bounds.width, bounds.height);
}
/**
 * Constructs an instance of this class by loading its representation
 * from the file with the specified name. Throws an error if an error
 * occurs while loading the image, or if the result is an image
 * of an unsupported type.  Application code is still responsible
 * for closing the input stream.
 * <p>
 * This constructor is provided for convenience when loading
 * a single image only. If the specified file contains
 * multiple images, only the first one will be used.
 *
 * @param device the device on which to create the image
 * @param filename the name of the file to load the image from
 *
 * @exception IllegalArgumentException <ul>
 *    <li>ERROR_NULL_ARGUMENT - if device is null and there is no current device</li>
 *    <li>ERROR_NULL_ARGUMENT - if the file name is null</li>
 * </ul>
 * @exception SWTException <ul>
 *    <li>ERROR_INVALID_IMAGE - if the image file contains invalid data </li>
 *    <li>ERROR_IO - if an IO error occurs while reading data</li>
 *    <li>ERROR_UNSUPPORTED_DEPTH - if the image file has an unsupported depth</li>
 *    <li>ERROR_UNSUPPORTED_FORMAT - if the image file contains an unrecognized format</li>
 * </ul>
 * @exception SWTError <ul>
 *    <li>ERROR_NO_HANDLES if a handle could not be obtained for image creation</li>
 * </ul>
 */
public Image(Device device, String filename) {
	init(device, filename);
	// testing purposes only
//	init(device, new ImageData(filename));
}
/**
 * Disposes of the operating system resources associated with
 * the image. Applications must dispose of all images which
 * they allocate.
 */
public void dispose() {
	if (internal_handle == 0) return;
	
	if (memGC != null) {
		memGC.dispose();
		memGC = null;
	}	
	OS.Image_Dispose(internal_handle);
	internal_handle = 0;
	device = null;
}
/**
 * Compares the argument to the receiver, and returns true
 * if they represent the <em>same</em> object using a class
 * specific comparison.
 *
 * @param object the object to compare with this object
 * @return <code>true</code> if the object is the same as this object and <code>false</code> otherwise
 *
 * @see #hashCode
 */
public boolean equals(Object object) {
	if (object == this) return true;
	if (!(object instanceof Image)) return false;
	Image image = (Image) object;
	return device == image.device && internal_handle == image.internal_handle;
}
/**
 * Returns the bounds of the receiver. The rectangle will always
 * have x and y values of 0, and the width and height of the
 * image.
 *
 * @return a rectangle specifying the image's bounds
 *
 * @exception SWTException <ul>
 *    <li>ERROR_GRAPHIC_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_INVALID_IMAGE - if the image is not a bitmap or an icon</li>
 * </ul>
 */
public Rectangle getBounds() {
	if (internal_handle == 0) SWT.error(SWT.ERROR_GRAPHIC_DISPOSED);
	if (type != SWT.BITMAP) SWT.error(SWT.ERROR_INVALID_IMAGE);
	int[] rect = OS.Image_GetBounds(internal_handle);
	
	return new Rectangle(rect[OS.INDEX_X], rect[OS.INDEX_Y], rect[OS.INDEX_WIDTH], rect[OS.INDEX_HEIGHT]); 
}
/**
 * Returns an <code>ImageData</code> based on the receiver
 * Modifications made to this <code>ImageData</code> will not
 * affect the Image.
 *
 * @return an <code>ImageData</code> containing the image's data and attributes
 *
 * @exception SWTException <ul>
 *    <li>ERROR_GRAPHIC_DISPOSED - if the receiver has been disposed</li>
 *    <li>ERROR_INVALID_IMAGE - if the image is not a bitmap or an icon</li>
 * </ul>
 *
 * @see ImageData
 */
public ImageData getImageData() {
	if (internal_handle == 0) SWT.error(SWT.ERROR_GRAPHIC_DISPOSED);
	if (type != SWT.BITMAP) SWT.error(SWT.ERROR_INVALID_IMAGE);
	ImageData imageData = createImageDataFromNativeImage(internal_handle);	
	return imageData;
}
/**
 * Returns an integer hash code for the receiver. Any two 
 * objects that return <code>true</code> when passed to 
 * <code>equals</code> must return the same value for this
 * method.
 *
 * @return the receiver's hash
 *
 * @see #equals
 */
public int hashCode() {
	return internal_handle;
}
void init(Device device, ImageData imageData) {
	if (device == null) device = Device.getDevice();
	if (device == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	if (imageData == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	int depth = imageData.depth;
	this.device = device;

	PaletteData palette = imageData.palette;
	if (palette.isDirect) {
		byte[] byteData = imageData.data;
		int width = imageData.width;
		int height = imageData.height;
		int[] intData = new int[width * height];
		int bytesPerPixel = depth / 8;
		int redMask = palette.redMask;
		int greenMask = palette.greenMask;
		int blueMask = palette.blueMask;
		int redShift = countBits(redMask, 0);
		int greenShift = countBits(greenMask, 0);
		int blueShift = countBits(blueMask, 0);
		int redMax8bit = 0;
		int greenMax8bit = 0;
		int blueMax8bit = 0;
		
		if (depth == 8) {
			int redSize = countBits(redMask >> redShift, 1);
			int greenSize = countBits(greenMask >> greenShift, 1);
			int blueSize = countBits(blueMask >> blueShift, 1);
			
			redMax8bit = (1 << redSize) - 1;
			greenMax8bit = (1 << greenSize) - 1;
			blueMax8bit = (1 << blueSize) - 1;
		}

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int byteIndex = y * imageData.bytesPerLine + x * bytesPerPixel;
				int pixel;
				if (depth == 8) {
					pixel = byteData[byteIndex];
				} else if (depth == 16) {
					// 16bpp image data is in least significant byte order
					pixel = (byteData[byteIndex+1] & 0xFF) << 8 | (byteData[byteIndex] & 0xFF);
				} else if (depth == 24) {
					// 24bpp image data is in most significant byte order
					pixel = (byteData[byteIndex] & 0xFF) << 16 | (byteData[byteIndex+1] & 0xFF) << 8 | (byteData[byteIndex+2] & 0xFF);
				} else {
					// 32bpp image data is in most significant byte order
					pixel = (byteData[byteIndex] & 0xFF) << 24 | (byteData[byteIndex+1] & 0xFF) << 16 | (byteData[byteIndex+2] & 0xFF) << 8 | (byteData[byteIndex+3] & 0xFF);
				}
				int red = getPixelRGBComponent(pixel, redMask, redShift);
				int green = getPixelRGBComponent(pixel, greenMask, greenShift); 
				int blue = getPixelRGBComponent(pixel, blueMask, blueShift);
				// UGL does not support 8 bit direct color. Convert color values to 16 bit.
				if (depth == 8) {
					final int RedMax16bit = 31;		// 5 bits
					final int GreenMax16bit = 63;	// 6 bits
					final int BlueMax16bit = 31;	// 5 bits
					
					if (redMax8bit != 0) {
						red = red * RedMax16bit / redMax8bit;
					}
					if (greenMax8bit != 0) {
						green = green * GreenMax16bit / greenMax8bit;
					}
					if (blueMax8bit != 0) {
						blue = blue * BlueMax16bit / blueMax8bit;
					}
					intData[y * width + x] = red << 11 | green << 5 | blue;
				} else if (depth == 16) {
					intData[y * width + x] = red << 11 | green << 5 | blue;
				} else if (depth == 24){
					intData[y * width + x] = red << 16 | green << 8 | blue;
				} else {
					if ((imageData.alpha == -1) && (imageData.alphaData == null) && (imageData.transparentPixel == -1)) {
						intData[y * width + x] = 255 << 24 | red << 16 | green << 8 | blue;
					} else {
						intData[y * width + x] = red << 16 | green << 8 | blue;
					}
				}
			}
		}
		// UGL does not directly support 8 bit direct images.
		if (depth == 8) {
			depth = 16;
		} 
		internal_handle = OS.Image_NewFromIntData(device.internal_handle, width, height, intData, depth, imageData.transparentPixel, imageData.alpha, imageData.alphaData);
	} else {
		RGB[] rgbs = imageData.getRGBs();
		// guard against SWT palette being too long, since PaletteData does 
		// no consistency check.
		int paletteSize = Math.min(rgbs.length, 1 << depth);
		byte[] indexedReds = new byte[paletteSize]; 
		byte[] indexedGreens = new byte[paletteSize];
		byte[] indexedBlues = new byte[paletteSize];

		for (int i = 0; i < paletteSize; i++) {
			RGB rgb = rgbs[i];
			indexedReds[i] = (byte) rgb.red; 
			indexedGreens[i] = (byte) rgb.green;
			indexedBlues[i] = (byte) rgb.blue;
		}
		internal_handle = OS.Image_NewFromByteData(device.internal_handle, imageData.width, imageData.height, imageData.data, imageData.bytesPerLine, depth, indexedReds, indexedGreens, indexedBlues, paletteSize, imageData.transparentPixel);		
	}
}
void init(Device device, String fileName) {
	if (device == null) device = Device.getDevice();
	if (device == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	if (fileName == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	int imageFormat = Image.imageFormat(fileName);
	if (imageFormat == SWT.IMAGE_UNDEFINED) SWT.error(SWT.ERROR_UNSUPPORTED_FORMAT);
	
	internal_handle = OS.Image_NewFromFile(device.internal_handle, fileName);
	this.device = device;
}
void init(Device device, InputStream stream) {
	if (device == null) device = Device.getDevice();
	if (device == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	if (stream == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

	byte[] buffer = readImageStream(stream);
	int imageFormat = Image.imageFormat(buffer);
	if (imageFormat == SWT.IMAGE_UNDEFINED) SWT.error(SWT.ERROR_UNSUPPORTED_FORMAT);
		
	internal_handle = OS.Image_NewFromFileData(device.internal_handle, buffer, buffer.length);
	this.device = device;
}
void init(Device device, int width, int height) {
	if (device == null) device = Device.getDevice();
	if (device == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	this.device = device;	
	if (width <= 0 | height <= 0) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
	this.type = SWT.BITMAP;

	// Fill with opaque black
	internal_handle = OS.Image_NewFromSize(device.internal_handle, width, height, 0xff000000);
	if (internal_handle == 0) SWT.error(SWT.ERROR_NO_HANDLES);
}

public void internal_copyArea(int destImageHandle, int srcX, int srcY, int srcWidth, int srcHeight) {
	OS.Image_CopyArea(internal_handle, destImageHandle, srcX, srcY, srcWidth, srcHeight);
}
/**	 
 * Invokes platform specific functionality to dispose a GC handle.
 * <p>
 * <b>IMPORTANT:</b> This method is <em>not</em> part of the public
 * API for <code>Image</code>. It is marked public only so that it
 * can be shared within the packages provided by SWT. It is not
 * available on all platforms, and should never be called from
 * application code.
 * </p>
 *
 * @param handle the platform specific GC handle
 * @param data the platform specific GC data 
 *
 */
public void internal_dispose_GC(int painter, InternalGCData data) {
	// do nothing. GCs disposed in GC.dispose
}
public Rectangle internal_getBounds () {
	return getBounds();
}
public int internal_getDepth() {
	return OS.Image_GetDepth(internal_handle);
}
/**	 
 * Invokes platform specific functionality to allocate a new GC handle.
 * <p>
 * <b>IMPORTANT:</b> This method is <em>not</em> part of the public
 * API for <code>Image</code>. It is marked public only so that it
 * can be shared within the packages provided by SWT. It is not
 * available on all platforms, and should never be called from
 * application code.
 * </p>
 *
 * @param data the platform specific GC data 
 * @return the platform specific GC handle
 *
 * @private
 */
public int internal_new_GC(InternalGCData data) {
	if (internal_handle == 0) SWT.error(SWT.ERROR_GRAPHIC_DISPOSED);
	/*
	 * Create a new GC that can draw into the image.
	 * Only supported for bitmaps.
	 */
	if (type != SWT.BITMAP || memGC != null) SWT.error(SWT.ERROR_INVALID_ARGUMENT);

	int gcHandle = OS.Image_NewGraphics(internal_handle); 
	data.device = device;
	data.image = this;
	return gcHandle;	
}
/**
 * Returns <code>true</code> if the image has been disposed,
 * and <code>false</code> otherwise.
 * <p>
 * This method gets the dispose state for the image.
 * When an image has been disposed, it is an error to
 * invoke any other method using the image.
 *
 * @return <code>true</code> when the image is disposed and <code>false</code> otherwise
 */
public boolean isDisposed() {
	return internal_handle == 0;
}
/**
 * Returns a string containing a concise, human-readable
 * description of the receiver.
 *
 * @return a string representation of the receiver
 */
public String toString () {
	if (isDisposed()) return "Image {*DISPOSED*}";
	return "Image {" + internal_handle + "}";
}

public Rectangle internal_getDefaultClipping() {
    return getBounds();
}

}