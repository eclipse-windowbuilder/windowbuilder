/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.graphics;

import java.io.InputStream;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;

import com.ibm.ugl.eswt.OS;


class ImageDataLoader {


	public ImageData[] load(InputStream stream) {
		if (stream == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		
		byte[] buffer = Image.readImageStream(stream);
		int imageFormat = Image.imageFormat(buffer);
		if (imageFormat == SWT.IMAGE_UNDEFINED) SWT.error(SWT.ERROR_UNSUPPORTED_FORMAT);

		// ImageLoader APIs can be called outside a display thread.
		// However, this implementation creates ImageData from a native
		// image, which requires a Display.
		ImageData imageData;
		synchronized (Display.class) {
		    // This code is in a synchronized block because the temporary
		    // Display that is created below will become the default Display
		    // (as returned by Display.getDefault()).  It is possible for
		    // a separate thread to call Display.getDefault() and then proceed
		    // to use this Display.  This is bad because the temporary Display
		    // will be disposed below, which will cause exceptions in the other
		    // thread.
			Display display = Display.getCurrent();
			boolean disposeDisplay = false;
			if (display == null) {
			    display = new Display();
			    disposeDisplay = true;
			}
			int imageHandle = OS.Image_NewFromFileData(display.internal_handle,buffer, buffer.length);
		    imageData = Image.createImageDataFromNativeImage(imageHandle);
		    imageData.type = imageFormat;
		    OS.Image_Dispose(imageHandle);
			if (disposeDisplay) {
			    display.dispose();
			}    
		}
		
		return new ImageData[] {imageData};
	}


	public ImageData[] load(String fileName) {
		if (fileName == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		
		int imageFormat = Image.imageFormat(fileName);
		if (imageFormat == SWT.IMAGE_UNDEFINED) SWT.error(SWT.ERROR_UNSUPPORTED_FORMAT);
		
		// ImageLoader APIs can be called outside a display thread.
		// However, this implementation creates ImageData from a native
		// image, which requires a Display.
		ImageData imageData;
		synchronized (Display.class) {
		    // This code is in a synchronized block because the temporary
		    // Display that is created below will become the default Display
		    // (as returned by Display.getDefault()).  It is possible for
		    // a separate thread to call Display.getDefault() and then proceed
		    // to use this Display.  This is bad because the temporary Display
		    // will be disposed below, which will cause exceptions in the other
		    // thread.
			Display display = Display.getCurrent();
			boolean disposeDisplay = false;
			if (display == null) {
			    display = new Display();
			    disposeDisplay = true;
			}
			int imageHandle = OS.Image_NewFromFile(display.internal_handle,fileName);
			imageData = Image.createImageDataFromNativeImage(imageHandle);	
			imageData.type = imageFormat;
			OS.Image_Dispose(imageHandle);
			if (disposeDisplay) {
			    display.dispose();
			}
		}
		
		return new ImageData[] {imageData};
	}

}