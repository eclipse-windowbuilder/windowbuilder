/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.graphics;


import java.util.*;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;

import com.ibm.ugl.eswt.OS;

/**
 * This class is the abstract superclass of all device objects,
 * such as the Display device. Devices can have a graphics 
 * context (GC) created for them, and they can be drawn on by 
 * sending messages to the associated GC.
 */
public abstract class Device implements Drawable {

	public int internal_handle = 0;
	public static int internal_vkstatus = 1; // NORMAL
	
	Font systemFont;

	/* System Colors */
	Color COLOR_BLACK, COLOR_DARK_RED, COLOR_DARK_GREEN, COLOR_DARK_YELLOW, COLOR_DARK_BLUE;
	Color COLOR_DARK_MAGENTA, COLOR_DARK_CYAN, COLOR_GRAY, COLOR_DARK_GRAY, COLOR_RED;
	Color COLOR_GREEN, COLOR_YELLOW, COLOR_BLUE, COLOR_MAGENTA, COLOR_CYAN, COLOR_WHITE;
	
	/*
	* TEMPORARY CODE. When a graphics object is
	* created and the device parameter is null,
	* the current Display is used. This presents
	* a problem because SWT graphics does not
	* reference classes in SWT widgets. The correct
	* fix is to remove this feature. Unfortunately,
	* too many application programs rely on this
	* feature.
	*
	* This code will be removed in the future.
	*/
	protected static Device Internal_CurrentDevice;
	protected static Runnable Internal_DeviceFinder;
	
	
	static {
		
		try {
			Class.forName("org.eclipse.swt.widgets.Display");
		} catch (Throwable e) {}
	}
	
/**
 * Constructs a new instance of this class.
 * <p>
 * You must dispose the device when it is no longer required. 
 * </p>
 *
 * @see #create
 * @see #init
 * 
 * @since 3.1
 */
public Device() {
	
	internal_create();
	init();
}
/**
 * Throws an <code>SWTException</code> if the receiver can not
 * be accessed by the caller. This may include both checks on
 * the state of the receiver and more generally on the entire
 * execution context. This method <em>should</em> be called by
 * device implementors to enforce the standard SWT invariants.
 * <p>
 * Currently, it is an error to invoke any method (other than
 * <code>isDisposed()</code> and <code>dispose()</code>) on a
 * device that has had its <code>dispose()</code> method called.
 * </p><p>
 * In future releases of SWT, there may be more or fewer error
 * checks and exceptions may be thrown for different reasons.
 * <p>
 *
 * @exception SWTException <ul>
 *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 */
protected void checkDevice() {
	if (internal_handle == 0) SWT.error(SWT.ERROR_DEVICE_DISPOSED);
}

/**
 * Creates the device in the operating system.  If the device
 * does not have a handle, this method may do nothing depending
 * on the device.
 * <p>
 * This method is called before <code>init</code>.
 * </p><p>
 * Subclasses are supposed to reimplement this method and not
 * call the <code>super</code> implementation.
 * </p>
 *
 * @param data the DeviceData which describes the receiver
 *
 * @see #init
 */
protected void internal_create() {
}

/**
 * Destroys the device in the operating system and releases
 * the device's handle.  If the device does not have a handle,
 * this method may do nothing depending on the device.
 * <p>
 * This method is called after <code>release</code>.
 * </p><p>
 * Subclasses are supposed to reimplement this method and not
 * call the <code>super</code> implementation.
 * </p>
 *
 * @see #dispose
 * @see #release
 */
protected void destroy() {
	OS.Device_Dispose(internal_handle);	
	internal_handle = 0;
}
/**
 * Disposes of the operating system resources associated with
 * the receiver. After this method has been invoked, the receiver
 * will answer <code>true</code> when sent the message
 * <code>isDisposed()</code>.
 *
 * @see #release
 * @see #destroy
 * @see #checkDevice
 */
public void dispose() {
	if (isDisposed()) return;
	checkDevice();
	release();
	destroy();
}
/**
 * Returns a rectangle describing the receiver's size and location.
 *
 * @return the bounding rectangle
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 */
public Rectangle getBounds() {
	checkDevice();
	int[] bounds = OS.Device_GetBounds(internal_handle);
	return new Rectangle(bounds[OS.INDEX_X], bounds[OS.INDEX_Y], bounds[OS.INDEX_WIDTH], bounds[OS.INDEX_HEIGHT]);
}
/**
 * Returns a rectangle which describes the area of the
 * receiver which is capable of displaying data.
 * 
 * @return the client area
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 *
 * @see #getBounds
 */
public Rectangle getClientArea() {
	return getBounds();
}
/**
 * Returns the bit depth of the screen, which is the number of
 * bits it takes to represent the number of unique colors that
 * the screen is currently capable of displaying. This number 
 * will typically be one of 1, 8, 15, 16, 24 or 32.
 *
 * @return the depth of the screen
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 */
public int getDepth() {
	checkDevice();
	return OS.Device_GetDepth(internal_handle);
}
/**
 * TEMPORARY CODE.
 */
static Device getDevice() {
	if (Internal_DeviceFinder != null) Internal_DeviceFinder.run();
	Device device = Internal_CurrentDevice;
	Internal_CurrentDevice = null;
	return device;
}
/**
 * Returns a point whose x coordinate is the horizontal
 * dots per inch of the display, and whose y coordinate
 * is the vertical dots per inch of the display.
 *
 * @return the horizontal and vertical DPI
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 */
public Point getDPI() {
	checkDevice();
	int[] dpi = OS.Device_GetDPI(internal_handle);
	return new Point(dpi[0], dpi[1]);
}
/**
 * Returns <code>FontData</code> objects which describe
 * the fonts that match the given arguments. If the
 * <code>faceName</code> is null, all fonts will be returned.
 *
 * @param faceName the name of the font to look for, or null
 * @param scalable if true only scalable fonts are returned, otherwise only non-scalable fonts are returned.
 * @return the matching font data
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 */
public FontData[] getFontList(String faceName, boolean scalable) {	
	checkDevice();

//	String[] fontNames = OS.Device_GetFontList(handle, faceName, scalable);
//	FontData[] ret = new FontData[fontNames.length];
//	for (int i=0;i<fontNames.length;i++) {
//		ret[i] = new FontData(fontNames[i]);
//	}
	
	FontData[] result = null;
	String[] typefaces = OS.Device_GetTypefaces(internal_handle,scalable);

	if (faceName == null) {
		// return all typeface variants with scalable value
		Vector list = new Vector();
		for (int i=0; i<typefaces.length; i++) {
			String[] variants = OS.Device_GetTypefaceVariants(internal_handle,typefaces[i],scalable);
			for (int v=0; v<variants.length; v++) {
				list.addElement(new FontData(variants[v]));
			}
		}
		result = new FontData[list.size()];
		for (int i=0; i<result.length; i++) {
			result[i] = (FontData)list.elementAt(i);
		}
	}
	else {
		// return only the variants for faceName
		for (int i=0; i<typefaces.length; i++) {
			if (faceName.equals(typefaces[i])) {
				String[] variants = OS.Device_GetTypefaceVariants(internal_handle,typefaces[i],scalable);
				result = new FontData[variants.length];
				for (int v=0; v<variants.length; v++) {
					result[v] = new FontData(variants[v]);
				}
				break;
			}
		}
		
	}
	
	//In WM device, the typefaces is 0 to cause dump.
	if(result==null && typefaces.length != 0 ){
		// when there are no matches to the faceName provided, return the first typeface variants by default.
		String[] variants = OS.Device_GetTypefaceVariants(internal_handle,typefaces[0],scalable);
		result = new FontData[variants.length];
		for (int v=0; v<variants.length; v++) {
			result[v] = new FontData(variants[v]);
		}
	}

	return result;
}
/**
 * Returns the matching standard color for the given
 * constant, which should be one of the color constants
 * specified in class <code>SWT</code>. Any value other
 * than one of the SWT color constants which is passed
 * in will result in the color black. This color should
 * not be freed because it was allocated by the system,
 * not the application.
 *
 * @param id the color constant
 * @return the matching color
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 *
 * @see SWT
 */
public Color getSystemColor(int id) {
	checkDevice();
	switch (id) {
		case SWT.COLOR_BLACK: 				return COLOR_BLACK;
		case SWT.COLOR_DARK_RED: 			return COLOR_DARK_RED;
		case SWT.COLOR_DARK_GREEN:	 		return COLOR_DARK_GREEN;
		case SWT.COLOR_DARK_YELLOW: 		return COLOR_DARK_YELLOW;
		case SWT.COLOR_DARK_BLUE: 			return COLOR_DARK_BLUE;
		case SWT.COLOR_DARK_MAGENTA: 		return COLOR_DARK_MAGENTA;
		case SWT.COLOR_DARK_CYAN: 			return COLOR_DARK_CYAN;
		case SWT.COLOR_GRAY: 				return COLOR_GRAY;
		case SWT.COLOR_DARK_GRAY: 			return COLOR_DARK_GRAY;
		case SWT.COLOR_RED: 				return COLOR_RED;
		case SWT.COLOR_GREEN: 				return COLOR_GREEN;
		case SWT.COLOR_YELLOW: 				return COLOR_YELLOW;
		case SWT.COLOR_BLUE: 				return COLOR_BLUE;
		case SWT.COLOR_MAGENTA: 			return COLOR_MAGENTA;
		case SWT.COLOR_CYAN: 				return COLOR_CYAN;
		case SWT.COLOR_WHITE: 				return COLOR_WHITE;
	}
	return COLOR_BLACK;
}
/**
 * Returns a reasonable font for applications to use.
 * On some platforms, this will match the "default font"
 * or "system font" if such can be found.  This font
 * should not be freed because it was allocated by the
 * system, not the application.
 * <p>
 * Typically, applications which want the default look
 * should simply not set the font on the widgets they
 * create. Widgets are always created with the correct
 * default font for the class of user-interface component
 * they represent.
 * </p>
 *
 * @return a font
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 */
public Font getSystemFont() {
	checkDevice();
	if (systemFont == null) {
		systemFont = new Font(OS.Device_GetSystemFont(internal_handle));
	}
	return systemFont;
}

/**
 * Returns <code>true</code> if the underlying window system prints out
 * warning messages on the console, and <code>setWarnings</code>
 * had previously been called with <code>true</code>.
 *
 * @return <code>true</code>if warnings are being handled, and <code>false</code> otherwise
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 */
public boolean getWarnings() {
	checkDevice();
	/** Nothing to do. **/
	return false;
}
protected void init() {
	COLOR_BLACK = new Color(this, 0,0,0);
	COLOR_DARK_RED = new Color(this, 0x80,0,0);
	COLOR_DARK_GREEN = new Color(this, 0,0x80,0);
	COLOR_DARK_YELLOW = new Color(this, 0x80,0x80,0);
	COLOR_DARK_BLUE = new Color(this, 0,0,0x80);
	COLOR_DARK_MAGENTA = new Color(this, 0x80,0,0x80);
	COLOR_DARK_CYAN = new Color(this, 0,0x80,0x80);
	COLOR_GRAY = new Color(this, 0xC0,0xC0,0xC0);
	COLOR_DARK_GRAY = new Color(this, 0x80,0x80,0x80);
	COLOR_RED = new Color(this, 0xFF,0,0);
	COLOR_GREEN = new Color(this, 0,0xFF,0);
	COLOR_YELLOW = new Color(this, 0xFF,0xFF,0);
	COLOR_BLUE = new Color(this, 0,0,0xFF);
	COLOR_MAGENTA = new Color(this, 0xFF,0,0xFF);
	COLOR_CYAN = new Color(this, 0,0xFF,0xFF);
	COLOR_WHITE = new Color(this, 0xFF,0xFF,0xFF);
}
/**	 
 * Invokes platform specific functionality to dispose a GC handle.
 * <p>
 * <b>IMPORTANT:</b> This method is <em>not</em> part of the public
 * API for <code>Device</code>. It is marked public only so that it
 * can be shared within the packages provided by SWT. It is not
 * available on all platforms, and should never be called from
 * application code.
 * </p>
 *
 * @param handle the platform specific GC handle
 * @param data the platform specific GC data 
 *
 */
public abstract void internal_dispose_GC(int handle, InternalGCData data);
/**	 
 * Invokes platform specific functionality to allocate a new GC handle.
 * <p>
 * <b>IMPORTANT:</b> This method is <em>not</em> part of the public
 * API for <code>Device</code>. It is marked public only so that it
 * can be shared within the packages provided by SWT. It is not
 * available on all platforms, and should never be called from
 * application code.
 * </p>
 *
 * @param data the platform specific GC data 
 * @return the platform specific GC handle
 *
 * @private
 */
public abstract int internal_new_GC(InternalGCData data);
/**
 * Returns <code>true</code> if the device has been disposed,
 * and <code>false</code> otherwise.
 * <p>
 * This method gets the dispose state for the device.
 * When a device has been disposed, it is an error to
 * invoke any other method using the device.
 *
 * @return <code>true</code> when the device is disposed and <code>false</code> otherwise
 */
public boolean isDisposed() {
	return internal_handle == 0;
}
/**
 * Releases any internal resources back to the operating
 * system and clears all fields except the device handle.
 * <p>
 * When a device is destroyed, resources that were acquired
 * on behalf of the programmer need to be returned to the
 * operating system.  For example, if the device allocated a
 * font to be used as the system font, this font would be
 * freed in <code>release</code>.  Also,to assist the garbage
 * collector and minimize the amount of memory that is not
 * reclaimed when the programmer keeps a reference to a
 * disposed device, all fields except the handle are zero'd.
 * The handle is needed by <code>destroy</code>.
 * </p>
 * This method is called before <code>destroy</code>.
 * </p><p>
 * If subclasses reimplement this method, they must
 * call the <code>super</code> implementation.
 * </p>
 *
 * @see #dispose
 * @see #destroy
 */
protected void release() {
	COLOR_BLACK.dispose();
	COLOR_DARK_RED.dispose();
	COLOR_DARK_GREEN.dispose();
	COLOR_DARK_YELLOW.dispose();
	COLOR_DARK_BLUE.dispose();
	COLOR_DARK_MAGENTA.dispose();
	COLOR_DARK_CYAN.dispose();
	COLOR_GRAY.dispose();
	COLOR_DARK_GRAY.dispose();
	COLOR_RED.dispose();
	COLOR_GREEN.dispose();
	COLOR_YELLOW.dispose();
	COLOR_BLUE.dispose();
	COLOR_MAGENTA.dispose();
	COLOR_CYAN.dispose();
	COLOR_WHITE.dispose();

	COLOR_BLACK = COLOR_DARK_RED = COLOR_DARK_GREEN = COLOR_DARK_YELLOW =
	COLOR_DARK_BLUE = COLOR_DARK_MAGENTA = COLOR_DARK_CYAN = COLOR_GRAY = COLOR_DARK_GRAY = COLOR_RED =
	COLOR_GREEN = COLOR_YELLOW = COLOR_BLUE = COLOR_MAGENTA = COLOR_CYAN = COLOR_WHITE = null;
	
	if (systemFont != null) systemFont.dispose();
}
/**
 * If the underlying window system supports printing warning messages
 * to the console, setting warnings to <code>false</code> prevents these
 * messages from being printed. If the argument is <code>true</code> then
 * message printing is not blocked.
 *
 * @param warnings <code>true</code>if warnings should be printed, and <code>false</code> otherwise
 *
 * @exception SWTException <ul>
 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
 * </ul>
 */
public void setWarnings(boolean warnings) {
	checkDevice();
	/** Nothing to do. **/
}

}
