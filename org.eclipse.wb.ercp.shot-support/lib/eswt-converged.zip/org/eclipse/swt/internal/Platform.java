/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.internal;

import com.ibm.ugl.eswt.OS;

public class Platform {
	/* see Platform.h
	bit 0-4 : OS
	  0 : Win32
	  1 : WinCE
	  2 : Window Mobile
	  3 : Window SmartPhone
	  4 : reserved
	bit 5-7  : version sn
	bit 8-15 : reserved
	*/
	public static final int WIN32  = 0x0001; // 000 00001
	public static final int WINCE  = 0x0002; // 000 00010
	public static final int WINCE5 = 0x0022; // 001 00010
	private static final int WM    = 0x0004;
	public static final int WM2003 = 0x0004; // 000 00100
	public static final int WM2005 = 0x0024; // 001 00100
	public static final int WM6PRO = 0x0044; // 010 00100
	private static final int SP    = 0x0008;
	public static final int SP2003 = 0x0008; // 000 01000
	public static final int SP2005 = 0x0028; // 001 01000
	public static final int WM6STD = 0x0048; // 010 01000
	
    public static final String PLATFORM;
    public static final int IDENTIFY_CODE;
    public static final int MAJOR_VERSION;

    public static final boolean isWin32() { return isWin32(IDENTIFY_CODE); }
	public static final boolean isWinCE() { return isWinCE(IDENTIFY_CODE); }
	public static final boolean isWindowMobile() { return isWindowMobile(IDENTIFY_CODE); }
	public static final boolean isSmartPhone() { return isSmartPhone(IDENTIFY_CODE); }

	public static final boolean isWin32(int identify) { return ((identify & WIN32) == WIN32); }
	public static final boolean isWinCE(int identify) { return ((identify & WINCE) == WINCE); }
	public static final boolean isWindowMobile(int identify) { return ((identify & WM) == WM); }
	public static final boolean isSmartPhone(int identify) { return ((identify & SP) == SP); }

	static {
	    PLATFORM = OS.Platform_GetName();
	    IDENTIFY_CODE = OS.Platform_GetIdentifyCode();
	    MAJOR_VERSION = OS.Platform_GetMajorVersion();
	}
}
