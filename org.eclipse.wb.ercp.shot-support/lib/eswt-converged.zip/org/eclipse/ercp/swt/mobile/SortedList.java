/*******************************************************************************
 * Copyright (c) 2004 IBM Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Mark Rogalski (IBM Corp.) - initial API specification
 *******************************************************************************/

package org.eclipse.ercp.swt.mobile;

import java.io.InputStream;
import java.util.Iterator;
import java.util.Vector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Scrollable;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.TypedListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Platform;

import org.eclipse.swt.widgets.Text;




/**
 * Instances of this class represent a selectable user interface object that
 * displays a sorted list of text items. The items may be displayed in ascending
 * or descending order. The sorting algorithm is platform and locale dependent.
 * <p>
 * If the FILTER style is specified during construction, an associated
 * label is also displayed showing characters entered which are then used
 * to filter the list to show fewer items. The selection state of items filtered
 * out of the list is cleared.
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * 
 * <dl>
 * <dt><b>Styles: </b></dt>
 * <dd>SINGLE, MULTI, UP, DOWN</dd>
 * <p>
 * Note: Only one of SINGLE and MULTI may be specified. Only one of UP and DOWN
 * may be specified.
 * <p>
 * <dt><b>Mode Styles:</b></dt>
 * <dd>FILTER</dd>
 * <p>
 * <dt><b>Events: </b></dt>
 * <dd>Selection, DefaultSelection</dd>
 * </dl>
 */
public class SortedList extends Scrollable {

	/**
	 * constructor style specifying filter field should be displayed
	 */
	public static final int FILTER = 1;

	/**
	 * Construct a new instance of this class given its parent and a style value
	 * describing its behavior and appearance.
	 * <p>
	 * The <code>style</code> value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. Style bits are also inherited from superclasses.
	 * <code>SWT.UP</code> (the default) means the list is sorted so that numbers go from
	 * low to high when the list is examined from top to bottom. <code>SWT.DOWN</code>
	 * means the list is sorted so that numbers go from high to low when
	 * examined from top to bottom. 
	 * 
	 * @param parent
	 *            a composite control which will be the parent of the new
	 *            instance (cannot be null)
	 * @param style
	 *            the style of the control
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see SWT#SINGLE
	 * @see SWT#MULTI
	 * @see SWT#UP
	 * @see SWT#DOWN
	 */
	
	List list = null;
	Vector listItems = new Vector(10,10);
	Text filterText  = null;
	static int hackfilterStyle = 0;
	static Composite hackComposite;
	static int hackStyle = 0;
	Composite internalComposite;
	Composite bottomcomposite;
	boolean isDisposed = false;
	int updownStyle = SWT.UP;
	SortedList sortedList = null;
	int filterHeight = 0;
	int filterWidth = 0;
	public boolean hasFilter = false;
	MobileDevice md = new MobileDevice();
	Composite parentComposite;
	int orgVKStatus = MobileDevice.VK_NORMAL;
	boolean saveVKStatus = true;
	VerticalLayout verticalLayout = null;
	VerticalLayout horizontalLayout = null;
	InputStream stream  = null;
	Label magnifyLabel = null;
	Display display2 = null;
	Listener keyListener;
	int numericCount = 0; //It's used to indicate where is the end of numeric number
	boolean enableTraverse = false; // for smartphone traverse

	public SortedList(Composite parent, int style) {
		this(parent, style, 0);
		
	}
	
	
	/**
	 * Construct a new instance of this class given its parent, a style value
	 * describing its behavior and appearance, and a mode style describing 
	 * additional behavior modes.
	 * <p>
	 * The <code>style</code> value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. Style bits are also inherited from superclasses.
	 * 
	 * <code>SWT.UP</code> (the default) means the list is sorted in dictionary order
	 * from top to bottom (i.e. A, B, C, ...). <code>SWT.DOWN</code>
	 * means the list is sorted in reverse dictionary order from top to bottom (i.e.
	 * Z, Y, X, ...). 
	 * 
	 * The <code>modeStyle</code> may specify the class constant <code>FILTER</code>.
	 * This style adds a text entry field to
	 * the widget which does not receive focus, but will display characters
	 * entered while the list has focus. These characters are used to filter the
	 * list items so that fewer items are displayed in the list. The selection is
	 * cleared for any items not shown as a result of filtering.
	 * 
	 * @param parent
	 *            a composite control which will be the parent of the new
	 *            instance (cannot be null)
	 * @param style
	 *            the style of the control
	 * 
	 * @param modeStyle
	 * 			  the mode for the control 
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see SWT#SINGLE
	 * @see SWT#MULTI
	 * @see SWT#UP
	 * @see SWT#DOWN
	 * @see SortedList#FILTER
	 */
	public SortedList(Composite parent, int style, int modeStyle) {
		super(SaveStyle(parent,style,modeStyle), SWT.NONE);
		if (parent == null) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
		}
		display2 = parent.getDisplay();
		
		sortedList = this;
		
		if (modeStyle == FILTER) {
			style = style & (~SWT.BORDER);
			
			verticalLayout = new VerticalLayout(SWT.VERTICAL);
			verticalLayout.wrap = false;
			verticalLayout.pack = true;

			internalComposite.setLayout(verticalLayout);

			list = new List(internalComposite, style);
			stream = this.getClass().getResourceAsStream("/resources/Magnify1.png");
			bottomcomposite = new Composite(internalComposite, SWT.NO_TRIM);
			horizontalLayout = new VerticalLayout(SWT.HORIZONTAL);
			horizontalLayout.wrap = false;
			horizontalLayout.pack = true;
			bottomcomposite.setLayout(horizontalLayout);
			magnifyLabel = new Label(bottomcomposite,SWT.NULL);
			magnifyLabel.setImage(new Image(display2,stream));
			
			filterText = new Text(bottomcomposite,SWT.SINGLE);
			filterText.setBackground(new Color(display2,230,230,230));

			internalComposite.addFocusListener(new FocusListener() {
				public void focusGained(FocusEvent e) {
					setVKAlwaysOff();
					filterText.forceFocus();
				}
				public void focusLost(FocusEvent e) {
				}
			});

			list.addFocusListener(new FocusListener() {
				public void focusGained(FocusEvent e) {
					setVKAlwaysOff();
					filterText.forceFocus();
				}
				public void focusLost(FocusEvent e) {
				}
			});

			magnifyLabel.addListener(SWT.MouseDown, new Listener(){ //fixed to bug# 99143
				public void handleEvent(Event event){
					setVKAlwaysOff();
					filterText.forceFocus();
				}
			});

			filterText.addFocusListener(new FocusListener() {
				public void focusGained(FocusEvent e) {
					setVKAlwaysOff();
				}
				public void focusLost(FocusEvent e) {
				}
			});

			
			keyListener = new Listener() {
				public void handleEvent(Event e) {
					if(e.widget != internalComposite && 
						e.widget != list &&
						e.widget != filterText) {
						if(!saveVKStatus) {
							md.setVKStatus(orgVKStatus);
							saveVKStatus = true;
						}
					}
				}
			};
			// restore VK Status when SortedList focus out
			display2.addFilter(SWT.FocusIn, keyListener);
			
			
			filterText.addKeyListener(new KeyListener(){
				public void keyPressed(KeyEvent e) {
					internal_processPressedKeyEvent(e);
				}
				public void keyReleased(KeyEvent e) {
				}
			});
			filterText.addModifyListener(new ModifyListener() {
				public void modifyText(ModifyEvent e) {
					removeListAll();
					Iterator listIterator = listItems.iterator();
					while(listIterator.hasNext()) {
						String stringToSearch = (String)(listIterator.next());
						if (stringToSearch.toUpperCase().indexOf(filterText.getText().toUpperCase()) >= 0) { //fix against bug#102029
							sortedList.internalAdd(stringToSearch);
						}
					}					
				}
			});
			
			hasFilter = true;
			
		} else {
			verticalLayout = new VerticalLayout(SWT.VERTICAL);
			verticalLayout.wrap = false;
			verticalLayout.pack = true;
			
			internalComposite.setLayout(verticalLayout);
			style = style & (~SWT.BORDER);
			list = new List(internalComposite, style);
			
			list.addKeyListener(new KeyListener(){

				public void keyPressed(KeyEvent e) {
					internal_processPressedKeyEvent(e);
				}

				public void keyReleased(KeyEvent e) {
				}


			});

		}		
		
		if ((SWT.UP & style) == SWT.UP) {
			updownStyle = SWT.UP;
		} else if ((SWT.DOWN & style) == SWT.DOWN) {
			updownStyle = SWT.DOWN;
		}			
		
		

		
		list.addSelectionListener(new SelectionListener() {

			public void widgetSelected(SelectionEvent e) {	
//				sortedList.forceFocus();	
				sortedList.internal_sendEvent(SWT.Selection);
							
			}

			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				sortedList.internal_sendEvent(SWT.DefaultSelection);
			}
		});
		
		list.addFocusListener(new FocusListener(){
			public void focusGained(FocusEvent e) {
				enableTraverse = false;
				sortedList.internal_sendEvent(SWT.FocusIn);
				
			}
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				sortedList.internal_sendEvent(SWT.FocusOut);
				
			}
		});
		
        parentComposite = hackComposite;
		
		//Sam: hope to reduce the memory leak
		hackStyle = 0;
		hackComposite = null;
	
	}
	
	protected void releaseWidget(){
		if (isDisposed()) return; //fix against bug# 100942
		
		if(filterText!=null){
			if(!filterText.isDisposed()){
				filterText.dispose();
			}
			filterText = null;
		}
		
		if(magnifyLabel!=null){
			if(!magnifyLabel.isDisposed()){
				magnifyLabel.dispose();
			}
			magnifyLabel = null;
		}
		
		if(stream!=null){
			stream = null;
		}
		
		if(md!=null){
			md = null;
		}
		if(verticalLayout!=null){
			verticalLayout = null;
		}
		if(horizontalLayout!=null){
			horizontalLayout = null;
		}
		
		if(bottomcomposite!=null){
			if(!bottomcomposite.isDisposed()){
				bottomcomposite.dispose();	
			}
			bottomcomposite = null;
		}
		
		if(listItems!=null){
			listItems = null;
		}
		
		if(list!=null){
			if(!list.isDisposed()){
				list.dispose();
			}
			list = null;
		}		
		
		
		if(internalComposite!=null){
			if(!internalComposite.isDisposed()){
				internalComposite.dispose();	
			}
			internalComposite = null;
		}
		
		removeInternalFilter();
		if(keyListener!=null){
			keyListener = null;
		}
		
		//Sam: can not dispose parent shell and composite
		if(parentComposite!=null){
				parentComposite = null;
		}
		
		
		sortedList = null;
		//Sam: I should put internal_handle = 0 here
		//otherwise, it will crash while executing 
		//OS.Widget_SetData(internal_handle, null); in Widget
		//since the internal_handle of it is equal with fComposite
		//and it has been set to 0 while disposing.
		//So, if we would like to call super.releaseWidget
		//we should set internal_handle =0 here
		internal_handle = 0;
		super.releaseWidget(); //fix against bug# 100942
		isDisposed = true;

	}
	
	protected void releaseHandle() {
		if(display2!=null){
			display2 = null;
		}
	}
	//we should overwrite the isDisposed() in SortedList 
	//since it will call checkWidget() --> if (isDisposed())
	//in Widget.java while calling super.releaseWidget(), 
	//then if we do not overwrite the isDisposed(), it will
	// return true if internal_handle = 0, however, since 
	//we set internal_handle = 0 before calling super.releaseWidget(), 
	//then it will throw error here. So, we should overwrite here to 
	//prevent this problem
	
	public boolean isDisposed() {
		return isDisposed;
	}
	
	protected void removeInternalFilter(){
		if(keyListener!=null){
			this.getDisplay().removeFilter(SWT.FocusIn, keyListener);
		}
	}
	
	private static Composite SaveStyle(Composite parent, int style, int filterStyle) {
		hackStyle = style;
		hackComposite = parent;
		hackfilterStyle = filterStyle;
		return parent;
	}
	
	public boolean forceFocus() {
		if((hackfilterStyle & SortedList.FILTER) == SortedList.FILTER) {
			setVKAlwaysOff();
			enableTraverse = false;
			return filterText.forceFocus();
		} else {
			return super.forceFocus();
		}
	}

	private void setVKAlwaysOff() {
		if(saveVKStatus) {
			orgVKStatus = Device.internal_vkstatus;
			saveVKStatus = false;
		}
		if(MobileDevice.VK_ALWAYS_OFF != Device.internal_vkstatus) {
			md.setVKStatus(MobileDevice.VK_ALWAYS_OFF);
		}
	}

	/**
	 * Adds the argument to the receiver's list of items.
	 * 
	 * @param item
	 *            text to be added to the list
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the item is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_ADDED - if the operation fails because
	 *                of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see SortedList#setItems(String[])
	 * @see SortedList#remove
	 * @see SortedList#removeAll()
	 */
	public void add(String item) {
		checkWidget();
		if (item == null) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		listItems.add(item);
		internalAdd(item);		
		
	}
	
	private void internalAdd(String item) {

		boolean exception = false;
		if (updownStyle ==0 ) {
			list.add(item);
			return;
		}
		try {			
			Integer.parseInt(item);
		} catch (NumberFormatException e) { //the add item is a alphabetic characters
			int totalCount = list.getItemCount();
			exception = true;
			if (totalCount == 0) {
				list.add(item);
				return;
			} else {		
				if (numericCount == totalCount) { //no alphabetic characters in SortedList, add it directly
					list.add(item);
					return;
				}

				//Find the proper position to insert item
				for (int i = numericCount; i<totalCount;i++) {
					if (updownStyle == SWT.UP) {
						if (item.compareTo(list.getItem(i)) < 0) {
							list.add(item,i);
							return;							
						} else continue;
					} else if (updownStyle == SWT.DOWN){
						if (item.compareTo(list.getItem(i)) > 0) {
							list.add(item,i);
							return;							
						} 							
					}
				}
				
				list.add(item);
				return;
				
			}
			
		} finally {
			
		}
		if (!exception) {
			int totalCount = list.getItemCount();
			if (totalCount == 0) {
				list.add(item);
				numericCount ++;
				return;
			}
			if (numericCount == 0) { //No numeric numbers in SortList, add item in the first index
				list.add(item,0);
				numericCount ++;
				return;
			}
			
			//Find the proper position to insert item
			
			for (int i = 0; i<numericCount;i++) {
				int list_i = Integer.valueOf(list.getItem(i)).intValue();
				int item_i = Integer.valueOf(item).intValue();
				if (updownStyle == SWT.UP) {
					
					if  (list_i >= item_i) {
						list.add(item,i);
						numericCount ++;
						return;
					}
				}
				if (updownStyle == SWT.DOWN) {
					if  (list_i <= item_i) {
						list.add(item,i);
						numericCount ++;
						return;
					}
				}
			}
			
			list.add(item,numericCount);
			numericCount ++;
			return;
			
		}			
	}

	/**
	 * Adds the listener to the collection of listeners who will be notified
	 * when the receiver's selection changes, by sending it one of the messages
	 * defined in the SelectionListener interface.
	 * <p>
	 * <code>widgetSelected</code> is called when the selection changes. <br>
	 * <code>widgetDefaultSelected</code> is typically called when selection
	 * is finalized.
	 * 
	 * @param listener
	 *            instance called when selection events occur
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_ADDED - if the operation fails because
	 *                of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see ListBox#removeSelectionListener
	 * @see SelectionListener
	 */
	public void addSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null)  SWT.error(SWT.ERROR_NULL_ARGUMENT);
		
		TypedListener typedListener = new TypedListener(listener);
		addListener(SWT.Selection, typedListener);
		addListener(SWT.DefaultSelection, typedListener);

	}

	/**
	 * Returns the prefered size of the receiver.
	 * <p>
	 * <b>Description copied from class: <code>Control</code> </b>
	 * <p>
	 * The preferred size of a control is the size that it would be best
	 * displayed at. The width hint and height hint arguments allow the caller
	 * to ask a control questions such as "Given a particular width, how high
	 * does the control need to be to show all of the contents?" To indicate
	 * that the caller does not wish to constrain a particular dimension, the
	 * constant SWT.DEFAULT is passed for the hint.
	 * <p>
	 * If the changed flag is true, it indicates that the receiver's contents
	 * have changed, therefore any caches that a layout manager containing the
	 * control may have been keeping need to be flushed. When the control is
	 * resized, the changed flag will be <code>false</code>, so layout
	 * manager caches can be retained.
	 * <p>
	 * <b>Overrides: </b> <code>computeSize</code> in class <b>
	 * <code>Control</code> </b>
	 * 
	 * @param wHint
	 *            the width hint (can be SWT.DEFAULT)
	 * @param hHint
	 *            the height hint (can be SWT.DEFAULT)
	 * @param changed
	 *            true if the control's contents have changed, and false
	 *            otherwise
	 * 
	 * @return the preferred size of the control
	 */
	public Point computeSize(int wHint, int hHint, boolean changed) {
		checkWidget();
			return internalComposite.computeSize(wHint,hHint,changed);
	}

	/**
	 * Returns the text of the item currently focused in the receiver, or
	 * <code>null</code> if no item has focus.
	 * <p>
	 * 
	 * @return the text of the item with focus
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 */
	public String getFocus() {
		checkWidget();
		return list.getItem(list.getFocusIndex());
		
	}

	/**
	 * Returns the height (in pixels) of the area which would be used to display
	 * one of the items in the tree.
	 * 
	 * @return height in pixels
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_HEIGHT - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public int getItemHeight() {
		checkWidget();
		return list.getItemHeight();
	}

	/**
	 * Returns an array of Strings of items that are currently selected in the
	 * receiver.
	 * 
	 * @return array of selected items
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_SELECTION - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see SortedList#getSelectionCount
	 */
	public String[] getSelection() {
		checkWidget();
		return list.getSelection();
	}

	/**
	 * Returns the number of items currently selected.
	 * 
	 * @return count of selected items
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_COUNT - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see SortedList#getSelection
	 */
	public int getSelectionCount() {
		checkWidget();
		return list.getSelectionCount();
	}

	/**
	 * Searches the receiver's list starting at the first item until an item is
	 * found that is equal to the argument, and removes that item from the list.
	 * 
	 * @param item
	 *            text of item to remove
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the string is not found
	 *                in the list</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see SortedList#add(String)
	 * @see SortedList#removeAll()
	 */
	public void remove(String item) {
		checkWidget();
		if (item == null){
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		
		Iterator listIterator = listItems.iterator();
		int index = 0;
		boolean exception = false;
		while(listIterator.hasNext()) {
			String stringToSearch = (String)(listIterator.next());
			if (item.compareTo(stringToSearch) == 0) {
				listItems.remove(index);
				try {			
					Integer.parseInt(item);
				} catch (NumberFormatException e) { //the add item is a alphabetic characters
					list.remove(item);
					return;
				} finally {
					
				}
				
				list.remove(item);
				numericCount --;
				return;
				
			}
			index ++;
		}		
		
		//Can't find item in list, throw ERROR_INVALID_ARGUMENT
		SWT.error(SWT.ERROR_INVALID_ARGUMENT);
	}

	/**
	 * Removes all of the items from the receiver.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see SortedList#add(String)
	 * @see SortedList#remove(String)
	 * @see SortedList#setItems(String[])
	 */
	public void removeAll() {
		checkWidget();
		numericCount = 0;
		listItems.clear();
		list.removeAll();
	}
	
	void removeListAll() {
		numericCount = 0;
		list.removeAll();
	}

	/**
	 * Removes the listener from the collection of listeners who are notified
	 * when the receiver's selection changes.
	 * 
	 * @param listener
	 *            instance called when selection events occur
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see SortedList#addSelectionListener
	 * @see SelectionListener
	 */
	public void removeSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null)  SWT.error(SWT.ERROR_NULL_ARGUMENT);

		removeListener(SWT.Selection, listener);	
		removeListener(SWT.DefaultSelection, listener);
	}

	/**
	 * Selects the first item that has text matching the given string. If the
	 * argument is <code>null</code>, the selection is cleared.
	 * 
	 * @param item
	 *            text of item to select
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the string is not found
	 *                in the list</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 */
	public void select(String item) {
		checkWidget();
		if (item == null) {
			list.deselectAll();
			return;
		}
		if (list.indexOf(item) == -1) { //can't find
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			return;
		}
		list.select(list.indexOf(item));
	}

	/**
	 * Sets the receiver's items to be the given array of items.
	 * 
	 * @param items
	 *            array of text strings to be shown in list
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string array is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_ADDED - if the operation fails because
	 *                of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see SortedList#add
	 */
	public void setItems(String[] items) {
		checkWidget();
		if (items == null) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		this.removeAll();
		for (int i=0;i<items.length;i++) {
			this.add(items[i]);
		}
	}

	/**
	 * Sets the receiver's selection to be the given array of items.
	 * 
	 * @param items
	 *            array of text strings to be selected in list
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string array is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see SortedList#select
	 */
	public void setSelection(String[] items) {
		checkWidget();
		list.setSelection(items);
	}

	/**
	 * Scrolls the list as necessary to show the selected items.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see SortedList#select
	 * @see SortedList#setSelection
	 */
	public void showSelection() {
		checkWidget();
		list.showSelection();
	}
	
	public void internal_createHandle(int index) {
		// List styles: SINGLE, MULTI
		// Scrollable styles: V_SCROLL, H_SCROLL
		// Control styles: LEFT_TO_RIGHT, RIGHT_TO_LEFT, BORDER (hint)
			if ((hackStyle & SWT.BORDER) == SWT.BORDER) {
				internalComposite = new Composite(hackComposite,SWT.BORDER);
			} else {
				internalComposite = new Composite(hackComposite,SWT.NO_TRIM);
			}
			internal_handle = internalComposite.internal_handle;
			hackComposite.internal_removeChild(internalComposite);

	}
	
	public void setBounds(int x, int y, int width, int height) {
		checkWidget();

		if (hasFilter) {
//			if ((OS.RotDetectDisplay_CheckOS() == OS.WIN32) && height >120) {
//				VerticalData rd = new VerticalData(width-8, height - 60);
//				list.setLayoutData(rd);
//				rd = new VerticalData(width-8, 55);
//				bottomcomposite.setLayoutData(rd);
//				rd = new VerticalData(width-40,20);
//				filterText.setLayoutData(rd);
//			} else {
				VerticalData rd = new VerticalData(width-8, height - 40);
				list.setLayoutData(rd);
				rd = new VerticalData(width-8, 35);
				bottomcomposite.setLayoutData(rd);
				rd = new VerticalData(width-40,20);
				filterText.setLayoutData(rd);
				
//			}
			
			internalComposite.setBounds(x,y,width,height);
			internalComposite.layout();
		} else {
			VerticalData rd = new VerticalData(width, height);
			list.setLayoutData(rd);
			internalComposite.setBounds(x,y,width,height);
			internalComposite.layout();
		}
	}
	
	public void setBounds(Rectangle rect) {
		checkWidget();
		if (rect == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		this.setBounds(rect.x, rect.y, rect.width, rect.height);
	}
	
	public void setLocation(int x, int y) {
		checkWidget();
		internalComposite.setLocation(x,y);
	}	
	
	public void setLocation(Point location) {
		checkWidget();
		if (location == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		setLocation(location.x,location.y);
		//internalComposite.setLocation(location.x, location.y);
	}
	
	public void setSize(int width, int height) {
		checkWidget();
		
		if (hasFilter) {
			VerticalData rd = new VerticalData(width-10, height - 32);
			list.setLayoutData(rd);
			rd = new VerticalData(width-10, 20);
			bottomcomposite.setLayoutData(rd);
			rd = new VerticalData(width-20,20);
			filterText.setLayoutData(rd);
			internalComposite.setSize(width,height);
		} else {
			VerticalData rd = new VerticalData(width-10, height - 10);
			list.setLayoutData(rd);
			internalComposite.setSize(width,height);
		}
		
		//internalComposite.layout();
	}
	
	public void pack(){
		super.pack();
		if(hasFilter){
			Point p = list.computeSize(-1, -1);
			Point p2 = bottomcomposite.computeSize(p.x, -1);
			internalComposite.setSize(internalComposite.computeSize(p.x, p.y+p2.y));
			list.pack();
			bottomcomposite.setBounds(0, p.y+2, p2.x, p2.y);
			
		} else {
		
			Point p = list.computeSize(-1, -1);
			internalComposite.setSize(internalComposite.computeSize(p.x, p.y));
			list.pack();
		}
	}
	
	public void setSize(Point size) {
		checkWidget();
		if (size == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		this.setSize(size.x, size.y);
		
	}
	
	public Rectangle getBounds() {
		checkWidget();
			return internalComposite.getBounds(); 
	}
	
	public Point getLocation() {
		checkWidget();
			return internalComposite.getLocation();
	}
	
	public Point getSize() {
		checkWidget();
			return internalComposite.getSize();
	}
	
	public boolean setFocus(){
		this.enableTraverse = false;
		return list.forceFocus();		
	}	

	protected Control getchild(){
		return list;
	}
	
	public void setFont(Font font){
	    list.setFont(font);		
	}	
	
	public Font getFont() {
		return list.getFont();
	}
	
	public boolean isFocusControl() {
		checkWidget();
		return list.isFocusControl();
	}
	
	public boolean isEnableTraverse() {
		return this.enableTraverse;
	}
	
	public boolean allowTraverseByArrowKey(Event event) {
		checkWidget();
		if(enableTraverse)
			return true;
		return list.allowTraverseByArrowKey(event);
	}

	protected boolean traverse(Event event) {
		sendEvent(SWT.Traverse, event);
		if (isDisposed()) return false;
		if (!event.doit) return false;
		if(allowTraverseByArrowKey(event)) {
			return traverseByArrowKey(event);
		}
		return super.traverse(event);
	}

	void internal_processPressedKeyEvent(KeyEvent e) {
		Event event = new Event();
		event.doit = false;
		event.keyCode = e.keyCode;
		SortedList thisSortedList = this;
		if(SWT.ARROW_UP == e.keyCode) {
			event.widget = e.widget;
			event.detail = SWT.TRAVERSE_ARROW_PREVIOUS;
			if(allowTraverseByArrowKey(event)) {
				event.widget = this;
				event.doit = true;
				traverse(event);
				e.doit = event.doit;
			} else {
				if(e.widget == this.filterText) {
					int idx = list.getSelectionIndex();
					if(idx > 0) {
						list.setSelection(idx-1);
						thisSortedList.internal_sendEvent(SWT.Selection);
					} else {
						if(Platform.isSmartPhone()) {
							list.setSelection(list.getItemCount()-1);
							thisSortedList.internal_sendEvent(SWT.Selection);
						}
					}
				}
			}
		} else if(SWT.ARROW_DOWN == e.keyCode) {
			event.widget = e.widget;
			event.detail = SWT.TRAVERSE_ARROW_NEXT;
			if(allowTraverseByArrowKey(event)) {
				event.widget = this;
				event.doit = true;
				traverse(event);
				e.doit = false;
			} else {
				if(e.widget == this.filterText) {
					int count = list.getItemCount();
					int idx = list.getSelectionIndex();
					if(idx < count - 1) {
						list.setSelection(idx+1);
						thisSortedList.internal_sendEvent(SWT.Selection);
					} else {
						if(Platform.isSmartPhone()) {
							list.setSelection(0);
							thisSortedList.internal_sendEvent(SWT.Selection);
						}
					}					
				}
			}
		} else if(SWT.ARROW_LEFT == e.keyCode) {
			event.widget = e.widget;
			event.detail = SWT.TRAVERSE_ARROW_PREVIOUS;
			if(allowTraverseByArrowKey(event)) {
				event.widget = this;
				event.doit = true;
				traverse(event);
				e.doit = false;
			}
		} else if(SWT.ARROW_RIGHT == e.keyCode) {
			event.widget = e.widget;
			event.detail = SWT.TRAVERSE_ARROW_NEXT;
			if(allowTraverseByArrowKey(event)) {
				event.widget = this;
				event.doit = true;
				traverse(event);
				e.doit = false;
			}
		} else if(SWT.CR == e.keyCode) {
			thisSortedList.internal_sendEvent(SWT.DefaultSelection);	
		} else if (SWT.TAB == e.keyCode) {
			if(e.stateMask == SWT.SHIFT){
				traverse(SWT.TRAVERSE_TAB_PREVIOUS);
			} else {
				traverse(SWT.TRAVERSE_TAB_NEXT);
			}
		}
	}
	
	
}

final class VerticalLayout extends Layout {
	public int type = SWT.HORIZONTAL;
 	public int marginWidth = 0;
 	public int marginHeight = 0;
	public int spacing = 3;
	public boolean wrap = true;
	public boolean pack = true;
	public boolean fill = false;
	public boolean justify = false;
//	public int marginLeft = 3;
//	public int marginTop = 3;
//	public int marginRight = 3;
//	public int marginBottom = 3;
	public int marginLeft = 0;
	public int marginTop = 0;
	public int marginRight = 0;
	public int marginBottom = 0;
	public int marginBorder = 2;
public VerticalLayout () {
}

public VerticalLayout (int type) {
	this.type = type;
}

protected Point computeSize (Composite composite, int wHint, int hHint, boolean flushCache) {
	Point extent;
	if (type == SWT.HORIZONTAL) {
		extent = layoutHorizontal (composite, false, (wHint != SWT.DEFAULT) && wrap, wHint, flushCache);
	} else {
		extent = layoutVertical (composite, false, (hHint != SWT.DEFAULT) && wrap, hHint, flushCache);
	}
	if (wHint != SWT.DEFAULT) extent.x = wHint;
	if (hHint != SWT.DEFAULT) extent.y = hHint;
	return extent;
}

Point computeSize (Control control, boolean flushCache) {
	int wHint = SWT.DEFAULT, hHint = SWT.DEFAULT;
	VerticalData data = (VerticalData) control.getLayoutData ();
	if (data != null) {
		wHint = data.width;
		hHint = data.height;
	}
	return control.computeSize (wHint, hHint, flushCache);
}

protected boolean flushCache (Control control) {
	return true;
}

String getName () {
	String string = getClass ().getName ();
	int index = string.lastIndexOf ('.');
	if (index == -1) return string;
	return string.substring (index + 1, string.length ());
}

protected void layout (Composite composite, boolean flushCache) {
	Rectangle clientArea = composite.getClientArea ();
	if (type == SWT.HORIZONTAL) {
		layoutHorizontal (composite, true, wrap, clientArea.width, flushCache);
	} else {
		layoutVertical (composite, true, wrap, clientArea.height, flushCache);
	}
}

Point layoutHorizontal (Composite composite, boolean move, boolean wrap, int width, boolean flushCache) {
	Control [] children = composite.getChildren ();

	int count = children.length;
	int childWidth = 0, childHeight = 0, maxHeight = 0;
	if (!pack) {
		for (int i=0; i<count; i++) {
			Control child = children [i];
			Point size = computeSize (child, flushCache);
			childWidth = Math.max (childWidth, size.x);
			childHeight = Math.max (childHeight, size.y);
		}
		maxHeight = childHeight;
	}
	int clientX = 0, clientY = 0;
	if (move) {
		Rectangle rect = composite.getClientArea ();
		clientX = rect.x;
		clientY = rect.y;
	}
	int [] wraps = null;
	boolean wrapped = false;
	Rectangle [] bounds = null;
	if (move && (justify || fill)) {
		bounds = new Rectangle [count];
		wraps = new int [count];
	}
	int maxX = 0, x = marginLeft + marginWidth, y = marginTop + marginHeight;
	for (int i=0; i<count; i++) {
		Control child = children [i];
		if (pack) {
			Point size = computeSize (child, flushCache);
			childWidth = size.x;
			childHeight = size.y;
		}
		if (wrap && (i != 0) && (x + childWidth > width)) {
			wrapped = true;
			if (move && (justify || fill)) wraps [i - 1] = maxHeight;
			x = marginLeft + marginWidth;
			y += spacing + maxHeight;
			if (pack) maxHeight = 0;
		}
		if (pack || fill) {
			maxHeight = Math.max (maxHeight, childHeight);
		}
		if (move) {
			int childX = x + clientX, childY = y + clientY;
			if (justify || fill) {
				bounds [i] = new Rectangle (childX, childY, childWidth, childHeight);
			} else {
				child.setBounds (childX, childY, childWidth, childHeight);
			}
		}
		x += spacing + childWidth;
		maxX = Math.max (maxX, x);
	}
	maxX = Math.max (clientX + marginLeft + marginWidth, maxX - spacing);
	if (!wrapped) maxX += marginRight + marginWidth;
	if (move && (justify || fill)) {
		int space = 0, margin = 0;
		if (!wrapped) {
			space = Math.max (0, (width - maxX) / (count + 1));
			margin = Math.max (0, ((width - maxX) % (count + 1)) / 2);
		} else {
			if (fill || justify) {
				int last = 0;
				if (count > 0) wraps [count - 1] = maxHeight;
				for (int i=0; i<count; i++) {
					if (wraps [i] != 0) {
						int wrapCount = i - last + 1;
						if (justify) {
							int wrapX = 0;
							for (int j=last; j<=i; j++) {
								wrapX += bounds [j].width + spacing;
							}
							space = Math.max (0, (width - wrapX) / (wrapCount + 1));
							margin = Math.max (0, ((width - wrapX) % (wrapCount + 1)) / 2);
						}
						for (int j=last; j<=i; j++) {
							if (justify) bounds [j].x += (space * (j - last + 1)) + margin;
							if (fill) bounds [j].height = wraps [i];
						}
						last = i + 1;
					}
				}
			}
		}
		for (int i=0; i<count; i++) {
			if (!wrapped) {
				if (justify) bounds [i].x += (space * (i + 1)) + margin;
				if (fill) bounds [i].height = maxHeight;
			}
			children [i].setBounds (bounds [i]);
		}
	}
	return new Point (maxX, y + maxHeight + marginBottom + marginHeight);
}

Point layoutVertical (Composite composite, boolean move, boolean wrap, int height, boolean flushCache) {
	Control [] children = composite.getChildren ();
	
	int count = children.length;
	int childWidth = 0, childHeight = 0, maxWidth = 0;
	if (!pack) {
		for (int i=0; i<count; i++) {
			Control child = children [i];
			Point size = computeSize (child, flushCache);
			childWidth = Math.max (childWidth, size.x);
			childHeight = Math.max (childHeight, size.y);
		}
		maxWidth = childWidth;
	}
	int clientX = 0, clientY = 0;
	if (move) {
		Rectangle rect = composite.getClientArea ();
		clientX = rect.x;
		clientY = rect.y;
	}
	int [] wraps = null;
	boolean wrapped = false;
	Rectangle [] bounds = null;
	if (move && (justify || fill)) {
		bounds = new Rectangle [count];
		wraps = new int [count];
	}
	int maxY = 0, x = marginLeft + marginWidth, y = marginTop + marginHeight;
	for (int i=0; i<count; i++) {
		Control child = children [i];
		if (pack) {
			Point size = computeSize (child, flushCache);
			childWidth = size.x;
			childHeight = size.y;
		}
		if (wrap && (i != 0) && (y + childHeight > height)) {
			wrapped = true;
			if (move && (justify || fill)) wraps [i - 1] = maxWidth;
			x += spacing + maxWidth;
			y = marginTop + marginHeight;
			if (pack) maxWidth = 0;
		}
		if (pack || fill) {
			maxWidth = Math.max (maxWidth, childWidth);
		}
		if (move) {
			int childX = x + clientX, childY = y + clientY;
			if (justify || fill) {
				bounds [i] = new Rectangle (childX, childY, childWidth, childHeight);
			} else {
				child.setBounds (childX, childY, childWidth-marginBorder, childHeight-marginBorder);
			}
		}
		y += spacing + childHeight;
		maxY = Math.max (maxY, y);
	}
	maxY = Math.max (clientY + marginTop + marginHeight, maxY - spacing);
	if (!wrapped) maxY += marginBottom + marginHeight;
	if (move && (justify || fill)) {
		int space = 0, margin = 0;
		if (!wrapped) {
			space = Math.max (0, (height - maxY) / (count + 1));
			margin = Math.max (0, ((height - maxY) % (count + 1)) / 2);
		} else {
			if (fill || justify) {
				int last = 0;
				if (count > 0) wraps [count - 1] = maxWidth;
				for (int i=0; i<count; i++) {
					if (wraps [i] != 0) {
						int wrapCount = i - last + 1;
						if (justify) {
							int wrapY = 0;
							for (int j=last; j<=i; j++) {
								wrapY += bounds [j].height + spacing;
							}
							space = Math.max (0, (height - wrapY) / (wrapCount + 1));
							margin = Math.max (0, ((height - wrapY) % (wrapCount + 1)) / 2);
						}
						for (int j=last; j<=i; j++) {
							if (justify) bounds [j].y += (space * (j - last + 1)) + margin;
							if (fill) bounds [j].width = wraps [i];
						}
						last = i + 1;
					}
				}
			}
		}
		for (int i=0; i<count; i++) {
			if (!wrapped) {
				if (justify) bounds [i].y += (space * (i + 1)) + margin;
				if (fill) bounds [i].width = maxWidth;
			}
			children [i].setBounds (bounds [i]);
		}
	}
	return new Point (x + maxWidth + marginRight + marginWidth, maxY);
}

public String toString () {
 	String string = getName ()+" {";
 	string += "type="+((type != SWT.HORIZONTAL) ? "SWT.VERTICAL" : "SWT.HORIZONTAL")+" ";
 	if (marginWidth != 0) string += "marginWidth="+marginWidth+" ";
 	if (marginHeight != 0) string += "marginHeight="+marginHeight+" ";
 	if (marginLeft != 0) string += "marginLeft="+marginLeft+" ";
 	if (marginTop != 0) string += "marginTop="+marginTop+" ";
 	if (marginRight != 0) string += "marginRight="+marginRight+" ";
 	if (marginBottom != 0) string += "marginBottom="+marginBottom+" ";
 	if (spacing != 0) string += "spacing="+spacing+" ";
 	string += "wrap="+wrap+" ";
	string += "pack="+pack+" ";
	string += "fill="+fill+" ";
	string += "justify="+justify+" ";
	string = string.trim();
	string += "}";
 	return string;
}
}


final class VerticalData {
	public int width = SWT.DEFAULT;
	public int height = SWT.DEFAULT;
	
public VerticalData () {
}

public VerticalData (int width, int height) {
	this.width = width;
	this.height = height;
}

public VerticalData (Point point) {
	this (point.x, point.y);
}

String getName () {
	String string = getClass ().getName ();
	int index = string.lastIndexOf ('.');
	if (index == -1) return string;
	return string.substring (index + 1, string.length ());
}

public String toString () {
	String string = getName ()+" {";
	if (width != SWT.DEFAULT) string += "width="+width+" ";
	if (height != SWT.DEFAULT) string += "height="+height+" ";
	string = string.trim();
	string += "}";
	return string;
}


}