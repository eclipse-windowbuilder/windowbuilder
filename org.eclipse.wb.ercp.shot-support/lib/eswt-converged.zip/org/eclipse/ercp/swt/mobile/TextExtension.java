/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import java.util.Locale;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import com.ibm.ugl.eswt.OS;


/**
 * This class contains methods for extending the functionality of the Text
 * control. The functionality is specific to non-full keyboard devices.
 * Applications can request certain text input modes when a TextExtension
 * control gets focused. The effective input mode takes into account two style
 * aspects. One aspect is based on the content semantics. The other is based on
 * the content character set.
 * </p>
 * <p>
 * The editing behavior and appearance are otherwise identical to the
 * <code>Text</code> control. The differences in TextExtension are to ease the
 * possible switch of initial input modes, such as to enable/disable predictive
 * input, changing initial casing styles and particular input modes of some
 * languages. The initial input mode does not persist if changed by the end-user
 * during editing. Whether the mode will be persist during the application
 * life-cycle is implementation-dependent.
 * </p>
 * 
 * <dl>
 * <dt><b>TextExtension Styles: </b></dt>
 * <dl>
 * <dt><b>Content Styles (exclusive): </b></dt>
 * <dd>EMAILADDRESS: an e-mail address</dd>
 * <dd>URL: a web address</dd>
 * <p>
 * These are different semantic styles but basically all characters are allowed
 * in each style. The implementation may use the content style to implement a
 * device-dependent UI for assisting user input, for example, providing a UI to
 * access the device's PIM or browser bookmarks, if available.
 * </p>
 * <dt><b>Input Modifier Styles: </b></dt>
 * <dd>NON_PREDICTIVE: hint for turning off possible predictive text input. By
 * default any predictive input facilities should be turned on if available
 * </dd>
 * <dd>LATIN_INPUT_ONLY: force that locale specific input modes should not be
 * available. This is used in some situations when only Latin characters are
 * allowed, for example, password text field</dd>
 * </dl>
 * </dl>
 * <dl>
 * <dt><b>Casing Modifiers (exclusive): </b> Casing modifiers define which case modes
 * are available for input. Only one casing modifier may be specified.</dt>
 * <dd>UPPERCASE: The capital letters of a typeface</dd>
 * <dd>LOWERCASE: The small letters of a typeface, as opposed to the capital
 * letters, or uppercase letters</dd>
 * <dd>TEXTCASE: The first word of a sentence is capitalized. Note:
 * Determination of where a sentence ends is implementation-dependent.</dd>
 * <dd>TITLECASE: Every word is capitalized.</dd>
 * </dl>
 * <dl>
 * <dt><b>Events: </b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */
public class TextExtension extends org.eclipse.swt.widgets.Text {

	/**
	 * E-mail address.
	 */
	public static final int EMAILADDRESS = 1 << 1;

	/**
	 * Uniform Resource Locator.
	 */
	public static final int URL = 1 << 2;

	/**
	 * Hint for turning off predictive text input. By default any predictive
	 * input facilities should be turned on if available.
	 */
	public static final int NON_PREDICTIVE = 1 << 3;

	/**
	 * Force that locale specific input modes should not be available.
	 */
	public static final int LATIN_INPUT_ONLY = 1 << 4;

	/**
	 * The capital letters of a typeface.
	 */
	public static final int UPPERCASE = 1;

	/**
	 * The lower case letters of a typeface.
	 */
	public static final int LOWERCASE = 2;

	/**
	 * The first word of each sentence is capitalized.
	 */
	public static final int TEXTCASE = 3;

	/**
	 * Every word is capitalized.
	 */
	public static final int TITLECASE = 4;

    //	Global variable
	private String[] HistorialString = new String[10];       //Input record 
	private int number = 0;                   //HistorialString index
	private boolean multi_line = true;        //Multi or Single line   
    private boolean change_line = false;      //change to other line or not
    private String previous_s = "";           //recoreded string
    private boolean match = false;            //the result of comparing two strings
    private String typed_string ="";          //the string that has been typed 
    private char typed_char;                  //present character that a user type. 
	private boolean DisableMode = false;      //check if the casingModifier mode is opened or not
	Locale locale;
    /**
	 * Constructs a new instance of <code>Text</code> class when specific
	 * styles are not used.
	 * <p>
	 * The <code>style</code> value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. Style bits are also inherited from superclasses.
	 * </p>
	 * 
	 * @param parent
	 *            a composite control which will be the parent of the new
	 *            instance (cannot be null)
	 * @param style
	 *            the style of control to construct
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * 
	 * @see SWT#SINGLE
	 * @see SWT#MULTI
	 * @see SWT#READ_ONLY
	 * @see SWT#WRAP
	 * @see org.eclipse.swt.widgets.Text#Text(Composite, int)
	 */
	public TextExtension(Composite parent, int style) {
		super(parent, style);
		if (parent == null)
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		
		if (((style & SWT.SINGLE) != 0) && ((style & SWT.MULTI) != 0))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		locale = Locale.getDefault();
		
		if ((style & SWT.MULTI) == 0) {   //check whether Multiline is supported or not
			content_record();	
			multi_line = false;
		}	
	}

	/**
	 * Constructs a new instance of this class given its parent, a style value
	 * describing behaviour and appearance, and an additional style specifying
	 * the text types defined above.
	 * <p>
	 * The <code>style</code> value is either one of the style constants defined 
	 * in class <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. Style bits are also inherited from superclasses.
	 * </p>
	 * <p>
	 * The <code>extensionStyle</code> value is a <em>bitwise OR</em> 'ing of 
	 * EMAILADDRESS, URL, NON_PREDICTIVE, and LATIN_INPUT_ONLY. EMAILADDRESS and 
	 * URL may not be both specified. The <code>extensionStyle</code> value is ignored 
	 * when <code>SWT.READ_ONLY</code> is specified in the <code>style</code> value.
	 * </p>
	 * 
	 * @param parent
	 *            a composite control which is the parent of the new instance
	 *            (cannot be null)
	 * @param style
	 *            the style of control to construct
	 * @param extensionStyle
	 *            the TextExtension specific style.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if either the style or the
	 *                extensionStyle is invalid</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * @see SWT#SINGLE
	 * @see SWT#MULTI
	 * @see SWT#READ_ONLY
	 * @see SWT#WRAP
	 * @see org.eclipse.swt.widgets.Text#Text(Composite, int)
	 */
	public TextExtension(Composite parent, int style, int extensionStyle) {
		super(parent, style);
		if (parent == null)
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if (((style & SWT.SINGLE) != 0) && ((style & SWT.MULTI) != 0))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		init();
		locale = Locale.getDefault();
		check_typeStyle(style,extensionStyle);	
	}

	//initial String value
	private void init ()             
	{
		for(int i=0; i <10; i++) {
			HistorialString[i]= null;
		}
	}

	//check typeStyle argument EMAILADDRESS, URL, LATIN_INPUT_ONLY, or NON_PREDICTIVE
    private void check_typeStyle(int style, int typestyle) {
        if((typestyle & EMAILADDRESS) != 0  && (typestyle & URL) != 0 )         		
        	     SWT.error(SWT.ERROR_INVALID_ARGUMENT);
        
        if ((typestyle & ~(EMAILADDRESS | URL | LATIN_INPUT_ONLY | NON_PREDICTIVE)) != 0)
        		 SWT.error(SWT.ERROR_INVALID_ARGUMENT);
        
    	if ((style & SWT.MULTI) != 0) {              //multiline don't support predictive
        	typestyle |= NON_PREDICTIVE;
        }
    	
    	
    	if ( (typestyle & EMAILADDRESS) != 0) {                 //Emailaddress type
    		setText("test@ibm.com");
    		previous_s = "test@ibm.com";
    		com.ibm.ugl.eswt.OS.AbstractTextComponent_SetCaretPosition(internal_handle,0);
    		setSelection(0,getText().length());
    	}else {
    		if( (typestyle & URL) != 0) {                       //URL type
    		 setText("http://");
    		 previous_s = "http://";
    		 com.ibm.ugl.eswt.OS.AbstractTextComponent_SetCaretPosition(internal_handle,7);
    		}
    	}
    	
    	if ((typestyle & LATIN_INPUT_ONLY) == LATIN_INPUT_ONLY) {               //LATIN_INPUT_ONLY type    
    	 predictive();
    	 this.addModifyListener(new ModifyListener() {
			public void modifyText (ModifyEvent e) {
				TextExtension t = (TextExtension)e.widget;
				int string_number = t.getCharCount();
				String s = t.getText();
				byte[] charArray = s.getBytes();                     //Get bytes of strings 
				byte[] p_charArray;
				if (match == true)
					previous_s = typed_string;	
				p_charArray = previous_s.getBytes();         
				
				if (charArray.length == string_number)  //Double bytes unicode character is not allowed to type               
				{
					previous_s = getText();					
				}
				else
				{
					 setText(previous_s);	 	
					 OS.AbstractTextComponent_SetCaretPosition(internal_handle,previous_s.length());
				}
			}
    	 });
    	 
   	    }
    	
    	if ( (typestyle & NON_PREDICTIVE) == 0) {                        //If predictive works
    		content_record();
    		predictive();
    		multi_line = false;    
    	}
   }
    
//  Check backspace,enter, right, up, down and left key to be typed or not.
	private boolean check_keydown(int keycode)
	{
		if (keycode == SWT.BS || keycode == SWT.ARROW_RIGHT || keycode == SWT.ARROW_LEFT || keycode == SWT.ARROW_UP || keycode ==SWT.ARROW_DOWN)
			return true;
		if (keycode == SWT.CR )
			return true;
		return false;
	}
	
	//Recording
	private void record(String content)
	{
			 number%=10;
			 HistorialString[number] = content;
			 //System.out.println(number+ " " +HistorialString[number]);
			 number++;			
	}
	
	//Recording historical text
	private void content_record() {
		this.addListener(SWT.KeyDown, new Listener() {
			public void handleEvent(Event event) {
				if( event.keyCode == SWT.CR) {
					record(getText());
					return;
		 		}
			}
		});
	}
	
	//Predictive function
	private void predictive() {
		this.addListener(SWT.KeyUp, new Listener() {                 
			public void handleEvent(Event event) {
    			int Caretposition= getCaretPosition();       //get current caret position
				int temp_number = 0;                         
				String string = getText();                   //current string in this control
				match =false;
				
				//check historical recorded string
				while (HistorialString[temp_number] != null)
				{
				 int end = Math.min(Caretposition, HistorialString[temp_number].length());  //rematch until end position 
				 
				 if(Caretposition == 0)
				  match = false;
				 else
				  match = string.regionMatches(0,HistorialString[temp_number],0,end); //rematch regions of two strings
				 //If match, show it in textfield
                 if(match) {
                 	typed_string = string.substring(0, Caretposition);
                 	if ( HistorialString[temp_number].length() >=  Caretposition && !(check_keydown(event.keyCode))) {
                     
                 	 insert(HistorialString[temp_number].substring(Caretposition, HistorialString[temp_number].length()));
                 	 com.ibm.ugl.eswt.OS.AbstractTextComponent_SetCaretPosition(internal_handle,Caretposition);
                 	 if (Caretposition == 0)
                 	  setSelection(Caretposition+1,HistorialString[temp_number].length());
                 	 else
                 	 	setSelection(Caretposition,HistorialString[temp_number].length());
                 	 //System.out.println("OriginalText  "+ string+" Caret "+Caretposition+" HistoryText "+ HistorialString[temp_number]);
                 	 break;
                 	}
                 }
                 	
                 temp_number++; 
                 
                 if(temp_number >= 10)                	
                  break;
				}  
			
	          }
		});
	}
	

	
	/**
	 * Hints to the implementation as to the input mode that should be used when
	 * the user initiates editing of this control.
	 * 
	 * <h3>Input mode string format</h3>
	 * <p>
	 * The initial input mode is specified as a string and can be null. A
	 * "Unicode character block" may be specified by adding the prefix "UCB_" to
	 * the names of Unicode character blocks as defined in the J2SE class
	 * <code>java.lang.Character.UnicodeBlock</code>. Any Unicode character
	 * block can be named in this fashion. For convenience, the most common
	 * Unicode character blocks are listed below.
	 * </p>
	 * <blockquote><code>
	 * UCB_BASIC_LATIN<br>UCB_GREEK<br>UCB_CYRILLIC<br>UCB_ARMENIAN<br>UCB_HEBREW<br>
	 * UCB_ARABIC<br>UCB_DEVANAGARI<br>UCB_BENGALI<br>UCB_THAI<br>UCB_HIRAGANA<br>UCB_KATAKANA<br>
	 * UCB_HANGUL_SYLLABLES<br></code> </blockquote>
	 * 
	 * <p>
	 * An "Input subset" may be specified by adding the prefix "IS_" to the name
	 * of input subsets as defined by the J2SE class
	 * <code>java.awt.im.InputSubset</code>. Any defined input subset can be
	 * used. For convenience, the names of the currently defined input subsets
	 * are listed below.
	 * </p>
	 * <blockquote><code>
	 * IS_FULLWIDTH_DIGITS<BR>IS_FULLWIDTH_LATIN<BR>IS_HALFWIDTH_KATAKANA<BR>IS_HANJA<br>
	 * IS_KANJI<BR>IS_LATIN<BR>IS_LATIN_DIGITS<BR>IS_SIMPLIFIED_HANZI<BR>IS_TRADITIONAL_HANZI
	 * </code> </blockquote>
	 * <p>
	 * Note: Implementations need not compile in support for all the strings
	 * listed above. Instead, they need only to compile in the strings that name
	 * Unicode character subsets that they support. If the subset name passed by
	 * the application is not known by the implementation, the request is
	 * gracefully ignored, and a default input mode based on current locale
	 * configuration is used.
	 * </p>
	 * 
	 * @param mode
	 *            a string naming a Unicode character block, input subset, or
	 *            null
	 * 
	 * @param casingModifier
	 *            an int value. Must be one of UPPERCASE, LOWERCASE, TEXTCASE or
	 *            TITLECASE.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the casingModifer is not
	 *                one of UPPERCASE, LOWERCASE, TEXTCASE or TITLECASE</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */

	public void setInitialInputMode(int casingModifier, String mode) {
		checkWidget();
		//Check if casingModifier is out of bound of the four type.
		if((casingModifier != LOWERCASE) && (casingModifier != UPPERCASE) && (casingModifier != TEXTCASE) && (casingModifier != TITLECASE))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);

//		if ((casingModifier & LOWERCASE) == LOWERCASE && ((casingModifier | LOWERCASE) != LOWERCASE) )	
//			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
//		else if ((casingModifier & UPPERCASE) == UPPERCASE && (casingModifier | UPPERCASE) != UPPERCASE)
//			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
//		else if ((casingModifier & TEXTCASE) == TEXTCASE && (casingModifier | TEXTCASE) != TEXTCASE)
//			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
//		else if ((casingModifier & TEXTCASE ) == TITLECASE && (casingModifier | TITLECASE) != TITLECASE)
//			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		
		
		//check casingModifier argument,
		//If the key value matches the restriction of the casingModifier argument, the key is valid.
		//if not, dispose the typed operation.
		switch (casingModifier) {
		
		case LOWERCASE:
			DisableMode = false;
			this.addListener(SWT.KeyDown, new Listener() {           //Dectecting typed keys. If it violates the definition of LOWERCASE, disabling this typring. 
				public void handleEvent(Event event) {
					if (event.keyCode == SWT.BS || event.keyCode == SWT.SHIFT)         //If backspace or shift key is typed, disabling this mode.
					 DisableMode = true;
					if (DisableMode == false)
					{
					 typed_char = event.character;
					 if(check_allowedcase(typed_char) && !check_keydown(event.keyCode)) {
					  event.doit = false;   // cancel operation.
					  String textString = String.valueOf(typed_char).toLowerCase(locale); //Dectecting typed keys. Changing string to match LOWERCASE.
	                  insert(textString);	
					  return;
					 }
					}				 
				}
			});		
		    break;
		case UPPERCASE:                                     
			DisableMode = false;
			this.addListener(SWT.KeyDown, new Listener() {   //Dectecting typed keys. If it violates the definition of UPPERCASE, disabling this typring. 
				public void handleEvent(Event event) {
					if (event.keyCode == SWT.BS || event.keyCode == SWT.SHIFT)
					 DisableMode = true;
					if (DisableMode == false)
					{
					 typed_char = event.character;
					 if(check_allowedcase(typed_char) && !check_keydown(event.keyCode)) {
					  event.doit = false;   // cancel operation.
					  String textString = String.valueOf(typed_char).toUpperCase(locale);    //Dectecting typed keys. Changing string to match UPPERCASE.
	                  insert(textString);	
					  return;
					 }
					}				 
				}
			});	
		break;	
		case TEXTCASE:
			 DisableMode = false;
				this.addListener(SWT.KeyDown, new Listener() {   //Dectecting typed keys. If it violates the definition of TEXTCASE, disabling this typring. 
					public void handleEvent(Event event) {
						if (event.keyCode == SWT.BS || event.keyCode == SWT.SHIFT)
						 DisableMode = true;
						if (DisableMode == false)
						{
						 typed_char = event.character;
							int Caretposition= getCaretPosition();
							String string = getText();
							string = string.concat(String.valueOf(typed_char));
							 if(Caretposition-1 < 0) {
							 	if(!(check_textcase(event.character,string, Caretposition-1, event.keyCode))) {
							    	if(check_allowedcase(typed_char) && !check_keydown(event.keyCode)) {
							 	 	 event.doit = false;   // cancel operation.
							 	 	 String textString = String.valueOf(typed_char).toUpperCase(locale);   //Dectecting typed keys. If it violates the definition of TEXTCASE, changing string to match that.
				                     insert(textString);   //insert modified string
						 		 	 return;
							   	}
							     }
							   }
							 else {			 	
							 	if(!(check_textcase(event.character,string, Caretposition-1, event.keyCode))) {
							    	if(check_allowedcase(typed_char) && !check_keydown(event.keyCode)) {
							        	event.doit = false;   // cancel operation.
							    	    String textString = String.valueOf(typed_char).toUpperCase(locale); //Dectecting typed keys. If it violates the definition of TEXTCASE, changing string to match that.
				                        insert(textString);	    
				                        if(change_line == true)    
					                     change_line = false;
						 		 	return;
							    	}
							     }
							 }   
						}				 
					}
				});
	
		break;
		case TITLECASE:			 
			 DisableMode = false;
				this.addListener(SWT.KeyDown, new Listener() {    //Dectecting typed keys. If it violates the definition of TITLECASE, disabling this typring. 
					public void handleEvent(Event event) {
						if (event.keyCode == SWT.BS || event.keyCode == SWT.SHIFT)
						 DisableMode = true;
						if (DisableMode == false)
						{
						 typed_char = event.character;
							int Caretposition= getCaretPosition();
							String string = getText();
							string = string.concat(String.valueOf(typed_char));
							 if(Caretposition-1 < 0) {
							   if(!(check_titlecase(event.character, ' ', event.keyCode))) {
							   	if(check_allowedcase(typed_char) && !check_keydown(event.keyCode)) {
							 	 	event.doit = false;   // cancel operation.							 	 	
							 	 	String textString = String.valueOf(typed_char).toUpperCase(locale);  //Dectecting typed keys. If it violates the definition of TITLECASE, changing words to match that.
							 	 	insert(textString);
						 		 	return;
							   	}
							   }
							 }
							 else {			 	
							    if(!(check_titlecase(event.character, string.charAt(Caretposition-1), event.keyCode))) {
							    	if(check_allowedcase(typed_char) && !check_keydown(event.keyCode)) {
							    	 event.doit = false;   // cancel operation.
							    	 String textString = String.valueOf(typed_char).toUpperCase(locale);   //Dectecting typed keys. If it violates the definition of TITLECASE, changing words to match that.
					                 insert(textString);	
					                 if(change_line == true)
					                  change_line = false;
						 		 	 return;
							    	}
							     }
							 }   
						}				 
					}
				});
		 break;	
	    }
	}
   
   //check if typed key is lowercase.	
   private boolean check_allowedcase(char keyin_char)
   {
   	//lowercase character
   	if ('A' <= keyin_char && keyin_char <= 'z')
   		return true;
   	//some specified key
   	if(check_special_key(keyin_char))
      	 return true;
   	if (keyin_char == ' ' || 0 <= keyin_char && keyin_char <= '9')
   		return true;
   	return false;
   }
   
   
// check if typed key is textcase.
   private boolean check_textcase(char keyin_char, String string, int caretposition, int keyCode)
   {
   	boolean new_sentense = false;
   	//multi-line support or not. 
   	//If not, predictive function works
   	if (keyCode == SWT.CR && multi_line == true )    
      	 change_line = true;
   	if (caretposition < 0)
   	 new_sentense = true;
   	else {
   	 while ( string.charAt(caretposition) == ' ' && caretposition >0 )   //check new stentense strats or not.
   	 {
   	   caretposition--;
   	   if (caretposition < 0 )
   	    new_sentense = false;
   	   else {
   	    if(string.charAt(caretposition) == '.')
   	     new_sentense = true;
   	   } 
   	 }
    }
   	
   	if(new_sentense || change_line) {    
   		return false;   			
    }
   	else { //lowercase and uppercase is allowed
   	 if ('A' <= keyin_char && keyin_char <= 'z') 
   	  		return true;
   	}
   	//specified key
  	if(check_special_key(keyin_char))
  	   	 return true;
   	if (keyin_char == ' ' || 0 <= keyin_char && keyin_char <= '9')
   		return true;
	return false;
   }
 
  
// check if typed key is titlecase.
   private boolean check_titlecase(char keyin_char, char back1, int keyCode)
   {
   	if (keyCode == SWT.CR && multi_line == true )
   	 change_line = true;

   	if(back1 == ' ' || change_line == true)             // if the previous key is ' ' or the first word in new line, the next word is retricted to Uppercase.
   		return false;
   	else {
   	 if ('A' <= keyin_char && keyin_char <= 'z') 
   	  		return true; 
   	}
   	if(check_special_key(keyin_char))
   	 return true;
   	if (keyin_char == ' ' || 0 <= keyin_char && keyin_char <= '9')
   		return true;
	return false;
   }
   
   //Check symbolic key
   private boolean check_special_key (char key)
   {
   	if (key == '@' || key == ':' || key == '.' || key == '&' || key == '%' || key == '~' || key == ' ')
		return true;
   	if (key == '/' || key == '"' || key == ';' || key == '?' || key == '=' || key == '_')
	    return true;
   	if (key == '`' || key == '|' || key == ']' || key == '[' || key == '{' || key == '}')
   	    return true;
	return false;
   	
   }
   
   public void append(String string) {
   	super.append(string);
   	if(string != "")
	 super.internal_sendEvent(SWT.Modify);
   }
   
	
}
