/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import java.util.Enumeration;
import java.util.Vector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.TypedListener;

// MultiPageDialog test usage
/*
import java.util.Random;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Text;
*/
/**
 * Instances of this class represents a tabbed dialog. The dialog contains
 * multiple pages. Each page contains a composite. At any given time, only one
 * page is visible. The page visibility can be selected by end-users or
 * applications programmatically. The dialog is modal. Modality hints SWT.SYSTEM_MODAL, 
 * SWT.APPLICATION_MODAL, and SWT.PRIMARY_MODAL may be specified on construction.
 * It is implementation dependent as to how these hints are interpreted since platforms
 * may not support all modality modes.
 * <p>
 * Each page has a label. The platform may display the label as text, 
 * an icon, or both together. The size and position of page labels is
 * implementation-dependent.
 * </p>
 * <p>
 * There is no fixed limit on the number of pages. 
 * A run-time exception may be thrown when resources are insufficient
 * to create a new page.
 * </p>
 * <p>
 * Note: The bounds of this dialog is implementation-dependent. Applications can
 * query the actual page size through <code>page.getBounds</code> after the page
 * has been created.
 * </p>
 * <p>
 * Commands associated to a page are only visible when that page is visible.
 * Commands may be associated with the whole MultiPageDialog by querying 
 * a page's Shell and using it as the Control when creating Commands. 
 * For example: <code>Command c = new Command(page.getShell(), Command.GENERAL, 10);</code>
 * </p>
 * <h3>Example:</h3>
 * <code><pre>
 * MultiPageDialog dialog = new MultiPageDialog(shell, SWT.PRIMARY_MODAL);
 * Composite page1 = dialog.createPage(&quot;Page 1&quot;, null);
 * // add child controls here 
 * Command okCMD = new Command(page1, Command.OK, 1);
 * okCMD.setText(&quot;Ok&quot;);
 * okCMD.addSelectionListener(new SelectionListener() {
 * 	public void widgetSelected(SelectionEvent e) {
 * 		// do something here before closing the dialog
 * 		dialog.close(); // Make the dialog invisible
 * 		dialog.dispose(); // Dispose the dialog and its children.
 * 	}
 *  public void widgetDefaultSelected(SelectionEvent e) {}
 * });
 * dialog.setSelection(dialog.getPageCount() - 1); // The last page
 * dialog.open(); // open a modal dialog
 * </pre></code>
 *  * </p><p>
 * Style <code>VIRTUAL</code> is used to create a <code>MultipageDialog</code> whose
 * <code>Composite</code>s are to be populated by the client on an on-demand basis
 * instead of up-front. This can provide significant performance and memory consumption 
 * improvements.
 * </p><p>
 * Here is an example of using a <code>MultipageDialog</code> with style <code>VIRTUAL</code>:
 * <code><pre>
 *  final MultiPageDialog dialog = new MultiPageDialog(shell, SWT.PRIMARY_MODAL | SWT.VIRTUAL);
 *  dialog.createPage(&quot;Page 1&quot;, null);
 *  dialog.createPage(&quot;Page 2&quot;, null);
 *  dialog.createPage(&quot;Page 3&quot;, null);
 *  dialog.addListener(SWT.SetData, new Listener() {
 *      public void handleEvent(Event event) {
 *          Composite page = (Composite)event.item;
 *          //Populate rest of the UI
 *      }
 *  });
 * </pre></code>
 * </p><p>
 * <dl>
 * <dt><b>Styles: </b></dt>
 * <dd>SYSTEM_MODAL</dd> 
 * <dd>APPLICATION_MODAL</dd>
 * <dd>PRIMARY_MODAL</dd>
 * <dd>VIRTUAL</dd>
 * <dt><b>Events: </b></dt>
 * <dd>Selection, SetData</dd>
 * </dl>
  * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
*/
public class MultiPageDialog extends Dialog {
	private int DIALOG_STYLE = 0;
	private static int TITLE_HEIGHT = 26;
	private static int MENU_HEIGHT = 26;
	private final static int INTERNAL_SHELL_LENGTH = 2;
	private MultiPageShell[] mpShells = new MultiPageShell[INTERNAL_SHELL_LENGTH];
	private int mpsIndex = 0;
	private MultiPageComposite mpc;
	private Display display;
	private FormLayout layout;
	private Rectangle bound;
	
	// SWT.VIRTUAL Style support
	private boolean virtual = false;

	/**
	 * Constructs a new instance of this class given only its parent.
	 * 
	 * @param parent
	 *            a shell which will be the parent of the new instance
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 */
	public MultiPageDialog(Shell parent) {
		this(parent, 0);
	}

	/**
	 * Constructs a new instance of this class given its parent and a style
	 * value describing its behavior and appearance.
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. The class description lists the style constants that are
	 * applicable to the class. Style bits are also inherited from superclasses.
	 * 
	 * @param parent
	 *            a shell which will be the parent of the new instance
	 * @param style
	 *            the style of dialog to construct
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 */
	public MultiPageDialog(Shell parent, int style) {
		super(parent, style);
		checkDialogStyle(style);
		display = parent.getDisplay();
		if((style & SWT.VIRTUAL) == SWT.VIRTUAL)
			virtual = true;
		
		int current = getCurrentInternalShellIndex();
		int next = getNextInternalShellIndex(); 
		mpShells[current] = new MultiPageShell(parent, DIALOG_STYLE);
		mpShells[next] = new MultiPageShell(parent, DIALOG_STYLE);
		mpc = new MultiPageComposite(parent, mpShells[current], SWT.NONE, virtual);
		layout = new FormLayout();
		mpShells[current].setLayout(layout);
		FormData fd = new FormData();
		fd.left = new FormAttachment(0, 0);
		fd.top = new FormAttachment(0, 0);
		fd.right = new FormAttachment(100, 0);
		fd.bottom = new FormAttachment(100, 0);
		mpc.setLayoutData(fd);

		int[] rect = OS.MultiPageComposite_GetWorkArea();
		bound = new Rectangle(rect[0], rect[1], rect[2], rect[3]); 
		mpShells[current].setBounds(bound);
		initCallBack(display);
		final MultiPageDialog mpd = this;
		parent.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
				if(mpd != null)
					mpd.dispose();
			}
		});
	}
	
	private MultiPageShell getCurrentInternalShell() {
		return mpShells[mpsIndex];
	}
	private int getCurrentInternalShellIndex() {
		return mpsIndex;
	}
	private int getNextInternalShellIndex() {
		return (mpsIndex+1)%INTERNAL_SHELL_LENGTH;
	}
	//Provide System.modal and Application_modal style of dialog for MPD
	private void checkDialogStyle(int style) {
		if((style & SWT.SYSTEM_MODAL) != 0 || (style & SWT.APPLICATION_MODAL) != 0)
			DIALOG_STYLE = SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL | SWT.RESIZE;
		else 
			DIALOG_STYLE = SWT.DIALOG_TRIM | SWT.SYSTEM_MODAL | SWT.RESIZE;		
	}

	/**
	 * Adds the listener to the collection of listeners who will be notified
	 * when the page changes, by sending it one of the messages defined in the
	 * <code>SelectionListener</code> interface.
	 * <p>
	 * When <code>widgetSelected</code> is called, the item field of the event
	 * object is valid. <code>widgetDefaultSelected</code> is not called.
	 * </p>
	 * 
	 * @param listener
	 *            the listener which should be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @see SelectionListener
	 * @see #removeSelectionListener
	 * @see org.eclipse.swt.events.SelectionEvent
	 */
	public void addSelectionListener(SelectionListener listener) {
		MultiPageShell shell = getCurrentInternalShell();
		if(shell == null || shell.isDisposed())
			SWT.error(SWT.ERROR_WIDGET_DISPOSED);
		if(shell.getDisplay().getThread() != Thread.currentThread())
			SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		mpc.addSelectionListener(listener);
	}

	/**
	 * Requests that the window manager close the dialog in the same way it
	 * would be closed when the user clicks on the "close box" or performs some
	 * other platform specific key or mouse combination that indicates the
	 * window should be removed.
	 * 
	 * No exception is thrown even when the dialog has been closed by the
	 * end-user.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see org.eclipse.swt.widgets.Shell#close
	 */
	public void close() {
		MultiPageShell shell = getCurrentInternalShell();
		if(shell == null || shell.isDisposed())
			SWT.error(SWT.ERROR_WIDGET_DISPOSED);
		if(shell.getDisplay().getThread() != Thread.currentThread())
			SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);

		if(shell != null && !shell.isDisposed())
			shell.dispose();
	}

	/**
	 * Creates a new page with the specified title string and icon.
	 * 
	 * @param title -
	 *            the title string. Cannot be null.
	 * @param icon -
	 *            the label icon image. May be null.
	 * @return composite - the new composite instance in the page. Cannot be
	 *         null.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the page title is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 * 				  <li>ERROR_ITEM_NOT_ADDED - if the page can not be created</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public Composite createPage(String title, Image icon) {
		return mpc.createPage(title, icon);
	}

	/**
	 * Deletes the page from the receiver at the given zero-relative index
	 * 
	 * @param index -
	 *            the index value. Cannot be negative, greater or equal to the
	 *            number of pages.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the index is not between 0
	 *                and the number of pages in the receiver minus 1
	 *                (inclusive)</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deletePage(int index) {
		mpc.deletePage(index);
	}

	/**
	 * Disposes of the operating system resources associated with the receiver.
	 * After this method has been invoked, all descendents will
	 * answer <code>true</code> when sent the message
	 * <code>isDisposed()</code>. Any internal connections between the
	 * widgets in the tree will have been removed to facilitate garbage
	 * collection.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see org.eclipse.swt.widgets.Widget#dispose
	 */
	public void dispose() {
		MultiPageShell shell = getCurrentInternalShell();
		if(mpc != null && !mpc.isDisposed())
			mpc.dispose();
		if(shell != null && !shell.isDisposed())
			shell.dispose();

		int current = getCurrentInternalShellIndex();
		mpShells[current] = null;
		layout = null;
		bound = null;
	}

	/**
	 * Returns the composite of the page at the given zero-relative index in the
	 * receiver.
	 * 
	 * @param index
	 *            the index of the page to select. Cannot be negative, greater
	 *            or equal to the number of pages.
	 * @return Composite the composite.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the page count is zero, or
	 *                if the index is negative or greater and equal to the page
	 *                count</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 */
	public Composite getPage(int index) {
		return mpc.getPage(index);
	}

	/**
	 * Returns the number of pages contained in the receiver.
	 * 
	 * @return int the number of pages. Returns zero when the dialog is
	 *         constructed.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 */
	public int getPageCount() {
		return mpc.getPageCount();
	}

	/**
	 * Returns the title string of the page at the given zero-relative index in
	 * the receiver.
	 * 
	 * @param index
	 *            the index of the page to select.
	 * @return String the title string of the page
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the page count is zero, or
	 *                if the index is negative or greater and equal to the page
	 *                count</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                </ul>
	 * @see #setTitle
	 */
	public String getTitle(int index) {
		return mpc.getTitle(index);
	}

	/**
	 * Returns the zero-relative index of the page which is currently selected
	 * in the receiver, or the newest page created to the receiver.
	 * 
	 * @return int the index of the selected page
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                </ul>
	 */
	public int getSelectionIndex() {
		return mpc.getSelectionIndex();
	}

	/**
	 * Makes the dialog visible and brings it to the front of the display.
	 * Note: This method does not return until the dialog is closed.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the dialog</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                </ul>
	 */
	public void open() {
		MultiPageShell shell = getCurrentInternalShell();
		if(shell == null || shell.isDisposed())
			SWT.error(SWT.ERROR_WIDGET_DISPOSED);
		if(shell.getDisplay().getThread() != Thread.currentThread())
			SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);

		
		int next = getNextInternalShellIndex();
		int current = getCurrentInternalShellIndex();
		
		if(mpShells[next] == null)
			mpShells[next] = new MultiPageShell((Shell)super.getParent(), DIALOG_STYLE);
		shell.setNextShell(mpShells[next]);

		shell.setLayout(layout);
		shell.setText(getText());
		shell.setBounds(bound);
		final Rectangle tmpBound = bound;
		shell.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
				Rectangle r = ((Shell)e.widget).getBounds();
				tmpBound.x = r.x;
				tmpBound.y = r.y;
				tmpBound.width = r.width;
				tmpBound.height = r.height;
			}
		});

		shell.open();
		if(mpc.getPageCount() > 0)
			mpc.setSelection(mpc.getSelectionIndex());
		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
		mpShells[current] = null;
		mpsIndex = next;
	}

	/**
	 * Removes the listener from the collection of listeners who will be
	 * notified when the receiver's selection changes.
	 * 
	 * @param listener
	 *            the listener which should no longer be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                </ul>
	 * 
	 * @see SelectionListener
	 * @see #addSelectionListener
	 */
	public void removeSelectionListener(SelectionListener listener) {
		MultiPageShell shell = getCurrentInternalShell();
		if(shell == null || shell.isDisposed())
			SWT.error(SWT.ERROR_WIDGET_DISPOSED);
		if(shell.getDisplay().getThread() != Thread.currentThread())
			SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);

		mpc.removeSelectionListener(listener);
	}

	/**
	 * Selects the active page by the given zero-relative index.
	 * 
	 * @param index
	 *            the index of the page to select. Cannot be negative, greater
	 *            or equal to the number of pages.
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the page count is zero, or
	 *                if the index is negative or greater and equal to the page
	 *                count</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 *  
	 */
	public void setSelection(int index) {
		mpc.setSelection(index);
	}

	/**
	 * Sets the icon image of the page at the given zero-relative index. Note
	 * that the icon size is implementation dependent so that the icon image may
	 * be stretched or shrunk automatically.
	 * 
	 * @param index
	 *            the index of the page to select.
	 * @param icon
	 *            the new icon image.
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the icon is null</li>
	 *                <li>ERROR_INVALID_RANGE - if the page count is zero, or
	 *                if the index is negative or greater and equal to the page
	 *                count</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setImage(int index, Image icon) {
		mpc.setImage(index, icon);
	}

	/**
	 * Sets the title string of the page at the given zero-relative index.
	 * 
	 * @param index
	 *            the index of the page to select.
	 * @param title
	 *            the new title string. Cannot be null.
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the page count is zero, or
	 *                if the index is negative or greater and equal to the page
	 *                count</li>
	 *                <li>ERROR_NULL_ARGUMENT - if the title is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @see #getTitle
	 */
	public void setTitle(int index, String title) {
		mpc.setTitle(index, title);
	}

	/**
	 * Adds the listener to the collection of listeners who will
	 * be notifed when an event of the given type occurs. When the
	 * event does occur in the display, the listener is notified by
	 * sending it the <code>handleEvent()</code> message.
	 *
	 * @param eventType the type of event to listen for
	 * @param listener the listener which should be notified when the event occurs
	 *
	 * @exception IllegalArgumentException <ul>
	 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 * </ul>
	 * @exception SWTException <ul>
	 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
	 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
	 * </ul>
	 *
	 * @see Listener
	 * @see #removeListener
	 * 
	 * @since eSWT 1.2 
	 */	
	public void addListener(int eventType, Listener listener) {
		mpc.addSetDataListener(eventType, listener);
	}
	
	
	/**
	 * Removes the listener from the collection of listeners who will
	 * be notifed when an event of the given type occurs.
	 *
	 * @param eventType the type of event to listen for
	 * @param listener the listener which should no longer be notified when the event occurs
	 *
	 * @exception IllegalArgumentException <ul>
	 *    <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 * </ul>
	 * @exception SWTException <ul>
	 *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
	 *    <li>ERROR_DEVICE_DISPOSED - if the receiver has been disposed</li>
	 * </ul>
	 *
	 * @see Listener
	 * @see #addListener
	 * 
	 * @since eSWT 1.2 
	 */
	public void removeListener(int eventType, Listener listener) {
		mpc.removeSetDataListener(eventType, listener);
	}
	
	static private boolean isInitCallBack = false;
	static private synchronized void initCallBack(Display display) {
		if(!isInitCallBack) {
			com.ibm.ugl.p3ml.OS.Display_RegisterCallback(display.internal_handle, OS.CALLBACK_MULTIPAGECOMPOSITE, "org/eclipse/ercp/swt/mobile/MultiPageDialog$MultiPageComposite", "Callback");
			isInitCallBack = true;
		}
	}

	public class MultiPageShell extends Shell {
		MultiPageShell next = null;
		public MultiPageShell(Shell parent, int style) {
			super(parent, style);
		}
		public void setNextShell(MultiPageShell mps) {
			this.next = mps;
		}
		public void dispose() {
			if(next != null) {
				Control[] controls = this.getChildren();
				for(int i=0; i<controls.length; i++) {
					controls[i].setParent(next);
				}
			}
			super.dispose();
		}
		public String toString() {
			return "MultiPageShell {handle=" + internal_handle + "}";  //$NON-NLS-1$ //$NON-NLS-2$
		}
	}

	private class MultiPageComposite extends Composite implements Listener {
		private Shell parent;
		private Vector pages;
		private int selected = 0;
		private MultiPageListener mpl;
		private TypedListener typedListener;
		boolean virtual;

		public MultiPageComposite(Shell realparent, Composite parent, int style, boolean virtual) {
			super(parent, SWT.NULL);
			pages = new Vector();
			this.parent = realparent;
			parent.getDisplay().addFilter(SWT.FocusIn, this);
			parent.getDisplay().addFilter(SWT.Traverse, this);
			this.virtual = virtual;
			mpl = new MultiPageListener(pages, virtual);
			typedListener = new TypedListener(mpl);
			addListener(SWT.Selection, typedListener);
			addListener(SWT.DefaultSelection, typedListener);
		}
		
		public void addSelectionListener(SelectionListener listener) {
			checkWidget();
			mpl.addSelectionListener(listener);
		}
		public void removeSelectionListener(SelectionListener listener) {
			checkWidget();
			mpl.removeSelectionListener(listener);
		}
		
		public void addSetDataListener(int eventType, Listener listener) {
			checkWidget();
			if(listener == null)
				SWT.error(SWT.ERROR_NULL_ARGUMENT);
			
			if(virtual && eventType == SWT.SetData)
				mpl.addSetDataListener(listener);
		}
		public void removeSetDataListener(int eventType, Listener listener) {
			checkWidget();
			if(listener == null)
				SWT.error(SWT.ERROR_NULL_ARGUMENT);

			if(virtual && eventType == SWT.SetData)
				mpl.removeSetDataListener(listener);
		}

		protected boolean traverse(Event event) {
			if (isDisposed()) return false;
			Composite page;
			Control control;
			switch (event.keyCode) {
				case SWT.ARROW_UP :
					page = getPage(getSelectionIndex());
					if(page == null || page.isDisposed())
						return false;
					control = getLastFocusableControl(page);
					if(control == null)
						return false;
					return control.setFocus();
				case SWT.ARROW_DOWN :
					page = getPage(getSelectionIndex());
					if(page == null || page.isDisposed())
						return false;
					control = getFirstFocusableControl(page);
					if(control == null)
						return false;
					return control.setFocus();
					
				case SWT.ARROW_RIGHT :
					if(getSelectionIndex() + 1 >= getPageCount())
						return false;
					page = getPage(getSelectionIndex() + 1);
					if(page == null || page.isDisposed())
						return false;
					else {
						return page.setFocus();
					}			
				case SWT.ARROW_LEFT :
					if(getSelectionIndex() - 1 < 0)
						return false;
					page = getPage(getSelectionIndex() - 1);
					if(page == null || page.isDisposed())
						return false;
					else {
						return page.setFocus();
					}
			}
			return super.traverse(event);
		}

		protected void internal_createHandle(int index) {
			internal_handle = OS.MultiPageComposite_New(internal_parent.internal_handle, 0);
		}

		synchronized public Composite createPage(String title, Image icon) {
			checkWidget();
			if(title == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

			int imageHandle = 0;
			if(icon != null)
				imageHandle = icon.internal_handle;
			Composite composite = null;
			
			boolean success = OS.MultiPageComposite_AddPage(internal_handle, title, imageHandle);
			if(success) {
				pages.add(new CompositePage(null, title, icon));
//				if(!virtual)
					composite = createPageComposite(pages.size()-1);
			}
			return composite;
		}
		
		Composite createPageComposite(int index) {
			if(index < 0 || index >= pages.size())
				return null;
			CompositePage page = (CompositePage)pages.get(index);
			if(page.composite == null) {
				Composite composite = new Composite(this, SWT.NONE);// | SWT.V_SCROLL | SWT.H_SCROLL);
				OS.MultiPageComposite_SetPageComposite(internal_handle, index, composite.internal_handle);
				page.composite = composite;
			}
			return page.composite;
		}
		
		Control getFirstFocusableControl(Composite composite) {
			Control[] childs = composite.getTabList();

			if(childs == null || childs.length == 0)
				return null;

			for(int i=0; i<childs.length; i++) {
				if(childs[i] instanceof Composite) {
					Control  child = getFirstFocusableControl((Composite)childs[i]);
					if(child != null)
						return child;
				}
				if(childs[i].isVisible() && isFocusableControl(childs[i]))
					return childs[i]; 
			}			
			return null;
		}

		Control getLastFocusableControl(Composite composite) {
			Control[] childs = composite.getTabList();

			if(childs == null || childs.length == 0)
				return null;

			for(int i=childs.length-1; i>=0; i--) {
				if(childs[i] instanceof Composite) {
					Control child = getLastFocusableControl((Composite)childs[i]);
					if(child != null)
						return child;
				}
				if(childs[i].isVisible() && isFocusableControl(childs[i]))
					return childs[i]; 
			}			
			return null;
		}
		
		boolean isFocusableControl(Control control) {
			if(control instanceof Label)
				return false;
			if(control instanceof ProgressBar)
				return false;
			if(control instanceof Canvas)
				return false;
			if(control instanceof CaptionedControl)
				return false;
			return true;
		}

		boolean isChild(Control parent, Control child) {
			if(parent == null || child == null)
				return false;

			if(parent == child)
				return true;
			
			Composite tmp = child.getParent();
			while(tmp != null) {
				if(tmp == parent)
					return true;
				tmp = tmp.getParent();
			}

			return false;
		}

		synchronized public void deletePage(int index) {
			checkWidget();
			if(index < 0 || index >= pages.size())
				SWT.error(SWT.ERROR_INVALID_RANGE);

			boolean success = OS.MultiPageComposite_DeletePage(internal_handle, index);
			if(success) {
				CompositePage page = (CompositePage)pages.get(index);
				if(page.composite != null && !page.composite.isDisposed())
					page.composite.dispose();
				page.composite = null;
				pages.remove(index);
				if(selected >= index && selected > 0) {
					selected --;
					setSelection(selected);
				} else if(index == 0 && pages.size() > 0) {
					setSelection(selected);
				}
			}
		}

		public void dispose() {
			checkWidget();

			removeListener(SWT.Selection, typedListener);
			removeListener(SWT.DefaultSelection, typedListener);

			int size = pages.size();
			for(int i=0; i<size; i++) {
				CompositePage page = (CompositePage)pages.get(i);
				if(page == null)
					continue;
				if(page.composite != null && !page.composite.isDisposed())
					page.composite.dispose();
				page.composite = null;
				page = null;
			}
			pages.clear();
			pages = null;
			parent.getDisplay().removeFilter(SWT.FocusIn, this);
			parent.getDisplay().removeFilter(SWT.Traverse, this);
			super.dispose();
		}

		public Composite getPage(int index) {
			checkWidget();
			if(index < 0 || index >= pages.size())
				SWT.error(SWT.ERROR_INVALID_RANGE);

			return ((CompositePage)pages.get(index)).composite;
		}

		public int getPageCount() {
			checkWidget();

			return pages.size();
		}

		public String getTitle(int index) {
			checkWidget();
			if(index < 0 || index >= pages.size())
				SWT.error(SWT.ERROR_INVALID_RANGE);

			return ((CompositePage)pages.get(index)).title;
		}

		public int getSelectionIndex() {
			checkWidget();

			return selected;
		}

		public void setSelection(int index) {
			checkWidget();
			if(index < 0 || index >= pages.size())
				SWT.error(SWT.ERROR_INVALID_RANGE);

			CompositePage page = (CompositePage)pages.get(index);
			if(page == null)
				return;

			if(virtual) {
				createPageComposite(index);
				mpl.sendSetDataEvent(index);
			}
			boolean success = OS.MultiPageComposite_SetSelection(internal_handle, index, page.composite.internal_handle);
			if(success) {
				forceFocus();
				selected = index;
			}
		}

		public void setImage(int index, Image icon) {
			checkWidget();
			if(icon == null)
				SWT.error(SWT.ERROR_NULL_ARGUMENT);
			if(index < 0 || index >= pages.size())
				SWT.error(SWT.ERROR_INVALID_RANGE);

			boolean success = OS.MultiPageComposite_SetImage(internal_handle, index, icon.internal_handle);
			if(success) {
				CompositePage page = (CompositePage)pages.get(index);
				page.setImage(icon);
			}
		}

		public void setTitle(int index, String title) {
			checkWidget();
			if(title == null)
				SWT.error(SWT.ERROR_NULL_ARGUMENT);
			if(index < 0 || index >= pages.size())
				SWT.error(SWT.ERROR_INVALID_RANGE);

			boolean success = OS.MultiPageComposite_SetTitle(internal_handle, index, title);
			if(success) {
				CompositePage page = (CompositePage)pages.get(index);
				page.title = title;
			}
		}
		private int Callback(int type, int index) {
			switch (type) {
				case OS.EVENT_MULTIPAGEDIALOG_SELECTION: {
					if(virtual)
						createPageComposite(index);
					if(index < 0 || index >= pages.size())
						return 0;
					CompositePage page = (CompositePage)pages.get(index);
					if(page == null || page.composite == null ||page.composite.isDisposed())
						return 0;
					selected = index;
					internal_sendEvent(SWT.Selection);
					return page.composite.internal_handle;
				}
				case OS.EVENT_MULTIPAGEDIALOG_GETPAGEHANDLE: {
					if(index < 0 || index >= pages.size())
						return 0;
					CompositePage page = (CompositePage)pages.get(index);
					if(page == null || page.composite == null ||page.composite.isDisposed())
						return 0;
					return page.composite.internal_handle;
				}
			}
			return 0;
		}

		public void handleEvent(Event e) {
			if(e.type == SWT.FocusIn) {
		        //Eric for Bug 180771, Interception focus in event to make sure that opened MPD is always on the top of its associated shell.
				if(e.widget == null || e.widget.isDisposed()) {
					return;
				}
				if(((Control)e.widget).getShell() == null || ((Control)e.widget).getShell().isDisposed()) {
					return;
				}
				if((this == null || this.isDisposed())) {
					return;
				}
				
				if (this.getParent() != null && !this.getParent().isDisposed() && ((Control)e.widget).getShell() == this.parent)
				{
						((Shell)this.getParent()).setActive();
				}
			} else if(e.type == SWT.Traverse) {
				if(isDisposed())
					return;
				if(getPageCount() == 0)
					return;
				Composite page = getPage(getSelectionIndex());
				if(page == null || page.isDisposed())
					return;
				Control[] childs = page.getChildren();
				if(childs == null || childs.length == 0)
					return;
				Control control;
				switch (e.detail) {
					case SWT.TRAVERSE_ARROW_NEXT :
						control = getLastFocusableControl(page);
						if(isChild((Control)e.widget, control)) {
							if(control.allowTraverseByArrowKey(e)) {
								e.doit = false;
								forceFocus();
							}
						}
						break;
					case SWT.TRAVERSE_ARROW_PREVIOUS :
						control = getFirstFocusableControl(page);
						if(isChild((Control)e.widget, control)) {
							if(control.allowTraverseByArrowKey(e)) {
								e.doit = false;
								forceFocus();
							}
						}
						break;
				}
			}
		}
		
	}

	private class CompositePage {
		public Composite composite;
		public String title;
		public int imageHandle;
		public boolean isSetData = false;
		public CompositePage(Composite composite, String title) {
			this(composite, title, null);
		}
		public CompositePage(Composite composite, String title, Image icon) {
			this.composite = composite;
			this.title = title;
			setImage(icon);
		}
		public void setImage(Image icon) {
			if(icon == null)
				imageHandle = 0;
			else
				imageHandle = icon.internal_handle;				
		}
	}

	private class MultiPageListener implements SelectionListener {
		private Vector selectionListeners = new Vector();
		private Vector setDataListeners = new Vector();
		private Vector pages;
		private boolean virtual = false;
		public MultiPageListener() {
			
		}
		public MultiPageListener(Vector pages, boolean virtual) {
			setCompositePage(pages);
			setVirtual(virtual);
		}
		public void setCompositePage(Vector pages) {
			this.pages = pages;
		}
		public void setVirtual(boolean virtual) {
			this.virtual = virtual;
		}
		public void addSelectionListener(SelectionListener listener) {
			if(listener != null)
				selectionListeners.add(listener);
		}
		public void removeSelectionListener(SelectionListener listener) {
			if(listener != null)
				selectionListeners.remove(listener);
		}
		public void addSetDataListener(Listener listener) {
			if(listener != null)
				setDataListeners.add(listener);
		}
		public void removeSetDataListener(Listener listener) {
			if(listener != null)
				setDataListeners.remove(listener);
		}
		public void widgetSelected(SelectionEvent se) {
			if(!(se.widget instanceof MultiPageComposite))
				return;
			MultiPageComposite mpc = (MultiPageComposite)se.widget;
			if(mpc == null)
				return;
			int index = mpc.getSelectionIndex();
			if(virtual) {
				sendSetDataEvent(index);
			}
			sendSelectionEvent(se);
		}
		
		void sendSelectionEvent(SelectionEvent se) {
			MultiPageComposite mpc = (MultiPageComposite)se.widget;
			if(mpc == null)
				return;
			Composite composite = mpc.getPage(mpc.getSelectionIndex());
			if(composite == null)
				return;

			Event e = new Event();
			e.display = composite.getDisplay();
			e.x = composite.getLocation().x;
			e.y = composite.getLocation().y;
			e.width = composite.getSize().x;
			e.height = composite.getSize().y;
			e.type = SWT.Selection;
			e.widget = composite;
			e.time = se.time;

			SelectionEvent nse = new SelectionEvent(e);
			Enumeration enumeration = selectionListeners.elements();
			while(enumeration.hasMoreElements()) {
				SelectionListener listener = (SelectionListener)enumeration.nextElement();
				if(listener == null)
					continue;
				listener.widgetSelected(nse);
			}
		}

		void sendSetDataEvent(int index) {
			if(!virtual)
				return;
			if(index >= pages.size())
				return;
			CompositePage page = (CompositePage)pages.get(index);
			if(page.composite == null || page.isSetData)
				return;

			Event e = new Event();
			e.display = page.composite.getDisplay();
			e.x = page.composite.getLocation().x;
			e.y = page.composite.getLocation().y;
			e.width = page.composite.getSize().x;
			e.height = page.composite.getSize().y;
			e.type = SWT.SetData;
			e.widget = page.composite;
			e.item = page.composite;
			e.index = mpc.getSelectionIndex();

			Enumeration enumeration = setDataListeners.elements();
			while(enumeration.hasMoreElements()) {
				Listener listener = (Listener)enumeration.nextElement();
				if(listener == null)
					continue;
				listener.handleEvent(e);
			}

			page.isSetData = true;
		}

		public void widgetDefaultSelected(SelectionEvent e) {
		}
	}

//	 MultiPageDialog test usage
/*
	public static void main(String[] args){
		final Display display = new Display();
		final Shell shell = new Shell(display);

		int style = 0;//SWT.BORDER;

		final Label pageLabel = new Label(shell, SWT.CENTER | style);
		pageLabel.setText("Page :");
		pageLabel.pack();
		
		final Combo pageCombo = new Combo(shell, SWT.DROP_DOWN | SWT.READ_ONLY | style);
		pageCombo.pack();

		final Button deletePageButton = new Button(shell, SWT.PUSH | style);
		deletePageButton.setText("Delete");
		deletePageButton.pack();
		
		final Button selectPageButton = new Button(shell, SWT.PUSH | style);
		selectPageButton.setText("setSelection");
		selectPageButton.pack();
		
		final Label getLabel = new Label(shell, SWT.CENTER | style);
		getLabel.setText("Get");
		getLabel.pack();
		
		final Button getTitleButton = new Button(shell, SWT.PUSH | style);
		getTitleButton.setText("Title");
		getTitleButton.pack();

		final Label sepLabel1 = new Label(shell, SWT.SEPARATOR | SWT.VERTICAL | SWT.BORDER | style);
		sepLabel1.pack();

		final Button getPageCountButton = new Button(shell, SWT.PUSH | style);
		getPageCountButton.setText("Count");
		getPageCountButton.pack();
		
		final Button getSelectionIndexButton = new Button(shell, SWT.PUSH | style);
		getSelectionIndexButton.setText("Selected");
		getSelectionIndexButton.pack();
		
		
		final Button titleCheckButton = new Button(shell, SWT.CHECK | style);
		titleCheckButton.setText("Title :");
		titleCheckButton.pack();
		
		final Text titleText = new Text(shell, SWT.LEFT | SWT.BORDER | style);
		titleText.pack();

		final Button modifyTitleButton = new Button(shell, SWT.PUSH | style);
		modifyTitleButton.setText("Modify");
		modifyTitleButton.pack();

		final Button iconCheckButton = new Button(shell, SWT.CHECK | style);
		iconCheckButton.setText("Icon :");
		iconCheckButton.pack();
		
		final Combo iconListCombo = new Combo(shell, SWT.DROP_DOWN | SWT.READ_ONLY | style);
		iconListCombo.add("001.gif");
		iconListCombo.add("002.gif");
		iconListCombo.add("003.gif");
		iconListCombo.add("004.gif");
		iconListCombo.add("005.gif");
		iconListCombo.add("006.gif");
		iconListCombo.add("007.gif");
		iconListCombo.add("008.gif");
		iconListCombo.add("009.gif");
		iconListCombo.add("010.gif");
		iconListCombo.add("iMac.JPG");
		iconListCombo.select(0);
		iconListCombo.pack();

		final Button modifyIconButton = new Button(shell, SWT.PUSH | style);
		modifyIconButton.setText("Modify");
		modifyIconButton.pack();

		final Label iconLabel = new Label(shell, SWT.LEFT | style);
		iconLabel.setImage(new Image(display, "/resources/001.gif"));
		iconLabel.setSize(20, 20);
		
		final Button addPageButton = new Button(shell, SWT.PUSH | style);
		addPageButton.setText("Add Page");
		addPageButton.pack();

		final Label sepLabel2 = new Label(shell, SWT.SEPARATOR | SWT.HORIZONTAL | style);
		sepLabel2.pack();
		
		final Label mpdLabel = new Label(shell, SWT.CENTER | style);
		mpdLabel.setText("MultiPageDialog :");
		mpdLabel.pack();

		final Button openButton = new Button(shell, SWT.PUSH | style);
		openButton.setText("Open");
		openButton.pack();
		
		final Button disposeButton = new Button(shell, SWT.PUSH | style);
		disposeButton.setText("Dispose");
		disposeButton.pack();
		
		final Button closeButton = new Button(shell, SWT.PUSH | style);
		closeButton.setText("Close");
		closeButton.pack();
		
		final MultiPageDialog mpd = new MultiPageDialog(shell, SWT.NONE);
		mpd.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("-- widgetSelected --");
				Composite composite = (Composite)e.widget;
				Control[] control = composite.getChildren();
				for(int i=0;i<control.length;i++)
					System.out.println(control[i]);
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		layout.spacing = 3;
		shell.setLayout(layout);
		
		
		FormData fda1 = new FormData();
		fda1.left = new FormAttachment(0, 0);
		fda1.top = new FormAttachment(0, 0);
		pageLabel.setLayoutData(fda1);

		FormData fda2 = new FormData();
		fda2.left = new FormAttachment(pageLabel, 0);
		fda2.top = new FormAttachment(0, 0);
//		fda2.right = new FormAttachment(pageLabel, 20);
		pageCombo.setLayoutData(fda2);
		
		FormData fda3 = new FormData();
		fda3.left = new FormAttachment(pageCombo, 0);
		fda3.top = new FormAttachment(0, 0);
		deletePageButton.setLayoutData(fda3);
		
		FormData fda5 = new FormData();
		fda5.left = new FormAttachment(deletePageButton, 0);
		fda5.top = new FormAttachment(0, 0);
		selectPageButton.setLayoutData(fda5);
		
		
		FormData fdb1 = new FormData();
		fdb1.left = new FormAttachment(0, 0);
		fdb1.top = new FormAttachment(selectPageButton, 0);
		getLabel.setLayoutData(fdb1);

		FormData fdb2 = new FormData();
		fdb2.left = new FormAttachment(getLabel, 0);
		fdb2.top = new FormAttachment(selectPageButton, 0);
		getTitleButton.setLayoutData(fdb2);

		FormData fdb3 = new FormData();
		fdb3.left = new FormAttachment(getTitleButton, 0);
		fdb3.top = new FormAttachment(selectPageButton, 0);
//		fdb3.right = new FormAttachment(getTitleButton, 20, SWT.RIGHT);
		fdb3.bottom = new FormAttachment(selectPageButton, getTitleButton.getSize().y);
		sepLabel1.setLayoutData(fdb3);

		FormData fdb4 = new FormData();
		fdb4.left = new FormAttachment(sepLabel1, 0);
		fdb4.top = new FormAttachment(selectPageButton, 0);
		getPageCountButton.setLayoutData(fdb4);
		
		FormData fdb5 = new FormData();
		fdb5.left = new FormAttachment(getPageCountButton, 0);
		fdb5.top = new FormAttachment(selectPageButton, 0);
		getSelectionIndexButton.setLayoutData(fdb5);
				
		
		FormData fd11 = new FormData();
		fd11.left = new FormAttachment(0, 0);
		fd11.top = new FormAttachment(getTitleButton, 0);
		titleCheckButton.setLayoutData(fd11);

		FormData fd12 = new FormData();
		fd12.left = new FormAttachment(titleCheckButton, 0);
		fd12.top = new FormAttachment(getTitleButton, 0);
		fd12.right = new FormAttachment(titleCheckButton, 150);
//		fd12.bottom = new FormAttachment(deletePageCombo, 20);
		titleText.setLayoutData(fd12);
		
		FormData fd13 = new FormData();
		fd13.left = new FormAttachment(titleText, 0);
		fd13.top = new FormAttachment(getTitleButton, 0);
		modifyTitleButton.setLayoutData(fd13);

		FormData fd21 = new FormData();
		fd21.left = new FormAttachment(0, 0);
		fd21.top = new FormAttachment(modifyTitleButton, 0);
		iconCheckButton.setLayoutData(fd21);

		FormData fd22 = new FormData();
		fd22.left = new FormAttachment(iconCheckButton, 0);
		fd22.top = new FormAttachment(modifyTitleButton, 0);
		iconListCombo.setLayoutData(fd22);
		
		FormData fd23 = new FormData();
		fd23.left = new FormAttachment(iconListCombo, 0);
		fd23.top = new FormAttachment(modifyTitleButton, 0);
//		fd23.right = new FormAttachment(iconListCombo, 20);
//		fd23.bottom = new FormAttachment(modifyTitleButton, 20);
		iconLabel.setLayoutData(fd23);
		
		FormData fd24 = new FormData();
		fd24.left = new FormAttachment(iconLabel, 0);
		fd24.top = new FormAttachment(modifyTitleButton, 0);
		modifyIconButton.setLayoutData(fd24);

		FormData fd81 = new FormData();
		fd81.left = new FormAttachment(0, 0);
		fd81.top = new FormAttachment(iconListCombo, 0);
		addPageButton.setLayoutData(fd81);
		
		FormData fd91 = new FormData();
		fd91.left = new FormAttachment(0, 0);
		fd91.top = new FormAttachment(addPageButton, 0);
		fd91.right = new FormAttachment(100, 0);
		sepLabel2.setLayoutData(fd91);

		FormData fdx1 = new FormData();
		fdx1.left = new FormAttachment(0, 0);
		fdx1.top = new FormAttachment(sepLabel2, 0);
		mpdLabel.setLayoutData(fdx1);

		FormData fdx2 = new FormData();
		fdx2.left = new FormAttachment(mpdLabel, 0);
		fdx2.top = new FormAttachment(sepLabel2, 0);
		openButton.setLayoutData(fdx2);

		FormData fdx3 = new FormData();
		fdx3.left = new FormAttachment(openButton, 0);
		fdx3.top = new FormAttachment(sepLabel2, 0);
		disposeButton.setLayoutData(fdx3);

		FormData fdx4 = new FormData();
		fdx4.left = new FormAttachment(disposeButton, 0);
		fdx4.top = new FormAttachment(sepLabel2, 0);
		closeButton.setLayoutData(fdx4);

		
		deletePageButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				int idx = pageCombo.getSelectionIndex();
				if(idx < 0)
					return;
				mpd.deletePage(idx);
				pageCombo.remove(pageCombo.getItemCount()-1);
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		selectPageButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				int idx = pageCombo.getSelectionIndex();
				if(idx < 0)
					return;
				mpd.setSelection(idx);
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		getTitleButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				int idx = pageCombo.getSelectionIndex();
				if(idx < 0)
					return;
				MessageBox mb = new MessageBox(shell, SWT.ICON_INFORMATION);
				mb.setText("Get Title");
				mb.setMessage(mpd.getTitle(idx));
				mb.open();
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		getPageCountButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				int count = mpd.getPageCount();
				MessageBox mb = new MessageBox(shell, SWT.ICON_INFORMATION);
				mb.setText("Get Page Count");
				mb.setMessage("" + count);
				mb.open();
				mb = null;
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		getSelectionIndexButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				int selected = mpd.getSelectionIndex();
				MessageBox mb = new MessageBox(shell, SWT.ICON_INFORMATION);
				mb.setText("Get Selection Index");
				mb.setMessage("" + selected);
				mb.open();
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		modifyTitleButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				int idx = pageCombo.getSelectionIndex();
				if(idx < 0)
					return;
				String title = null;
				if(titleCheckButton.getSelection()) {
					title = titleText.getText();
				}
				mpd.setTitle(idx, title);
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		iconListCombo.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				iconLabel.setImage(new Image(display, "/resources/" + iconListCombo.getItem(iconListCombo.getSelectionIndex())));
				iconLabel.setSize(20, 20);
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		modifyIconButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				int idx = pageCombo.getSelectionIndex();
				if(idx < 0)
					return;
				Image icon = null;
				if(iconCheckButton.getSelection()) {
					icon = new Image(display, "/resources/" + iconListCombo.getItem(iconListCombo.getSelectionIndex()));
				}
				mpd.setImage(idx, icon);
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		addPageButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				String title = null;
				Image icon = null;
				if(titleCheckButton.getSelection()) {
					title = titleText.getText();
				}
				if(iconCheckButton.getSelection()) {
					icon = new Image(display, "/resources/" + iconListCombo.getItem(iconListCombo.getSelectionIndex()));
				}

				Composite page = mpd.createPage(title, icon);
System.out.println("createPage, bound : " + page.getBounds());
				Button closeButton = new Button(page, SWT.BORDER);
				closeButton.setText("Close");
				closeButton.pack();
				closeButton.addSelectionListener(new SelectionListener() {
					public void widgetSelected(SelectionEvent e) {
						mpd.close();
					}
					public void widgetDefaultSelected(SelectionEvent e) {
					}
				});
				
				Random random = new Random();
				int r = random.nextInt(64);
				int count = pageCombo.getItemCount() + 1;
				int sx = 0, sy = closeButton.getSize().y, th = 0;

				Label compo = new Label(page, SWT.LEFT);
				compo.setText("Here is composite " + count);
				compo.setLocation(sx, sy);
				compo.pack();

				sy += compo.getSize().y;
				if((r & 1) == 1) {
					Button button = new Button(page, SWT.CENTER);
					button.setText("i am button");
					button.setLocation(sx, sy);
					button.pack();
					
					sx += button.getSize().x;
					th = button.getSize().y;
				}
				if((r & 2) == 2) {
					Text text = new Text(page, SWT.BORDER | SWT.LEFT | SWT.SINGLE);
					text.setText("Please input...");
					text.setLocation(sx, sy);
					text.pack();

					if(th < text.getSize().y)
						th = text.getSize().y;
				}
				sx = 0;
				sy += th;
				th = 0;
				if((r & 4) == 4) {
					Label label = new Label(page, SWT.CENTER);
					label.setText("Are you daniel su?");
					label.setLocation(sx, sy);
					label.pack();

					sx += label.getSize().x;
					th = label.getSize().y;
				}
				if((r & 8) == 8) {
					Combo combo = new Combo(page, SWT.CENTER);
					combo.add("YES");
					combo.add("NO");
					combo.select(r % 2);
					combo.setLocation(sx, sy);
					combo.pack();

					if(th < combo.getSize().y)
						th = combo.getSize().y;
				}
				sx = 0;
				sy += th;
				th = 0;
				if((r & 16) == 16) {
					Combo combo = new Combo(page, SWT.CENTER);
					for(int i=0; i<10; i++)
						combo.add("" + i);
					combo.setLocation(sx, sy);
					combo.pack();

					sx += combo.getSize().x;
				}
				if((r & 32) == 32) {
					Label label = new Label(page, SWT.CENTER);
					Image icon2 = null;
					if((r & 1) == 1)
						icon2 = new Image(display, "/resources/image001.jpg");
					else if((r & 2) == 2) 
						icon2 = new Image(display, "/resources/iMac.JPG");
					else if((r & 4) == 4) 
						icon2 = new Image(display, "/resources/Girl.png");
					else 
						icon2 = new Image(display, "/resources/001.gif");

					label.setImage(icon2);
					label.setLocation(sx, sy);
					label.pack();

					sx += label.getSize().x;
				}
				
				int p = mpd.getPageCount();
				pageCombo.add(String.valueOf(p));
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		
		});

		openButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				mpd.open();
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		disposeButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				mpd.dispose();
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		closeButton.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				mpd.close();
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		shell.pack();
		shell.open();
		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
		display.dispose();
	}
*/
}
