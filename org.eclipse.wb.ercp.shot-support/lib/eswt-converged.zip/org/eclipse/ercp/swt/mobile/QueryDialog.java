/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ResourceBundle;

// QueryDialog test usage
/*
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Combo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
*/
/**
 * A modal window used to prompt the end-user for data input.
 * 
 * <p>
 * A QueryDialog contains a prompt text and an entry field. The QueryDialog
 * supports five types of entry fields: STANDARD, NUMERIC, PASSWORD, TIME and
 * DATE. The position and size of the dialog is implementation-dependent.
 * </p>
 * 
 * <dl>
 * <dt><b>Styles: </b></dt>
 * <dd>APPLICATION_MODAL, PRIMARY_MODAL</dd>
 * <dt><b>Query types: </b></dt>
 * <dd>STANDARD: alphanumeric data input</dd>
 * <dd>NUMERIC: numerical only data input</dd>
 * <dd>PASSWORD: a platform-dependent way for sensitive information input. 
 * The initial input mode is set to allow entry of digit characters</dd>
 * <dd>TIME: time input. The default and return values are strings in the 
 * international standard time
 * notation (ISO 8601), hh:mm:ss, where hh is the number of complete hours that
 * have passed since midnight (00-24), mm is the number of complete minutes that
 * have passed since the start of the hour (00-59), and ss is the number of
 * complete seconds since the start of the minute (00-60). If the hour value is
 * 24, then the minute and second values must be zero. The visual representation
 * of the time is locale specific. If the implementation
 * does not display the number of seconds, the second value returned is zero.</dd>
 * <dd>DATE: date input. The default and return values are strings in the 
 * international standard date notation (ISO
 * 8601) "YYYY-MM-DD", where YYYY is the year in the Gregorian
 * calendar, MM is the month of the year between 01 (January) and 12 (December),
 * and DD is the day of the month between 01 and 31.
 * The visual representation of the date is locale specific.</dd>
 * <dt><b>Events: </b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * Note: When the style is either DATE or TIME, the date or time input is locale
 * specific. User entered data is constrained to a valid date
 * or time and is converted to an ISO 8601 string format to be returned from
 * open().
 * </p>
 * <p>
 * Example:
 * 
 * <code><pre>
 * QueryDialog dialog = new QueryDialog(shell, SWT.NONE, QueryDialog.STANDARD);
 * dialog.setPromptText(&quot;Enter name:&quot;, &quot;game1&quot;);
 * String gameName = dialog.open();
 * if (gameName != null) {
 * 	// OK
 * 	// do something
 * } else {
 * 	// Cancelled
 * 	// do something else
 * }
 * </pre></code>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */
public class QueryDialog extends Dialog {
	// default layout setting
	private final static int MARGIN_WIDTH = 3;
	private final static int MARGIN_HEIGHT = 3;
	private final static int SPACING = 3;
	private final static int SHELL_MARGIN_WIDTH = 20;
	private static final int INPUT_WIDTH_MINIMUM = 80;

	private TextModifyListener tml;

	private int maximum = Text.LIMIT;
	private int minimum = 0;
	private int queryType;
	private String promptText;
	private String value;
	private Control focusControl = null;

	private static final String QUERYDIALOG_OK_KEY = "QueryDialog_Ok";
	private static final String QUERYDIALOG_CANCEL_KEY = "QueryDialog_Cancel";
	private static final String MOBILE_PROPERTY_NAME = "mobile";
	private static String strOk;
	private static String strCancel;
	Thread thread;

	/**
	 * Alphanumeric data entry type
	 */
	public static final int STANDARD = 0;

	/**
	 * Password entry type. The input method and resulting string value
	 * are platform-dependent.
	 */
	public static final int PASSWORD = 1;

	/**
	 * Numerical data entry type. Only locale-dependent digit characters are
	 * allowed.
	 */
	public static final int NUMERIC = 2;

	/**
	 * Time entry type. The implementation can decide to use either 12 or 24 hour
	 * mode for input, but the return value is in 24 hour format.
	 */
	public static final int TIME = 3;

	/**
	 * Date entry type.
	 */
	public static final int DATE = 4;

	/**
	 * Constructs a new instance of this class given its parent.
	 * 
	 * <p>
	 * By default, APPLICATION_MODAL style and STANDARD query type is used.
	 * </p>
	 * 
	 * @param parent
	 *            a shell which will be the parent of the new instance
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * @see #QueryDialog(Shell, int, int)
	 */
	public QueryDialog(Shell parent) {
		this(parent, SWT.APPLICATION_MODAL, STANDARD);
	}

	/**
	 * Constructs a new instance of this class given its parent and style .
	 * 
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>Dialog</code>. By default STANDARD query type is used.
	 * </p>
	 * 
	 * @param parent
	 *            a shell which will be the parent of the new instance
	 * @param style
	 *            the style of control to construct
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @see SWT#APPLICATION_MODAL
	 * @see SWT#PRIMARY_MODAL
	 * @see #QueryDialog(Shell, int, int)
	 */
	public QueryDialog(Shell parent, int style) {
		this(parent, style, STANDARD);
	}

	/**
	 * Constructs a new instance of this class given its parent, style and query
	 * type.
	 * 
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>Dialog</code>.
	 * </p>
	 * 
	 * @param parent
	 *            a shell which will be the parent of the new instance
	 * @param style
	 *            the style of control to construct
	 * @param queryType
	 *            one of STANDARD, NUMERIC, PASSWORD, TIME, or DATE.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the queryType is invalid
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * @see SWT#APPLICATION_MODAL
	 * @see SWT#PRIMARY_MODAL
	 * @see #STANDARD
	 * @see #PASSWORD
	 * @see #NUMERIC
	 * @see #TIME
	 * @see #DATE
	 */
	public QueryDialog(Shell parent, int style, int queryType) {
		super(parent, style);
		if(queryType != STANDARD && queryType != PASSWORD &&
		   queryType != NUMERIC && queryType != TIME && 
		   queryType != DATE) {
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			return;
		}
			
		this.queryType = queryType;
		tml = new TextModifyListener();
		ResourceBundle rb = ResourceBundle.getBundle(MOBILE_PROPERTY_NAME, Locale.getDefault());
		strOk = rb.getString(QUERYDIALOG_OK_KEY);
		strCancel = rb.getString(QUERYDIALOG_CANCEL_KEY);
		rb = null;
		thread = Thread.currentThread();
	}

	/**
	 * Creates the prompt dialog in front of its parent shell and waits for input.
	 * This method will return when the input is finished or cancelled.
	 * 
	 * @return String the value entered. Null means that input was cancelled,
	 *         regardless of whether a default value was specified. For STANDARD,
	 * 		   NUMERIC, and PASSWORD types, the string contains precisely
	 * 		   the characters entered without any formatting, up to the maximum
	 * 		   number of characters. For DATE and TIME
	 * 		   types, the string contains an ISO 8601 formatted value.	
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                </ul>
	 */
	public String open() {

		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		
		if(this.value == null) {
			this.value = "";
		}
		focusControl = super.getParent().getDisplay().getFocusControl();
		
		int maxw, maxh;
		int promptw, prompth;
		int shellx, shelly, shellw, shellh;

		Shell parent = getParent();
		final Display display = parent.getDisplay();
		maxw = display.getBounds().width;
		maxh = display.getBounds().height;
		if(org.eclipse.swt.SWT.getPlatform().equals("win32")) {
			maxw /= 2;
			maxh /= 2;
		}

		final Shell shell = new Shell(parent, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setText(getText());

		Label prompt = new Label(shell, SWT.LEFT | SWT.WRAP);
		if(this.promptText != null)
			prompt.setText(this.promptText);

		int textStyle = SWT.LEFT | SWT.SINGLE | SWT.BORDER;
		if(queryType == PASSWORD)
			textStyle |= SWT.PASSWORD;
		final Text input = new Text(shell, textStyle);
		input.setTextLimit(maximum);
		if(value != null)
			input.setText(this.value);
		input.pack();

		tml.setMaximum(maximum);
		tml.setMinimum(minimum);
		tml.setQueryType(queryType);
		tml.setValue(value);
		input.addModifyListener(tml);
		
		Button okButton = new Button(shell, SWT.NONE);
		okButton.setText(strOk);
		okButton.pack();
		
		Button cancelButton = new Button(shell, SWT.NONE);
		cancelButton.setText(strCancel);
		cancelButton.pack();
		
		FormLayout layout = new FormLayout();
		layout.marginWidth = MARGIN_WIDTH;
		layout.marginHeight = MARGIN_HEIGHT;
		layout.spacing = SPACING;
		shell.setLayout(layout);

		// get prompt text width and height
		int lineCount = 0;
		if(prompt.getText().length() == 0) {
			promptw = 0;
			prompth = 0;
		} else { 
			Text text = new Text(shell, SWT.LEFT | SWT.WRAP | SWT.MULTI);
			FormData fdMsg = new FormData();
			fdMsg.left = new FormAttachment(0, 0);
			fdMsg.top = new FormAttachment(0, 0);
			fdMsg.right = new FormAttachment(100, 0);
			fdMsg.bottom = new FormAttachment(100, 0);
			text.setLayoutData(fdMsg);
			if(this.promptText != null)
				text.setText(this.promptText);
			text.pack();
			shell.setSize(maxw - SHELL_MARGIN_WIDTH, maxh);
			lineCount = text.getLineCount();
			if(lineCount <= 1)
				text.pack();
			promptw = text.getBounds().width;
			prompth = text.getLineCount() * text.getLineHeight();
			text.dispose();
			text = null;
			fdMsg = null;
		}
		prompt.setSize(promptw, prompth);

		FormData fdPrompt = new FormData();
		fdPrompt.left = new FormAttachment(0, 0);
		fdPrompt.top = new FormAttachment(0, 0);
		if(lineCount > 1 || promptw + SHELL_MARGIN_WIDTH + INPUT_WIDTH_MINIMUM > maxw)
			fdPrompt.right = new FormAttachment(100, 0);
		fdPrompt.bottom = new FormAttachment(0, prompth);
		prompt.setLayoutData(fdPrompt);
		
		FormData fdText = new FormData();
		if(lineCount > 1 || promptw + SHELL_MARGIN_WIDTH + INPUT_WIDTH_MINIMUM > maxw) {
			fdText.left = new FormAttachment(0, 0);
			fdText.top = new FormAttachment(prompt, 0);
		} else {
			fdText.left = new FormAttachment(prompt, 0);
			fdText.top = new FormAttachment(0, 0);
		}
		fdText.right = new FormAttachment(100, 0);
		input.setLayoutData(fdText);
		
		int useWidth = okButton.getSize().x + cancelButton.getSize().x + SPACING + MARGIN_WIDTH + MARGIN_HEIGHT;
		int sx = (maxw - SHELL_MARGIN_WIDTH - useWidth)/2;

		FormData fdOKButton = new FormData();
		fdOKButton.left = new FormAttachment(0, sx);
		fdOKButton.top = new FormAttachment(input, 0);
		okButton.setLayoutData(fdOKButton);

		FormData fdCancelButton = new FormData();
		fdCancelButton.left = new FormAttachment(okButton, okButton.getBorderWidth());
		fdCancelButton.top = new FormAttachment(input, 0);
		cancelButton.setLayoutData(fdCancelButton);
		
		okButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				String value = input.getText();
				int type = tml.getQueryType();
				boolean valid = true;
				if(type == QueryDialog.TIME) {
					if(!tml.isValidTimeFormat(value))
						valid = false;
				} else if(type == QueryDialog.DATE) {
					if(!tml.isValidDateFormat(value))
						valid = false;
				} else {
					if(type == QueryDialog.NUMERIC) {
						if(!tml.isValidNumericFormat(value))
							valid = false;
					}
					if(valid) {
						int minimum = tml.getMinimum();
						if(minimum != 0 && value.length() < minimum)
							valid = false;
					}
					if(valid) {
						int maximum = tml.getMaximum();
						if(maximum != 0 && value.length() > maximum)
							valid = false;
					}
				}
				if(valid) {
					tml.setResult(value);
					shell.close();
				} else {
					input.setFocus();
					display.beep();
				}
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		cancelButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				shell.close();
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		shell.pack();
		shellw = maxw - SHELL_MARGIN_WIDTH;
		if(shell.getBounds().height > maxh)
			shellh = maxh;
		else
			shellh = shell.getBounds().height;
		shellx = SHELL_MARGIN_WIDTH/2;
		shelly = (maxh - shellh)/2;
		if(org.eclipse.swt.SWT.getPlatform().equals("win32")) {
			shellx = (display.getBounds().width - shellw)/2;
			shelly = maxh/2;
		}
		shell.setBounds(shellx, shelly, shellw, shellh);
		shell.open();

		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
		if(focusControl != null) {
			focusControl.forceFocus();
		}
		return tml.getResult();
	}

	/**
	 * Defines the maximum number of characters that can be entered.
	 * If the input string already exceeds the maximum, the excessive part of 
	 * the value is not displayed.
	 * 
	 * Usually the maximum length is system-dependent, and applications should
	 * not specify it.
	 * 
	 * Note: This method has no effect for DATE and TIME types.
	 * 
	 * @param maximum
	 *            the maximum character length. Must be equal or greater than
	 *            zero. Zero means no limit.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if maximum is negative, or less
	 *                than the minimum length defined by
	 *                {@link #setMinimum(int) setMinimum(int)}.</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if maximum is greater than
	 *                the real maximum length the receiver can hold. Typically
	 *                the real maximum length is defined by
	 *                {@link org.eclipse.swt.widgets.Text#LIMIT Text.LIMIT}
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                </ul>
	 * 
	 * @see #setMinimum(int)
	 */
	public void setMaximum(int maximum) {
		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		if(queryType == TIME || queryType == DATE)
			return;
		if(maximum < 0 || maximum < this.minimum) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		if(maximum > Text.LIMIT) {
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			return;
		}
		this.maximum = maximum;
	}

	/**
	 * Defines the minimum number of characters that must be entered before
	 * the dialog can be completed (not cancelled).
	 * 
	 * Note: This method has no effect for DATE and TIME types.
	 * 
	 * @param minimum
	 *            the minimum number of characters. Must be equal or greater than
	 *            zero. Zero means no limit.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if minimum is negative, or
	 *                greater than the maximum length defined by
	 *                {@link #setMaximum(int) setMaximum(int)}.</li>
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                </ul>
	 * 
	 * @see #setMaximum(int)
	 */
	public void setMinimum(int minimum) {
		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		if(queryType == TIME || queryType == DATE)
			return;
		if(minimum < 0 || minimum > this.maximum) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		this.minimum = minimum;
	}

	/**
	 * Sets the prompt text and default input value.
	 * 
	 * @param promptText
	 *            the prompt text. Can be null.
	 * @param defaultValue
	 *            the initial value. Cannot be null. The {@link #open() open()}
	 *            method may return the same value even when no input is
	 *            received from the end-user. If the value length is greater than 
	 * 			  the maximum number of characters, only the maximum will be 
	 * 			  displayed.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if defaultValue is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if defaultValue format is
	 *                invalid (only for DATE and TIME styles)</li>
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the dialog has been
	 *                disposed</li>
	 *                </ul>
	 */
	public void setPromptText(String promptText, String defaultValue) {
		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		if(defaultValue == null) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;	
		}
		if(!defaultValue.equals("")) {
			if(queryType == DATE) {
				String localeDate = tml.convISO8601ToLocaleDate(defaultValue);
				if(localeDate == null) {
					SWT.error(SWT.ERROR_INVALID_ARGUMENT);
					return;			
				}	
				this.value = localeDate;
			} else {
				if(!tml.isValidFormat(defaultValue, this.queryType)) {
					SWT.error(SWT.ERROR_INVALID_ARGUMENT);
					return;
				}
				this.value = defaultValue;
			}
		}
		
		this.promptText = promptText;
	}
	
	// 1.check input format and character length
	// 2.real time check numeric 
	public class TextModifyListener implements ModifyListener {
		private int queryType = QueryDialog.STANDARD;
		private String value, result = null;
		private int maximum;
		private int minimum;
		public void setMaximum(int maximum) {
			this.maximum = maximum;
		}
		public int getMaximum() {
			return this.maximum;
		}
		public void setMinimum(int minimum) {
			this.minimum = minimum;
		}
		public int getMinimum() {
			return this.minimum;
		}
		public void setQueryType(int queryType) {
			this.queryType = queryType;
		}
		public int getQueryType() {
			return this.queryType;
		}
		public void setValue(String value){
			this.value = value;
		}
		public String getValue() {
			return value;
		}
		public void setResult(String result){
			this.result = result;
		}
		public String getResult() {
			if(queryType == QueryDialog.DATE)
				return convLocaleDateToISO8601(value);
			return result;
		}
		
		// provide click OK button
		// all condition should be valid
		public boolean isValidNumericFormat(String value) {
			if(value == null)
				return false;
			if(value.equals(""))
				return false;
			for(int i=0; i<value.length(); i++)
				if(value.charAt(i) < '0' || value.charAt(i) > '9')
					return false;
			return true;

		}
		
		// provide click OK button
		// all condition should be valid
		public boolean isValidTimeFormat(String value) {
			if(value == null)
				return false;
			if(value.equals(""))
				return false;
			if(value.length() != 8)
				return false;

			StringTokenizer st = new StringTokenizer(value, ":");
			if(st.countTokens() != 3) {
				st = null;
				return false;
			} else {
				try {
					String sh = st.nextToken();
					if(sh.length() != 2) {
						sh = null;
						return false;
					}
					String ss = st.nextToken();
					if(ss.length() != 2) {
						ss = null;
						return false;
					}
					String sm = st.nextToken();
					if(sm.length() != 2) {
						sm = null;
						return false;
					}
					int ih = Integer.parseInt(sh);
					int im = Integer.parseInt(sm);
					int is = Integer.parseInt(ss);
					sh = null;
					sm = null;
					ss = null;
					if(ih < 0 || ih > 24 || 
						im < 0 || im > 59 ||
						is < 0 || is > 60)
						return false;
					if(ih == 24 && (im != 0 || is != 0))
						return false;
				} catch (NumberFormatException nfe) {
					return false;
				} finally {
					st = null;
				}
			}
			st = null;
			
			return true;
		}
		
		// provide click OK button
		// all condition should be valid
		public boolean isValidDateFormat(String value) {
			if(value == null)
				return false;
			if(value.equals(""))
				return false;

			Date date;
			boolean valid = true;
			Locale locale = Locale.getDefault();
			DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, locale);
			df.setLenient(false);
			try {
				date = df.parse(value);
				if(date == null) {
					valid =  false;
				}
			} catch(ParseException pe) {
				valid = false;
			}
			df = null;
			locale = null;
			date = null;
			return valid;
		}
		
		// convert locale specific date format to ISO 8601 date format
		public String convLocaleDateToISO8601(String value) {
			try {
				Locale locale = Locale.getDefault();
				DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, locale);
				df.setLenient(false);
				Date date = df.parse(value);
				Calendar calendar = Calendar.getInstance(locale);
				calendar.setTime(date);
				int y = calendar.get(Calendar.YEAR);
				int m = calendar.get(Calendar.MONTH) + 1;
				int d = calendar.get(Calendar.DAY_OF_MONTH);
				StringBuffer sb = new StringBuffer();
				if(y < 1000)
					sb.append("0");
				else if(y < 100)
					sb.append("00");
				else if(y < 10)
					sb.append("000");
				sb.append(String.valueOf(y));
				sb.append("-");
				if(m < 10)
					sb.append("0");
				sb.append(String.valueOf(m));
				sb.append("-");
				if(d < 10)
					sb.append("0");
				sb.append(String.valueOf(d));

				locale = null;
				df = null;
				date = null;
				calendar = null;
				return sb.toString(); 
			} catch(Exception e) {
				return null;
			}			
		}
		
		// convert ISO 8601 date format to locale specific date format
		public String convISO8601ToLocaleDate(String value) {
			try {
				if(value == null)
					return null;
				if(value.equals(""))
					return null;
				if(value.length() != 10)
					return null;

				StringTokenizer st = new StringTokenizer(value, "-");
				if(st.countTokens() != 3) {
					st = null;
					return null;
				}

				String sy = st.nextToken();
				if(sy.length() != 4) {
					sy = null;
					st = null;
					return null;
				}
				String sm = st.nextToken();
				if(sm.length() != 2) {
					sm = null;
					st = null;
					return null;
				}
				String sd = st.nextToken();
				if(sd.length() != 2) {
					sd = null;
					st = null;
					return null;
				}
				int iy = Integer.parseInt(sy);
				int im = Integer.parseInt(sm);
				int id = Integer.parseInt(sd);
				sy = null;
				sm = null;
				sd = null;
				st = null;

				int maxDay = 31;
				if(im == 2) {
					if(iy % 400 == 0)
						maxDay = 29;
					else if(iy % 100 == 0)
						maxDay = 28;
					else if(iy % 4 == 0)
						maxDay = 29;
					else
						maxDay = 28;
				} else if(im == 4 || im == 6 || im == 9 || im == 10){
					maxDay = 30;
				}
				if(id > maxDay)
					return null;
				
				Locale locale = Locale.getDefault();
				Calendar calendar = Calendar.getInstance(locale);
				calendar.set(iy, im-1, id);
				DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, locale);
				df.setLenient(false);

				String localeDate = df.format(calendar.getTime());
				locale = null;
				calendar = null;
				df = null;

				return localeDate;
			} catch (NumberFormatException nfe) {
				return null;
			} catch(Exception e) {
				return null;
			} 
		}
		
		// provide check default value
		// if value equal null, return false
		// if value equal "", return true
		// otherwise, call check format method
		public boolean isValidFormat(String value, int type) {
			if(value == null)
				return false;
			if(value.equals(""))
				return true;
			switch(type) {
				case QueryDialog.STANDARD :
				case QueryDialog.PASSWORD :
					return true;
				case QueryDialog.NUMERIC :
					return isValidNumericFormat(value);
				case QueryDialog.TIME :
					return isValidTimeFormat(value);
//				case QueryDialog.DATE :
//					return isValidDateFormat(value);
			}
			return true;
		}
		
		// provide real time check numeric format
		// if value equal "", valid
		// else call isValidNumericFormat
		public void modifyText(ModifyEvent e) {
			boolean valid = true;
			Text input = (Text)e.widget;
			if(this.value != null && this.value.equals(input.getText()))
				return;
			if(input.getText().equals(""))
				valid = true;
			else {
				if(queryType == QueryDialog.NUMERIC)
					valid = isValidNumericFormat(input.getText());
			}

			if(valid) {
				this.value = input.getText();
			} else {
				int position = input.getCaretPosition()-1;
				input.setText(this.value);
				input.setSelection(position);
				e.display.beep();
			}
		}
		
	}

	// QueryDialog test usage, don't trust test code
/*
	public static void main(String[] args){
		Display display = new Display();
		final Shell shell = new Shell(display);
		int minValue = 0, maxValue = 10;

		shell.setText("QueryDialog Test");
		int style = 0;//SWT.BORDER;
		
		final Button typeCheckButton = new Button(shell, SWT.CHECK | style);
		typeCheckButton.setText("QueryDialog Type : ");
		typeCheckButton.pack();

		final Combo typeCombo = new Combo(shell, SWT.DROP_DOWN);
		typeCombo.add("STANDARD");
		typeCombo.add("NUMERIC");
		typeCombo.add("PASSWORD");
		typeCombo.add("TIME");
		typeCombo.add("DATE");
		typeCombo.add("= 100");
		typeCombo.select(0);
		typeCombo.pack();
		
		final Button minCheckButton = new Button(shell, SWT.CHECK | style);
		minCheckButton.setText("Minimum Character : ");
		minCheckButton.pack();

		Button minSubButton = new Button(shell, style);
		minSubButton.setText("-");
		minSubButton.pack();

		final Label minValueLabel = new Label(shell, SWT.CENTER | style);
		minValueLabel.setText("           ");
		minValueLabel.pack();

		Button minAddButton = new Button(shell, style);
		minAddButton.setText("+");
		minAddButton.pack();

		final Button maxCheckButton = new Button(shell, SWT.CHECK | style);
		maxCheckButton.setText("Maximum Character : ");
		maxCheckButton.pack();

		Button maxSubButton = new Button(shell, style);
		maxSubButton.setText("-");
		maxSubButton.pack();

		final Label maxValueLabel = new Label(shell, SWT.CENTER | style);
		maxValueLabel.setText("           ");
		maxValueLabel.pack();

		Button maxAddButton = new Button(shell,style);
		maxAddButton.setText("+");
		maxAddButton.pack();

		final Button promptCheckButton = new Button(shell, SWT.CHECK | style);
		promptCheckButton.setText("Prompt : ");
		promptCheckButton.pack();
		
		final Text promptText = new Text(shell, SWT.SINGLE | SWT.LEFT | SWT.BORDER);
		promptText.setSize(100, 20);

		final Button valueCheckButton = new Button(shell, SWT.CHECK | style);
		valueCheckButton.setText("Value : ");
		valueCheckButton.pack();

		final Text valueText = new Text(shell, SWT.SINGLE | SWT.LEFT | SWT.BORDER);
		valueText.setSize(100, 20);

		Button openButton = new Button(shell, 0);
		openButton.setText("Open QueryDialog");
		openButton.pack();

		
		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		layout.spacing = 3;
		shell.setLayout(layout);

		FormData fd11 = new FormData();
		fd11.left = new FormAttachment(0, 0);
		fd11.top = new FormAttachment(0, 0);
		typeCheckButton.setLayoutData(fd11);

		FormData fd12 = new FormData();
		fd12.left = new FormAttachment(typeCheckButton, 0);
		fd12.top = new FormAttachment(0, 0);
		typeCombo.setLayoutData(fd12);

		FormData fd21 = new FormData();
		fd21.left = new FormAttachment(0, 0);
		fd21.top = new FormAttachment(typeCombo, 0);
		minCheckButton.setLayoutData(fd21);

		FormData fd22 = new FormData();
		fd22.left = new FormAttachment(minCheckButton, 0);
		fd22.top = new FormAttachment(typeCombo, 0);
		minSubButton.setLayoutData(fd22);

		FormData fd23 = new FormData();
		fd23.left = new FormAttachment(minSubButton, 0);
		fd23.top = new FormAttachment(typeCombo, 0);
		minValueLabel.setLayoutData(fd23);

		FormData fd24 = new FormData();
		fd24.left = new FormAttachment(minValueLabel, 0);
		fd24.top = new FormAttachment(typeCombo, 0);
		minAddButton.setLayoutData(fd24);

		FormData fd31 = new FormData();
		fd31.left = new FormAttachment(0, 0);
		fd31.top = new FormAttachment(minAddButton, 0);
		maxCheckButton.setLayoutData(fd31);

		FormData fd32 = new FormData();
		fd32.left = new FormAttachment(maxCheckButton, 0);
		fd32.top = new FormAttachment(minAddButton, 0);
		maxSubButton.setLayoutData(fd32);

		FormData fd33 = new FormData();
		fd33.left = new FormAttachment(maxSubButton, 0);
		fd33.top = new FormAttachment(minAddButton, 0);
		maxValueLabel.setLayoutData(fd33);

		FormData fd34 = new FormData();
		fd34.left = new FormAttachment(maxValueLabel, 0);
		fd34.top = new FormAttachment(minAddButton, 0);
		maxAddButton.setLayoutData(fd34);

		FormData fd41 = new FormData();
		fd41.left = new FormAttachment(0, 0);
		fd41.top = new FormAttachment(maxAddButton, 0);
		promptCheckButton.setLayoutData(fd41);
		
		FormData fd42 = new FormData();
		fd42.left = new FormAttachment(promptCheckButton, 0);
		fd42.top = new FormAttachment(maxAddButton, 0);
		fd42.right = new FormAttachment(100, 0);
		promptText.setLayoutData(fd42);
		
		FormData fd50 = new FormData();
		fd50.left = new FormAttachment(0, 0);
		fd50.top = new FormAttachment(promptCheckButton, 0);
		valueCheckButton.setLayoutData(fd50);

		FormData fd52 = new FormData();
		fd52.left = new FormAttachment(valueCheckButton, 0);
		fd52.top = new FormAttachment(promptCheckButton, 0);
		fd52.right = new FormAttachment(100, 0);
		valueText.setLayoutData(fd52);

		FormData fd9 = new FormData();
		fd9.left = new FormAttachment(0, 0);
		fd9.top = new FormAttachment(valueCheckButton, 0);
		openButton.setLayoutData(fd9);

		minSubButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int value = Integer.parseInt(minValueLabel.getText());
				if(value < 0)
					return;
				value --;
				minValueLabel.setText(String.valueOf(value));
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		minAddButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int value = Integer.parseInt(minValueLabel.getText());
				if(value > Text.LIMIT)
					return;
				value ++;
				minValueLabel.setText(String.valueOf(value));
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		maxSubButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int value = Integer.parseInt(maxValueLabel.getText());
				if(value < 0)
					return;
				value --;
				maxValueLabel.setText(String.valueOf(value));
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		maxAddButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int value = Integer.parseInt(maxValueLabel.getText());
				if(value > Text.LIMIT)
					return;
				value ++;
				maxValueLabel.setText(String.valueOf(value));
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		openButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent se) {
				try {
					QueryDialog qd;
					if(typeCheckButton.getSelection()) {
						int queryType = 100;
						String queryTypeString = typeCombo.getItem(typeCombo.getSelectionIndex());
						if(queryTypeString.equals("STANDARD"))
							queryType = QueryDialog.STANDARD;
						else if(queryTypeString.equals("NUMERIC"))
							queryType = QueryDialog.NUMERIC;
						else if(queryTypeString.equals("PASSWORD"))
							queryType = QueryDialog.PASSWORD;
						else if(queryTypeString.equals("TIME"))
							queryType = QueryDialog.TIME;
						else if(queryTypeString.equals("DATE"))
							queryType = QueryDialog.DATE;
						qd = new QueryDialog(shell, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL, queryType);
					} else {
						qd = new QueryDialog(shell, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
					}
					if(minCheckButton.getSelection()) {
						int min = Integer.parseInt(minValueLabel.getText());
						qd.setMinimum(min);
					}
					if(maxCheckButton.getSelection()) {
						int max = Integer.parseInt(maxValueLabel.getText());
						qd.setMaximum(max);					
					}
					String prompt = null;
					String value = null;
					if(promptCheckButton.getSelection()) {
						prompt = promptText.getText();
					}
					if(valueCheckButton.getSelection()) {
						value = valueText.getText();
					}
					qd.setPromptText(prompt, value);
					String result = qd.open();
					System.out.println("result : " + result);

					value = null;
					prompt = null;
					qd = null;
				} catch(Exception e) {
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					PrintStream ps = new PrintStream(baos);
					e.printStackTrace(ps);
					MessageBox mb = new MessageBox(shell, SWT.ICON_ERROR);
					mb.setMessage(baos.toString());
					mb.open();
					ps.close();
					try {
						baos.close();
					} catch(IOException ioe)  {
					}
					ps = null;
					baos = null;
					mb = null;
					
				}
			}
			public void widgetDefaultSelected(SelectionEvent e) {				
			}
		});

		shell.pack();
		minValueLabel.setText(String.valueOf(minValue));
		maxValueLabel.setText(String.valueOf(maxValue));
		shell.open();

		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
		display.dispose();
	}
*/
}
