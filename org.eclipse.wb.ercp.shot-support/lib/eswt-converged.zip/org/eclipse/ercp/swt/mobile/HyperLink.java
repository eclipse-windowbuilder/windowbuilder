/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import java.util.Locale;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

/**
 * 
 * Instances of this class represent a selectable user interface object that
 * launchs other applications when activated by the end-user.
 * 
 * <p>
 * This class represents several types of hyperlinks associated with certain
 * functionalities. The end-user can activate the associated program determined
 * by the style. The concrete visual effect and activation behavior vary from
 * platform to platform.
 * </p>
 * <p>
 * A HyperLink instance accepts general characters as other controls do, but the
 * appearance is implementation and locale dependent, for example, a HyperLink
 * object with the PHONE style might display as follows: <br>
 * (416) 123-4567 <br>
 * but the actual contents of the object visible to the application through the
 * APIs, e.g. <code>getText()</code>, can be the string "4161234567".
 * </p>
 * <p>
 * <b>Example </b>
 * 
 * <pre>
 * HyperLink email = new HyperLink(composite, SWT.NONE, HyperLink.EMAIL);
 * email.setText(&quot;firstname.lastname@foo.com&quot;);
 * HyperLink dialer = new HyperLink(composite, SWT.BORDER | SWT.LEFT,
 * 		HyperLink.PHONE);
 * dialer.setText(&quot;3581234567&quot;);
 * </pre>
 * 
 * </p>
 * <dl>
 * <dt><b>Styles: </b></dt>
 * <dd>BORDER, CENTER, LEFT, RIGHT</dd>
 * <dt><b>Format Styles: </b></dt>
 * <dd>URL: launches a platform specific web browser when activated</dd>
 * <dd>EMAIL: opens the platform specific e-mail client when activated</dd>
 * <dd>PHONE: shows a platform specific dialer interface when activated</dt>
 * <dt><b>Events: </b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * Note: Since the style provides hint for the implementation, there is no event
 * that applications need to listen to.
 * </p>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */
public class HyperLink extends org.eclipse.swt.widgets.Control {

	
	/**
	 * launches a implementation-dependent web browser when activated.
	 */
	public static final int URL = 0x01;

	/**
	 * opens the implementation-dependent e-mail client when activated.
	 */
	public static final int EMAIL = 0x01 << 1;

	/**
	 * shows the implementation-dependent dialer interface when activated.
	 */
	public static final int PHONE = 0x01 << 2;
	
	private Label label;        
 	private static Composite hackComposite;
	private static int hackStyle; 
	private Color normalForeground, activeForeground;            //foreground color
	private String argument;                                     
	private int Global_Format;
	private boolean isActive;	
	private Locale locale;
	/**
	 * Constructs a new instance of this class given its parent, a style value
	 * and a format value describing its behavior and appearance.
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. The class description lists the style constants that are
	 * applicable to the class. Style bits are also inherited from superclasses.
	 * </p>
	 * <p>
	 * The format value must be one of URL, EMAIL and PHONE.
	 * </p>
	 * 
	 * @param parent
	 *            a composite control which will be the parent of the new
	 *            instance (cannot be null)
	 * @param style
	 *            the style of control to construct
	 * @param format
	 *            the format value.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the format is invalid
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * 
	 * @see SWT#BORDER
	 * @see SWT#CENTER
	 * @see SWT#LEFT
	 * @see SWT#RIGHT
	 * @see #URL
	 * @see #EMAIL
	 * @see #PHONE
	 */
	public HyperLink(Composite parent, int style, int format) {
		super(SaveStyle(parent, checkStyle(style)),checkStyle(style));
		locale = Locale.getDefault();
		
		//throw new RuntimeException("spec implementation");
	    normalForeground = getDisplay().getSystemColor(SWT.COLOR_BLUE);     //Set word color
	    activeForeground = getDisplay().getSystemColor(SWT.COLOR_DARK_MAGENTA);  
	    this.setForeground(normalForeground);
	    checkFormat(format);
	    
	    isActive = false;
	    this.addListener(SWT.MouseUp, new Listener() {                 
	    	public void handleEvent(Event event) {
	    			if (!isActive) {
	    					return;
	    			}
	    			label.setForeground(activeForeground);
	    			//launch a platform specified relative program
	    			OS.HyperLink_Launch(label.internal_handle, Global_Format, argument);
	    	}
	    });
	    
	    this.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				OS.HyperLink_SetItalic(label.internal_handle, true);
			}

			public void focusLost(FocusEvent e) {
				OS.HyperLink_SetItalic(label.internal_handle, false);
			}
	    	
	    });
	    
	    this.addKeyListener(new KeyListener() {
			public void keyPressed(KeyEvent e) {
				if (e.character == SWT.CR) {
					if (!isActive) {
    					return;
					}
					label.setForeground(activeForeground);
					//launch a platform specified relative program
					OS.HyperLink_Launch(label.internal_handle, Global_Format, argument);
				}
			}

			public void keyReleased(KeyEvent e) {
			} 	
	    });

	}
	
	//Save style argument as global argument
	private static Composite SaveStyle(Composite parent, int style) {
		hackStyle = style;
		hackComposite = parent;
		return parent;
	}
    
	private static int checkStyle(int style)
	{
		if ((style & (SWT.SEPARATOR | SWT.HORIZONTAL | SWT.VERTICAL | SWT.WRAP | SWT.SHADOW_IN | SWT.SHADOW_OUT | SWT.SHADOW_NONE)) != 0 ) 
			style &= ~(SWT.SEPARATOR | SWT.HORIZONTAL | SWT.VERTICAL | SWT.WRAP | SWT.SHADOW_IN | SWT.SHADOW_OUT | SWT.SHADOW_NONE);
		return style;
	}
	
	
    //Check format parameter of URL, EMAIL, or PHONE
    private void checkFormat(int format)
    {
    	Global_Format = format;
    	
    	if ((format & ~(URL | EMAIL| PHONE)) != 0)
      		 SWT.error(SWT.ERROR_INVALID_ARGUMENT);    	
    	
    	if ((format & URL) == URL && ((format | URL) != URL))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if ((format & EMAIL) == EMAIL && ((format | EMAIL) != EMAIL))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if ((format & PHONE) == PHONE && ((format | PHONE) != PHONE))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
    }
    

    
    //Overwrite the setFont function of control
    public void setFont(Font font) {          
    	checkWidget();
      	super.setFont(font);
    	OS.HyperLink_SetUnderLine(internal_handle);      //Set Underline to string
    }
    

    
	/**
	 * Returns the receiver's text, which will be an empty string if it has
	 * never been set.
	 * 
	 * @return the receiver's text
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @see #setText(String)
	 */     
     //Get the string from setText function
	 public String getText() {
		//throw new RuntimeException("spec implementation");
	 	checkWidget();
	 	String return_argument = argument;
	 	if (argument == null)
	 		return_argument = "";
	 	if (Global_Format == EMAIL && return_argument.length() >= 7){
	 	 return_argument = return_argument.substring(7, return_argument.length());	
	 	}
	 	else if (Global_Format == PHONE && return_argument.length() >= 9) {
	 		return_argument = return_argument.substring(9, return_argument.length());
	 	}
        return return_argument;
	 }

	/**
	 * Sets the receiver's text.
	 * <p>
	 * This method sets the link text.
	 * </p>
	 * 
	 * @param string
	 *            the new text
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the text is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @see #getText()
	 */
	 //Set the URL, Email, or phonenumber to executive relatively
	 public void setText(String string) {
		//throw new RuntimeException("spec implementation");
	   checkWidget();	   
	   String show_string = null;
	   	   
	   if (string == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
	   if(Global_Format == URL)         //URL
	   {
	   	argument = string;
	   	show_string = string;
	   }
	   else if (Global_Format == EMAIL)       //EMAIL
	   {
	   	argument =new String("mailto:");
	   	argument= argument.concat(string);
	   	show_string = string;
	   }
	   else if (Global_Format == PHONE)         //PHONENUMBER
	   {
		//Eric, Fill in phone numer to dialer. 
	   	argument = "-url tel:" + string;
//	   	if (new String("ja_JP").equals(locale.toString()))
	   	if(Locale.JAPAN.toString().equals(locale.toString()))
			show_string = JPPhoneLocale(string);
		else if (Locale.FRANCE.toString().equals(locale.toString())) 
			show_string = FrancePhoneLocale(string); 
	    else if (Locale.CHINA.toString().equals(locale.toString()))
			show_string = ChinaPhoneLocale(string); 
	    else if (new String("pl_PL").equals(locale.toString()))
	    	show_string = PolandPhoneLocale(string); 
	   	else
	   	 show_string = DefaultPhoneLocale(string);	
	   }
	   //System.out.println(Global_Format + "    "+ Executive_file + "   "+ argument);
	   OS.HyperLink_SetUnderLine(internal_handle);
	   OS.HyperLink_SetText(internal_handle,show_string);

	   isActive = true;	   
	  }
    //Japen phone format
	private String JPPhoneLocale (String string)
	{
		String TempString = null;
		if(string.length() < 5)
			return string;
	   	else if (string.length() < 7)
	   	{
	   		TempString = string.substring(0,4);
	   		TempString = TempString.concat("-");
	   		TempString = TempString.concat(string.substring(4,string.length()));
	   		return TempString;
	   	} 
		else
		{
			TempString = string.substring(0,4);
			TempString = TempString.concat("-");
			TempString = TempString.concat(string.substring(4,6));
			TempString = TempString.concat("-");
			TempString = TempString.concat(string.substring(6,string.length()));
		}
		return TempString;
	}
	//China phone format
	private String ChinaPhoneLocale (String string) {
		String TempString= null;
		if(string.length() < 2) {
			TempString = "+";
		    TempString = TempString.concat(string);
			return TempString;
		}
		else if(string.length() < 5) {
			TempString = "+";
		    TempString = TempString.concat(string.substring(0,1));
		    TempString = TempString.concat("-");
		    TempString = TempString.concat(string.substring(1,string.length()));
			return TempString;
		}
		else
		{
			TempString = "+";
		    TempString = TempString.concat(string.substring(0,1));
		    TempString = TempString.concat("-");
		    TempString = TempString.concat(string.substring(1,4));
		    TempString = TempString.concat("-");
		    TempString = TempString.concat(string.substring(4,string.length()));
		}
		return TempString;
	}
	
	//France phone format
	private String FrancePhoneLocale (String string) {
		String TempString= null;
		if(string.length() < 3) {
			return string;
		}
		else if(string.length() < 5) {
		    TempString = string.substring(0,2);
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(2,string.length()));
			return TempString;
		}
		else if(string.length() < 7) {
		    TempString = string.substring(0,2);
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(2,4));
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(4,string.length()));
			return TempString;
		}
		else if(string.length() < 9) {
		    TempString = string.substring(0,2);
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(2,4));
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(4,6));
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(6,string.length()));
			return TempString;
		}
		else
		{
		    TempString = string.substring(0,2);
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(2,4));
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(4,6));
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(6,8));
		    TempString = TempString.concat(" ");
		    TempString = TempString.concat(string.substring(8,string.length()));
		}
		return TempString;
	}
	
	//Poland phone format
	private String PolandPhoneLocale (String string) {
		String TempString= null;
		if(string.length() < 9)
			return string;
		else
		{
			TempString = "(";
			TempString = TempString.concat(string.substring(0,2));
			TempString = TempString.concat(") ");
			TempString = TempString.concat(string.substring(2,5));
			TempString = TempString.concat(".");
			TempString = TempString.concat(string.substring(5,7));
			TempString = TempString.concat(".");
			TempString = TempString.concat(string.substring(7,string.length()));
		}
		return TempString;
	}
	
	private String DefaultPhoneLocale (String string) {
		String TempString= null;
		if(string.length() < 3)
			return string;
	   	else if (string.length() < 7)
	   	{
	   		TempString = "(";
	   		TempString = TempString.concat(string.substring(0,3));
	   		TempString = TempString.concat(")");
	   		TempString = TempString.concat(string.substring(3,string.length()));
	   		return TempString;
	   	} 
		else
		{
			TempString = "(";
			TempString = TempString.concat(string.substring(0,3));
			TempString = TempString.concat(")");
			TempString = TempString.concat(string.substring(3,6));
			TempString = TempString.concat("-");
			TempString = TempString.concat(string.substring(6,string.length()));
		}
		return TempString;
	}
	 
	int i=0;
	public void internal_createHandle(int index) {		
		label = new Label(hackComposite, checkStyle(hackStyle));
		internal_handle = label.internal_handle;
        hackComposite.internal_removeChild(label);
	}
	
	public boolean allowTraverseByArrowKey(Event event) {
		switch (event.keyCode) {
			case SWT.ARROW_UP :
			case SWT.ARROW_LEFT :
			case SWT.ARROW_DOWN :
			case SWT.ARROW_RIGHT :
			return true;
		}
		return false;
	}

	protected boolean traverse(Event event) {
		if (isDisposed()) return false;
		if(allowTraverseByArrowKey(event)) {
			return traverseByArrowKey(event);
		}
		return super.traverse(event);
	}
	
}