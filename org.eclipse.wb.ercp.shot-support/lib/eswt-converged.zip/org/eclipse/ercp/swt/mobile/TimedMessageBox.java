/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Display;

import java.io.InputStream;
import java.util.Date;

// TimedMessageBox test usage
/*
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.MessageBox;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
*/
/**
 * A modal window used to shortly inform the user of limited information using a
 * standard style.
 * 
 * <p>
 * A TimedMessageBox is capable of closing itself automatically after a certain
 * period of time. There is no need to define button styles for TimedMessageBox.
 * </p>
 * 
 * <p>
 * Unlike TaskTip, the TimedMessageBox is a modal dialog and execution will
 * be blocked until the dialog is closed after a short period of time. The exact
 * time-out duration is implementation dependent. Applications can not change
 * the period of time.
 * </p>
 * <dl>
 * <dt><b>Styles: </b></dt>
 * <dd>ICON_WORKING: informs that an action was successful</dd>
 * <dd>ICON_INFORMATION: informs of a situation that may not require user
 * action</dd>
 * <dd>ICON_WARNING: informs of a situation that may require user intervention
 * </dd>
 * <dd>ICON_ERROR: informs that a serious situation occurred</dd>
 * </dd>
 * <dt><b>Events: </b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */
public class TimedMessageBox extends Dialog {
	// default layout setting
	private final static int MARGIN_WIDTH = 3;
	private final static int MARGIN_HEIGHT = 3;
	private final static int SHELL_MARGIN_WIDTH = 20;
	private final static int SPACING = 3;
	private final static int MENU_HEIGHT = 26;

	private final static int DEFAULT_DURATION = 5000;	// ms
	private long duration = DEFAULT_DURATION;

	private int iconStyle = SWT.NONE;
	Label label;
	Text text;
	Image image;
	String message;
	Thread thread;

	/**
	 * Constructs a new instance of this class given only its parent.
	 * 
	 * @param parent
	 *            a shell which will be the parent of the new instance
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 */
	public TimedMessageBox(Shell parent) {
		this(parent, SWT.ICON_INFORMATION | SWT.APPLICATION_MODAL);
	}

	/**
	 * Constructs a new instance of this class given its parent and a style
	 * value describing its behavior and appearance.
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. The class description lists the style constants that are
	 * applicable to the class. Style bits are also inherited from superclasses.
	 * </p>
	 * 
	 * @param parent
	 *            a shell which will be the parent of the new instance
	 * @param style
	 *            the style of control to construct
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 */
	public TimedMessageBox(Shell parent, int style) {
		super(parent, checkStyle(style));
		if((style & SWT.ICON_WORKING) == SWT.ICON_WORKING)
			iconStyle = SWT.ICON_WORKING;
		else if((style & SWT.ICON_INFORMATION) == SWT.ICON_INFORMATION)
			iconStyle = SWT.ICON_INFORMATION;
		else if((style & SWT.ICON_WARNING) == SWT.ICON_WARNING)
			iconStyle = SWT.ICON_WARNING;
		else if((style & SWT.ICON_ERROR) == SWT.ICON_ERROR)
			iconStyle = SWT.ICON_ERROR;
		thread = Thread.currentThread();
	}

	static int checkStyle(int style) {
		if ((style & (SWT.PRIMARY_MODAL | SWT.APPLICATION_MODAL | SWT.SYSTEM_MODAL)) == 0)
			style |= SWT.APPLICATION_MODAL;
		return style;
	}

	/**
	 * Returns the icon object.
	 * 
	 * @return Image the icon reference. May by null if the implementation does
	 *         not support custom icons, or has no way to get the image object.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public Image getImage() {
		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		return this.image;
	}

	/**
	 * Returns the dialog's message, which is a description of the purpose for
	 * which it was opened. This message will be visible on the dialog while it
	 * is open.
	 * 
	 * @return the message
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public String getMessage() {
		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		return message;
	}

	/**
	 * Makes the dialog visible and brings it to the front of the display.
	 * 
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the dialog</li>
	 *                </ul>
	 */

	public void open() {
		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		Display display;
		Shell shell, parent;
		Label icon, msg;	// icon and message
		Text text;			// for calculate message height
		int maxw, maxh;
		int iconh;
		int msgw, msgh;
		int shellx, shelly, shellw, shellh;
		int titleHeight;

		parent = getParent();
		display = parent.getDisplay();
		maxw = display.getBounds().width;
		maxh = display.getBounds().height;

		shell = new Shell(parent, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL | SWT.BORDER);
		shell.setText(getText());

		text = new Text(shell, SWT.LEFT | SWT.WRAP  | SWT.MULTI);
		icon = new Label(shell, SWT.LEFT);

		if(image == null)
			image = getSystemIcon(display, iconStyle);

		if(image != null)
			icon.setImage(image);
		
		icon.pack();
		icon.setLocation(MARGIN_WIDTH, MARGIN_HEIGHT);
		iconh = icon.getBounds().height;

		shell.pack();
		titleHeight = shell.getBounds().height - iconh - MARGIN_HEIGHT;
		
		// wm2003 shell bound 
		shellw = maxw - SHELL_MARGIN_WIDTH;
		shellh = maxh - titleHeight - MENU_HEIGHT;
		shellx = SHELL_MARGIN_WIDTH/2;
		shelly = titleHeight;
		if(org.eclipse.swt.SWT.getPlatform().equals("win32")) {
			shellw = maxw/2;
			shellh = maxh/2;
			shellx = shellw/2;
			shelly = shellh/2;
		}

		text.setSize(shellw - icon.getSize().x - MARGIN_WIDTH * 3, shellh);
		if (message != null) text.setText(message);
		msgw = text.getBounds().width;
		msgh = text.getLineCount() * text.getLineHeight();

		int h = msgh;
		if(iconh > msgh)
			h = iconh;
		if(h + titleHeight < shellh) {
			shellh = h + titleHeight + MARGIN_HEIGHT * 2;
			if(org.eclipse.swt.SWT.getPlatform().equals("wm2003"))
				shelly = (maxh - shellh)/2;
		}

		msg = new Label(shell, SWT.LEFT | SWT.WRAP);
		if (message != null) msg.setText(message);
		msg.setLocation(icon.getLocation().x + icon.getSize().x + MARGIN_WIDTH, MARGIN_HEIGHT);
		msg.setSize(msgw, msgh);

		text.dispose();
		text = null;
		
		shell.setBounds(shellx, shelly, shellw, shellh);
		shell.open();

		new Thread(new DisposeThread(shell)).start();
		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
	}
	/**
	 * Sets the receiver's icon to the argument.
	 * 
	 * The argument cannot be null.
	 * 
	 * @param image
	 *            the image to display on the receiver.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the image is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the image has been
	 *                disposed</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setImage(Image image) {
		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		if(image == null) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		if(image.internal_handle == 0) {
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			return;
		}
		this.image = image;
		
	}

	/**
	 * Sets the dialog's message, which is a description of the purpose for
	 * which it was opened. This message will be visible on the dialog while it
	 * is open.
	 * 
	 * @param string
	 *            the message
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setMessage(String string) {
		if (thread != Thread.currentThread()) SWT.error(SWT.ERROR_THREAD_INVALID_ACCESS);
		if (string == null) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		message = new String(string);
	}
	
	private Image getSystemIcon(Display display, int style) {
		String iconName = getSystemIconName(style);
		if(iconName != null) {
			InputStream stream = this.getClass().getResourceAsStream("/resources/"+iconName);
			return (new Image(display, stream));
		}
		return null;
	}

	private String getSystemIconName(int style) {
		switch(style) {
			case SWT.ICON_WORKING :
				return "IconWorking.png";
			case SWT.ICON_ERROR:
				return "IconError.png";
			case SWT.ICON_INFORMATION:
				return "IconInformation.png";
			case SWT.ICON_WARNING :
				return "IconWarning.png";		
		}
		return null;
	}
	
	public class DisposeThread implements Runnable {
		long sleepTime = 100;
		final Shell shell;
		final Display display;
		final long start;
		public DisposeThread(Shell shell) {
			this.shell = shell;
			display = shell.getDisplay();
			start = (new Date()).getTime();
        }
		public void run() {
			while(!shell.isDisposed()) { 
				try {
					Thread.sleep(sleepTime);
				} catch(Exception e) {
					return;
				}
				long check = (new Date()).getTime();
				if(check - start >= duration) {
					display.asyncExec(new Runnable() {
						public void run() {
							shell.dispose();
						}
					});
				}
			}
		}
	}
	

	// TimedMessageBox test usage
/*
	public static void main(String[] args){
		final Display display = new Display();
		final Shell shell = new Shell(display);

		shell.setText("TimedMessageBox Test");
		int style = 0;//SWT.BORDER;
		
		final Button iconCheckButton = new Button(shell, SWT.CHECK | style);
		iconCheckButton.setText("Icon Type : ");
		iconCheckButton.pack();

		final Combo iconCombo = new Combo(shell, SWT.DROP_DOWN);
		iconCombo.add("WORKING");
		iconCombo.add("INFORMATION");
		iconCombo.add("WARNING");
		iconCombo.add("ERROR");
		iconCombo.select(0);
		iconCombo.pack();

		final Button imageCheckButton = new Button(shell, SWT.CHECK | style);
		imageCheckButton.setText("Set Image : ");
		imageCheckButton.pack();

		final Combo imageCombo = new Combo(shell, SWT.DROP_DOWN);
		imageCombo.add("/iMac.JPG");
		imageCombo.add("/Girl.png");
		imageCombo.select(0);
		imageCombo.pack();

		final Button messageCheckButton = new Button(shell, SWT.CHECK | style);
		messageCheckButton.setText("Set Message : ");
		messageCheckButton.pack();
	
		final Text messageText = new Text(shell, SWT.MULTI | SWT.WRAP | SWT.LEFT | SWT.BORDER);

		Button openButton = new Button(shell, 0);
		openButton.setText("Open TimedMessageBox");
		openButton.pack();

		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		layout.spacing = 3;
		shell.setLayout(layout);

		FormData fd11 = new FormData();
		fd11.left = new FormAttachment(0, 0);
		fd11.top = new FormAttachment(0, 0);
		iconCheckButton.setLayoutData(fd11);

		FormData fd12 = new FormData();
		fd12.left = new FormAttachment(iconCheckButton, 0);
		fd12.top = new FormAttachment(0, 0);
		iconCombo.setLayoutData(fd12);

		FormData fd21 = new FormData();
		fd21.left = new FormAttachment(0, 0);
		fd21.top = new FormAttachment(iconCombo, 0);
		imageCheckButton.setLayoutData(fd21);

		FormData fd22 = new FormData();
		fd22.left = new FormAttachment(imageCheckButton, 0);
		fd22.top = new FormAttachment(iconCombo, 0);
		imageCombo.setLayoutData(fd22);

		FormData fd41 = new FormData();
		fd41.left = new FormAttachment(0, 0);
		fd41.top = new FormAttachment(imageCombo, 0);
		messageCheckButton.setLayoutData(fd41);

		FormData fd42 = new FormData();
		fd42.left = new FormAttachment(messageCheckButton, 0);
		fd42.top = new FormAttachment(imageCombo, 0);
		fd42.right = new FormAttachment(100, 0);
		fd42.bottom = new FormAttachment(iconCheckButton, 100);
		messageText.setLayoutData(fd42);

		FormData fd9 = new FormData();
		fd9.left = new FormAttachment(0, 0);
		fd9.top = new FormAttachment(messageText, 0);
		openButton.setLayoutData(fd9);

		openButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent se) {
				try {
					TimedMessageBox tmb;
					if(iconCheckButton.getSelection()) {
						int iconType = SWT.NONE;
						String queryTypeString = iconCombo.getItem(iconCombo.getSelectionIndex());
						if(queryTypeString.equals("WORKING"))
							iconType = SWT.ICON_WORKING;
						else if(queryTypeString.equals("INFORMATION"))
							iconType = SWT.ICON_INFORMATION;
						else if(queryTypeString.equals("WARNING"))
							iconType = SWT.ICON_WARNING;
						else if(queryTypeString.equals("ERROR"))
							iconType = SWT.ICON_ERROR;
						tmb = new TimedMessageBox(shell, iconType);
					} else {
						tmb = new TimedMessageBox(shell);
					}
					if(imageCheckButton.getSelection()) {
						String imageFileName = imageCombo.getItem(imageCombo.getSelectionIndex());
						tmb.setImage(new Image(display, imageFileName));
					}

					String message = null;
					if(messageCheckButton.getSelection()) {
						message = messageText.getText();
					}
					tmb.setMessage(message);
					tmb.open();

					message = null;
					tmb = null;
				} catch(Exception e) {
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					PrintStream ps = new PrintStream(baos);
					e.printStackTrace(ps);
					MessageBox mb = new MessageBox(shell, SWT.ICON_ERROR);
					mb.setMessage(baos.toString());
					mb.open();
					ps.close();
					try {
						baos.close();
					} catch(IOException ioe)  {
					}
					ps = null;
					baos = null;
					mb = null;
					
				}
			}
			public void widgetDefaultSelected(SelectionEvent e) {				
			}
		});

		shell.pack();
		shell.open();

		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
		display.dispose();
	}
*/
}
