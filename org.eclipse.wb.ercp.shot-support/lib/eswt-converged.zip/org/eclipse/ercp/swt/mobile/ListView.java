/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import java.util.Arrays;
import java.util.Vector;

import org.eclipse.swt.*;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Scrollable;
import org.eclipse.swt.widgets.TypedListener;

/**
 * 
 * A widget that allows the user to select one or more items from a collection
 * of items that can be displayed in a multi-column way with different styles.
 * 
 * <p>
 * ListView lays out its children items in one or more columns from top to
 * bottom. If a layout orientation hint is not specified, the implementation
 * chooses the orientation. If there is only enough screen width for one column,
 * the list scrolls vertically. If there is room to display multiple columns
 * within the widget, then the list scrolls horizontally. The list never scrolls
 * in more than one direction. The layout orientation may be set at runtime by
 * calling method <code>setLayout(int)</code>.
 * <p>
 * The item density hint determines the size and positioning of items in order
 * to fit more or less within the widget. Applications can query the preferred
 * sizes of the icons for each density level. Note that the sizes may be diverse
 * in different platforms. When the given icons do not match the prefered size,
 * the implementation may adjust icon sizes without throwing any exception.
 * Applications can change the item density level at runtime by calling method
 * <code>setLayoutDensity(int)</code>. Some platforms may use
 * context-sensitive device keys to allow the user to change the ListView's
 * density level at run-time. For example, by activating "zoom in/out" device
 * keys when the ListView is focused.
 * <p>
 * Applications can query the current layout and density values by calling the
 * corresponding "get" methods.
 * 
 * <dl>
 * <dt><b>SWT styles: </b></dt>
 * <dd>SINGLE, MULTI: single or multiple selection</dd>
 * <dd>VERTICAL, HORIZONTAL: defines the layout orientation</dd>
 * <dt><b>ListView density levels: </b></dt>
 * <dd>HIGH, MEDIUM (default), LOW: defines the item density levels that
 * determine the numbers of visible list items per screen</dd>
 * <dt><b>Events: </b></dt>
 * <dd>Selection, DefaultSelection</dd>
 * </dl>
 * <p>
 * Note: If styles not applicable to ListView are specified, they are ignored.
 * </p>
 * <p>
 * Note: ListView is a subclass of Scrollable. Changing the scrollbar values (
 * <code>ScrollBar.setSelection(int)</code>) will affect the scrolling
 * position of the ListView control. However, changing the range of scrollbars,
 * such as <code>setMaximum(int)</code> and <code>setMinimum(int)</code>,
 * will not affect the ListView at all.
 * </p>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */
public class ListView extends Scrollable {

	/**
	 * A low density level.
	 * 
	 * <P>
	 * Value <code>1</code> is assigned to <code>LOW</code>.
	 * </P>
	 *  
	 */
	public static final int LOW = 1;

	/**
	 * A medium density level.
	 * 
	 * <P>
	 * Value <code>2</code> is assigned to <code>MEDIUM</code>.
	 * </P>
	 *  
	 */
	public static final int MEDIUM = 2;

	/**
	 * A high density level.
	 * <P>
	 * Value <code>3</code> is assigned to <code>HIGH</code>.
	 * </P>
	 * </DL>
	 *  
	 */
	public static final int HIGH = 3;
	
	private int density = MEDIUM;
	private Vector items;
	private static Object fLock = new Object();
	private static boolean isInit = false;
	private Color disabledcolor = null;
	private void init() {
		// TODO Auto-generated method stub		
		synchronized (fLock) {
			if(!isInit)
			{
				//Register Callback function to Display widget.
				com.ibm.ugl.p3ml.OS.Display_RegisterCallback(getDisplay().internal_handle, OS.CALLBACK_LISTVIEW, "org/eclipse/ercp/swt/mobile/ListView", "ListViewCallback");
				isInit=true;
			}
		}
		
	}
	
	/**
	 * Constructs a new instance of this class given its parent and a style
	 * value describing its behavior and appearance.
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. The class description lists the style constants that are
	 * applicable to the class. Style bits are also inherited from superclasses.
	 * </p>
	 * 
	 * @param parent
	 *            a widget which will be the parent of the new instance (cannot
	 *            be null)
	 * @param style
	 *            the style value of the widget to construct. See <a
	 *            href="#description">Description </a> for details.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * 
	 * @see SWT#SINGLE
	 * @see SWT#MULTI
	 * @see SWT#HORIZONTAL
	 * @see SWT#VERTICAL
	 */
	public ListView(Composite parent, int style) {
		this(parent, style, MEDIUM);
	}

	/**
	 * Constructs a new instance of this class given its parent and a style
	 * value describing its behavior and appearance styles.
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. The class description lists the style constants that are
	 * applicable to the class. Style bits are also inherited from superclasses.
	 * </p>
	 * 
	 * <p>
	 * The density style is one of HIGH, MEDIUM and LOW.
	 * </p>
	 * 
	 * @param parent
	 *            a widget which will be the parent of the new instance (cannot
	 *            be null)
	 * @param style
	 *            the style value of the widget to construct. See <a
	 *            href="#description">Description </a> for details.
	 * @param density
	 *            the density style value.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the density is invalid
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * 
	 * @see SWT#SINGLE
	 * @see SWT#MULTI
	 * @see SWT#HORIZONTAL
	 * @see SWT#VERTICAL
	 * @see #HIGH
	 * @see #MEDIUM
	 * @see #LOW
	 * @see #getLayoutDensity
	 */
	public ListView(Composite parent, int style, int density) {
		super(parent, checkStyle(style));
		if (parent == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

		init();
		items = new Vector();
		setLayoutDensity(density);
	}
	
	private static int checkStyle(int style) {
		int nStyle = style;
		if (!((style & SWT.VERTICAL) == SWT.VERTICAL)) {
			nStyle |= SWT.HORIZONTAL;
		}
		if (!((style & SWT.SINGLE) == SWT.SINGLE)) {
			nStyle |= SWT.MULTI;
		}
		return nStyle;		
	}

	/**
	 * Returns the value of the item density level.
	 * 
	 * @return the density level. One of HIGH, MEDIUM, or LOW.
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see ListView#LOW
	 * @see ListView#MEDIUM
	 * @see ListView#HIGH
	 */
	public int getLayoutDensity() {
		checkWidget();
		return density;
	}

	/**
	 * Returns the value of the layout orientation.
	 * 
	 * 
	 * @return the scrolling orientation value. One of SWT.VERTICAL and
	 *         SWT.HORIZONTAL
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see SWT#HORIZONTAL
	 * @see SWT#VERTICAL
	 */
	public int getLayout() {
		checkWidget();
		if (SWT.HORIZONTAL == (internal_style & SWT.HORIZONTAL))  return SWT.HORIZONTAL;
		else return SWT.VERTICAL; //default SWT.VERTICAL
	}

	/**
	 * Adds the string item and an optional icon to the end of the receiver's
	 * list.
	 * 
	 * @param item
	 *            the new item text
	 * @param icon
	 *            the icon of the item, or null.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the item is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_ADDED - if the operation fails because
	 *                of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see #add(String,Image, int)
	 */
	public void add(String item, Image icon) {
		checkWidget();
		if (item == null)	SWT.error(SWT.ERROR_NULL_ARGUMENT);

		boolean success;
		ListViewItem lvItem = new ListViewItem(item, icon);
		success = OS.ListView_Add(internal_handle ,lvItem.getText(), lvItem.getIconHandle(), items.size());
		
		if(success)
			items.add(lvItem);
	}

	/**
	 * Adds the string item and an optional icon to the receiver's list at the
	 * given zero-relative index.
	 * <p>
	 * Note: To add an item at the end of the list, use the result of calling
	 * <code>getItemCount()</code> as the index or use
	 * <code>add(String, Image)</code>.
	 * </p>
	 * 
	 * @param string
	 *            the new item
	 * @param icon
	 *            the icon part of the item, or null.
	 * @param index
	 *            the index for the item
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                <li>ERROR_INVALID_RANGE - if the index is not between 0
	 *                and the number of elements in the list (inclusive)</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_ADDED - if the operation fails because
	 *                of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see #add(String, Image)
	 */
	public void add(String string, Image icon, int index) {
		checkWidget();
		if (string == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		if (index < 0 || index > items.size()) SWT.error(SWT.ERROR_INVALID_RANGE);

		boolean success;
		ListViewItem item = new ListViewItem(string, icon);
		success = OS.ListView_Add(internal_handle ,item.getText(), item.getIconHandle(), index);
		
		if(success)
			items.add(index, item);
	}

	/**
	 * Adds the listener to the collection of listeners who will be notified
	 * when the receiver's selection changes. The listener receives the messages
	 * defined in the <code>SelectionListener</code> interface.
	 * <p>
	 * <code>widgetSelected</code> is called when the selection changes.
	 * <code>widgetDefaultSelected</code> is typically called when an item is
	 * double-clicked.
	 * </p>
	 * 
	 * @param listener
	 *            the listener which should be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see SelectionListener
	 * @see #removeSelectionListener
	 * @see org.eclipse.swt.events.SelectionEvent
	 */
	public void addSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

		TypedListener typedListener = new TypedListener(listener);
		addListener(SWT.Selection, typedListener);
		addListener(SWT.DefaultSelection, typedListener);
	}

	/**
	 * Deselects the item at the given zero-relative index in the receiver. If
	 * the item at the index was already deselected, it remains deselected.
	 * Indices that are out of range are ignored.
	 * 
	 * @param index
	 *            the index of the item to deselect
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deselect(int index) {
		checkWidget();
		if ((index <0) || (index>items.size())) return;
		OS.ListView_Select(internal_handle,index,false);
	}

	/**
	 * Deselects the items at the given zero-relative indices in the receiver.
	 * If the items at the given zero-relative indexes in the receiver were
	 * selected, they are deselected. If they were not selected, they remain
	 * deselected. The range of the indices is inclusive. Indices that are out
	 * of range are ignored.
	 * 
	 * @param start
	 *            the start index of the items to deselect
	 * @param end
	 *            the end index of the items to deselect
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deselect(int start, int end) {
		checkWidget();

		if (end < start) { // if end < start, exchange start and end
			int temp = end;
			end = start;
			start = temp;
		}
		for (int i = start; i < end+1; i++) {
			OS.ListView_Select(internal_handle,i,false);
		}
	}

	/**
	 * Deselects the items at the given zero-relative indices in the receiver.
	 * If the items at the given zero-relative indexes in the receiver are
	 * selected, they are deselected. If they were not selected, they remain
	 * deselected. Indices that are out of range and duplicate indices are
	 * ignored.
	 * 
	 * @param indices
	 *            the array of indices for the items to deselect
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the set of indices is null
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deselect(int[] indices) {
		checkWidget();
		if (null == indices) SWT.error(SWT.ERROR_NULL_ARGUMENT);

		for (int i = 0; i < indices.length; i++) {
			OS.ListView_Select(internal_handle,indices[i],false);
		}	
	}

	/**
	 * Deselects all selected items in the receiver.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deselectAll() {
		checkWidget();

		OS.ListView_Select(internal_handle,-1,false);
	}

	/**
	 * Returns the zero-relative index of the item which currently has the focus
	 * in the receiver, or -1 if no item has focus.
	 * 
	 * @return the index of the selected item
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public int getFocusIndex() {
		checkWidget();

		return OS.ListView_GetFocusIndex(internal_handle);
	}

	/**
	 * Returns the item at the given, zero-relative index in the receiver.
	 * Throws an exception if the index is out of range.
	 * 
	 * @param index
	 *            the index of the item to return
	 * @return the item at the given index
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the index is not between 0
	 *                and the number of elements in the list minus 1 (inclusive)
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_ITEM - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public String getItem(int index) {
		checkWidget();
		if (index < 0 || index >= items.size()) SWT.error(SWT.ERROR_INVALID_RANGE);

		return ((ListViewItem)items.elementAt(index)).getText();
	}

	/**
	 * Returns the item icon at the given, zero-relative index in the receiver.
	 * Throws an exception if the index is out of range.
	 * 
	 * @param index
	 *            the index of the item to return
	 * @return the associated icon at the given index. Null means no icon
	 *         defined.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the index is not between 0
	 *                and the number of elements in the list minus 1 (inclusive)
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_ITEM - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public Image getIcon(int index) {
		checkWidget();
		if (index < 0 || index >= items.size()) SWT.error(SWT.ERROR_INVALID_RANGE);
		
		return ((ListViewItem)items.elementAt(index)).getIcon();
	}

	/**
	 * Gets the preferred icon size that matches the density style. The style
	 * must be one of HIGH, MEDIUM, or or LOW.
	 * 
	 * @param style
	 *            the size style. Only HIGH, MEDIUM, and LOW can be used.
	 * 
	 * @return Point the best icon size in pixel (width and height). Must be
	 *         positive values.
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the style value is
	 *                invalid</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 *                
	 * @see ListView#LOW
	 * @see ListView#MEDIUM
	 * @see ListView#HIGH
	 */
	public Point getIconSize(int style) {
		checkWidget();
		if ((style != HIGH) && (style != MEDIUM) && (style != LOW)) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		int width = OS.ListView_GetIconSize(internal_handle,style);

		return (new Point(width, width));
	}

	/**
	 * Returns the number of items contained in the receiver.
	 * 
	 * @return the number of items
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_COUNT - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public int getItemCount() {
		checkWidget();

		return items.size();
	}

	/**
	 * Returns an array of <code>String</code> s which are the items in the
	 * receiver.
	 * <p>
	 * Note: This is not the actual structure used by the receiver to maintain
	 * its list of items, so modifying the array will not affect the receiver.
	 * </p>
	 * 
	 * @return the items in the receiver's list
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_ITEM - if the operation fails
	 *                because of an operating system failure while getting an
	 *                item</li>
	 *                <li>ERROR_CANNOT_GET_COUNT - if the operation fails
	 *                because of an operating system failure while getting the
	 *                item count</li>
	 *                </ul>
	 */
	public String[] getItems() {
		checkWidget();

		String[] array = new String[items.size()];
		for (int i=0; i<array.length; i++) {
			ListViewItem item = (ListViewItem)items.elementAt(i);
			array[i] = item.getText();
		}
		return array;
	}

	/**
	 * Returns an array of <code>String</code> s that are currently selected
	 * in the receiver. An empty array indicates that no items are selected.
	 * <p>
	 * Note: This is not the actual structure used by the receiver to maintain
	 * its selection, so modifying the array will not affect the receiver.
	 * </p>
	 * 
	 * @return an array representing the selection
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_SELECTION - if the operation fails
	 *                because of an operating system failure while getting the
	 *                selection</li>
	 *                <li>ERROR_CANNOT_GET_ITEM - if the operation fails
	 *                because of an operating system failure while getting an
	 *                item</li>
	 *                </ul>
	 */
	public String[] getSelection() {
		checkWidget();

		int[] selectionIndices = getSelectionIndices();
		int selectionCount = selectionIndices.length;
		String[] result = new String[getSelectionCount()];
		
		for (int i=0; i<selectionCount; i++) {
			ListViewItem item = (ListViewItem)items.elementAt(selectionIndices[i]);
			result[i] = item.getText();
		}
		return result;
	}

	/**
	 * Returns the number of selected items contained in the receiver.
	 * 
	 * @return the number of selected items
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_COUNT - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public int getSelectionCount() {
		checkWidget();
		
		return OS.ListView_GetSelectionCount(internal_handle);
	}

	/**
	 * Returns the zero-relative indices of the items which are currently
	 * selected in the receiver. The array is empty if no items are selected.
	 * <p>
	 * Note: This is not the actual structure used by the receiver to maintain
	 * its selection, so modifying the array will not affect the receiver.
	 * </p>
	 * 
	 * @return the array of indices of the selected items
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_SELECTION - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public int[] getSelectionIndices() {
		checkWidget();

		return OS.ListView_GetSelectionIndices(internal_handle);
	}

	/**
	 * Returns the zero-relative index of the item which is currently at the top
	 * of the receiver. This index can change when items are scrolled or new
	 * items are added or removed.
	 * 
	 * @return the index of the top item
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public int getTopIndex() {
		checkWidget();

		return OS.ListView_GetTopItemIndex(internal_handle);
	}

	/**
	 * Gets the index of an item.
	 * <p>
	 * The list is searched starting at 0 until an item is found that is equal
	 * to the search item. If no item is found, -1 is returned. Indexing is zero
	 * based.
	 * 
	 * @param string
	 *            the search item
	 * @return the index of the item
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public int indexOf(String string) {
		checkWidget();
		return indexOf(string, 0);
	}

	/**
	 * Searches the receiver's list starting at the given, zero-relative index
	 * until an item is found that is equal to the argument, and returns the
	 * index of that item. If no item is found or the starting index is out of
	 * range, returns -1.
	 * 
	 * @param string
	 *            the search item
	 * @param start
	 *            the zero-relative index at which to start the search
	 * @return the index of the item
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_COUNT - if the operation fails
	 *                because of an operating system failure while getting the
	 *                item count</li>
	 *                <li>ERROR_CANNOT_GET_ITEM - if the operation fails
	 *                because of an operating system failure while getting an
	 *                item</li>
	 *                </ul>
	 */
	public int indexOf(String string, int start) {
		checkWidget();
		if (string == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

		if(start < 0 || start >= items.size())
			return -1;

		for(int i=start; i<items.size(); i++) {
			ListViewItem item = (ListViewItem)items.elementAt(i);
			if(item.getText().equals(string))
				return i;
		}
		
		return -1;
	}

	/**
	 * Returns <code>true</code> if the item is selected, and
	 * <code>false</code> otherwise. Indices out of range are ignored.
	 * 
	 * @param index
	 *            the index of the item
	 * @return the visibility state of the item at the index
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public boolean isSelected(int index) {
		checkWidget();

		return OS.ListView_IsSelected(internal_handle,index);
	}

	/**
	 * Removes the item from the receiver at the given zero-relative index.
	 * 
	 * @param index
	 *            the index for the item
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the index is not between 0
	 *                and the number of elements in the list minus 1 (inclusive)
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public void remove(int index) {
		checkWidget();
		if ((index < 0) || (index >= items.size())) SWT.error(SWT.ERROR_INVALID_RANGE);

		boolean success;
		success = OS.ListView_Delete(internal_handle,index);
		if(success)
			items.remove(index);
	}

	/**
	 * Removes the items from the receiver which are between the given
	 * zero-relative start and end indices (inclusive).
	 * 
	 * @param start
	 *            the start of the range
	 * @param end
	 *            the end of the range
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if either the start or end are
	 *                not between 0 and the number of elements in the list minus
	 *                1 (inclusive)</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public void remove(int start, int end) {
		checkWidget();
		if ((start < 0) || (start >= items.size())) SWT.error(SWT.ERROR_INVALID_RANGE);
		if ((end < 0) || (end >= items.size())) SWT.error(SWT.ERROR_INVALID_RANGE);

		int temp;
		if (start > end) { //exchange start and end
			temp = end;
			end = start;
			start = temp;
		}
		boolean success;
		for (int i=end; i>=start; i--) {
			success = OS.ListView_Delete(internal_handle,i);
			if(success)
				items.remove(i);
		}
	}

	/**
	 * Searches the receiver's list starting at the first item until an item is
	 * found that is equal to the argument, and removes that item from the list.
	 * 
	 * @param string
	 *            the item to remove
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the string is not found
	 *                in the list</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public void remove(String string) {
		checkWidget();
		if (string == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

		int index = indexOf(string);
		if (index < 0) SWT.error(SWT.ERROR_INVALID_ARGUMENT);

		boolean success;
		success = OS.ListView_Delete(internal_handle,index);
		if(success)		
			items.remove(index);
	}

	/**
	 * Removes the items from the receiver at the given zero-relative indices.
	 * 
	 * @param indices
	 *            the array of indices of the items
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the index is not between 0
	 *                and the number of elements in the list minus 1 (inclusive)
	 *                </li>
	 *                <li>ERROR_NULL_ARGUMENT - if the indices array is null
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public void remove(int[] indices) {
		checkWidget();
		if (null == indices) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		for (int i=0; i< indices.length; i++) {
			if ((indices[i] < 0) || (indices[i] >= items.size())) SWT.error(SWT.ERROR_INVALID_RANGE);
		}

		int[] tmp = new int[indices.length];
		System.arraycopy(indices, 0, tmp, 0, indices.length);
		Arrays.sort(tmp);
		boolean success;
		for (int i=tmp.length -1; i>=0; i--) {
			success = OS.ListView_Delete(internal_handle,tmp[i]);
			if(success)
				items.remove(tmp[i]);
		}
	}

	/**
	 * Removes all of the items from the receiver.
	 * <p>
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void removeAll() {
		checkWidget();

		OS.ListView_DeleteAll(internal_handle);
		items.clear();
	}

	/**
	 * Removes the listener from the collection of listeners who will be
	 * notified when the receiver's selection changes.
	 * 
	 * @param listener
	 *            the listener which should no longer be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see SelectionListener
	 * @see #addSelectionListener
	 */
	public void removeSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

		removeListener(SWT.Selection, listener);		
		removeListener(SWT.DefaultSelection, listener);		
	}

	/**
	 * Selects the item at the given zero-relative index in the receiver's list.
	 * If the item at the index was already selected, it remains selected.
	 * Indices that are out of range are ignored.
	 * 
	 * @param index
	 *            the index of the item to select
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void select(int index) {
		checkWidget();

		if(index < 0 || index >= items.size())
			return;
		
		OS.ListView_Select(internal_handle,index,true);
	}

	/**
	 * Selects the items in the range specified by the given zero-relative
	 * indices in the receiver. The range of indices is inclusive. The current
	 * selection is not cleared before the new items are selected.
	 * <p>
	 * If an item in the given range is not selected, it is selected. If an item
	 * in the given range was already selected, it remains selected. Indices
	 * that are out of range are ignored and no items will be selected if start
	 * is greater than end. If the receiver is single-select and there is more
	 * than one item in the given range, then all indices are ignored.
	 * 
	 * @param start
	 *            the start of the range
	 * @param end
	 *            the end of the range
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see List#setSelection(int,int)
	 */
	public void select(int start, int end) {
		checkWidget();
		if (start > end) return;
		if (start > items.size()) return;
		
		int itemCount = items.size();
		if ((internal_style & SWT.SINGLE) != 0) {
			if (start == end && start >= 0 && end < itemCount) {
				OS.ListView_Select(internal_handle,start,true);
			}
		}
		else {
			start = Math.max(0,start); // force (start >= 0)
			end = Math.min(itemCount-1,end); // force (end <= itemCount-1)
			for (int i=start; i<=end; i++) {
				OS.ListView_Select(internal_handle,i,true);
			}
		}
	}

	/**
	 * Selects the items at the given zero-relative indices in the receiver. The
	 * current selection is not cleared before the new items are selected.
	 * <p>
	 * If the item at a given index is not selected, it is selected. If the item
	 * at a given index was already selected, it remains selected. Indices that
	 * are out of range and duplicate indices are ignored. If the receiver is
	 * single-select and multiple indices are specified, then all indices are
	 * ignored.
	 * 
	 * @param indices
	 *            the array of indices for the items to select
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the array of indices is null
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see List#setSelection(int[])
	 */
	public void select(int[] indices) {
		checkWidget();
		if (indices == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

		if(((internal_style & SWT.SINGLE) != 0) && indices.length > 1) {
		    for (int i = 1; i < indices.length; ++i) {
		        if (indices[i] != indices[0]) {
		            return;
		        }		        
		    }
		    if (indices[0] != -1) {
				select (indices[0]);
			} 
		    return;
		
		}


		int itemCount = items.size();
		for (int i = 0; i < indices.length; i++) {
			int index = indices[i];
			if (index >= 0 && index < itemCount) {
				OS.ListView_Select(internal_handle,index,true);
			}
		}
	}

	/**
	 * Selects all of the items in the receiver.
	 * <p>
	 * If the receiver is single-select, do nothing.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void selectAll() {
		checkWidget();
		
		if ((internal_style & SWT.SINGLE) != 0) return;

		OS.ListView_Select(internal_handle, -1, true);
	}

	/**
	 * Sets the text and icon of the item in the receiver's list at the given
	 * zero-relative index to the string argument. This is equivalent to
	 * <code>remove</code> 'ing the old item at the index, and then
	 * <code>add</code> 'ing the new item at that index.
	 * 
	 * @param index
	 *            the index for the item
	 * @param string
	 *            the new text for the item
	 * @param icon
	 *            the icon image for the item, can be Null.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the index is not between 0
	 *                and the number of elements in the list minus 1 (inclusive)
	 *                </li>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the remove operation
	 *                fails because of an operating system failure</li>
	 *                <li>ERROR_ITEM_NOT_ADDED - if the add operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public void setItem(int index, String string, Image icon) {
		checkWidget();
		if (string == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		if (index < 0 || index >= items.size())
			SWT.error(SWT.ERROR_INVALID_RANGE);

		ListViewItem newItem = new ListViewItem(string, icon);
		boolean success = OS.ListView_Set(internal_handle, newItem.getText(), newItem.getIconHandle(), index);
		if(success) {
			ListViewItem item = (ListViewItem)items.elementAt(index);
			item.setText(string);
			item.setIcon(icon);
		}
		newItem = null;
	}

	/**
	 * Sets the receiver's items to be the given array of items and icons.
	 * 
	 * @param items
	 *            the array of items
	 * @param icons
	 *            the array of icons. Can be NULL.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the <code>items</code>
	 *                array is null</li>
	 *                <li>ERROR_INVALID_RANGE - if number of elements in
	 *                <code>icons</code> does not match the number in
	 *                <code>items</code></li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_ADDED - if the operation fails because
	 *                of an operating system failure</li>
	 *                </ul>
	 */
	public void setItems(String[] items, Image[] icons) {
		checkWidget();
		if (items == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		if (items.length != icons.length) SWT.error(SWT.ERROR_INVALID_RANGE);

		removeAll();
		this.items.clear();
		boolean success;
		for (int i=0; i< items.length; i++) {
			if(items[i] == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
			ListViewItem item = new ListViewItem(items[i], icons[i]);
			success = OS.ListView_Add(internal_handle ,item.getText(), item.getIconHandle(), i);
			if(success)
				this.items.add(item);
		}
	}

	/**
	 * Changes the widget layout orientation, which affects which way the widget
	 * scrolls.
	 * 
	 * @param style
	 *            the orientation style. Only SWT.VERTICAL and SWT.HORIZONTAL
	 *            can be used.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the style value is
	 *                invalid</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 *  
	 * @see SWT#HORIZONTAL
	 * @see SWT#VERTICAL
	 */
	public void setLayout(int style) {
		checkWidget();
		if ((style != SWT.VERTICAL) && (style != SWT.HORIZONTAL)) 
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		internal_style &= (~SWT.VERTICAL);
		internal_style &= (~SWT.HORIZONTAL);

		internal_style |= style;

		if(density == HIGH || density == MEDIUM)
			return;
		
		int nativeStyle = internal_getNativeStyle();
		
		OS.ListView_SetLayoutDensity(internal_handle, nativeStyle, density);
	}
	
	/**
	 * Changes the item density level.
	 * 
	 * @param style
	 *            the density level. Only HIGH, MEDIUM, LOW can be used.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the style value is
	 *                invalid</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see ListView#LOW
	 * @see ListView#MEDIUM
	 * @see ListView#HIGH
	 */
	public void setLayoutDensity(int style) {
		checkWidget();
		if(style != LOW && style != MEDIUM && style != HIGH)
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);

		int tmpStyle = style;
		if(tmpStyle == MEDIUM)
			tmpStyle = HIGH;
		OS.ListView_SetLayoutDensity(internal_handle, internal_getNativeStyle(), tmpStyle);
		density = style;
	}

	/**
	 * Selects the item at the given zero-relative index in the receiver. If the
	 * item at the index was already selected, it remains selected. The current
	 * selected is first cleared, then the new items are selected. Indices that
	 * are out of range are ignored.
	 * 
	 * @param index
	 *            the index of the item to select
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @see List#deselectAll()
	 * @see List#select(int)
	 */
	public void setSelection(int index) {
		checkWidget();
		OS.ListView_Select(internal_handle,-1,false); // clear selection
		if(index < 0 || index > items.size())
			return;

		
		OS.ListView_Select(internal_handle,index,true);
	}

	/**
	 * Selects the items in the range specified by the given zero-relative
	 * indices in the receiver. The range of indices is inclusive. The current
	 * selection is cleared before the new items are selected.
	 * <p>
	 * Indices that are out of range are ignored and no items will be selected
	 * if start is greater than end. If the receiver is single-select and there
	 * is more than one item in the given range, then all indices are ignored.
	 * 
	 * @param start
	 *            the start index of the items to select
	 * @param end
	 *            the end index of the items to select
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see List#deselectAll()
	 * @see List#select(int,int)
	 */
	public void setSelection(int start, int end) {
		checkWidget();
		OS.ListView_Select(internal_handle,-1,false); // clear selection

		if(isSingleStyle() && (end - start != 0))
			return;
		
		if (start > items.size()) return;

		
		for (int i=start; i<=end ; i++)
			OS.ListView_Select(internal_handle,i,true);
	}

	/**
	 * Selects the items at the given zero-relative indices in the receiver. The
	 * current selection is cleared before the new items are selected.
	 * <p>
	 * Indices that are out of range and duplicate indices are ignored. If the
	 * receiver is single-select and multiple indices are specified, then all
	 * indices are ignored.
	 * 
	 * @param indices
	 *            the indices of the items to select
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the array of indices is null
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see List#deselectAll()
	 * @see List#select(int[])
	 */
	public void setSelection(int[] indices) {
		checkWidget();
		OS.ListView_Select(internal_handle,-1,false); // clear selection
		if (indices == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

	
		if(((internal_style & SWT.SINGLE) != 0) && indices.length > 1) {
		    for (int i = 1; i < indices.length; ++i) {
		        if (indices[i] != indices[0]) {
		            return;
		        }		        
		    }
		    if (indices[0] != -1) {
		    	deselectAll();
				select (indices[0]);
			} 
		    return;
		
		}
		
		
		int size = items.size();
		for (int i=0;i<indices.length;i++) {
			int index = indices[i]; 
			if(index < 0 || index > size)
				continue;
			OS.ListView_Select(internal_handle, index, true);
		}
	}

	/**
	 * Sets the receiver's selection to be the given array of items. The current
	 * selection is cleared before the new items are selected.
	 * <p>
	 * Items that are not in the receiver are ignored. If the receiver is
	 * single-select and multiple items are specified, then all items are
	 * ignored.
	 * 
	 * @param items
	 *            the array of items
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the array of items is null
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see List#deselectAll()
	 * @see List#select(int[])
	 * @see List#setSelection(int[])
	 */
	public void setSelection(String[] items) {
		checkWidget();
		OS.ListView_Select(internal_handle,-1,false); // clear selection
		if (items == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);

		if(isSingleStyle() && (items.length != 1))
			return;

		Vector v = new Vector();
		int size = this.items.size();
		for (int i=0;i<size;i++) {
			ListViewItem item = (ListViewItem)this.items.elementAt(i);
			v.add(item.getText());
		}
		
		
		size = items.length;
		for (int i=0; i<size; i++) {
			if(items[i] == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
			
			int index = v.indexOf(items[i]); 
			if(index == -1)
				continue;
			
			OS.ListView_Select(internal_handle, index, true);
		}
	}

	/**
	 * Shows the selection. If the selection is already showing in the receiver,
	 * this method simply returns. Otherwise, the items are scrolled until the
	 * selection is visible. When multiple items are selected, the selection of
	 * which item becomes visible is implementation-dependent.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void showSelection() {
		checkWidget();

		OS.ListView_MakeSelectionVisible(internal_handle);
	}

	public void internal_createHandle(int index) {
        internal_handle = OS.ListView_New(internal_parent.internal_handle, internal_getNativeStyle(), density);
        if (internal_handle == 0) throw new OutOfMemoryError();
	}
	
	public int internal_getNativeStyle() {
		int nativeStyle = super.internal_getNativeStyle();

		if ((internal_style & SWT.VERTICAL) == SWT.VERTICAL) {
			nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_VERTICAL;
		} else {
			nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_HORIZONTAL;
		}

		if ((internal_style & SWT.BORDER) == SWT.BORDER) {
			nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_BORDER;
		}		
		
		if ((internal_style & SWT.SINGLE) == SWT.SINGLE) {
			nativeStyle |= org.eclipse.ercp.swt.mobile.OS.STYLE_SINGLE;
		} else {
			nativeStyle |= com.ibm.ugl.p3ml.OS.STYLE_MULTI;
		}
		return nativeStyle;
	}
	
	private void ListViewCallback(int type) {
		if(type == 0)
			internal_sendEvent(SWT.Selection);
		else if(type == 1)
			internal_sendEvent(SWT.DefaultSelection);
	}

	private boolean isSingleStyle() {
		return ((internal_style & SWT.SINGLE) == SWT.SINGLE); 
	}
	
	int getFlags() {
		int bits = OS.WS_CHILD | OS.WS_VISIBLE | OS.WS_BORDER | OS.LVS_LIST;
			return bits;
	}
	
	public boolean allowTraverseByArrowKey(Event event) {
		int size = items.size(); 
		if(size == 0)
			return true;

		// dimension[0] : number of horizontal
		// dimension[1] : number of vertical 
		int[] dimension = OS.ListView_GetDimension(internal_handle);
		int focus = getFocusIndex();
		switch (event.keyCode) {
			case SWT.ARROW_LEFT :
				if(density == ListView.LOW && (internal_style & SWT.HORIZONTAL) == SWT.HORIZONTAL) {
					if(focus % dimension[0] == 0)
						return true;
				} else {
					if(focus < dimension[1])
						return true;
				}
				break;
			case SWT.ARROW_RIGHT :
				if(focus == size-1)
					return true;
				if(density == ListView.LOW && (internal_style & SWT.HORIZONTAL) == SWT.HORIZONTAL) {
					if((focus+1) % dimension[0] == 0)
						return true;
				} else {
					if(focus >= size - dimension[1])
						return true;
				}
				break;
		}
		return false;
	}
	
	public void setEnabled(boolean enabled) {
		super.setEnabled(enabled);
		if(enabled == false) {
			if(disabledcolor != null) {
				super.setBackground(null);
			} else {
				disabledcolor = super.getBackground();
				super.setBackground(null);
			}
		}
		else {
			if(disabledcolor != null) {
				super.setBackground(disabledcolor);
				disabledcolor = null;
			}
		}
	}

	public void setBackground(Color color) {
		if(isEnabled() == true) {
			super.setBackground(color);
		} else {
			if(disabledcolor != null && disabledcolor.isDisposed() == false) {
				disabledcolor.dispose();
			}
			disabledcolor = color;
		}
	}

	public Color getBackground() {
		if(isEnabled() == true) {
			return super.getBackground();
		} else {
			return disabledcolor;
		}
	}

	public void dispose() {
		if(disabledcolor != null && disabledcolor.isDisposed() == false) {
			disabledcolor.dispose();
			disabledcolor = null;
		}
		super.dispose();
	}

	protected boolean traverse(Event event) {
		if (isDisposed()) return false;
		if(allowTraverseByArrowKey(event)) {
			return traverseByArrowKey(event);
		}
		return super.traverse(event);
	}

	public class ListViewItem {
		private String text;
		private Image icon;
		private int iconHandle;
		public ListViewItem(String text) {
			this(text, null);
		}
		public ListViewItem(String text, Image icon) {
			this.text = text;
			setIcon(icon);
		}
		public int getIconHandle() {
			return iconHandle;
		}
		public void setText(String text) {
			this.text = text;
		}
		public String getText() {
			return text;
		}
		public void setIcon(Image icon) {
			if(icon == null)
				iconHandle = 0;
			else
				iconHandle = icon.internal_handle;
			this.icon = icon;
		}
		public Image getIcon() {
			return icon;
		}
	}
}
