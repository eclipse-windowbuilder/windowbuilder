/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import org.eclipse.ercp.swt.mobile.CommandHandle.CommandNode;
import org.eclipse.ercp.swt.mobile.MultiPageDialog.MultiPageShell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TypedListener;

// Command test code
/*
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Text;
*/

/**
 * 
 * Command is a metaphor that represents a general action. Command contains no
 * information about the behavior that happens when a command is activated. The
 * concrete action is defined in a SelectionListener. Commands may be
 * implemented using any user interface construct that has semantics for activating
 * a single action. Some implementations may implement commands as widgets, such
 * as buttons or menu items, or voice tags. However, the implementation should
 * not adversely affect an application's layout when realizing commands.
 * 
 * <p>
 * A Command must be associated with a control and only becomes accessible 
 * when that control is in the current <i>focus context</i>. The current
 * focus context includes the control that currently has focus and all of
 * its visible ancestor controls up through the lowest level Shell. 
 * The term <i>visible</i> above refers to widgets which 
 * are not explicitly hidden by calling <code>setVisible(false)</code>. 
 * The focus contenxt does not include siblings of the control with focus 
 * or ancestors of the lowest level Shell. 
 * </p>
 * 
 * <p>
 * The implementation guarantees that all commands within the current
 * focus context are accessible. However, the concrete method for doing this
 * is device-specific and implementation-dependent. 
 * Commands may be bound to hardware keys or device softkeys. 
 * As various devices have a different number of keys, the conventional way to
 * place commands by indexing is not appropriate, especially as there may be
 * more commands than available keys. The placement of commands is
 * also dynamic. For example, new commands can be added by the implementation 
 * at run-time in order to facilitate some context-related operations.
 * Therefore, the implementation uses various information to place commands:
 * </p>
 * 
 * <ul> 
 * <li><code>Command type</code> is a hint used by the
 * implementation to associate commands with specific keys. 
 * It is common to bind more than one command of the same type to a control.
 * In such cases, command precedence rules are used to determine which
 * command is assigned to a key and which others are placed on a menu. 
 * <code>Command type</code> is not used for ordering within menus. 
 * </li>
 * <br>&nbsp;
 * <li>
 * When multiple commands are in competition for key or menu assignment, the 
 * <code>priority</code> argument is used to help determine assignment and order. 
 * The lowest value (zero) has the lowest precedence (and appears visually 
 * lowest in menus). If priority values of competing commands are the same, 
 * higher precedence is given to commands created first. Commands bound to 
 * the currently focused control are always given higher
 * precedence than commands bounds to ancestor controls regardless of their 
 * <code>priority</code> value. Commands and CommandGroups within the same 
 * command menu are ordered by priority value. 
 * </li>
 * </ul>
 * 
 * <p>
 * A default command means that a command can be activated via a device
 * selection key or any other "short-cut" like the concept of default button in
 * a shell. Usually the default command has a different visual style to
 * make it distinguishable from other commands. Within a focus context, there
 * can only be one default command at any time. A command becomes the default
 * one via the method "setDefaultCommand", and any previous default command 
 * becomes non-default.
 * </p>
 * 
 * <p>
 * When pressing the key associated with a command, a SelectionEvent will be
 * delivered to all the command's SelectionListeners, if any.
 * </p>
 * 
 * <p>
 * Commands can have a long label (<code>setLongLabel(String)</code>), which
 * is typically used for when a command is assigned to a menu.
 * The long label is optional. If the long label is not present on a command,
 * the default text label (<code>setText(String)</code>) is used. The
 * default label should be as short as possible so that it consumes a
 * minimum of screen real estate. The long label can be longer and more
 * descriptive, but it should be no longer than a few words. For example, a
 * command's default label might be "Play", and its long label might be "Play
 * Sound Clip".
 * Labeling of command menus is implementation-dependent. 
 * </p>
 * 
 * <p>
 * Note that although this class is a subclass of
 * {@link org.eclipse.swt.widgets.Item Item} and allows setting the image even
 * if the underlying platform does not. But in this case the image is not
 * displayed.
 * </p>
 * <h3>Example 1: Single Command per Control (within a focus context of List and
 * its parent)</h3>
 * <code><pre>
 * List list = new List(parent, SWT.SINGLE); // a single selection list
 * Command cmd1 = new Command(list, Command.SELECT, 1);
 * cmd1.setText(&quot;Open&quot;);
 * cmd1.addSelectionListener(new SelectionListener() {
 * 	public void widgetSelected(SelectionEvent e) {
 * 		System.out.println(&quot;Command &quot; + e.data + &quot; pressed.&quot;);
 * 		// e.widget contains the Command object. 
 * 	}
 * });
 * Command cmd2 = new Command(parent, Command.GENERAL, 0);
 * cmd2.setText(&quot;New&quot;);
 * cmd2.addSelectionListener(new SelectionListener() {
 * 	public void widgetSelected(SelectionEvent e) {
 * 		System.out.println(&quot;Command &quot; + e.data + &quot; pressed.&quot;);
 * 		// e.widget contains the Command object. 
 * 	}
 * });
 * </pre></code>
 * 
 * <h3>Example 2: Multiple Commands per Control and DefaultCommand</h3>
 * <code><pre>
 * List list = new List(composite1, SWT.SINGLE);
 * Command cmd1 = new Command(list, Command.SELECT, 0);
 * cmd1.setText(&quot;Open&quot;);
 * cmd1.setDefaultCommand();
 * Command cmd2 = new Command(list, Command.SELECT, 0);
 * cmd2.setText(&quot;Edit&quot;);
 * Command cmd3 = new Command(list, Command.SELECT, 0);
 * cmd3.setText(&quot;Delete&quot;);
 * Command cmd4 = new Command(composite1, Command.EXIT, 0); // create a EXIT type
 * cmd4.setText(&quot;Exit&quot;);
 * </pre></code>
 * 
 * <dl>
 * <dt><b>Command types: </b></dt>
 * <dd>COMMANDGROUP: represents a special command that contains sub-commands
 * </dd>
 * <dd>GENERAL, SELECT, OK, CANCEL, DELETE, BACK, EXIT, STOP, HELP: Logical
 * command types</dd>
 * <dt><b>Events: </b></dt>
 * <dd>Selection</dd>
 * </dl>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */
public class Command extends Item {
	Control control;
	int type;
	int priority;
	int accelerator;
	boolean enabled;
	boolean defaultCommand;
	String label;
	Vector listeners = null; 
	private static CommandHandle cmdHandle = new CommandHandle();
	private boolean dispose = false;
	private static boolean hasHandleFocusIn = false;
	int selectionListenerCount = 0;

	/**
	 * A command that can be bound to any hardware keys or softkeys.
	 * 
	 * <P>
	 * Value <code>1</code> is assigned to <code>GENERAL</code>.
	 * </P>
	 *  
	 */
	public static final int GENERAL = 1;

	/**
	 * A command that represents the context-sensitive action.
	 * 
	 * <P>
	 * Value <code>2</code> is assigned to <code>SELECT</code>.
	 * </P>
	 *  
	 */
	public static final int SELECT = 2;

	/**
	 * A special command used for grouping commands. This command does not fire
	 * SelectionEvents if there are any commands associated. Instead, pressing
	 * down the command results in displaying sub-commands.
	 * <P>
	 * Value <code>10</code> is assigned to <code>COMMANDGROUP</code>.
	 * </P>
	 * </DL>
	 *  
	 */
	public static final int COMMANDGROUP = 10;

	/**
	 * A navigation command that returns the user to the logical OK action.
	 * 
	 * <P>
	 * Value <code>3</code> is assigned to <code>OK</code>.
	 * </P>
	 *  
	 */
	public static final int OK = 3;

	/**
	 * A command that is a standard negative answer to an action.
	 * 
	 * <p>
	 * With this command type, the application hints to the implementation that
	 * the user wants to dismiss the current action.
	 * </p>
	 * <P>
	 * Value <code>4</code> is assigned to <code>CANCEL</code>.
	 * </P>
	 *  
	 */
	public static final int CANCEL = 4;

	/**
	 * This command hints to the implementation to destroy data.
	 * </p>
	 * <P>
	 * Value <code>5</code> is assigned to <code>DELETE</code>.
	 * </P>
	 *  
	 */
	public static final int DELETE = 5;

	/**
	 * A command that hints to the implementation to navigate backward.
	 * 
	 * <P>
	 * Value <code>6</code> is assigned to <code>BACK</code>.
	 * </P>
	 *  
	 */
	public static final int BACK = 6;

	/**
	 * A command that indicates an exiting action.
	 * <P>
	 * Value <code>7</code> is assigned to <code>EXIT</code>.
	 * </P>
	 * </DL>
	 *  
	 */
	public static final int EXIT = 7;

	/**
	 * A command that stops some currently running process, operation, etc.
	 * Nothing is stopped automatically by the implementation.
	 * 
	 * <P>
	 * Value <code>8</code> is assigned to <code>STOP</code>.
	 * </P>
	 *  
	 */
	public static final int STOP = 8;

	/**
	 * A command that specifies a request for on-line help. No help information
	 * is shown automatically by the implementation. The application is
	 * responsible for answering the event.
	 * 
	 * <P>
	 * Value <code>9</code> is assigned to <code>HELP</code>.
	 * </P>
	 *  
	 */
	public static final int HELP = 9;

	/**
	 * Constructs a new instance of this class given an associated Command, a
	 * type value describing its behaviour and priority for positioning hints.
	 * <p>
	 * The constructor creates a command associated with a Command (cannot be
	 * null and must be COMMANDGROUP type). The implementation must group
	 * commands within the same command group.
	 * </p>
	 * 
	 * @param command
	 *            the associated Command. It must be COMMANDGROUP type.
	 *            Otherwise throw an exception.
	 * @param type
	 *            the type of Command to construct
	 * @param priority
	 *            the priority value. The lowest value (zero) has the lowest
	 *            precedence.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the command type is not
	 *                COMMANDGROUP</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the type is not one of
	 *                the valid command types</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the priority is less than
	 *                zero</li>
	 *                <li>ERROR_NULL_ARGUMENT - if the command is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * 
	 * @see #GENERAL
	 * @see #SELECT
	 * @see #OK
	 * @see #CANCEL
	 * @see #DELETE
	 * @see #BACK
	 * @see #EXIT
	 * @see #STOP
	 * @see #HELP
	 */
	
	boolean isValidSubclass() {
		return isValidClass(getClass());
	}
	
	boolean isValidClass(Class clazz) {
		String name = clazz.getName();
		int index = name.lastIndexOf('.');
		
		// allow mobile extensions
		if (name.substring(0, index + 1).equals("org.eclipse.ercp.swt.mobile.")) return true;

		return false;	
	}
	
	public Command(Command command, int type, int priority) {
		super(cmdHandle.findControl(command), 0);
		if(command == null)
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
		if ((priority < 0) || (command.type != COMMANDGROUP))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if ((type <0) || (type > COMMANDGROUP)) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if (!isValidSubclass()) SWT.error(SWT.ERROR_INVALID_SUBCLASS);
		final Command c = this;
		command.addDisposeListener(new DisposeListener(){

			public void widgetDisposed(DisposeEvent e) {
				c.internal_sendEvent(SWT.Dispose);
//mdr				c.dispose();
			}});		
		
		Control control = cmdHandle.findControl(command); 
		this.control = control;
		this.type = type;
		this.priority = priority;
		this.accelerator = 0;
		this.enabled = true;
		cmdHandle.add(command, this);
	}

	/**
	 * Constructs a new instance of this class given an associated Control, a
	 * type value describing its behaviour and priority for positioning hints.
	 * <p>
	 * The type value is one of the type constants defined in class
	 * <code>Command</code>
	 * </p>
	 * 
	 * @param control
	 *            the associated Control
	 * @param type
	 *            the type of Command to construct
	 * @param priority
	 *            the priority value. The lowest value (zero) has the lowest
	 *            precedence.
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the type is not one of
	 *                the valid command types</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the priority is less than
	 *                zero</li>
	 *                <li>ERROR_NULL_ARGUMENT - if the control is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * 
	 * @see #GENERAL
	 * @see #SELECT
	 * @see #OK
	 * @see #CANCEL
	 * @see #DELETE
	 * @see #BACK
	 * @see #EXIT
	 * @see #STOP
	 * @see #HELP
	 */
	public Command(Control control, int type, int priority) {
		super(control, 0);
		if (control == null)  SWT.error(SWT.ERROR_NULL_ARGUMENT);
		if ((type <0) || (type > COMMANDGROUP)) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if ((priority < 0)) {
			if (priority != -1 || type != Command.EXIT) {
				SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			}
		}
		if (!isValidSubclass()) SWT.error(SWT.ERROR_INVALID_SUBCLASS);
		final Command c = this;
		control.addDisposeListener(new DisposeListener(){

			public void widgetDisposed(DisposeEvent e) {
				c.internal_sendEvent(SWT.Dispose);
				c.dispose();
			}});		
		
		if(!hasHandleFocusIn) {
			control.getDisplay().addFilter(SWT.FocusIn, cmdHandle);
			control.getDisplay().addFilter(SWT.FocusOut, cmdHandle);
			hasHandleFocusIn = true;
		}
		this.control = control;
		this.type = type;
		this.priority = priority;
		this.accelerator = 0;
		this.enabled = true;
		cmdHandle.add(control, this);
	}
	
	/**
	 * Adds the listener to the collection of listeners who will be notified
	 * when the command is activated, by sending it one of the messages defined
	 * in the <code>SelectionListener</code> interface.
	 * <p>
	 * When <code>widgetSelected</code> is called, the stateMask field of the
	 * event object is valid. <code>widgetDefaultSelected</code> is not
	 * called.
	 * </p>
	 * 
	 * @param listener
	 *            the listener which should be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see SelectionListener
	 * @see #removeSelectionListener
	 */
	public void addSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null)  SWT.error(SWT.ERROR_NULL_ARGUMENT);
		
		TypedListener typedListener = new TypedListener(listener);
		addListener(SWT.Selection, typedListener);
		addListener(SWT.DefaultSelection, typedListener);
		selectionListenerCount ++;
	}

	/**
	 * Returns <code>true</code> if the receiver is enabled, and
	 * <code>false</code> otherwise. A disabled control is typically not
	 * selectable from the user interface and draws with an inactive or "grayed"
	 * look.
	 * 
	 * @return the receiver's enabled state
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see #isEnabled
	 */
	public boolean getEnabled() {
		checkWidget();
		return enabled;
	}

	/**
	 * Returns the command's long label, which shall be null if it has never
	 * been set.
	 * 
	 * @return the receiver's text. Can be null.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @see #setLongLabel(String)
	 */
	public String getLongLabel() {
		checkWidget();
		return label;
	}

	/**
	 * Returns the command's priority value.
	 * 
	 * @return the priority value.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 */
	public int getPriority() {
		checkWidget();
		return priority;
	}

	/**
	 * Returns <code>true</code> if the command is a Default Command, and
	 * <code>false</code> otherwise. By default a command is not a default
	 * one.
	 * 
	 * @return boolean the command's state
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @see #setDefaultCommand()
	 */
	public boolean isDefaultCommand() {
		checkWidget();
		return defaultCommand;
	}

	/**
	 * Returns <code>true</code> if the receiver is enabled and all of the
	 * receiver's ancestors are enabled, and <code>false</code> otherwise. A
	 * disabled control is typically not selectable from the user interface and
	 * draws with an inactive or "grayed" look.
	 * 
	 * @return boolean the receiver's enabled state
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @see #getEnabled
	 */
	public boolean isEnabled() {
		checkWidget();
		if(control == null || control.isDisposed())
			return false;
		return (cmdHandle.isEnabled(this) && control.isEnabled());
	}

	/**
	 * Removes the listener from the collection of listeners who will be
	 * notified when the command is activated.
	 * 
	 * @param listener
	 *            the listener which should be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see SelectionListener
	 * @see #addSelectionListener
	 */
	public void removeSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null)  SWT.error(SWT.ERROR_NULL_ARGUMENT);
		
		removeListener(SWT.Selection, listener);	
		removeListener(SWT.DefaultSelection, listener);
		selectionListenerCount--;
	}

	/**
	 * Sets the command accelerator. An accelerator is the bit-wise OR of zero
	 * or more modifier masks and a key. Examples:
	 * <code>SWT.MOD1 | SWT.MOD2 | 'T'</code>,
	 * <code>SWT.CONTROL | SWT.SHIFT | 'T'</code>.
	 * 
	 * This requires fullkeyboard or computer keyboard-like support and is an
	 * implementation-dependent feature. It will be gracefully ignored if the
	 * implementation does not support keyboard accelerator.
	 * 
	 * @param accelerator
	 *            an integer that is the bit-wise OR of masks and a key
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if accelerator value is
	 *                invalid</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 *  
	 */
	public void setAccelerator(int accelerator) {
		checkWidget();
		boolean remakemenu = false;
		if(this.accelerator != accelerator && isFocusControl())
			remakemenu = true;
		this.accelerator = accelerator;
		if(remakemenu)
			cmdHandle.makeMenu(this);
	}

	/**
	 * Sets the default command.
	 *  
	 */
	public void setDefaultCommand() {
		checkWidget();
		defaultCommand = true;
		cmdHandle.setDefaultCommand(this);
	}

	/**
	 * Enables the command if the argument is <code>true</code>, and disables
	 * it otherwise. A disabled control is typically not selectable from the
	 * user interface and draws with an inactive or "grayed" look; or even
	 * completely removed from the user interface.
	 * 
	 * @param enabled
	 *            the new enabled state
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 */
	public void setEnabled(boolean enabled) {
		checkWidget();
		boolean remakemenu = false;
		if(this.enabled != enabled && isFocusControl())
			remakemenu = true;
		this.enabled = enabled;
		if(remakemenu){
			cmdHandle.makeMenu(this);
		}
	}

	/**
	 * Sets the command's long label text.
	 * 
	 * Commands may optionally have long labels, enabling the application to
	 * specify a short form for button or softkey, and a more verbose form when
	 * realized as menu item.
	 * 
	 * @param label
	 *            the long descriptive label text. Can be null.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @see #getLongLabel()
	 */
	public void setLongLabel(String label) {
		checkWidget();
		boolean remakemenu = false;
		if(isFocusControl()) {
			if(this.label == null) {
				if(label != null)
					remakemenu = true;
			} else {
				if(label == null)
					remakemenu = true;
				else if(!this.label.equals(label))
					remakemenu = true;
			}
		}
		this.label = label;
		if(remakemenu)
			cmdHandle.makeMenu(this);
	}
	
	public void setText (String string) {
		checkWidget ();
		boolean remakemenu = false;
		if(!super.getText().equals(string) && isFocusControl())
			remakemenu = true;
		super.setText(string);
		if(remakemenu)
			cmdHandle.makeMenu(this);
	}
	
	public void dispose() {
		if(listeners != null) {
			CommandNode node = cmdHandle.findCommandNode(this);
			Enumeration elements = listeners.elements();
			while(elements.hasMoreElements()) {
				CommandListener cmdListener = (CommandListener)elements.nextElement();
				if(node != null && !node.isDispose()) { 
					if(node.item != null && !node.item.isDisposed()) {
						node.item.removeListener(cmdListener.getEventType(), cmdListener);
					}
				}
				cmdListener = null;
			}
			this.listeners.clear();
		}
		this.listeners = null;
		cmdHandle.removeCommand(this);
		dispose = true;
	}

	public boolean isDisposed() {
		return dispose;
	}
	
	public void addListener(int eventType, Listener listener) {
		checkWidget();
		if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		
		if(listeners == null)
			listeners = new Vector();
		CommandListener commandListener = new CommandListener(this, eventType, listener);
		CommandNode node = cmdHandle.findCommandNode(this);
		if(node != null && !node.isDispose()) { 
			if(node.item != null && !node.item.isDisposed())
				node.item.addListener(eventType, commandListener);
		}
		Enumeration elements = listeners.elements();
		while(elements.hasMoreElements()) {
			CommandListener cmdListener = (CommandListener)elements.nextElement();
			if(cmdListener.getEventType() == eventType && cmdListener.getListener() == listener) {
				return;
			}
		}
		this.listeners.add(commandListener);
	}

	public void removeListener(int eventType, Listener listener) {
		checkWidget();
		if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		
		if(listeners == null)
			return;
		Enumeration elements = listeners.elements();
		while(elements.hasMoreElements()) {
			CommandListener cmdListener = (CommandListener)elements.nextElement();
			if(cmdListener.getEventType() == eventType && cmdListener.getListener() == listener) {
				CommandNode node = cmdHandle.findCommandNode(this);
				if(node != null && !node.isDispose()) { 
					if(node.item != null && !node.item.isDisposed()) {
						node.item.removeListener(eventType, cmdListener);
					}
				}
				this.listeners.remove(cmdListener);
				cmdListener = null;
				break;
			}
		}
	}
	
	public void Command_SendEvent(int event){
		this.internal_sendEvent(event);
	}
	
	public String toString() {
		return "Command {label:"+this.getText()+", long label:"+ label +", type:"+type+", priority:"+priority+"}";
	}
	
	// fix bug 99158 problem 2
	// check control has focus or shell has active
	private boolean isFocusControl() {
		if(control.isFocusControl() || 
			(control instanceof Shell && control.getDisplay().getActiveShell() == control))
			return true;
		// fix against 101554
		if (control instanceof Composite) 	{	
			
			return isChildFocusControl((Composite)control);
		}
		return false;
	}

	// fix against 101554
	// look for all possible children to see if anyone contains focus
	private boolean isChildFocusControl(Composite c) {
		
		
		if (c == null) return false;
		Control[] children = c.getChildren();
		if (children == null) return false; //no

		for (int i=0;i<children.length;i++) {
			if (children[i] == null) continue;
			if (children[i].isFocusControl()){
				return true;
			}
			if(children[i] instanceof Canvas || children[i] instanceof CaptionedControl || children[i] instanceof Composite) {
				
				if(isChildFocusControl((Composite)children[i]))
					return true;
			}
			if(children[i] instanceof SortedList){
				Control child = ((SortedList) children[i]).getchild();
				if(child.isFocusControl()){
					return true;
				}
			}
		}
		return false;
	}

	
// Command test code
/*
	public final static void main(String[] args){
		final Display display = new Display();
		final Shell shell = new Shell(display, SWT.DIALOG_TRIM);
		shell.setToolTipText("Shell 1");
		Command command = new Command(shell, Command.OK, 1);
		command.setText("OK");
		Button button = new Button(shell, SWT.BORDER);
		button.setText("open");
		button.pack();
		
		button.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				Shell s = new Shell(shell, SWT.DIALOG_TRIM);
				s.setToolTipText("Shell 2");
				Command c = new Command(s, Command.EXIT, 1);
				c.setText("EXIT");

				Button b = new Button(s, SWT.BORDER);
				Command c2 = new Command(b, Command.GENERAL, 1);
				c2.setText("AAA");
				b.setText("sssss");
				b.pack();
				s.setSize(240, 320);
				s.open();
				while( !s.isDisposed() ) {
					if( !display.readAndDispatch() )
						display.sleep();
				}
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		shell.setSize(240, 320);
		shell.open();
		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
		display.dispose();	
	}
*/
/*
	public final static void main(String[] args){
		final String RESOURCE_DIRECTORY = "/resources/";  
		final Display display = new Display();
		final Shell shell = new Shell(display, SWT.DIALOG_TRIM);
		
		Composite composite1 = new Composite(shell, SWT.NONE);
		Button com1Button1 = new Button(composite1, SWT.BORDER);
		com1Button1.setText("Compo1 Button1");
		com1Button1.pack();
//		Command com1Button1Cmd1 = new Command(com1Button1, Command.OK, 0);
//		com1Button1Cmd1.setText("Compo1 Button1 Cmd1");
//		com1Button1Cmd1.addSelectionListener(new SelectionListener() {
//			public void widgetSelected(SelectionEvent e) {
//				System.out.println("Compo1 Button1 Cmd1 widgetSelected");
//			}
//			public void widgetDefaultSelected(SelectionEvent e) {
//				System.out.println("Compo1 Button1 Cmd1 widgetDefaultSelected");
//			}
//		});
		
		Text com1Text1 = new Text(composite1, SWT.BORDER);
		com1Text1.setText("Compo1 Text1");
		com1Text1.pack();
		composite1.pack();
		composite1.setBackground(new Color(display, 0,0,255));

		FormLayout com1Layout = new FormLayout();
		com1Layout.marginWidth = 3;
		com1Layout.marginHeight = 3;
		com1Layout.spacing = 3;
		composite1.setLayout(com1Layout);
		
		FormData com1fd11 = new FormData();
		com1fd11.left = new FormAttachment(0, 0);
		com1fd11.top = new FormAttachment(0, 0);
		com1Button1.setLayoutData(com1fd11);

		FormData com1fd21 = new FormData();
		com1fd21.left = new FormAttachment(com1Button1, 0);
		com1fd21.top = new FormAttachment(0, 0);
		com1Text1.setLayoutData(com1fd21);


		Command com1Cmd1 = new Command(com1Text1, Command.OK, 0);
		com1Cmd1.setText("Compo1 Text1 Cmd1");
		


		
		Composite composite2 = new Composite(shell, SWT.NONE);
		composite2.setBackground(new Color(display, 255, 0, 0));

		Command com2Cmd0 = new Command(composite2, Command.OK, 0);
		com2Cmd0.setText("Compo2 Cmd1");
		com2Cmd0.setImage(new Image(display, RESOURCE_DIRECTORY + "001.gif"));
		
		Button com2Button2 = new Button(composite2, SWT.BORDER);
		com2Button2.setText("Compo2 Button2");
		com2Button2.pack();

		Command com2Cmd1 = new Command(com2Button2, Command.OK, 2);
		com2Cmd1.setText("Compo2 Button2 Cmd1");
		com2Cmd1.setImage(new Image(display, RESOURCE_DIRECTORY + "005.gif"));

		Command com2Cmd2 = new Command(com2Button2, Command.COMMANDGROUP, 0);
		com2Cmd2.setText("Compo2 Button2 Cmd2");
		com2Cmd2.setImage(new Image(display, RESOURCE_DIRECTORY + "iMac.JPG"));
		com2Cmd2.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
System.out.println("com2Cmd2 widgetSelected");
			}
			public void widgetDefaultSelected(SelectionEvent e) {
System.out.println("com2Cmd2 widgetDefaultSelected");
			}
		});
//		com2Cmd2.setEnabled(false);

		Command com2Cmd21 = new Command(com2Cmd2, Command.COMMANDGROUP, 1);
		com2Cmd21.setText("Compo2 Button2 Cmd2-1");
		Command com2Cmd22 = new Command(com2Cmd2, Command.CANCEL, 1);
		com2Cmd22.setText("Compo2 Button2 Cmd2-2");
		Command com2Cmd23 = new Command(com2Cmd2, Command.GENERAL, 0);
		com2Cmd23.setText("Compo2 Button2 Cmd2-3");
//		com2Cmd21.setEnabled(false);
		com2Cmd22.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
System.out.println("com2Cmd22 widgetSelected");
			}
			public void widgetDefaultSelected(SelectionEvent e) {
System.out.println("com2Cmd22 widgetDefaultSelected");
			}
		});

		Command com2Cmd211 = new Command(com2Cmd21, Command.EXIT, 0);
		com2Cmd211.setText("Compo2 Button2 Cmd2-1-1");
		com2Cmd211.setLongLabel("loooooooooooooooooooong label");
		Command com2Cmd212 = new Command(com2Cmd21, Command.COMMANDGROUP, 0);
		com2Cmd212.setText("Compo2 Button2 Cmd2-1-2");

		Command com2Cmd2121 = new Command(com2Cmd212, Command.OK, 0);
		com2Cmd2121.setText("Compo2 Button2 Cmd2-1-2-1");
		com2Cmd2121.setLongLabel("looooooooooooooooooooooooooooooong label");

		Command com2Cmd3 = new Command(com2Button2, Command.HELP, 1);
		com2Cmd3.setText("Compo2 Button2 Cmd3");
		com2Cmd3.setLongLabel("looooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooong label");
		
		
		SortedList com2SortedList1 = new SortedList(composite2, SWT.MULTI);
		com2SortedList1.add("abc");
		com2SortedList1.add("def");
		com2SortedList1.add("ghi");
		com2SortedList1.pack();
//		com2SortedList1.setLocation(100, 100);
		Command com2SortedList1Cmd1 = new Command(com2SortedList1, Command.HELP, 1);
		com2SortedList1Cmd1.setText("Compo2 SortedList1 Cmd1");

		Combo com2combo1 = new Combo(composite2, SWT.DROP_DOWN);
		com2combo1.add("123");
		com2combo1.add("456");
		com2combo1.add("789");
		com2combo1.pack();
		composite2.pack();
		Command com2combo1Cmd1 = new Command(com2combo1, Command.HELP, 1);
		com2combo1Cmd1.setText("Compo2 Combo1 Cmd1");

		FormLayout com2Layout = new FormLayout();
		com2Layout.marginWidth = 3;
		com2Layout.marginHeight = 3;
		com2Layout.spacing = 3;
		composite2.setLayout(com2Layout);

		FormData com2fd11 = new FormData();
		com2fd11.left = new FormAttachment(0, 0);
		com2fd11.top = new FormAttachment(0, 0);
		com2Button2.setLayoutData(com2fd11);

		FormData com2fd21 = new FormData();
		com2fd21.left = new FormAttachment(0, 0);
		com2fd21.top = new FormAttachment(com2Button2, 0);
		com2fd21.bottom = new FormAttachment(com2Button2, 50);
		com2SortedList1.setLayoutData(com2fd21);

		FormData com2fd22 = new FormData();
		com2fd22.left = new FormAttachment(com2SortedList1, 0);
		com2fd22.top = new FormAttachment(com2Button2, 0);
		com2combo1.setLayoutData(com2fd22);

		
		Composite composite3 = new Composite(shell, SWT.NONE | SWT.BORDER);
		Text com3Text1 = new Text(composite3, SWT.MULTI | SWT.BORDER);
		
		List com3List1 = new List(composite3, SWT.MULTI);
		com3List1.add("List 1");
		com3List1.add("List 2");
		com3List1.add("List 3");
		com3List1.pack();
		
		FormLayout com3Layout = new FormLayout();
		com3Layout.marginWidth = 3;
		com3Layout.marginHeight = 3;
		com3Layout.spacing = 3;
		composite3.setLayout(com3Layout);
		
		FormData com3fd11 = new FormData();
		com3fd11.left = new FormAttachment(0, 0);
		com3fd11.top = new FormAttachment(0, 0);
		com3fd11.right = new FormAttachment(0, 40);
		com3fd11.bottom = new FormAttachment(0, 30);
		com3Text1.setLayoutData(com3fd11);

		FormData com3fd12 = new FormData();
		com3fd12.left = new FormAttachment(com3Text1, 0);
		com3fd12.top = new FormAttachment(0, 0);
		com3List1.setLayoutData(com3fd12);

		composite3.pack();
		composite3.setBackground(new Color(display, 0, 255, 0));

		Command com3Cmd1 = new Command(composite3, Command.OK, 2);
		com3Cmd1.setText("Compo3 Cmd1");
//		com3Cmd1.setImage(new Image(display, "/resource/020.gif"));

		final Command com3Cmd2 = new Command(composite3, Command.CANCEL, 1);
		com3Cmd2.setText("Compo3 Cmd2");
		com3Cmd2.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("Dispose Composite3 Cmd2");
				System.out.println("--- before dispose ---");
				System.out.println(Command.cmdHandle.toString());
				System.out.println("--- before dispose ---");
				com3Cmd2.dispose();
				System.out.println("--- after dispose ---");
				System.out.println(Command.cmdHandle.toString());
				System.out.println("-----------------------");
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		final Command com3Cmd3 = new Command(composite3, Command.DELETE, 1);
		com3Cmd3.setText("Compo3 Cmd3");
		SelectionListener com3Cmd3Listener = new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
System.out.println("Compo3 Cmd3 SelectionListener");
System.out.println("now, remove SelectionListener");
				com3Cmd3.removeSelectionListener(this);
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		};
		
		com3Cmd3.addSelectionListener(com3Cmd3Listener);

		Command com3Text1Cmd1 = new Command(com3Text1, Command.COMMANDGROUP, 1);
		com3Text1Cmd1.setText("Compo3 Text1 Cmd1");
		Command com3Text1Cmd11 = new Command(com3Text1Cmd1, Command.COMMANDGROUP, 1);
		com3Text1Cmd11.setText("Compo3 Text1 Cmd1-1");
//		com3Text1Cmd1.setEnabled(false);

		Command com3Text1Cmd2 = new Command(com3Text1, Command.COMMANDGROUP, 1);
		com3Text1Cmd2.setText("Compo3 Text1 Cmd2");
		
		Command com3List1Cmd1 = new Command(com3List1, Command.COMMANDGROUP, 1);
		com3List1Cmd1.setText("Compo3 Lis1 Cmd1");
//		com3List1Cmd1.setImage(new Image(display, "/resource/iMac.JPG"));


		Composite composite31 = new Composite(composite3, SWT.NONE);
		Label com31Label1 = new Label(composite31, SWT.NONE);
		com31Label1.setText("Compo31 Labe1");
		com31Label1.pack();
		Text com31Text1 = new Text(composite31, SWT.BORDER);
		com31Text1.setText("Text1");
		com31Text1.pack();
		Button com31Button1 = new Button(composite31, SWT.BORDER);
		com31Button1.setText("Button1");
		com31Button1.pack();

		FormLayout com31Layout = new FormLayout();
		com31Layout.marginWidth = 3;
		com31Layout.marginHeight = 3;
		com31Layout.spacing = 3;
		composite31.setLayout(com31Layout);
		
		FormData com31fd11 = new FormData();
		com31fd11.left = new FormAttachment(0, 0);
		com31fd11.top = new FormAttachment(0, 0);
		com31Label1.setLayoutData(com31fd11);

		FormData com31fd21 = new FormData();
		com31fd21.left = new FormAttachment(0, 0);
		com31fd21.top = new FormAttachment(com31Label1, 0);
		com31Text1.setLayoutData(com31fd21);

		FormData com31fd22 = new FormData();
		com31fd22.left = new FormAttachment(com31Text1, 0);
		com31fd22.top = new FormAttachment(com31Label1, 0);
		com31Button1.setLayoutData(com31fd22);
		
		
		FormData com3fd21 = new FormData();
		com3fd21.left = new FormAttachment(com3List1, 0);
		com3fd21.top = new FormAttachment(0, 0);
		composite31.setLayoutData(com3fd21);

		composite31.setBackground(new Color(display, 128, 0, 255));

		
		Command com31Cmd1 = new Command(composite31, Command.COMMANDGROUP, 1);
		com31Cmd1.setText("Compo31 Cmd1");
		com31Cmd1.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
System.out.println("Compo31 Cmd1 widgetSelected");
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		Command com31Cmd11 = new Command(com31Cmd1, Command.COMMANDGROUP, 1);
		com31Cmd11.setText("Compo31 Text1 Cmd1-1");

		Command com31Text1Cmd1 = new Command(com31Text1, Command.COMMANDGROUP, 1);
		com31Text1Cmd1.setText("Compo31 Text1 Cmd1");
		Command com31Text1Cmd11 = new Command(com31Text1Cmd1, Command.COMMANDGROUP, 1);
		com31Text1Cmd11.setText("Compo31 Text1 Cmd1-1");

		Command com31Button1Cmd1 = new Command(com31Button1, Command.COMMANDGROUP, 1);
		com31Button1Cmd1.setText("Compo31 Button1 Cmd1");

		
		// Composite 4
		Composite composite4 = new Composite(shell, SWT.BORDER);
		composite4.setBackground(new Color(display, 128, 128, 255));
		Command com4Cmd1 = new Command(composite4, Command.COMMANDGROUP, 1);
		com4Cmd1.setText("Compo4 Cmd1");

		final Button com4Button1 = new Button(composite4, SWT.BORDER);
		com4Button1.setText("Compo4 Button1");
		com4Button1.pack();
		com4Button1.setLocation(0, 0);

		final Button com4Button2 = new Button(composite4, SWT.BORDER);
		com4Button2.setText("Button2");
		com4Button2.setToolTipText("composite4 Button2");
		com4Button2.pack();
		com4Button2.setLocation(com4Button1.getSize().x, 0);

		final Button com4Button3 = new Button(composite4, SWT.BORDER);
		com4Button3.setText("Button3");
		com4Button3.setToolTipText("composite4 Button3");
		com4Button3.pack();
		com4Button3.setLocation(com4Button2.getLocation().x + com4Button2.getSize().x, 0);

		Command com4Button3Cmd1 = new Command(com4Button3, Command.COMMANDGROUP, 1);
		com4Button3Cmd1.setText("Compo4 Button3 Cmd1");
		com4Button3Cmd1.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("Compo4 Button3 Cmd1(Group) widgetSelected");
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
//		Command com4Button3Cmd11 = new Command(com4Button3Cmd1, Command.OK, 1);
//		com4Button3Cmd11.setText("Compo4 Button3 Cmd1-1");

		Command com4Button1Cmd1 = new Command(com4Button1, Command.COMMANDGROUP, 1);
		com4Button1Cmd1.setText("Compo4 Button1 Cmd1");

		final Command com4Button1Cmd11 = new Command(com4Button1Cmd1, Command.EXIT, 2);
		com4Button1Cmd11.setText("Compo4 Button1 Cmd1-1");
		com4Button1Cmd11.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println(e.widget);
				MessageBox mb = new MessageBox(shell, SWT.ICON_INFORMATION);
				mb.setText(com4Button1Cmd11.getText());
				mb.setMessage("Select Composite4 Button1 Command 1-1");
				mb.open();
				mb = null;
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		Command com4Button1Cmd12 = new Command(com4Button1Cmd1, Command.COMMANDGROUP, 1);
		com4Button1Cmd12.setText("Compo4 Button1 Cmd1-2");
		Command com4Button1Cmd13 = new Command(com4Button1Cmd1, Command.DELETE, 0);
		com4Button1Cmd13.setText("Compo4 Button1 Cmd1-3");

		Command com4Button1Cmd121 = new Command(com4Button1Cmd12, Command.CANCEL, 1);
		com4Button1Cmd121.setText("Compo4 Button1 Cmd1-2-1");
		Command com4Button1Cmd122 = new Command(com4Button1Cmd12, Command.OK, 0);
		com4Button1Cmd122.setText("Compo4 Button1 Cmd1-2-2");

		// Composite 5
		Composite composite5 = new Composite(shell, SWT.NONE);
		Composite composite6 = new Composite(composite5, SWT.NONE);
		composite6.setBackground(new Color(display, 255, 128, 128));

		final Button com5Button1 = new Button(composite6, SWT.BORDER);
		com5Button1.setText("Compo5 Button1");
		com5Button1.pack();
		com5Button1.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				Command cmd = new Command(com5Button1, Command.OK, 1);
				cmd.setText("Compo5 Button1");
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		Command cmdCom5Button1 = new Command(composite5, Command.OK, 0);
		cmdCom5Button1.setText("Compo5 Cmd1");
		
		FormLayout com6Layout = new FormLayout();
		com6Layout.marginWidth = 3;
		com6Layout.marginHeight = 3;
		com6Layout.spacing = 3;
		composite6.setLayout(com6Layout);

		FormData com6fd11 = new FormData();
		com6fd11.left = new FormAttachment(0, 0);
		com6fd11.top = new FormAttachment(0, 0);
		composite5.setLayoutData(com6fd11);
		

		FormLayout com5Layout = new FormLayout();
		com5Layout.marginWidth = 3;
		com5Layout.marginHeight = 3;
		com5Layout.spacing = 3;
		composite5.setLayout(com5Layout);
		
		FormData com5fd11 = new FormData();
		com5fd11.left = new FormAttachment(0, 0);
		com5fd11.top = new FormAttachment(0, 0);
		com5Button1.setLayoutData(com5fd11);

		FormData com5fd12 = new FormData();
		com5fd12.left = new FormAttachment(0, 0);
		com5fd12.top = new FormAttachment(com5Button1, 0);
		
		com4Button1.setParent(composite6);
		com4Button1.setLayoutData(com5fd12);

		

		Text text1 = new Text(shell, SWT.BORDER);
		text1.setText("No command");
		text1.pack();

		
		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		layout.spacing = 3;
		shell.setLayout(layout);
		
		FormData fd11 = new FormData();
		fd11.left = new FormAttachment(0, 0);
		fd11.top = new FormAttachment(0, 0);
		composite1.setLayoutData(fd11);

		FormData fd21 = new FormData();
		fd21.left = new FormAttachment(0, 0);
		fd21.top = new FormAttachment(composite1, 0);
		composite2.setLayoutData(fd21);

		FormData fd31 = new FormData();
		fd31.left = new FormAttachment(0, 0);
		fd31.top = new FormAttachment(composite2, 0);
		composite3.setLayoutData(fd31);

		FormData fd41 = new FormData();
		fd41.left = new FormAttachment(0, 0);
		fd41.top = new FormAttachment(composite3, 0);
		composite4.setLayoutData(fd41);

		FormData fd51 = new FormData();
		fd51.left = new FormAttachment(0, 0);
		fd51.top = new FormAttachment(composite4, 0);
		composite5.setLayoutData(fd51);

		FormData fd91 = new FormData();
		fd91.left = new FormAttachment(0, 0);
		fd91.top = new FormAttachment(composite5, 0);
		fd91.right = new FormAttachment(100, 0);
		text1.setLayoutData(fd91);
		
		

		// shell menu
		final Menu menu = new Menu(shell,SWT.BAR);
		final MenuItem fileMenuItem = new MenuItem(menu,SWT.CASCADE);
		fileMenuItem.setText("File");

		final Menu fileMenu = new Menu(shell,SWT.DROP_DOWN);
		fileMenuItem.setMenu(fileMenu);
		
		MenuItem textCommand1 = new MenuItem(fileMenu,SWT.PUSH);
		textCommand1.setText("Text Command 1");
		
		MenuItem textCommand2 = new MenuItem(fileMenu,SWT.PUSH);
		textCommand2.setText("Text Command 1");
		
		MenuItem groupItem1 = new MenuItem(fileMenu,SWT.CASCADE);
		groupItem1.setText("Group");
		Menu subMenu = new Menu(shell, SWT.DROP_DOWN);
		groupItem1.setMenu(subMenu);
		MenuItem grou1_1 = new MenuItem(subMenu, SWT.PUSH);
		grou1_1.setText("Text Group 1");
		MenuItem grou1_2 = new MenuItem(subMenu, SWT.PUSH);
		grou1_2.setText("Text Group 2");
		MenuItem itemBar = new MenuItem(fileMenu,SWT.BAR);
		
		MenuItem item2 = new MenuItem(fileMenu,SWT.PUSH);
		item2.setText("Compo Command 1");
		
		MenuItem item3 = new MenuItem(fileMenu,SWT.PUSH);
		item3.setText("Compo Command 2");
		MenuItem itemBar2 = new MenuItem(fileMenu,SWT.BAR);
		
		MenuItem item4 = new MenuItem(fileMenu,SWT.PUSH);
		item4.setText("Shell Command");
		//item2.setEnabled(false);

		MenuItem helpMenuItem = new MenuItem(menu,SWT.CASCADE);
		helpMenuItem.setText("Help1");
		
		Menu helpMenu = new Menu(shell,SWT.DROP_DOWN);
		helpMenuItem.setMenu(helpMenu);

		MenuItem helpMenuItem1 = new MenuItem(helpMenu,SWT.PUSH);
		helpMenuItem1.setText("Help");

		com4Button2.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		shell.setMenuBar(menu);

//System.out.println(Command.cmdHandle.toString());

		shell.setSize(240, 320);
		shell.open();
		shell.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
//				System.out.println(Command.cmdHandle.toString());
			}
		});

		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
		display.dispose();	
	}
*/
}

class CommandListener implements Listener {
	private int eventType;
	private Command command;
	private Listener listener;
	public CommandListener(Command command, int eventType, Listener listener) {
		setCommand(command);
		setEventType(eventType);
		setListener(listener);
	}
	public void setCommand(Command command) {
		this.command = command;
	}
	public Command getCommand() {
		return command;
	}
	public void setEventType(int eventType) {
		this.eventType = eventType;
	}
	public int getEventType() {
		return eventType;
	}
	public void setListener(Listener listener) {
		this.listener = listener;
	}
	public Listener getListener() {
		return listener;
	}
	public void handleEvent(Event event) {
		if(listener == null || command == null)
			return;
		Event e = new Event();
		e.button = event.button;
		e.character = event.character;
		e.count = event.count;
		e.data = event.data;
		e.detail = event.detail;
		e.display = event.display;
		e.doit = event.doit;
		e.end = event.end;
		e.gc = event.gc;
		e.height = event.height;
		e.item = event.item;
		e.keyCode = event.keyCode;
		e.start = event.start;
		e.stateMask  =event.stateMask;
		e.text = event.text;
		e.time = event.time;
		e.type = event.type;
		e.width = event.width;
		e.x = event.x;
		e.y = event.y;
		e.setBounds(event.getBounds());
		e.widget = command;
		listener.handleEvent(e);
	}
	
}

/*
 * @author daniel
 *
 * This class handle ControlNode tree
 * 1. bring up menu when Control gaine focus
 * 2. dispose menu when Control lost focus
 * 3. dispose ControlNode when Control dispose
 *  
 * Provide Command class access ControlNode tree
 * 1. add new control's command
 * 2. add sub command
 * 3. remove command when Command dispose
 * 4. add command SelectionListener
 * 5. remove command SelectionListener
 * 6. find control by command
 * 
 */
class CommandHandle implements Listener {
//	 if COMMAND_MENU_EXPAND_LEVEL set -1, expand all sub menu
//	 otherwise, expand sub menu to specify level 
	private static final int COMMAND_MENU_EXPAND_LEVEL = -1;
	private static final String COMMAND_MENU_NAME_KEY = "Command_Menu_Name";
	private static final String MOBILE_PROPERTY_NAME = "mobile";
	private static String cmdMenuName;
	private ControlNode root;
	private GC gc;
	private int displayWidth;
	private Vector commandList = new Vector(4, 4);

	// for softkey support
	static boolean supportSoftkey = false;
	static {
		switch(org.eclipse.swt.internal.Platform.IDENTIFY_CODE) {
			case org.eclipse.swt.internal.Platform.WM2005 :
			case org.eclipse.swt.internal.Platform.WM6PRO :
			case org.eclipse.swt.internal.Platform.SP2005 :
			case org.eclipse.swt.internal.Platform.WM6STD :
				supportSoftkey = true;
			case org.eclipse.swt.internal.Platform.WM2003 :
			case org.eclipse.swt.internal.Platform.SP2003 :
				if(org.eclipse.swt.internal.Platform.MAJOR_VERSION >= 5) {
					supportSoftkey = true;
				}
		}
	}
	private boolean skipSeparateMenuItem = false; 
	private Vector needDisposeMenuItems = new Vector();

	public CommandHandle() {
		root = new ControlNode();
		ResourceBundle rb = ResourceBundle.getBundle(MOBILE_PROPERTY_NAME, Locale.getDefault());
		cmdMenuName = rb.getString(COMMAND_MENU_NAME_KEY);
		rb = null;
	}

	// add sub command
	public ControlNode add(Command parent, Command command) {
		if(parent == null || command == null)
			return null;

		ControlNode ctrlode = findControlNode(parent);
		if(ctrlode == null)
			return null;
		CommandNode cmdNode = ctrlode.commandNode.findCommandNode(parent);
		cmdNode.addChild(new CommandNode(command));
		
		commandList.add(command);
		return ctrlode;
	}

	// add control and command
	public ControlNode add(Control control, Command command) {
		if(control == null || command == null)
			return null;

		ControlNode node = add(control);
		if(node != null)
			node.addCommand(command);

		// fix bug 99158 problem 2
		if(control.isFocusControl() || 
			(control instanceof Shell && control.getDisplay().getActiveShell() == control)) {
			Control child = null;
			if(control instanceof Composite) {
				child = getFocusChild((Composite)control);
			}
			if(child != null)
				makeMenu(child);
			else
				makeMenu(control);
		}

		commandList.add(command);
		return node;
	}

	// remove command
	public void removeCommand(Command command) {
		if(command == null)
			return;
		ControlNode node = root.findControlNode(command);
		if(node == null)
			return;
		node.commandNode.removeCommand(command);

		Shell shell = node.control.getShell();
		ControlNode shellNode = root.findControlNode(shell);
		Control focusControl = getFocusChild(shell);
		ControlNode focusNode = root.findControlNode(focusControl);
		// no control has focus or control(and parent) no command 
		if(focusControl == null || focusNode == null || !focusNode.hasCommand()) {
			if(shellNode != null) {
				if(shellNode.commandMenuItem != null && !shellNode.commandMenuItem.isDisposed())
					shellNode.commandMenuItem.dispose();
				shellNode.commandMenuItem = null;
			}
		} else {
			makeMenu(focusControl);
		}

		/*
		// fix bug 99158 problem 1
		if(!node.hasCommand()) {
			if(node.control == null)
				return;
			ControlNode shellNode = root.findControlNode(node.control.getShell());
			if(shellNode.commandMenuItem != null && !shellNode.commandMenuItem.isDisposed())
				shellNode.commandMenuItem.dispose();
			shellNode.commandMenuItem = null;
		}
*/
	}
	
	// check command and parent(s) are enabled
	public boolean isEnabled(Command command) {
		ControlNode ctrlNode = root.findControlNode(command);
		CommandNode cmdNode = ctrlNode.commandNode.findCommandNode(command);
		return cmdNode.isEnabled();
	}

	// find command's control in ControlNode tree
	public Control findControl(Command command) {
		if(command == null)
			return null;
		ControlNode node = root.findControlNode(command);
		if(node == null || node.control == null)
			return null;		
		return node.control;
	}
	public CommandNode findCommandNode(Command command) {
		ControlNode ctrlNode = root.findControlNode(command);
		if(ctrlNode == null)
			return null;
		return ctrlNode.commandNode.findCommandNode(command);
	}
	public void handleEvent(Event event) {
		if(event.type != SWT.FocusIn &&
			event.type != SWT.FocusOut)
			return;

		if(!(event.widget instanceof Control))
			return;

		Control control = (Control)event.widget;
		Shell shell = control.getShell();
		Rectangle oldClientArea = new Rectangle(0, 0, 0, 0);
		if(shell != null){
			oldClientArea = shell.getClientArea();
		}
		if(event.type == SWT.FocusOut) {
			if(supportSoftkey) {
				for(Iterator iterator = needDisposeMenuItems.iterator();iterator.hasNext();) {
					MenuItem item = (MenuItem)iterator.next();
					if(item != null && !item.isDisposed()) {
						item.dispose();
					}
				}
				needDisposeMenuItems.clear();
			} else {
				ControlNode shellNode = root.findControlNode(shell);
				if(shellNode == null)
					return;
				if(shellNode.commandMenuItem != null && !shellNode.commandMenuItem.isDisposed())
					shellNode.commandMenuItem.dispose();
				shellNode.commandMenuItem = null;
				shellNode.trigger = null;
			}
			
			//if OS == WIN32, check if command causes the client area to expand or shrink then re-layout
			if(org.eclipse.swt.internal.Platform.isWin32()) {
				if(shell != null && !oldClientArea.equals(shell.getClientArea())){
					shell.layout(true);
				}
			}
			
		} else {
			if (!control.isVisible()) return;
			ControlNode node = root.findControlNode(control);
			if(node == null) {
				node = findParentControlNode(control);
				if(node == null)
					return;
				else
					node = add(control);
			} else {
				if(node.parent.control != control.getParent())
					processParentChanged(control);
			}
			if(node.hasCommand()) {
				makeMenu(node.control);
				
				//if OS == WIN32, check if command causes the client area to expand or shrink then re-layout
				if(org.eclipse.swt.internal.Platform.isWin32()){
					if(shell != null && !oldClientArea.equals(shell.getClientArea())){
						shell.layout(true);
					}
				}
			}
		}
	}

	// add control and parent(s) to node
	private ControlNode add(Control control) {
		if(control == null)
			return null;

		Vector controls, unhandles;
		ControlNode node;
		Control c;

		// get control and parent(s)
		controls = new Vector();
		c = control;
		while(c != null) {
			controls.add(c);
//			if(c == control.getShell())
//				break;
			c = c.getParent();
		}

		// get control if control not in Control tree
		unhandles = new Vector();
		for(Iterator iterator = controls.iterator();iterator.hasNext();) {
			c = (Control)iterator.next();
			node = root.findControlNode(c);
			if(node == null)
				unhandles.add(c);
		}
		
		// add all control and parent to ControlNode tree
		node = root;
		for(int i=controls.size()-1; i>=0; i--) {
			c = (Control)controls.elementAt(i);
			node = add(node, c);
		}
		
		for(Iterator iterator = unhandles.iterator();iterator.hasNext();)
			addDisposeListener((Control)iterator.next());

		return node;
	}

	// add control to parent node, return control's node 
	private ControlNode add(ControlNode parent, Control control) {
		if(parent == null || control == null)
			return null;
		ControlNode node = root.findControlNode(control);
		if(node == null) {
			node = new ControlNode(control);
			parent.addChild(node);
		}
		return node;
	}

	// dispose ControlNode when control dispose
	private void addDisposeListener(Control control) {
		if(control == null)
			return;
		control.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
				ControlNode node = (ControlNode)root.findControlNode((Control)e.widget);
				if(node != null && !node.isDispose())
					node.dispose();
				node = null;
			}
		});
	}
	
	// process Control parent has changed
	private ControlNode processParentChanged(Control control) {
		if(control == null || control.getParent() == null)
			return null;

		ControlNode current, node;

		current = root.findControlNode(control);
		// clean no command(s) or no child(s) ControlNode
		if(current.parent != null) {
			node = current;
			node.parent.removeChild(node);
			node = node.parent;
			while(node.control != null) {
				if(!node.hasCommand() && !node.hasChild()) {
					node.dispose();
				}
				node = node.parent;
			}
		}

		// add all parent(s) control
		node = add(control.getParent());
		node.addChild(current);
		
		return current;		
	}

	// find command's ControlNode in ControlNode tree
	private ControlNode findControlNode(Command command) {
		if(command == null)
			return null;
		return root.findControlNode(command);
	}

	// find control or parent(s) if exist ControlNode tree
	private ControlNode findParentControlNode(Control control) {
		if(control == null)
			return null;

		ControlNode node = null;
		Control c = control;
		while(c != null) {
			node = root.findControlNode(c);
			if(node != null)
				break;
//			if(c == control.getShell())
//				break;
			c = c.getParent();
		}
		return node;
	}

	// bring up menu by Command
	public void makeMenu(Command command) {
		if(command == null)
			return;
		Control control = findControl(command);
		if(control == null)
			return;
		
		Control child = null;
		if(control instanceof Composite) {
			child = getFocusChild((Composite)control);
		}
		if(child != null)
			makeMenu(child);
		else
			makeMenu(control);
	}
	
	// bring up menu by Control
	private void makeMenu(Control control) {
		if(control == null)
			return;
		ControlNode node = root.findControlNode(control);
		if(node == null)
			return;

		if(gc == null) {
			gc = new GC(control.getDisplay());
			displayWidth = control.getDisplay().getBounds().width;
		}

		Shell shell = control.getShell();
		Menu mainMenu = shell.getMenuBar();
		// if shell menu not exist, create shell menu
		if (mainMenu == null) {
			mainMenu = new Menu(shell,SWT.BAR);
			shell.setMenuBar(mainMenu);
		}
		if(supportSoftkey) {
			makeSoftkeyMenu(node, mainMenu);
		} else {
			makeMenu(control, node, mainMenu);
		}
	}

	private void makeMenu(Control control, ControlNode controlNode, Menu mainMenu) {
		ControlNode shellNode = root.findControlNode(control.getShell());
		if(shellNode.commandMenuItem != null && shellNode.commandMenuItem.isDisposed()) {
			return;
		}
		if(shellNode.trigger == control) {
			if(shellNode.commandMenuItem != null && !shellNode.commandMenuItem.isDisposed()) {
				Menu m = shellNode.commandMenuItem.getMenu();
				if(m != null && !m.isDisposed())
					m.dispose();
			}
		} else {
			if(shellNode.commandMenuItem != null && !shellNode.commandMenuItem.isDisposed())
				shellNode.commandMenuItem.dispose();
			shellNode.commandMenuItem = null;
			shellNode.trigger = control;
		}
		if(shellNode.commandMenuItem == null) {
			shellNode.commandMenuItem = new MenuItem(mainMenu, SWT.CASCADE);
			shellNode.commandMenuItem.setText(cmdMenuName);
		}
		
		Menu commandMenu = new Menu(shellNode.commandMenuItem);
		shellNode.commandMenuItem.setMenu(commandMenu);

		controlNode.makeMenu(commandMenu);
	}
	private void makeSoftkeyMenu(ControlNode controlNode, Menu mainMenu) {
		for(Iterator iterator = needDisposeMenuItems.iterator();iterator.hasNext();) {
			MenuItem item = (MenuItem)iterator.next();
			if(item != null && !item.isDisposed()) {
				item.dispose();
			}
		}
		needDisposeMenuItems.clear();
		if(controlNode.hasCommand()) {
			controlNode.makeMenu(mainMenu);
		}
		ControlNode tmp = controlNode;
		while(tmp != null) {
			for(Iterator iterator = tmp.commandNode.childs.iterator(); iterator.hasNext();) {
				CommandNode commandNode = (CommandNode)iterator.next();
				needDisposeMenuItems.add(commandNode.item);
			}
			if(tmp.separateMenuItem != null) {
				needDisposeMenuItems.add(tmp.separateMenuItem);
			}
			tmp = tmp.parent;
		}
	}

	private Control getFocusChild(Composite c) {
		if (c == null) return null;
		Control[] children = c.getChildren();
		if (children == null) return null; //no

		for (int i=0;i<children.length;i++) {
			if (children[i] == null) continue;
			if (children[i].isDisposed()) continue;
			if (children[i].isFocusControl())
				return children[i];
			if(children[i] instanceof Canvas || children[i] instanceof CaptionedControl || children[i] instanceof Composite) {
				Control child = getFocusChild((Composite)children[i]); 
				if(child != null)
					return child;
			}
		}
		return null;
	}

/* debug method start
	public String toString() {
		return root.toString();
	}
debug method end */
	
	/*
	 * @author daniel
	 * This class produce control and child(s) tree
	 * this tree include all control if has command
	 * 
	 * example :
	 * root +-- Shell1 +-- Button11
	 *      |          +-- Composite12
	 *      |          +-- Composite13 +-- Text131
	 *      |                          +-- Labe132
	 *      | 
	 *      +-- Shell2 +-- Composite21 +-- Composite211 +-- Combo2111
	 *      |          +-- List22      +-- Button212
	 *      |          +-- Labe23
	 *      | 
	 *      +-- Shell3 +-- Shell31 +-- Text311
	 *      | 
	 *      +-- Shell4 +-- MultiPageShell41 +-- MultiPageComposite411 +-- Composite4111 +-- Text41111
	 *                                                                                  +-- Button41112
	 *                                                                +-- Composite4112 +-- Button41121
	 *     ...
	 * 
	 * When Control focus, Control make menu,
	 * continue call parent node make menu until Shell.
	 * 
	 * example 1 :
	 * 1. Text131 focus
	 * 2. Text131 make menu
	 * 3. Text131 call parent make menu
	 * 4. Composite13 make menu
	 * 5. Composite13 call parent make menu
	 * 6. Shell1 make menu
	 * 
	 * example 2 :
	 * 1. Combo2111 focus
	 * 2. Combo2111 make menu
	 * 3. Combo2111 call parent make menu
	 * 4. Composite211 make menu
	 * 5. Composite211 call parent make menu
	 * 6. Composite21 make menu
	 * 7. Composite21 call parent make menu
	 * 8. Shell2 make menu
	 * 
	 * example 3 :
	 * 1. Text311 focus
	 * 2. Text311 make menu
	 * 3. Text311 call parent make menu
	 * 4. Shell31 make menu
	 * 
	 * example 4(MultiPageDialog) :
	 * 1. Text41111 focus
	 * 2. Text41111 make menu
	 * 3. Text41111 call parent make menu
	 * 4. Composite4111 make menu
	 * 5. Composite4111 call parent make menu
	 * 6. MultiPageComposite411 make menu
	 * 7. MultiPageComposite411 call parent make menu
	 * 8. MultiPageShell41 make menu
	 * 9. MultiPageShell41 call parent make menu
	 * 10.Shell4 make menu
	 */
	class ControlNode {
		ControlNode parent;
		Vector childs;				// put ControlNode
		Control control;
		CommandNode commandNode;	// Command
		boolean dispose = false;
		MenuItem commandMenuItem = null;
		MenuItem separateMenuItem = null;
		Control trigger = null;
		
		// root node constructs
		public ControlNode() {
			parent = null;
			control = null;
			childs = new Vector();
			commandNode = new CommandNode();
		}
	
		// leaf node constructs
		public ControlNode(Control control) {
			this.control = control;
			childs = new Vector();
			commandNode = new CommandNode();
		}
	
		// add child node
		public ControlNode addChild(ControlNode node) {
			node.parent = this;
			childs.add(node);
			return node;
		}
		public ControlNode removeChild(ControlNode child) {
			childs.remove(child);
			return child;
		}
	
		// check this node has command
		public boolean contains(Command command) {
			return commandNode.contains(command);		
		}
		
		// add command
		public void addCommand(Command command) {
			commandNode.addChild(new CommandNode(command));
		}
		
		// find command's ControlNode in this or child(s) 
		public ControlNode findControlNode(Command command) {
			if(commandNode.contains(command))
				return this;
			return findControlNode(command, true);
		}
	
		// recursion find command's ControlNode 
		private ControlNode findControlNode(Command command, boolean recursion) {
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				ControlNode node = (ControlNode)iterator.next();
				if(node.isDispose())
					continue;
				if(node.commandNode.contains(command))
					return node;
				if(recursion) {
					node = node.findControlNode(command, recursion);
					if(node != null)
						return node;
				}
			}
	
			return null;		
		}
		
		// find control's ControlNode in this or child(s) 
		public ControlNode findControlNode(Control control) {
			if(control == null)
				return null;
			return findControlNode(control, control.getShell());
		}
		
		private ControlNode findControlNode(Control control, Shell shell) {
			return findControlNode(control, shell, true);
		}
		
		// recursion find control's ControlNode 
		private ControlNode findControlNode(Control control, Shell shell, boolean recursion) {
			if(control == null)
				return null;
	
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				ControlNode node = (ControlNode)iterator.next();
				if(node.isDispose())
					continue;
				if(node.control == control)
					return node;
				if(recursion) {
					node = node.findControlNode(control, shell, recursion);
					if(node != null && node.control == control)
						return node;
				}
			}
	
			return null;		
		}
		// has child(s)
		public boolean hasChild() {
			return (childs.size() > 0);
		}
		
		// this node has command
		public boolean hasCommand() {
			return hasCommand(true);
		}

		// this node and parent(s) has command
		private boolean hasCommand(boolean recursion) {
			if(commandNode.hasCommand())
				return true;
			if(recursion && parent != null && !isLast())
				if(parent.hasCommand(recursion))
					return true;
				
			return false;
		}
		
		// make this node command(and command child) menu, expand all sub menu
		public void makeMenu(Menu menu) {
			skipSeparateMenuItem = false;
			makeMenu(menu, COMMAND_MENU_EXPAND_LEVEL);
		}
		
		// make this node command(and command child) menu, expand specify level sub menu
		private void makeMenu(Menu menu, int level) {
			if(control == null || parent == null)
				return;
			if(commandNode.childs.size() > 0) {
				commandNode.makeMenu(menu, level);
				if(insertSeparateMenuItem()) {
					separateMenuItem = new MenuItem(menu, SWT.SEPARATOR);
				}
			}
			if(parent.hasCommand() && !isLast())
				parent.makeMenu(menu, level);
		}
		
		private boolean insertSeparateMenuItem() {
			if(!parent.hasCommand()) {
				return false;
			}
			if(isLast()) {
				return false;
			}
			if(supportSoftkey) {
				if(skipSeparateMenuItem) {
					return true;
				}
				boolean hasChild = false;
				for(Iterator iterator = commandNode.childs.iterator();iterator.hasNext();) {
					CommandNode node = (CommandNode)iterator.next();
					if(node.childs.size() > 0) {
						hasChild = true;
						break;
					}
				}
				if(hasChild) {
					return true;
				}
				if(commandNode.childs.size() == 1) {
					skipSeparateMenuItem = true;
					return false;
				}
			}
			
			return true;
		}
		
		private boolean isLast() {
			if(parent == null)
				return true;
			if(control == null)
				return true;
			if(control instanceof MultiPageShell)
				return true;
			if(!(control instanceof Shell))
				return false;
			Shell s = (Shell)control;
			if(s == s.getDisplay().getActiveShell())
				return true;
			if(control instanceof Shell && parent.control instanceof Shell)
				return true;
			return false;
			
		}
		
		// dispose this node and child(s) node
		public void dispose() {
			if(dispose)
				return;
			// dispose command
			commandNode.dispose();
			commandNode = null;
			
			// dispose menu
			if(commandMenuItem != null && !commandMenuItem.isDisposed())
				commandMenuItem.dispose();
			commandMenuItem = null;
			
			// dispose child(s)
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				ControlNode node = (ControlNode)iterator.next();
				if(node.isDispose())
					continue;
				node.dispose();
				node = null;
			}
			childs.clear();
			childs = null;
			dispose = true;
		}
		
		public boolean isDispose() {
			return dispose;
		}
/* debug method start
		public String toString() {
			return toString("");
		}
		public String toString(boolean reverse) {
			if(reverse) {
				return toStringReverse("");
			} else {
				return toString("");
			}
		}
		// child -> parent, like menu
		private String toStringReverse(String pre) {
			if(dispose)
				return "";
			StringBuffer sb = new StringBuffer();
			if(control != null) {
				sb.append(pre+control.toString() + "{handle="+control.internal_handle+"}");
			}
			sb.append(pre+"command(s) : \n");
			sb.append(commandNode.toString(pre));
			if(parent == null)
				sb.append("root");
			else
				sb.append(parent.toStringReverse(pre + "   "));
			return sb.toString();
		}
		// parent -> child, tree data
		private String toString(String pre) {
			if(dispose)
				return "";
			StringBuffer sb = new StringBuffer();
			if(control != null) {
				sb.append(pre+control.toString() + "{handle="+control.internal_handle+"}");
			}
			sb.append("[");
			if(parent == null) {
				sb.append("root");
			} else {
				if(parent.control == null)
					sb.append("root");
				else
					sb.append(parent.control.toString());
			}
			sb.append("]\n");
			sb.append(pre+"   command(s) : \n");
			sb.append(commandNode.toString(pre));
			if(hasChild()) {
				sb.append(pre+"   child(s) : \n");
				for(Iterator iterator = childs.iterator();iterator.hasNext();) {
					ControlNode node = (ControlNode)iterator.next();
					sb.append(node.toString(pre + "   "));
				}
			}
	
			return sb.toString();
		}
debug method end */
	}
	
	/*
	 * @author daniel
	 * This class provide command and sub command(s) tree in every ControlNode
	 */
	class CommandNode {
		CommandNode parent;
		Command command;
		Vector childs;			// put CommandNode
		MenuItem item; 
		boolean dispose = false;
	
		// root node constructs
		public CommandNode() {
			parent = null;
			command = null;
			childs = new Vector();
		}
	
		// leaf node constructs
		public CommandNode(Command command) {
			parent = null;
			this.command = command;
			childs = new Vector();
		}
	
		// add child command
		public CommandNode addChild(CommandNode child) {
			int insert = childs.size();
			for(int i=0; i<childs.size(); i++) {
				CommandNode node = (CommandNode)childs.elementAt(i);
				if(node.isDispose())
					continue;
				if(child.command.priority > node.command.priority) {
					insert = i;
					break;
				}
			}
			childs.insertElementAt(child, insert);
			child.parent = this;
			return child;
		}
	
		// has child(s)
		public boolean hasChild() {
			return (childs.size() > 0);
		}
	
		// check command already in this or child(s) 
		public boolean contains(Command command) {
			return contains(command, true);
		}
	
		// recursion check command already in this or child(s) 
		private boolean contains(Command command, boolean recursion) {
			if(this.command == command)
				return true;
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				CommandNode node = (CommandNode)iterator.next();
				if(node.isDispose())
					continue;
				if(recursion) {
					if(node.contains(command, recursion))
						return true;
				}
			}
			return false;
		}
		
		// check this and parent(s) node is enabled
		public boolean isEnabled() {
			return isEnabled(true);
		}

		// recursion check this and parent(s) node is enabled
		private boolean isEnabled(boolean recursion) {
			if(command != null && !command.getEnabled())
				return false;
			if(recursion && parent != null)
				if(!parent.isEnabled(recursion))
					return false;

			return true;
		}

		// check this and child(s) node has command 
		public boolean hasCommand() {
			return hasCommand(true);
		}
		
		// recursion check this and child(s) node has command 
		private boolean hasCommand(boolean recursion) {
			if(command != null)
				return true;
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				CommandNode node = (CommandNode)iterator.next();
				if(node.isDispose())
					continue;
				if(node.command != null)
					return true;
				if(node.hasCommand(recursion))
					return true;
			}
			return false;
		}
	
		// find command's ControlNode in this or child(s) 
		public CommandNode findCommandNode(Command child) {
			return findCommandNode(child, true);
		}
	
		// find command's ControlNode in child(s) when recursion is true
		private CommandNode findCommandNode(Command child, boolean recursion) {
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				CommandNode node = (CommandNode)iterator.next();
				if(node.isDispose())
					continue;
				if(node.command == child)
					return node;
				if(recursion) {
					node = node.findCommandNode(child, recursion);
					if(node != null && node.command == child)
						return node;
				}
			}
			return null;
		}
	
		// bring up this node command(and command child) menu, expand all sub menu
		public void makeMenu(Menu menu) {
			makeMenu(menu, true, -1);
		}
	
		// bring up this node command(and command child) menu, expand specify level sub menu
		public void makeMenu(Menu menu, int level) {
			makeMenu(menu, true, level);
		}
	
		// bring up this node command(and command child if recursion is true) menu, expand specify level sub menu
		private void makeMenu(Menu menu, boolean recursion, int level) {
			if(!hasChild())
				return;
	
			Vector hasChild = new Vector();
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				CommandNode node = (CommandNode)iterator.next();
				if(node.isDispose())
					continue;
				if(node.hasChild()) {
					MenuItem item = new MenuItem(menu, SWT.CASCADE);
					setMenuItem(item, node.command);
					implementListener(item, node.command);
					node.item = item;
					if(!node.command.enabled)
						continue;
					if(!recursion)
						continue;
					if(level != 0) {
						Menu subMenu = new Menu(item);
						item.setMenu(subMenu);
						node.makeMenu(subMenu, recursion, level-1);
					} else {
						hasChild.add(node);
					}
				} else { 
					MenuItem item = new MenuItem(menu, SWT.PUSH);
					setMenuItem(item, node.command);
					implementListener(item, node.command);
					node.item = item;
					itemAddSelectionListener(item, node.command);
				}
			}
			// has child command
			for(Iterator iterator = hasChild.iterator();iterator.hasNext();) {
				CommandNode node = (CommandNode)iterator.next();
				if(node.isDispose())
					continue;
				MenuItem barItem = new MenuItem(menu, SWT.SEPARATOR);
				node.makeMenu(menu, recursion, 0);
			}
		}
		
		private void implementListener(MenuItem item, Command command) {
			if(command.listeners == null)
				return;
			final MenuItem item_tmp = item;
			for(int i=0; i<command.listeners.size(); i++) {
				final CommandListener cmdListener = (CommandListener)command.listeners.elementAt(i);
				item.addListener(cmdListener.getEventType(), cmdListener);
				item.addDisposeListener(new DisposeListener() {
					public void widgetDisposed(DisposeEvent e) {
						item_tmp.removeListener(cmdListener.getEventType(), cmdListener);
					}
				});
			}
		}
		
		private void itemAddSelectionListener(MenuItem item, Command command) {
			if(item == null || item.isDisposed() || 
			   command == null || command.isDisposed())
				return;
			final Command nodeCommand = command;
			item.addSelectionListener(new SelectionListener(){
				public void widgetSelected(SelectionEvent e) {
					if(nodeCommand.selectionListenerCount > 0)
						nodeCommand.Command_SendEvent(SWT.Selection);
				}
				public void widgetDefaultSelected(SelectionEvent e) {
					if(nodeCommand.selectionListenerCount > 0)
						nodeCommand.Command_SendEvent(SWT.DefaultSelection);
				}
			});
		}
		
		// set MenuItem data from Command
		private void setMenuItem(MenuItem item, Command command) {
			if(item == null || command == null)
				return;

			String longLabel = command.getLongLabel();
			if(longLabel != null && (gwtStringWidth(longLabel) < displayWidth || command.getText().equals("")))
				item.setText(longLabel);
			else
				item.setText(command.getText());
			item.setAccelerator(command.accelerator);
			if(command.getImage() != null)
				item.setImage(command.getImage());
			item.setEnabled(command.enabled);
			item.setSelection(command.defaultCommand);
		}
		
		private int gwtStringWidth(String str) {
			if(str == null)
				return 0;
			int width = 0;
			for(int i=0; i<str.length(); i++)
				width += gc.getCharWidth(str.charAt(i));
			return width;
		}
		
		// remove command
		public boolean removeCommand(Command command) {
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				CommandNode node = (CommandNode)iterator.next();
				if(node.isDispose())
					continue;
				if(node.command == command) {
					childs.remove(node);
					node.dispose();
					node = null;
					return true;
				}
				if(node.removeCommand(command))
					return true;
			}
			return false;
		}
	
		// dispose this node and child(s) node
		public void dispose() {
			if(dispose)
				return;
			for(Iterator iterator = childs.iterator();iterator.hasNext();) {
				CommandNode node = (CommandNode)iterator.next();
				if(node.isDispose())
					continue;
				node.dispose();
				node = null;
			}
			if(item != null && !item.isDisposed())
				item.dispose();
			childs.clear();
			childs = null;
			dispose = true;
		}
		public boolean isDispose() {
			return dispose;
		}
/* debug method start
		public String toString() {
			return toString("");
		}
		public String toString(String pre) {
			if(dispose)
				return "";
			StringBuffer sb = new StringBuffer();
			if(command != null) {
				sb.append(pre);
				sb.append(command.toString());
				sb.append("\n");
			}
			
			if(hasChild()) {
				if(command != null)
					sb.append(pre+"child(s) : \n");
				for(Iterator iterator = childs.iterator();iterator.hasNext();) {
					CommandNode node = (CommandNode)iterator.next();
					sb.append(node.toString(pre + "   "));
				}
			}
			return sb.toString();
		}
debug method end */
	}
	
	public void setDefaultCommand(Command c){
		Command tempCommand;
		for(int i = 0; i<commandList.size(); i++){
			tempCommand = (Command) commandList.elementAt(i);
			if(tempCommand.defaultCommand && !tempCommand.equals(c)){
				tempCommand.defaultCommand = false;
			}
		}		
	}

}
