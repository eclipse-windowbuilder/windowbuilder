/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.*;

import org.eclipse.swt.graphics.*;



/**
 * 
 * A CaptionedControl is used to display a label (caption) in front of a
 * control. An optional trailing text can be used after the control, for
 * example, to indicate units of measurement.
 * <p>
 * The highlighting is implementation dependent. Typically, a focused
 * CaptionedControl will highlight all its elements, i.e. the leading label, the
 * control, and optional trailing label, when it gets focus. The positioning
 * order for the captions is determined by the <code>SWT.LEFT_TO_RIGHT</code>
 * and <code>SWT.RIGHT_TO_LEFT</code> styles hints.
 * </p>
 * 
 * <p>
 * CaptionedControl does not support nested CaptionedControls. An exception will
 * be thrown when an instance of CaptionedControl is given as the constructor's
 * argument. To change the control contained by the CaptionedControl, a new
 * control can be created using the CaptionedControl as its parent control.
 * The old control must be disposed by the application manually. Only one control
 * can be active and visible in a CaptionedControl. Which control is displayed
 * when multiple controls have been added is implementation-dependent.
 * </p>
 * <p>
 * When using CaptionedControl in a layout and setting layout data, be sure to 
 * set the data on the CaptionedControl instance and not on the captioned 
 * widget. The internal layout of the CaptionedControl is not user modifyable.
 * </p>
 * <p>
 * <em>Example code:</em>
 * </p>
 * <p>
 * <code><pre>
 * CaptionedControl control = new CaptionedControl(shell, SWT.NONE);
 * ConstraintedText currency = new ConstraintedText(control, SWT.NONE,
 * 		ConstraintedText.NUMERIC);
 * control.setText(&quot;Velocity&quot;);
 * control.getTrailingText(&quot;cm&quot;);
 * </pre></code>
 * </p>
 * 
 * <p>
 * <dl>
 * <dt><b>Styles: </b></dt>
 * <dd>SWT.LEFT_TO_RIGHT (default)</dd>
 * <dd>SWT.RIGHT_TO_LEFT</dd>
 * <dt><b>Events: </b></dt>
 * <dd>(none)</dd>
 * </dl>
 * <p>
 * Note: Even though this class is a subclass of Composite, 
 * setting a layout on it is not supported.
 * </p>
 * <p>
 * IMPORTANT: This class is not intended to be subclassed.
 * </p>
 *  
 */
public class CaptionedControl extends Composite {

	/**
	 * Constructs a new instance of this class given its parent and a style
	 * value describing its behavior and appearance.
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. The class description lists the style constants that are
	 * applicable to the class. Style bits are also inherited from superclasses.
	 * </p>
	 * 
	 * @param parent
	 *            a widget which will be the parent of the new instance (cannot
	 *            be null)
	 * @param style
	 *            the style of widget to construct
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * 
	 * @see SWT#LEFT_TO_RIGHT
	 * @see SWT#RIGHT_TO_LEFT
	 */
	
	Label captionLabel = null;
	Label trailingLabel = null;
	Label iconImage = null;
	IndexData rd;
	int orientationStyle = 0;
	int headingIndex = 0;
	int imgIndex = 0;
	int trailingIndex = 0;
	int innerLabelCount = 0;
	
	private Listener focusInListener;
	private Listener focusOutListener;
	
	public CaptionedControl(Composite parent, int style) {
		super(parent, SWT.NULL);
		if (parent instanceof CaptionedControl){
			SWT.error(SWT.ERROR_INVALID_SUBCLASS);
			return;
		}
		
		
		orientationStyle = style;
		
		IndexLayout rl = new IndexLayout();
		rl.wrap = false;
		rl.pack = true;
		this.setLayout(rl);
		
//		captionLabel = new Label(this, SWT.NULL);
//		iconImage = new Label(this, SWT.NULL);
		//FontData boldFont = new FontData("Ariel",9,SWT.BOLD);
		//captionLabel.setFont(new Font(this.getDisplay(),boldFont));
		
		final Display display = this.getDisplay();
		final Control thisControl = this;
	
		focusInListener = new Listener(){
			public void handleEvent(Event event) {
				
				Control c = (Control)event.widget;
				Control parent = c.getParent();
				if ((parent == thisControl) || (c == thisControl)) {
					if (!thisControl.isDisposed()) {
						
						if ( (captionLabel != null) && (!captionLabel.isDisposed())){
							captionLabel.setBackground(new Color(display,255,200,120));
						}
						
						if ((trailingLabel!=null)&& (!trailingLabel.isDisposed())) {
							trailingLabel.setBackground(new Color(display,255,200,120));
							
						}
					}
				}
				if (c == thisControl) {
					if (!thisControl.isDisposed()) {
						Control[] children = ((Composite)thisControl).getChildren();
						for (int i=0;i<children.length;i++) {
							if (!(children[i] instanceof Label)) {
								children[i].forceFocus();
								break;
							}
						}
					}
				}
			}
		};
		
		focusOutListener = new Listener(){
			public void handleEvent(Event event) {
				Control c = (Control)event.widget;
				// fix bug of 
				//SortedList caption stays highlighted after it has been selected
				while(c!=thisControl){
					if(c.getParent() instanceof Shell){
						break;
					}else{
						c = c.getParent();
					}
				}
				if (c == thisControl) {
					if (captionLabel!=null)
						captionLabel.setBackground(null);
					if (trailingLabel!=null) {
						trailingLabel.setBackground(null);
					}
				}
			}
		};
		
		display.addFilter(SWT.FocusIn, focusInListener);
		display.addFilter(SWT.FocusOut, focusOutListener);
		
		this.addListener(SWT.MouseDown, new Listener(){
			public void handleEvent(Event event){
				if (getControl()!=null)
					getControl().setFocus();
			}
		});
	}

	/**
	 * Sets the caption label
	 * 
	 * @param string
	 *            the new caption label
	 * 
	 * @throws java.lang.IllegalArgumentException
	 *             <code>ERROR_NULL_ARGUMENT</code> if the text is null
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @see #getText
	 */
	public void setText(java.lang.String string) {
		checkWidget();
		if (string == null){
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		if (null == captionLabel) {
			captionLabel = new Label(this, SWT.NULL);
			captionLabel.addListener(SWT.MouseDown, new Listener(){
				public void handleEvent(Event event){
					if (getControl()!=null){					
						getControl().setFocus();
					}
				}
			});
			innerLabelCount ++;
			headingIndex = innerLabelCount;
		}
		captionLabel.setText(string);
		Point p = captionLabel.computeSize(SWT.DEFAULT, SWT.DEFAULT);
		rd = new IndexData(p.x, p.y);
		captionLabel.setLayoutData(rd);
		
		
		this.layout();
	}
	
//	public Point computeSize(int wHint, int hHint, boolean changed) {
//
//		
//			Point p = super.computeSize(wHint, hHint, changed);
//			System.out.println("size is "+p.x+", "+p.y);
//			return p;
//			
//			
//			
//			
//			
//	}
//	
//	public void setSize(int x, int y){
//		System.out.println("setSize "+x+", "+y);
//		super.setSize(x, y);
//		
//		
//		
//	}
//	public void setSize(Point p){
//		System.out.println("setSize "+p.x+", "+p.y);
//		super.setSize(p);
//		
//		
//		
//	}
	
	protected void releaseWidget(){
		if(captionLabel!=null){
			if(!captionLabel.isDisposed()){
				captionLabel.dispose();
			}
			captionLabel=null;
		}
		if(trailingLabel!=null){
			if(!trailingLabel.isDisposed()){
				trailingLabel.dispose();
			}
			trailingLabel=null;
		}
		if(iconImage!=null){
			if(!iconImage.isDisposed()){
				iconImage.dispose();
			}
			iconImage=null;
		}
		if(rd!=null){
			rd=null;
		}
		
		super.releaseWidget();
	}
	
	//Eric, Make embedded children as correct enablement 
	public void setEnabled(boolean enabled) {
		super.setEnabled(enabled);
		Control[] children = this.getChildren();
		for (int i=0;i<children.length;i++) {
			if(!children[i].isDisposed())
				children[i].setEnabled(enabled);
		}
		
	}

	/**
	 * Sets the trailing label
	 * 
	 * @param string
	 *            the new trailing label
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see #getTrailingText
	 */
	public void setTrailingText(java.lang.String string) {
		checkWidget();
		if (string == null){
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
			return;
		}
		
		if (trailingLabel == null) {
			trailingLabel = new Label(this, SWT.NULL);
			trailingLabel.addListener(SWT.MouseDown, new Listener(){
				public void handleEvent(Event event){
					if (getControl()!=null)
						getControl().setFocus();
				}
			});
			innerLabelCount ++;
			trailingIndex = innerLabelCount;
		}
		trailingLabel.setText(string);
		Point p = trailingLabel.computeSize(SWT.DEFAULT, SWT.DEFAULT);
		rd = new IndexData(p.x, p.y);		
		trailingLabel.setLayoutData(rd);
		
		this.layout();
	}
	
	/**
	 * Gets the caption text, which will be an empty string if it has never been
	 * set.
	 * 
	 * @return The label text.
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see #setText(java.lang.String)
	 */
	public String getText() {
		checkWidget();
		if (captionLabel == null) return new String("");
		return captionLabel.getText();
	}
	
	/* CaptionedControl has internal layout for using, overwrite setLayout to prevent user set other Layout */
	public void setLayout(Layout layout) {
		
		checkWidget();
		
		if (layout instanceof IndexLayout) {
			super.setLayout(layout);
			
		} else {
			super.setLayout(null);
			Control [] children = this.getChildren();
			for(int i =0; i<children.length; i++){
				children[i].setLayoutData(null);
			}			
			super.setLayout(layout);
		}
	}

	/**
	 * Gets the trailing text, which will be an empty string if it has never
	 * been set.
	 * 
	 * @return The trailing text.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see #setTrailingText(java.lang.String)
	 */
	public String getTrailingText() {
		checkWidget();
		if (trailingLabel == null) return new String("");
		else return trailingLabel.getText();
	}

	/**
	 * Sets the image as an icon to the CaptionedControl. The icon can co-exist
	 * with caption text. The icon position is platform-dependent.
	 * 
	 * <p>
	 * The parameter can be null indicating that no image should be displayed.
	 * The implementation will adjust the image size to make it best fit the
	 * CaptionedControl.
	 * </p>
	 * 
	 * @param image
	 *            the image to display on the receiver
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the image has been
	 *                disposed</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 *  
	 */

	public void setImage(Image image) {
		checkWidget();
		if (image == null) {
			if (iconImage != null) {
				iconImage.dispose();
				iconImage = null;
				if (headingIndex > imgIndex) {
					headingIndex --;
				}
				if (trailingIndex > imgIndex ) {
					trailingIndex --;
				}
				imgIndex = 0;
				innerLabelCount --;
			}
			return;
		}
		if (image.isDisposed()){
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		}
		if (null == iconImage) {
			iconImage = new Label(this, SWT.NULL);
			iconImage.addListener(SWT.MouseDown, new Listener(){
				public void handleEvent(Event event){
					if (getControl()!=null)
						getControl().setFocus();
				}
			});
			innerLabelCount ++;
			imgIndex = innerLabelCount;
			
		}
		iconImage.setImage(image);
		
	}

	/**
	 * Returns the CaptionedControl's icon image, or null if it has never been
	 * set.
	 * 
	 * @return the icon image or null.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @see #setImage(Image)
	 */
	public Image getImage() {
		checkWidget();
		if (iconImage == null) return null;
		else return iconImage.getImage();
	}
	
	
	Control getControl(){
		Control controlList[] =  new Control[4];		
		controlList = this.getTabList();
		for(int i=0; i<controlList.length; i++){
			if (!(controlList[i] instanceof Label)){
				return controlList[i];
			}
		}
		return null;
	}
	
	// Michael
	public Control [] getChildren(){
		Control [] children = super.getChildren();
		CaptionedControl captionedControl = this;
		
		if (children.length == 2) {
			if ((children[0] instanceof Label) && (children[1] instanceof Label)) {
				if ((captionedControl.headingIndex > captionedControl.imgIndex) ||        /* [img] [heading] */
					(captionedControl.imgIndex > captionedControl.trailingIndex) || 	  /* [trailing] [img] */
					(captionedControl.headingIndex > captionedControl.trailingIndex)) {   /* [trailing] [heading] */
					Control tmp;
					tmp = children[1];
					children[1] = children[0];
					children[0] = tmp;
				}
			} else if (children[0] instanceof Label) {
				if (captionedControl.trailingIndex == 1) { /* [trailing] [innerControl] */
					Control tmp;
					tmp = children[1];
					children[1] = children[0];
					children[0] = tmp;
				}
				//innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) - - 3*spacing;
			} else if (children[1] instanceof Label) {
				if ((captionedControl.headingIndex == 1) || /* [innerControl] [heading] */
					(captionedControl.imgIndex ==1)) {		/* [innerControl] [icon] */
					Control tmp;
					tmp = children[1];
					children[1] = children[0];
					children[0] = tmp;
				}
				//innerControlWidth = width - (children[1].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) - 3*spacing;
			}
			if (this.orientationStyle == SWT.RIGHT_TO_LEFT) {
				Control tmp;
				tmp = children[1];
				children[1] = children[0];
				children[0] = tmp;
			}
		} else if (children.length == 3) {
			if ((children[0] instanceof Label) && 
				(children[1] instanceof Label) && 
				(children[2] instanceof Label)) {
				Control[] tempChildren = new Control[3];
				tempChildren[0] = children[captionedControl.headingIndex];          //Eric modified for bug 131560 problem [3]
				tempChildren[1] = children[captionedControl.imgIndex];
				tempChildren[2] = children[captionedControl.trailingIndex ];
				children = tempChildren;
			} else if (captionedControl.headingIndex == 0) { /* [icon] [innerControl] [trailing] */
				Control[] tempChildren = new Control[3];
				for (int i=0; i<3; i++) {
					if (children[i] == (Control)captionedControl.iconImage) {
						tempChildren[0] =  children[i];
					} else if (children[i] == (Control)captionedControl.trailingLabel) {
						tempChildren[2] =  children[i];
					} else { //innerControl
						tempChildren[1] = children[i];
					}
				}
				children = tempChildren;
//				innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
//										  - (children[2].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
//										  - 4*spacing;
			} else if (captionedControl.imgIndex == 0) { /* [heading] [innerControl] [trailing] */
				Control[] tempChildren = new Control[3];
				for (int i=0; i<3; i++) {
					if (children[i] == (Control)captionedControl.captionLabel) {
						tempChildren[0] =  children[i];
					} else if (children[i] == (Control)captionedControl.trailingLabel) {
						tempChildren[2] =  children[i];
					} else { //innerControl
						tempChildren[1] = children[i];
					}
				}
				children = tempChildren;
//				innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
//										  - (children[2].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
//										  - 4*spacing;
				
			} else if (captionedControl.trailingIndex == 0) { /* [heading] [icon] [innerControl] */
				Control[] tempChildren = new Control[3];
				for (int i=0; i<3; i++) {
					if (children[i] == (Control)captionedControl.captionLabel) {
						tempChildren[0] =  children[i];
					} else if (children[i] == (Control)captionedControl.iconImage) {
						tempChildren[1] =  children[i];
					} else { //innerControl
						tempChildren[2] = children[i];
					}
				}
				children = tempChildren;
//				innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
//										  - (children[1].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
//										  - 4*spacing;
//				
			}
			
			if (this.orientationStyle == SWT.RIGHT_TO_LEFT) {
				
				Control temp;
				temp = children[2];
				children[2] = children[0];
				children[0] = temp;

			}
			
		} else if (children.length == 4) { /* [heading] [icon] [innerControl] [trailing] */
			Control[] tempChildren = new Control[4];
			for (int i=0; i<4; i++) {
				if (children[i] == (Control)captionedControl.captionLabel) {
					tempChildren[0] =  children[i];
				} else if (children[i] == (Control)captionedControl.iconImage) {
					tempChildren[1] =  children[i];
				} else if (children[i] == (Control)captionedControl.trailingLabel) {
					tempChildren[3] =  children[i];
				} else { //innerControl
					tempChildren[2] = children[i];
				}
		   }
			children = tempChildren;
			// workaround to bug# 100722, make the innerControl's width = the rest of available CaptionedControl's space
//			innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
//										- (children[1].computeSize(SWT.DEFAULT,SWT.DEFAULT).x)
//										- (children[3].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) - 5*spacing;

			
			if (this.orientationStyle == SWT.RIGHT_TO_LEFT) {
				Control temp;
				temp = children[3];
				children[3] = children[0];
				children[0] = temp;
				temp = children[2];
				children[2] = children[1];
				children[1] = temp;
			}
			
		}
			return children;		
	}	
	

	
	protected void removeInternalFilter(){
		if(focusInListener!=null){
			this.getDisplay().removeFilter(SWT.FocusIn, focusInListener);
		}
		focusInListener = null;
		if(focusOutListener!=null){
			this.getDisplay().removeFilter(SWT.FocusOut, focusOutListener);
		}
		focusOutListener = null;
		
	}
}



final class IndexLayout extends Layout {
	public int type = SWT.HORIZONTAL;
 	public int marginWidth = 0;
 	public int marginHeight = 0;
	public int spacing = 3;
	public boolean wrap = true;
	public boolean pack = true;
	public boolean fill = false;
	public boolean justify = false;
	public int marginLeft = 3;
	public int marginTop = 3;
	public int marginRight = 3;
	public int marginBottom = 3;
public IndexLayout () {
}

public IndexLayout (int type) {
	this.type = type;
}

protected Point computeSize (Composite composite, int wHint, int hHint, boolean flushCache) {
	Point extent;
	if (type == SWT.HORIZONTAL) {
		extent = layoutHorizontal (composite, false, (wHint != SWT.DEFAULT) && wrap, wHint, flushCache);
	} else {
		extent = layoutVertical (composite, false, (hHint != SWT.DEFAULT) && wrap, hHint, flushCache);
	}
	if (wHint != SWT.DEFAULT) extent.x = wHint;
	if (hHint != SWT.DEFAULT) extent.y = hHint;
	return extent;
}

Point computeSize (Control control, boolean flushCache) {
	int wHint = SWT.DEFAULT, hHint = SWT.DEFAULT;
	IndexData data = (IndexData) control.getLayoutData ();
	if (data != null) {
		wHint = data.width;
		hHint = data.height;
	}
	return control.computeSize (wHint, hHint, flushCache);
}

protected boolean flushCache (Control control) {
	return true;
}

String getName () {
	String string = getClass ().getName ();
	int index = string.lastIndexOf ('.');
	if (index == -1) return string;
	return string.substring (index + 1, string.length ());
}

protected void layout (Composite composite, boolean flushCache) {
	Rectangle clientArea = composite.getClientArea ();
	if (type == SWT.HORIZONTAL) {
		layoutHorizontal (composite, true, wrap, clientArea.width, flushCache);
	} else {
		layoutVertical (composite, true, wrap, clientArea.height, flushCache);
	}
}

Point layoutHorizontal (Composite composite, boolean move, boolean wrap, int width, boolean flushCache) {
	
	Control [] children = composite.getChildren ();
	int innerControlWidth = 0,  label_count= 0;	
	Control temp;
	CaptionedControl captionedControl = (CaptionedControl) composite; 
	if (children.length == 2) {
	  if ((children[0] instanceof Label) && (children[1] instanceof Label)) {     //Eric : if there are two labels coexisted
		 if (((CaptionedControl)composite).orientationStyle == SWT.LEFT_TO_RIGHT) {  //       the order of captionedcontrol including controls will be incorrect for bug 131560 [2]
			if (captionedControl.captionLabel != null){
			     if(captionedControl.captionLabel.equals(((Label)children[1])))    //if captionLabel isn't in first position
				 {
				  temp = children[0];
				  children[0] = children[1];
				  children[1] = temp;
				 }
			}
			else if (captionedControl.trailingLabel != null){                     //if trailingLabel isn't in last position  
			     if(captionedControl.trailingLabel.equals(((Label)children[0])))
				 {
				  temp = children[1];
				  children[1] = children[0];
				  children[0] = temp;
				 }
			  }
		 }
		 else if (((CaptionedControl)composite).orientationStyle == SWT.RIGHT_TO_LEFT) {
		   if (captionedControl.captionLabel != null){
			   if(captionedControl.captionLabel.equals(((Label)children[0])))
					 {
					  temp = children[1];
					  children[1] = children[0];
					  children[0] = temp;
					 }
		   }		
		   else if (captionedControl.trailingLabel != null){
		       if(captionedControl.trailingLabel.equals(((Label)children[1])))
					 {
					  temp = children[0];
					  children[0] = children[1];
					  children[1] = temp;
					 }
		    }
		  }
		} else if (children[0] instanceof Label) {
			innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) - 3*spacing;
		} else if (children[1] instanceof Label) {
			innerControlWidth = width - (children[1].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) - 3*spacing;
		}
		
	} else if (children.length == 3) {
		if ((children[0] instanceof Label) &&                         //Eric : if there are three labels coexisted
			(children[1] instanceof Label) &&                         //       The order of captionedcontrol including controls will be incorrect
			(children[2] instanceof Label)) {                         //       for bug 121560 [2]
			if (((CaptionedControl)composite).orientationStyle == SWT.LEFT_TO_RIGHT) {
				 if (captionedControl.captionLabel != null){
					 for ( label_count =1; label_count <= 2; label_count++ )
				      if(captionedControl.captionLabel.equals(((Label)children[label_count])))
					  {
					   temp = children[0];
					   children[0] = children[label_count];
					   children[label_count] = temp;
					  }
				 }
				 if (captionedControl.trailingLabel != null){
					for ( label_count = 0; label_count <= 1; label_count++ )
				     if(captionedControl.trailingLabel.equals(((Label)children[label_count])))
					 {
					  temp = children[2];
					  children[2] = children[label_count];
					  children[label_count] = temp;
					 }
				  }
			} 
			else if (((CaptionedControl)composite).orientationStyle == SWT.RIGHT_TO_LEFT) {
				  if (captionedControl.captionLabel != null){
				   for ( label_count = 0; label_count <= 1; label_count++ )
				    if(captionedControl.captionLabel.equals(((Label)children[label_count])))
						 {
						  temp = children[2];
						  children[2] = children[label_count];
						  children[label_count] = temp;
						 }
					  }		
				  if (captionedControl.trailingLabel != null){
				   for ( label_count = 1; label_count <= 2; label_count++ )
					if(captionedControl.trailingLabel.equals(((Label)children[label_count])))
						 {
						  temp = children[0];
						  children[0] = children[label_count];
						  children[label_count] = temp;
						 }
					 }
			}			
		} else if (captionedControl.headingIndex == 0) { /* [icon] [innerControl] [trailing] */
			innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
									  - (children[2].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
									  - 4*spacing;
		} else if (captionedControl.imgIndex == 0) { /* [heading] [innerControl] [trailing] */
			innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
									  - (children[2].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
									  - 4*spacing;

		} else if (captionedControl.trailingIndex == 0) { /* [heading] [icon] [innerControl] */
			innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
									  - (children[1].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
									  - 4*spacing;			
		}

	} else if (children.length == 4) { /* [heading] [icon] [innerControl] [trailing] */
		// workaround to bug# 100722, make the innerControl's width = the rest of available CaptionedControl's space
		innerControlWidth = width - (children[0].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) 
									- (children[1].computeSize(SWT.DEFAULT,SWT.DEFAULT).x)
									- (children[3].computeSize(SWT.DEFAULT,SWT.DEFAULT).x) - 5*spacing;
	}	
	
	int count = children.length;
	int childWidth = 0, childHeight = 0, maxHeight = 0;
	if (!pack) {
		
		for (int i=0; i<count; i++) {
			Control child = children [i];
			Point size = computeSize (child, flushCache);
			childWidth = Math.max (childWidth, size.x);
			childHeight = Math.max (childHeight, size.y);
		}
		maxHeight = childHeight;
		
	}
	int clientX = 0, clientY = 0;
	if (move) {
		Rectangle rect = composite.getClientArea ();
		clientX = rect.x;
		clientY = rect.y;
	}
	int [] wraps = null;
	boolean wrapped = false;
	Rectangle [] bounds = null;
	if (move && (justify || fill)) {
		bounds = new Rectangle [count];
		wraps = new int [count];
	}
	int maxX = 0, x = marginLeft + marginWidth, y = marginTop + marginHeight;
	for (int i=0; i<count; i++) {
		Control child = children [i];
		if (pack) {
			
			Point size = computeSize (child, flushCache);
			childWidth = size.x;
			childHeight = size.y;
		}
		if (wrap && (i != 0) && (x + childWidth > width)) {
			wrapped = true;
			if (move && (justify || fill)) wraps [i - 1] = maxHeight;
			x = marginLeft + marginWidth;
			y += spacing + maxHeight;
			if (pack) maxHeight = 0;
		}
		if (pack || fill) {
			maxHeight = Math.max (maxHeight, childHeight);
		}
		if (move) {
			int childX = x + clientX, childY = y + clientY;
			if (justify || fill) {
				bounds [i] = new Rectangle (childX, childY, childWidth, childHeight);
			} else {
				if ((!(children[i] instanceof Label)) ){//&& (i !=(count-1)))  { //if there are only 2 children, we won't change innterControl's width
					childWidth = innerControlWidth; 		// workaround to bug# 100722, make the innerControl's width = the rest of available CaptionedControl's space
					childHeight = composite.getSize().y-marginTop-marginBottom; // fix for Bug 110367, subtract margin off the child widget size
				}
				
				child.setBounds (childX, childY, childWidth, childHeight);
			}
		}
		x += spacing + childWidth;
		maxX = Math.max (maxX, x);
	}
	maxX = Math.max (clientX + marginLeft + marginWidth, maxX - spacing);
	if (!wrapped) maxX += marginRight + marginWidth;
	if (move && (justify || fill)) {
		int space = 0, margin = 0;
		if (!wrapped) {
			space = Math.max (0, (width - maxX) / (count + 1));
			margin = Math.max (0, ((width - maxX) % (count + 1)) / 2);
		} else {
			if (fill || justify) {
				int last = 0;
				if (count > 0) wraps [count - 1] = maxHeight;
				for (int i=0; i<count; i++) {
					if (wraps [i] != 0) {
						int wrapCount = i - last + 1;
						if (justify) {
							int wrapX = 0;
							for (int j=last; j<=i; j++) {
								wrapX += bounds [j].width + spacing;
							}
							space = Math.max (0, (width - wrapX) / (wrapCount + 1));
							margin = Math.max (0, ((width - wrapX) % (wrapCount + 1)) / 2);
						}
						for (int j=last; j<=i; j++) {
							if (justify) bounds [j].x += (space * (j - last + 1)) + margin;
							if (fill) bounds [j].height = wraps [i];
						}
						last = i + 1;
					}
				}
			}
		}
		for (int i=0; i<count; i++) {
			if (!wrapped) {
				if (justify) bounds [i].x += (space * (i + 1)) + margin;
				if (fill) bounds [i].height = maxHeight;
			}
			children [i].setBounds (bounds [i]);
		}
	}
	
	return new Point (maxX, y + maxHeight + marginBottom + marginHeight);
}

Point layoutVertical (Composite composite, boolean move, boolean wrap, int height, boolean flushCache) {
	
	Control [] children = composite.getChildren ();
	
	if (children.length == 4) {
		if (children[2] instanceof Label) {
			Control temp;
			temp = children[2];
			children[2] = children[3];
			children[3] = temp;
		}
		if (((CaptionedControl)composite).orientationStyle == SWT.RIGHT_TO_LEFT) {
			Control temp;
			temp = children[3];
			children[3] = children[0];
			children[0] = temp;
			temp = children[2];
			children[2] = children[1];
			children[1] = temp;
		}
	} else if ((children.length == 3) && ((CaptionedControl)composite).orientationStyle == SWT.RIGHT_TO_LEFT) {
		Control temp;
		temp = children[2];
		children[2] = children[0];
		children[0] = temp;
	}
	
	int count = children.length;
	int childWidth = 0, childHeight = 0, maxWidth = 0;
	if (!pack) {
		for (int i=0; i<count; i++) {
			Control child = children [i];
			Point size = computeSize (child, flushCache);
			childWidth = Math.max (childWidth, size.x);
			childHeight = Math.max (childHeight, size.y);
		}
		maxWidth = childWidth;
	}
	int clientX = 0, clientY = 0;
	if (move) {
		Rectangle rect = composite.getClientArea ();
		clientX = rect.x;
		clientY = rect.y;
	}
	int [] wraps = null;
	boolean wrapped = false;
	Rectangle [] bounds = null;
	if (move && (justify || fill)) {
		bounds = new Rectangle [count];
		wraps = new int [count];
	}
	int maxY = 0, x = marginLeft + marginWidth, y = marginTop + marginHeight;
	for (int i=0; i<count; i++) {
		Control child = children [i];
		if (pack) {
			Point size = computeSize (child, flushCache);
			childWidth = size.x;
			childHeight = size.y;
		}
		if (wrap && (i != 0) && (y + childHeight > height)) {
			wrapped = true;
			if (move && (justify || fill)) wraps [i - 1] = maxWidth;
			x += spacing + maxWidth;
			y = marginTop + marginHeight;
			if (pack) maxWidth = 0;
		}
		if (pack || fill) {
			maxWidth = Math.max (maxWidth, childWidth);
		}
		if (move) {
			int childX = x + clientX, childY = y + clientY;
			if (justify || fill) {
				bounds [i] = new Rectangle (childX, childY, childWidth, childHeight);
			} else {
				
				child.setBounds (childX, childY, childWidth, childHeight);
			}
		}
		y += spacing + childHeight;
		maxY = Math.max (maxY, y);
	}
	maxY = Math.max (clientY + marginTop + marginHeight, maxY - spacing);
	if (!wrapped) maxY += marginBottom + marginHeight;
	if (move && (justify || fill)) {
		int space = 0, margin = 0;
		if (!wrapped) {
			space = Math.max (0, (height - maxY) / (count + 1));
			margin = Math.max (0, ((height - maxY) % (count + 1)) / 2);
		} else {
			if (fill || justify) {
				int last = 0;
				if (count > 0) wraps [count - 1] = maxWidth;
				for (int i=0; i<count; i++) {
					if (wraps [i] != 0) {
						int wrapCount = i - last + 1;
						if (justify) {
							int wrapY = 0;
							for (int j=last; j<=i; j++) {
								wrapY += bounds [j].height + spacing;
							}
							space = Math.max (0, (height - wrapY) / (wrapCount + 1));
							margin = Math.max (0, ((height - wrapY) % (wrapCount + 1)) / 2);
						}
						for (int j=last; j<=i; j++) {
							if (justify) bounds [j].y += (space * (j - last + 1)) + margin;
							if (fill) bounds [j].width = wraps [i];
						}
						last = i + 1;
					}
				}
			}
		}
		for (int i=0; i<count; i++) {
			if (!wrapped) {
				if (justify) bounds [i].y += (space * (i + 1)) + margin;
				if (fill) bounds [i].width = maxWidth;
			}
			children [i].setBounds (bounds [i]);
		}
	}
	return new Point (x + maxWidth + marginRight + marginWidth, maxY);
}

public String toString () {
 	String string = getName ()+" {";
 	string += "type="+((type != SWT.HORIZONTAL) ? "SWT.VERTICAL" : "SWT.HORIZONTAL")+" ";
 	if (marginWidth != 0) string += "marginWidth="+marginWidth+" ";
 	if (marginHeight != 0) string += "marginHeight="+marginHeight+" ";
 	if (marginLeft != 0) string += "marginLeft="+marginLeft+" ";
 	if (marginTop != 0) string += "marginTop="+marginTop+" ";
 	if (marginRight != 0) string += "marginRight="+marginRight+" ";
 	if (marginBottom != 0) string += "marginBottom="+marginBottom+" ";
 	if (spacing != 0) string += "spacing="+spacing+" ";
 	string += "wrap="+wrap+" ";
	string += "pack="+pack+" ";
	string += "fill="+fill+" ";
	string += "justify="+justify+" ";
	string = string.trim();
	string += "}";
 	return string;
}
}


final class IndexData {
	public int width = SWT.DEFAULT;
	public int height = SWT.DEFAULT;
	
public IndexData () {
}

public IndexData (int width, int height) {
	this.width = width;
	this.height = height;
}

public IndexData (Point point) {
	this (point.x, point.y);
}

String getName () {
	String string = getClass ().getName ();
	int index = string.lastIndexOf ('.');
	if (index == -1) return string;
	return string.substring (index + 1, string.length ());
}

public String toString () {
	String string = getName ()+" {";
	if (width != SWT.DEFAULT) string += "width="+width+" ";
	if (height != SWT.DEFAULT) string += "height="+height+" ";
	string = string.trim();
	string += "}";
	return string;
}
}



