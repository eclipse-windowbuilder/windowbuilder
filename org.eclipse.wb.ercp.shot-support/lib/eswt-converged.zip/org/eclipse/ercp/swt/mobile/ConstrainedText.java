/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.*;
import org.eclipse.ercp.swt.mobile.OS;

/**
 * A single-line Text control which constrains the user input by styles.
 * 
 * <p>
 * This control limits the characters that users can enter by the styles to make
 * data entry more efficient. This capability is usually implemented by the
 * underlying platform and applications are not allowed to change or override
 * the constraints. An IllegalArgumentException will be thrown if illegal
 * content is set programmatically by applications.
 * </p>
 * <dl>
 * <dt><b>Constraint Styles (exclusive): </b></dt>
 * <dd>NUMERIC: limit to digits and an optional minus sign in the beginning of
 * the string</dd>
 * <dd>DECIMAL: limit to digits, fractional separator and an optional minus
 * sign in the beginning of the string</dd>
 * <dd>PHONENUMBER: all dialing digitals: 0-9, *, #, +, A, B, C, D and
 * modifier characters , T P ! W @ ; > I i G g. See the standard at <a
 * href="http://www.3gpp.org/ftp/Specs/html-info/27007.htm">3GPP TS 27.007, ITU-T dial
 * command </a>. In addition to the "standard" characters allowed, a platform may also
 * allow other characters in keeping with the platform's native components.</dd>
 * 
 * <dt><b>Events: </b></dt>
 * <dd>Selection, DefaultSelection, Modify</dd>
 * </dl>
 */
public final class ConstrainedText extends Control {

	/*
	* The maximum number of characters that can be entered
	* into a text widget.
	*/
	private static final int LIMIT;
	
	
	/*
	* These values can be different on different platforms.
	* Therefore they are not initialized in the declaration
	* to stop the compiler from inlining.
	*/
	static {LIMIT = com.ibm.ugl.eswt.OS.AbstractTextComponent_GetDefaultTextLimit();	}	
	
	//Global variable.
	private int orientation = SWT.LEFT_TO_RIGHT;
	boolean editable;
	private int textLimit = LIMIT;
	private static Object fLock = new Object();
	private static boolean isInit = false;
	private int ConstrainedStyle_global = 0;
	
	/**
	 * Numeric input style allows the input of numeric values.
	 * 
	 * <P>
	 * Value <code>1</code> is assigned to <code>NUMERIC</code>.
	 * </P>
	 *  
	 */
	public static final int NUMERIC = 1;

	/**
	 * Decimal input style allows the input of numeric values with optional
	 * decimal fractions, for example, "-123", "0.123", or ".5" are all valid
	 * input.
	 * 
	 * <P>
	 * Value <code>2</code> is assigned to <code>DECIMAL</code>.
	 * </P>
	 *  
	 */
	public static final int DECIMAL = 2;

	/**
	 * Phone number input style allows the input of numeric values with optional
	 * phone specific characters like "+", "* and "#".
	 * 
	 * <P>
	 * Value <code>4</code> is assigned to <code>PHONENUMBER</code>.
	 * </P>
	 *  
	 */
	public static final int PHONENUMBER = 4;

    
	/**
	 * Constructs a new instance of this class given its parent, a style value
	 * describing behaviour and appearance, and an additional constrained style
	 * specifying the input styles defined above.
	 * <p>
	 * The style value is either one of the style constants defined in class
	 * <code>SWT</code> which is applicable to instances of this class, or
	 * must be built by <em>bitwise OR</em> 'ing together (that is, using the
	 * <code>int</code> "|" operator) two or more of those <code>SWT</code>
	 * style constants. Style bits are also inherited from superclasses. The
	 * class description lists the constrained style constants that can be set
	 * in constrainedStyle.
	 * </p>
	 * 
	 * @param parent
	 *            a composite control which will be the parent of the new
	 *            instance (cannot be null)
	 * @param style
	 *            the style of control to construct
	 * @param constrainedStyle
	 *            the constrained style
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if either the style or the
	 *                constrainedStyle is invalid</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see #NUMERIC
	 * @see #DECIMAL
	 * @see #PHONENUMBER
	 */
	public ConstrainedText(Composite parent, int style, int constrainedStyle) {
		super(parent, checkStyle(style));
		
		init();
		CheckConstrainedStyle(constrainedStyle);
	}

	/**
	 * Adds the listener to the collection of listeners who will be notified
	 * when the receiver's text is modified, by sending it one of the messages
	 * defined in the <code>ModifyListener</code> interface.
	 * 
	 * @param listener
	 *            the listener which should be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see ModifyListener
	 * @see #removeModifyListener
	 */
	public void addModifyListener(ModifyListener listener) {
		checkWidget();
		if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		TypedListener typedListener = new TypedListener(listener);
		addListener(SWT.Modify, typedListener);
	}

	/**
	 * Adds the listener to the collection of listeners who will be notified
	 * when the control is selected, by sending it one of the messages defined
	 * in the <code>SelectionListener</code> interface.
	 * <p>
	 * <code>widgetSelected</code> is not called for this control. <br />
	 * <code>widgetDefaultSelected</code> is called when a selection key is
	 * pressed.
	 * </p>
	 * 
	 * @param listener
	 *            the listener which should be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see SelectionListener
	 * @see #removeSelectionListener
	 * @see SelectionEvent
	 */
	public void addSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		TypedListener typedListener = new TypedListener(listener);
		addListener(SWT.DefaultSelection, typedListener);
	}

    

	/**
	 * Appends a string.
	 * <p>
	 * The new text is appended to the text at the end of the widget. The
	 * excessive characters will be truncated if the length exceeds the maximum
	 * number of characters that the receiver is capable of holding.
	 * </p>
	 * 
	 * @param string
	 *            the string to be appended
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the string is invalid
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void append(String string) {
		checkWidget();
		if (string == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		String str = string;
		if(checkType(str)) {
		 int length = getCharCount();
		 if (isListening(SWT.Verify) != false) {
			str = VerifyText (string, length, length, null);
			if (str == null) return;
		 }
		 if(string.length() > textLimit - getCharCount() )
			str=string.substring(0,textLimit - getCharCount() );
		 
		 OS.ConstrainedText_Replace(internal_handle, str, length, length);
		
		 // Set the caret position based on the actual text in the widget,
		 // not str.  This allows us to correctly handle newline conversion.
		 int newLength = com.ibm.ugl.eswt.OS.AbstractTextComponent_GetText(internal_handle).length();
		 com.ibm.ugl.eswt.OS.AbstractTextComponent_SetCaretPosition(internal_handle,newLength);
		 internal_sendEvent(SWT.Modify);
		} 
	}

	
	static int checkStyle(int style) {
		style = checkBITs (style, SWT.LEFT, SWT.CENTER, SWT.RIGHT, 0, 0, 0);
			
		if ((style & (SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.WRAP | SWT.PASSWORD)) != 0 ) 
			style &= ~(SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.WRAP | SWT.PASSWORD);
		return (style | SWT.SINGLE);
	}

	static int checkBITs(int style, int int0, int int1, int int2, int int3, int int4, int int5) {
		int mask = int0 | int1 | int2 | int3 | int4 | int5;
		if ((style & mask) == 0) style |= int0;
		if ((style & int0) != 0) style = (style & ~mask) | int0;
		if ((style & int1) != 0) style = (style & ~mask) | int1;
		if ((style & int2) != 0) style = (style & ~mask) | int2;
		if ((style & int3) != 0) style = (style & ~mask) | int3;
		if ((style & int4) != 0) style = (style & ~mask) | int4;
		if ((style & int5) != 0) style = (style & ~mask) | int5;
		return style;
	}
	
	protected void internal_createHandle(int index) {
		int parentHandle = internal_parent.internal_handle;
		int nativeStyle = internal_getNativeStyle();
		
		System.err.flush();
		internal_handle = OS.ConstrainedText_New(parentHandle,nativeStyle);
		System.out.flush();
		if (internal_handle == 0) SWT.error(SWT.ERROR_NO_HANDLES);
		
	    setEditable((internal_style & SWT.READ_ONLY) == 0);
	}

	protected int internal_getNativeStyle(){
	    int nativeStyle = super.internal_getNativeStyle();
		return nativeStyle;
	}
	
	/*
	 * The user is trying to modify the text in some way, but the ConstrainedText widget
	 * has not been updated yet.  Send a VerifyEvent.  If the operation
	 * is cancelled, return true.  Otherwise, set the string at index
	 * 0 to the modified text (or null if the text was not modified), and
	 * return false;
	 */
	boolean TextVerifyCallback(String originalText, int start, int end, String[] returnedText) {
		
		String modifiedText = VerifyText(originalText,start,end,null);
		if (modifiedText == null) return true;
		
		if (returnedText == null || returnedText.length == 0) SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		
		// Just use a shallow compare.  Using String.equals() would
		// most often be a waste of time because if the shallow compare
		// fails, the strings are probably different anyway.
		if (modifiedText == originalText) {
			returnedText[0] = null;
		}
		else {
			returnedText[0] = modifiedText;
		}
		
		return false;
	}
	
	
	/*
	 * A null return value cancels the operation.
	 */
	String VerifyText(String string, int start, int end, Event keyEvent) {
		Event event = new Event();
		event.text = string;
		event.start = start;
		event.end = end;
		if (keyEvent != null) {
			event.character = keyEvent.character;
			event.keyCode = keyEvent.keyCode;
			event.stateMask = keyEvent.stateMask;
		}
		/*
		 * It is possible (but unlikely), that application
		 * code could have disposed the widget in the verify
		 * event.  If this happens, answer null to cancel
		 * the operation.
		 */
		
		internal_sendEvent(SWT.Verify);
		if (!event.doit || isDisposed()) return null;
		
		return event.text;
	}
    
	public Point computeSize(int wHint, int hHint, boolean changed) {
		if ((wHint != SWT.DEFAULT)) {
			checkWidget();
			int[] pointArray = OS.ConstrainedText_GetMinimumSize(internal_handle, wHint);
			return new Point(pointArray[com.ibm.ugl.eswt.OS.INDEX_X],pointArray[com.ibm.ugl.eswt.OS.INDEX_Y]);
		} else {
			return super.computeSize(wHint, hHint, changed);
		}	
	}

	/*
	 * When ConstrainedText focus in, check the status of the Virtual Keyboard, it should be one of ALWAYS_ON
	 * , ALWAYS_OFF, or NORMAL
	 */
	private void ConstrainedTextCallback(int index, int type) {
		switch (type) {
		case OS.EVENT_CONSTRAINEDTEXT_FOCUSIN:{
			if(Device.internal_vkstatus == MobileDevice.VK_ALWAYS_ON){
				OS.MobileDevice_SetVKStatus(true, internal_handle);
			} else if(Device.internal_vkstatus == MobileDevice.VK_ALWAYS_OFF){
				OS.MobileDevice_SetVKStatus(false, internal_handle);
			} else if(this.editable == false) {
				OS.MobileDevice_SetVKStatus(false, internal_handle);
			} else{
				OS.MobileDevice_SetVKStatus(true, internal_handle);
			}
				break;
		}
		
		case OS.EVENT_CONSTRAINEDTEXT_FOCUSOUT:{
			if(Device.internal_vkstatus == MobileDevice.VK_ALWAYS_ON){
				OS.MobileDevice_SetVKStatus(true, internal_handle);
			} else if(Device.internal_vkstatus == MobileDevice.VK_ALWAYS_OFF){
				OS.MobileDevice_SetVKStatus(false, internal_handle);
			} else if(this.editable == false) {
				OS.MobileDevice_SetVKStatus(false, internal_handle);
			} else{
				OS.MobileDevice_SetVKStatus(false, internal_handle);
			}
				break;
		}
		
		case OS.EVENT_CONSTRAINEDTEXT_MODIFY:
			internal_sendEvent(SWT.Modify);
		break;
		}
	}	
 
	
	
	/**
	 * Clears the selection.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void clearSelection() {
		checkWidget();
		Point sel = getSelection();
		OS.ConstrainedText_Replace(internal_handle, "",sel.x,sel.y);
	}

	private Point getSelection() {
		checkWidget();
		int[] selection = com.ibm.ugl.eswt.OS.AbstractTextComponent_GetSelection(internal_handle);
		return new Point(selection[0], selection[1]);
	}
	/**
	 * Copies the selected text.
	 * <p>
	 * The current selection is copied to the clipboard.
	 * </p>
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void copy() {
		checkWidget();
		String text = getSelectionText();
		if (text != null) {
			// Expected SWT behavior
			com.ibm.ugl.eswt.OS.Clipboard_SetText(text);
		}
	}

	private String getSelectionText() {
		checkWidget();
		return com.ibm.ugl.eswt.OS.AbstractTextComponent_GetSelectionText(internal_handle);
	}
	/**
	 * Cuts the selected text.
	 * <p>
	 * The current selection is first copied to the clipboard and then deleted
	 * from the widget.
	 * </p>
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void cut() {
		checkWidget();
		String text = getSelectionText();
		com.ibm.ugl.eswt.OS.Clipboard_SetText(text);
		int[] sel = com.ibm.ugl.eswt.OS.AbstractTextComponent_GetSelection(internal_handle);
		OS.ConstrainedText_Replace(internal_handle,"",sel[0],sel[1]);
		OS.ConstrainedText_SetSelection(internal_handle,sel[0],sel[0]);
	}

	/**
	 * Gets the position of the caret.
	 * <p>
	 * The character position of the caret is returned.
	 * </p>
	 * 
	 * @return the position of the caret
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public int getCaretPosition() {
		checkWidget();
		int selection[] = com.ibm.ugl.eswt.OS.AbstractTextComponent_GetSelection(internal_handle);
		//fix bug PBPP7Q2AST
		return selection[com.ibm.ugl.eswt.OS.INDEX_Y];
	}

	/**
	 * Gets the number of characters.
	 * 
	 * @return number of characters in the widget
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public int getCharCount() {
		checkWidget();
		return com.ibm.ugl.eswt.OS.AbstractTextComponent_GetCharCount(internal_handle);
	}

	/**
	 * Gets the editable state.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public boolean getEditable() {
		checkWidget();
		return this.editable;
	}

	/**
	 * Gets the widget text.
	 * <p>
	 * The text for a text widget is the characters in the widget.
	 * </p>
	 * 
	 * @return the widget text
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public String getText() {
		checkWidget();
		return com.ibm.ugl.eswt.OS.AbstractTextComponent_GetText(internal_handle);
	}

	/**
	 * Returns the maximum number of characters that the receiver is capable of
	 * holding.
	 * <p>
	 * If this has not been changed by <code>setTextLimit()</code>, it will
	 * be the constant <code>Text.LIMIT</code>.
	 * </p>
	 * 
	 * @return the text limit
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	
	public int getTextLimit() {
		checkWidget();
		return textLimit;
	}

	/**
	 * Inserts a string after the caret position.
	 * <p>
	 * The old selection is replaced with the new text. The excessive characters
	 * will be truncated if the length exceeds the maximum number of characters
	 * that the receiver is capable of holding.
	 * </p>
	 * 
	 * @param string
	 *            the string value.
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the string is invalid
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void insert(String string) {
		checkWidget();
		if (string == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		String str = string;
		if(checkType(str)) {
		 int[] selection = com.ibm.ugl.eswt.OS.AbstractTextComponent_GetSelection(internal_handle);
		 if (isListening(SWT.Verify) != false) {
			str = VerifyText (string, selection[com.ibm.ugl.eswt.OS.INDEX_X], selection[com.ibm.ugl.eswt.OS.INDEX_Y], null);
			if (str == null) return;
		 }
		 
		 if(string.length() > textLimit - getCharCount() )
			str = string.substring(0,textLimit - getCharCount() );

		 OS.ConstrainedText_Replace(internal_handle, str, selection[com.ibm.ugl.eswt.OS.INDEX_X], selection[com.ibm.ugl.eswt.OS.INDEX_Y]);
		 com.ibm.ugl.eswt.OS.AbstractTextComponent_SetCaretPosition(internal_handle,selection[com.ibm.ugl.eswt.OS.INDEX_X]+str.length());
		 internal_sendEvent(SWT.Modify);
		} 
	}

	/**
	 * Pastes text from clipboard.
	 * <p>
	 * The selected text is deleted from the widget and new text inserted from
	 * the clipboard. The excessive characters will be truncated if the length
	 * exceeds the maximum number of characters that the receiver is capable of
	 * holding.
	 * </p>
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the string is invalid
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void paste() {
		checkWidget();
		String text = com.ibm.ugl.eswt.OS.Clipboard_GetText();
		String str = text;
		if(checkType(str)) {
		clearSelection();
		insert(text);
		}
	}

	/**
	 * Removes the listener from the collection of listeners who will be
	 * notified when the receiver's text is modified.
	 * 
	 * @param listener
	 *            the listener which should no longer be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see ModifyListener
	 * @see #addModifyListener
	 */
	
	public void removeModifyListener(ModifyListener listener) {
		checkWidget();
		if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		removeListener(SWT.Modify,listener);
	}

	/**
	 * Removes the listener from the collection of listeners who will be
	 * notified when the control is selected.
	 * 
	 * @param listener
	 *            the listener which should be notified
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see SelectionListener
	 * @see #addSelectionListener
	 */
	
	public void removeSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		removeListener(SWT.Selection, listener);	
		removeListener(SWT.DefaultSelection, listener);	
	}
	

	/**
	 * Selects all the text in the receiver.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void selectAll() {
		checkWidget();
		com.ibm.ugl.eswt.OS.AbstractTextComponent_SelectAll(internal_handle);
	}

	/**
	 * Sets the editable state.
	 * 
	 * @param editable
	 *            the new editable state
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setEditable(boolean editable) {
		checkWidget();
		this.editable = editable;
		com.ibm.ugl.eswt.OS.AbstractTextComponent_SetEditable(internal_handle, editable);
	}

	/**
	 * Sets the selection.
	 * <p>
	 * Indexing is zero based. The range of a selection is from 0..N where N is
	 * the number of characters in the widget.
	 * </p>
	 * <p>
	 * Text selections are specified in terms of caret positions. In a text
	 * widget that contains N characters, there are N+1 caret positions, ranging
	 * from 0..N. This differs from other functions that address character
	 * position such as getText () that use the regular array indexing rules.
	 * </p>
	 * 
	 * @param start
	 *            new caret position
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the start is less than
	 *                zero.</li>
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the start value is greater
	 *                than N.</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setSelection(int start) {
		checkWidget();
		int text_number=this.getCharCount();
		if (!(0 <= start))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if (!(start <= text_number))
			SWT.error(SWT.ERROR_INVALID_RANGE);
		com.ibm.ugl.eswt.OS.AbstractTextComponent_SetCaretPosition(internal_handle, start);
	}

	/**
	 * Sets the selection.
	 * <p>
	 * Indexing is zero based. The range of a selection is from 0..N where N is
	 * the number of characters in the widget.
	 * </p>
	 * <p>
	 * Text selections are specified in terms of caret positions. In a text
	 * widget that contains N characters, there are N+1 caret positions, ranging
	 * from 0..N. This differs from other functions that address character
	 * position such as getText () that use the usual array indexing rules.
	 * </p>
	 * 
	 * @param start
	 *            the start of the range
	 * @param end
	 *            the end of the range
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the start or end values
	 *                are less than zero.</li>
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the start value is greater
	 *                than the end value; or if the end value is greater than N.
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setSelection(int start, int end) {
		checkWidget();
		int text_number = this.getCharCount();
		if ( !(0 <= start && 0 <= end))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if (!(end <= text_number ))
			SWT.error(SWT.ERROR_INVALID_RANGE);
		if ( !(start <= end))
			SWT.error(SWT.ERROR_INVALID_RANGE);
		int nStart = Math.min(start, end);
		int nEnd = Math.min(Math.max(start, end), text_number);
		OS.ConstrainedText_SetSelection(internal_handle, nStart, nEnd);
	}

	/**
	 * Sets the initial contents of the receiver to the given string. If the
	 * argument contains multiple lines of text, the result of this operation is
	 * undefined and may vary from platform to platform.
	 * <p>
	 * It is not recommended to set the initial contents especially when the
	 * style is <em>PHONENUMBER</em> because an IllegalArgumentException will
	 * be thrown when the string format does not match the present
	 * locale-specific format.
	 * </p>
	 * 
	 * @param text
	 *            the new text
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the string is null</li>
	 *                <li>ERROR_INVALID_ARGUMENT - if the string format is
	 *                invalid</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	
	public void setText(String text) {
		checkWidget();
		if (text == null) SWT.error(SWT.ERROR_NULL_ARGUMENT);
		String str = text;
		if(str == "")
		{
			 com.ibm.ugl.eswt.OS.AbstractTextComponent_SetText(internal_handle, str);
			 com.ibm.ugl.eswt.OS.AbstractTextComponent_SetCaretPosition(internal_handle,0);
			 internal_sendEvent(SWT.Modify);
		}			
		else if(checkType(str)) {
		 if (isListening(SWT.Verify) != false) {
			int length = getCharCount();
			str = VerifyText (text, 0, length, null);
			if (str == null) return;
		 }
		 if(text.length() > textLimit)
			str=text.substring(0,textLimit);
		  
		 com.ibm.ugl.eswt.OS.AbstractTextComponent_SetText(internal_handle, str);
		 com.ibm.ugl.eswt.OS.AbstractTextComponent_SetCaretPosition(internal_handle,0);
		 internal_sendEvent(SWT.Modify);
		}	
	}
	

	
	/**
	 * Sets the maximum number of characters that the receiver is capable of
	 * holding to be the argument.
	 * <p>
	 * Instead of trying to set the text limit to zero, consider creating a
	 * read-only text widget.
	 * </p>
	 * <p>
	 * To reset this value to the default, use
	 * <code>setTextLimit(Text.LIMIT)</code>.
	 * </p>
	 * 
	 * @param limit
	 *            new text limit
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the limit is lower or
	 *                equal to zero, or greater than Text.LIMIT</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @see org.eclipse.swt.widgets.Text#LIMIT
	 */
	
	public void setTextLimit(int limit) {
		checkWidget();
		if (limit <= 0 || limit > LIMIT ) SWT.error (SWT.ERROR_INVALID_ARGUMENT);
		textLimit = limit;
		com.ibm.ugl.eswt.OS.AbstractTextComponent_SetTextLimit(internal_handle,limit);
	}

	/**
	 * Shows the selection.
	 * <p>
	 * If the selection is already showing in the receiver, this method simply
	 * returns. Otherwise, lines are scrolled until the selection is visible.
	 * </p>
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void showSelection() {
		checkWidget();
		Point sel = getSelection();
		// Qt doesn't support this, so reselect the text
		setSelection(sel.x, sel.y);
	}
	
//	/**
//	 * Sets a hint to the implementation as to the input mode that should be
//	 * used when the user initiates editing of this control.
//	 * 
//	 * The argument can be null. If the argument is null, or not a valid Unicode
//	 * character subset, the default input mode will be used according to the
//	 * device's locale settings. see <a href="">setInitialInputMode </a> in
//	 * <code>Text</code>.
//	 * 
//	 * @param mode
//	 *            a string naming a Unicode character blocks and unicode
//	 *            subsets, or null
//	 * 
//	 * @exception SWTException
//	 *                <ul>
//	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
//	 *                disposed</li>
//	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
//	 *                thread that created the receiver</li>
//	 *                </ul>
//	 * @see Text#setInitialInputMode
//	 */
	//public void setInitialInputMode(String mode) {
	//}
	
	private void init() {		
		synchronized (fLock) {
			if(!isInit)
			{
				//Register Callback function to Display widget.
				com.ibm.ugl.p3ml.OS.Display_RegisterCallback(getDisplay().internal_handle, OS.CALLBACK_CONSTRAINEDTEXT, "org/eclipse/ercp/swt/mobile/ConstrainedText", "ConstrainedTextCallback");
				isInit=true;
			}
		}
		
	}
	

	//Check digital key(0~9) to be typed or not.
	private boolean check_numeric(char keyin_char,int position)
	{
		switch(position) {
		 case 0:  //first character
			 if(keyin_char == '-' || check_NumericString(keyin_char) )
 		 	    return true;
			 break;
				
		default:				
			if(check_NumericString(keyin_char) )
 		 	    return true;
			 break;
		}
		return false;
	}	

	
	
	//Check the typed key to match the DECIMAL definition.
	private boolean check_decimal(char keyin_char,int position, String content)
	{
		int dot_number = 0;
		int unselectedtext_number = 0;
		char[] chars = null;
				
		chars = new char[content.length()];
		content.getChars(0, chars.length, chars, 0);
        //	Based on the caretposition to restrict user operation to match DECIMAL defination.		
		
		switch(position) {
		
		case 0:  //first character
			// While not all of string is selected, '0' isn't allowed to type.
			unselectedtext_number = content.length() - getSelectionText().length();
			if( unselectedtext_number >= 1 )
		    {
			 if(keyin_char == '-' || keyin_char == '.' || check_NumericString(keyin_char) ) {
 		 	    return true;
 		 	 }
		    }
			else {
				if(keyin_char == '-' || check_DecimalString(keyin_char, chars))
				 return true;
			}
		    break;
		case 1:  // second character.
			if (chars[0] == '0') {     //If first character is 0, only '.' allowed to type. 
				if((keyin_char == '.' )) { 
	 		 		return true;
				}
			} 
			else {				 	   //If the first character isn't 0.		  
				return check_DecimalString(keyin_char, chars);
	 		    }
		break;
		
		case 2:  //third character
			if (chars[0] == '-') {     //If first character is '-' and second character is 0 , only '.' allowed to type. 
			  if(chars[1] == '0') {	   
				if((keyin_char == '.' )) {
	 		 		return true;				
				}
			  }
			  else {                    //If the first character is '-'.
			  	return check_DecimalString(keyin_char, chars);
			  }
			} 
			else { 			             //If the first character isn't '-'.
				return check_DecimalString(keyin_char, chars);
			}			
		break;
		
		default:				
			return check_DecimalString(keyin_char, chars); 
		}
		return false;					
	}
	
	
    //Check the typed key to match the PHONENUMBER definition.
	private boolean check_phonenumber(char keyin_char) 
	{	
	 if(keyin_char == ' ' || keyin_char == '*' || keyin_char == '#' || keyin_char == '+' || check_NumericString(keyin_char))
		      return true;
	 if(keyin_char == 'A' || keyin_char == 'B' || keyin_char == 'C' || keyin_char == 'D') 
	      return true;
	 //	Eric, add more support phone format in 2007
	 if(keyin_char == '(' || keyin_char == ')' || keyin_char == '-' || keyin_char == '/' || keyin_char == '.' || keyin_char == 'x') 
	      return true;
	 if(keyin_char == ',' || keyin_char == 'T' || keyin_char == 'P' || keyin_char == '!' || keyin_char == 'W' || keyin_char == '@') 
	      return true;
	 if(keyin_char == ';' || keyin_char == '>' || keyin_char == 'I' || keyin_char == 'i' || keyin_char == 'G' || keyin_char == 'g') 
	      return true;
	 return false;
	}
	
		
	//Check backspace, right, and left key to be typed or not.
	private boolean check_keydown(int keycode)
	{
		if (keycode == SWT.BS || keycode == SWT.ARROW_RIGHT || keycode == SWT.ARROW_LEFT)
			return true;
		if (keycode == SWT.CR )
			internal_sendEvent(SWT.DefaultSelection);
		return false;
	}
	
	//check if typed word matches the definition od Numeric or not.
	private boolean check_NumericString(char keyin_char)
	{
		if ('0' <= keyin_char && keyin_char <= '9')
		 return true;
		return false;
	}	
	
    //check if typed word matches the definition of Decimal in each position or not.
	private boolean check_DecimalString(char keyin_char, char[] chars)
	{
		int dot_number = 0;
		for(int i = 0; i< chars.length; i++ )
		 if(chars[i] == '.')
		  dot_number++;                   //Check the dot number in all of string.
			   
		if(dot_number < 1) {
		 if(keyin_char == '.' || check_NumericString(keyin_char)) {
		  return true;
		 }
		} 
		else { // While unselected string doesn't include '.' , '.' is allowed to type.
		 if((dot_number - check_selected_dotnumber(getSelectionText())) < 1) {	
		  if(keyin_char == '.' || check_NumericString(keyin_char)) {
           return true;
		  }
		 } 
		 else {
	      if(check_NumericString(keyin_char)) {
		   return true;
		  }
		 } 
	    }
		return false; 
	}
	
	
	//Check the dot number of the selected string. 
	private int check_selected_dotnumber(String selected_content)
	{
		int Selected_dot_number = 0;
		if(selected_content == null)
			return 0;
		char[] chars = null;
		chars = new char[selected_content.length()];
		selected_content.getChars(0, chars.length, chars, 0);
		for(int i = 0; i< chars.length; i++ )
			 if( chars[i] == '.')
			 	Selected_dot_number++;
		return Selected_dot_number;
	}
	
	/*
	 * Check if the ConstrainedStyle matches the NMERIC,DECIMAL,PHONENUMBER of spec definition. 
 	 * Listening when user types and check if characters user typed match the rule of three definition.
 	 * If not, the operation is cancel   
 	 */
	private void CheckConstrainedStyle(int constrainedStyle)
    { 
		if ((constrainedStyle & ~(NUMERIC | DECIMAL| PHONENUMBER)) != 0)
   		 SWT.error(SWT.ERROR_INVALID_ARGUMENT);
				 
		if ((constrainedStyle & NUMERIC) == NUMERIC && ((constrainedStyle | NUMERIC) != NUMERIC))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if ((constrainedStyle & DECIMAL) == DECIMAL && ((constrainedStyle | DECIMAL) != DECIMAL))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		if ((constrainedStyle & PHONENUMBER) == PHONENUMBER && ((constrainedStyle | PHONENUMBER) != PHONENUMBER))
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		
		 if ((constrainedStyle & NUMERIC) != 0) {
			this.addListener(SWT.KeyDown, new Listener() {
				public void handleEvent(Event event) {
					char keyin_char = event.character;
					if(!(check_numeric(keyin_char, getCaretPosition())|| check_keydown(event.keyCode))) {
			 		 	event.doit = false;   // cancel operation.
			 		 	return;
			 		}
				}
			});
		 }
		 else if ((constrainedStyle & DECIMAL) != 0 ) {
		 	this.addListener(SWT.KeyDown, new Listener() {
				public void handleEvent(Event event) {
					char keyin_char = event.character;
					String content= getText();
					if(!(check_decimal(keyin_char, getCaretPosition(), content)  || check_keydown(event.keyCode))) {
			 		 	event.doit = false;   // cancel operation.
			 		 	return;
			 		}
				}	
		 	});		
		 }
		 else if ( (constrainedStyle & PHONENUMBER) != 0 ) {
		 	this.addListener(SWT.KeyDown, new Listener() {
				public void handleEvent(Event event) {
					char keyin_char = event.character;
					
					if(!(check_phonenumber(keyin_char) || check_keydown(event.keyCode))) {
			 		 	event.doit = false;   // cancel operation.
			 		 	return;
			 		}
				}
		 	});
		  }
		 ConstrainedStyle_global = constrainedStyle;
     	}
	
	//check if a string matches the NUMERIC, DECIMAL, and PHONENUMBER restriction 
	private boolean checkType (String string)
	{
		int count = 0;
		boolean match = false;
		
		if (ConstrainedStyle_global == NUMERIC)          //if constrainedStyle is numeric
		{
			while(count < string.length())
			{
				match = check_numeric(string.charAt(count), count);
				if (match == false)
				{
					SWT.error(SWT.ERROR_INVALID_ARGUMENT);
					break;
				}
				count++;
			}
			return match;
				
		}
		else if (ConstrainedStyle_global == DECIMAL) {    //if constrainedStyle is decimal
			while(count < string.length())
			{
				match = check_decimal(string.charAt(count), count, string.substring(0, count));
				if (match == false)
				{
					SWT.error(SWT.ERROR_INVALID_ARGUMENT);
					break;
				}
				count++;
			}
			return match;
		}
		else if (ConstrainedStyle_global == PHONENUMBER) {   //if constrainedStyle is phonenumber
			while(count < string.length())
			{
				match = check_phonenumber(string.charAt(count));
				if (match == false)
				{
					SWT.error(SWT.ERROR_INVALID_ARGUMENT);
					break;
				}
				count++;
			}
			return match;
		}
		return false;
		
	}

	public boolean allowTraverseByArrowKey(Event event) {
		switch (event.keyCode) {
			case SWT.ARROW_UP :
			case SWT.ARROW_DOWN :	
				return true;
			case SWT.ARROW_LEFT :
				if(super.isEnableTraverse())
					return true;
				if(getCaretPosition() == 0) {
					return true;
				}
				break;
			case SWT.ARROW_RIGHT :
				if(super.isEnableTraverse())
					return true;
				if(getCaretPosition() >= getCharCount()) {
					return true;
				}
				break;
		}
		return false;
	}
	
	protected boolean traverse(Event event) {
		if (isDisposed()) return false;
		if(allowTraverseByArrowKey(event)) {
			return traverseByArrowKey(event);
		}
		return super.traverse(event);
	}
	
}