/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.ercp.swt.mobile;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Scrollable;
import org.eclipse.swt.widgets.TypedListener;


/**
 * Instances of this class represent a selectable user interface object that
 * displays a list of items consisting of text and icons from a data model. Each
 * list item may include combinations of heading text, heading icons, detail
 * text, and detail icons. The layout and display of the various text and icons
 * is variable depending upon the style and modifier constants passed to the
 * constructor. Only one LB_STYLE_xxxx layout style constant may be specified.
 * The LB_STYLE_NO_HEADING_TEXT style displays detail text on a single line per
 * item. The LB_STYLE_1LINE_ITEM style displays heading text next to detail text
 * in a single row. The LB_STYLE_2LINE_ITEM style displays heading text above
 * detail text in a two line cell.
 * <p>
 * The following diagrams show the general layout for each layout style:
 * <p>
 * LB_STYLE_NO_HEADING_TEXT <Table width=200 border=1>
 * <tr>
 * <td>Detail Text</td>
 * </tr>
 * <tr>
 * <td>Detail Text</td>
 * </tr>
 * <tr>
 * <td>Detail Text</td>
 * </tr>
 * <tr>
 * <td>Detail Text</td>
 * </tr>
 * </table>
 * <p>
 * LB_STYLE_1LINE_ITEM <Table width=200 border=1>
 * <tr>
 * <td>Heading Text</td>
 * <td>Detail Text</td>
 * </tr>
 * <tr>
 * <td>Heading Text</td>
 * <td>Detail Text</td>
 * </tr>
 * <tr>
 * <td>Heading Text</td>
 * <td>Detail Text</td>
 * </tr>
 * <tr>
 * <td>Heading Text</td>
 * <td>Detail Text</td>
 * </tr>
 * </table>
 * <p>
 * LB_STYLE_2LINE_ITEM <Table width=200 border=1>
 * <tr>
 * <td><b>Heading Text </b> <br>
 * Detail Text</td>
 * </tr>
 * <tr>
 * <td><b>Heading Text </b> <br>
 * Detail Text</td>
 * </tr>
 * <tr>
 * <td><B>Heading Text </b> <br>
 * Detail Text</td>
 * </tr>
 * </table>
 * <p>
 * The specific placement of item elements is locale and platform-dependent.
 * LB_MOD_xxxx style modifiers are hints which are implemented in a
 * platform-dependent fashion or perhaps not at all. They may be specified by
 * or-ing any number of LB_MOD_xxxx constants with one selected layout style.
 * Heading and detail icons are optionally displayed on any of the style layouts
 * by specifying the LB_MOD_SHOW_HEADING_ICONS or LB_MOD_SHOW_DETAILS_ICONS
 * modifiers. Heading and detail icons, if both displayed, are separated within
 * the layout to indicate that they are distinct from each other. The
 * LB_MOD_SHOW_SELECTION_NUMBER modifier is a hint for the ListBox to display a
 * single digit next to each item which indicates that pressing that number
 * selects the item. A list may be SINGLE or MULTI select. However, due to
 * typical layout contraints, MULTI select is a hint that is guaranteed to be
 * implemented only when no style modifiers are used.
 * <p>
 * The following is a possible layout for LB_STYLE_1LINE_ITEM |
 * LB_MOD_SHOW_DETAIL_ICONS | LB_MOB_SHOW_SELECTION_NUMBER: <Table width=200
 * border=1>
 * <tr>
 * <td>1</td>
 * <td>Heading</td>
 * <td>Detail Text</td>
 * <td>icon</td>
 * </tr>
 * <tr>
 * <td>2</td>
 * <td>Heading</td>
 * <td>Detail Text</td>
 * <td>icon</td>
 * </tr>
 * <tr>
 * <td>3</td>
 * <td>Heading</td>
 * <td>Detail Text</td>
 * <td>icon</td>
 * </tr>
 * <tr>
 * <td>4</td>
 * <td>Heading</td>
 * <td>Detail Text</td>
 * <td>icon</td>
 * </tr>
 * </table>
 * 
 * <p>
 * The model data is provided by an array of ListBoxItems. The array is not
 * copied. The array is used until the ListBox is destroyed or a new data model
 * is set.
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed. On some
 * platforms, the fonts of the heading and detail texts are defined by the
 * layout styles. ListBox allows setting the fonts even if the underlying
 * platform does not, but in this case the appearance of the control will not
 * change.
 * <p>
 * <dl>
 * <dt><b>Styles: </b></dt>
 * <dd>SINGLE, MULTI</dd>
 * <p>
 * Note: Only one of SINGLE and MULTI may be specified.
 * <p>
 * </dl>
 * <dl>
 * <dt><b>Layout Styles: </b></dt>
 * <dd>LB_STYLE_NO_HEADING_TEXT</dd>
 * <dd>LB_STYLE_1LINE_ITEM</dd>
 * <dd>LB_STYLE_2LINE_ITEM</dd>
 * <p>
 * Note: Only one layout style may be specified. If more than one layout style
 * is specified, the actual style used is implementation dependent.
 * <p>
 * <dl>
 * <dt><b>Layout Style Modifiers: </b></dt>
 * <dd>LB_MOD_SHOW_SELECTION_NUMBER</dd>
 * <dd>LB_MOD_SHOW_HEADING_ICONS</dd>
 * <dd>LB_MOD_SHOW_DETAIL_ICONS</dd>
 * </dl>
 * <p>
 * Note: Style modifiers are hints. Any number of modifier styles may be
 * combined with a layout style
 * </dl>
 * <p>
 * <dt><b>Events: </b></dt>
 * <dd>Selection, DefaultSelection</dd>
 * </dl>
 * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 * @see ListBoxItem
 */
public class ListBox extends Scrollable {

	
	ListBoxItem [] fItems = null;
	Label [] fLabels = new Label [40];
	int fLabelCount = 0;
	int fColumns = 0;
	int fLayoutStyle = 0;
	Canvas fComposite;
	Composite innerComposite;
	Composite parentComposite;
	static Composite hackComposite;
	static int hackStyle;
	int widgetStyle;
	ListBoxLayout fListBoxLayout;
	int [] selectedIndex= new int[100];
	int selectedCount = 0;
    Display display2 = null;
	Color textFocusColor = null;
	Color focusColor = null;
	Color focusAndSelColor =  null;
	Color selectedColor = null;
	Color normalColor = null;
	int setWidth = -1;
	int setHeight = -1;
	int scrollbarWidthHeight = 12; // do this because scrollbar getsize does not return the correct number
	ScrollBar fVScrollBar = null;
	ScrollBar fHScrollBar = null;
	boolean ifVscrollBar = false;
	boolean ifHscrollBar = false;
	int ScrollY=0;
	int detailPosition = 0;
	int headingPosition = 0;
	int headingIconPosition = 0;
	boolean twoLine = false;
	private boolean isDispose = false;
	boolean styleDefined = false;
	boolean showNumber = false;
	boolean showHeadingText = false;
	boolean showHeadingIcon = false;
	boolean showDetailIcon = false;
	boolean twoline = false;
	boolean oneline = false;
	boolean isDisposed = false;
	int preferredWidth = 0;
	int preferredHeight = 0;
	Listener keyListener;
	ListBox lb = null;
//	Composite [] listCells = new Composite[40];
	ListComposite [] listCells = new ListComposite[40];
	
	// add by Uriel
	private int focusIndex = 0;
	private Font font = null;
	private Font headingFont = null;
	
	
	/**
	 * single line item, 1 column (default)
	 */
	public static final int LB_STYLE_NO_HEADING_TEXT = 0;

	/**
	 * single line item, 2 columns
	 */
	public static final int LB_STYLE_1LINE_ITEM = 1;

	/**
	 * double line item, 1 column with heading and detail combined
	 */
	public static final int LB_STYLE_2LINE_ITEM = 2;

	/**
	 * shows a single digit number aligned with each item which may be used to
	 * select the item.
	 */
	public static final int LB_MOD_SHOW_SELECTION_NUMBER = 0x10;

	/**
	 * shows icon associated with heading text
	 */
	public static final int LB_MOD_SHOW_HEADING_ICONS = 0x20;

	/**
	 * shows icons associated with detail text
	 */
	public static final int LB_MOD_SHOW_DETAIL_ICONS = 0x40;

	/**
	 * Constructs a new instance of this class given its parent, a style value
	 * describing its selection behavior, and a style value describing its
	 * layout.
	 * <p>
	 * The <code>style</code> value is either one of the style constants
	 * defined in class <code>SWT</code> which is applicable to instances of
	 * this class, or must be built by <em>bitwise OR</em> 'ing together (that
	 * is, using the <code>int</code> "|" operator) two or more of those
	 * <code>SWT</code> style constants. Style bits are also inherited from
	 * superclasses.
	 * <p>
	 * The <code>layoutStyle</code> value is one or more of the class layout
	 * style constants which may be combined by <em>bitwise OR</em> 'ing. Use
	 * of styles not applicaple to this class are ignored.
	 * </p>
	 * 
	 * @param parent
	 *            a composite control which will be the parent of the new
	 *            instance (cannot be null)
	 * @param style
	 *            the style of control to construct
	 * @param layoutStyle
	 *            the layout style of control to construct
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * 
	 * @see SWT#SINGLE
	 * @see SWT#MULTI
	 */
	public ListBox(Composite parent, int style, int layoutStyle) {
		super(SaveStyle(parent, style), SWT.NONE);
		
		display2 = parent.getDisplay();
		
		textFocusColor = display2.getSystemColor(SWT.COLOR_LIST_SELECTION_TEXT);
		focusColor = display2.getSystemColor(SWT.COLOR_LIST_BACKGROUND);
		selectedColor = display2.getSystemColor(SWT.COLOR_LIST_SELECTION);
		normalColor = display2.getSystemColor(SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW);
		
		innerComposite.setBackground(new Color(display2,0,0,0));
		fComposite.setBackground(new Color(display2,215, 215, 255));
		
		
		widgetStyle = style;
		
		if((widgetStyle & SWT.MULTI) != SWT.MULTI){
			widgetStyle |= SWT.SINGLE;
		}
		
		if (parent == null) {
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
		}
		fLayoutStyle = layoutStyle;
		
		if((style & SWT.V_SCROLL) == SWT.V_SCROLL){
			ifVscrollBar = true;
		}
		if((style & SWT.H_SCROLL) == SWT.H_SCROLL)
			ifHscrollBar = true;
		
		
		fListBoxLayout = new ListBoxLayout();

		innerComposite.setLayout(fListBoxLayout);
		
		lb = this;
		
		//This attribute is used to highlight a selected and focused item with a color different from selected(255,213,0) and focused colors.
		int red = selectedColor.getRGB().red -30 ;
		int green = selectedColor.getRGB().green + 30;
		int blue = selectedColor.getRGB().blue + 30;
		if (red < 0)
			red = 0;
		if (green > 255)
			green = 255;
		if (blue > 255)
			blue = 255;
		focusAndSelColor = new Color(display2, new RGB(red, green , blue ));
		
		parentComposite = hackComposite;
		
		//Sam: hope to reduce the memory leak
		hackStyle = 0;
		hackComposite = null;
	}

	/**
	 * Adds the listener to the collection of listeners who will be notified
	 * when the receiver's selection changes, by sending it one of the messages
	 * defined in the SelectionListener interface.
	 * <p>
	 * <code>widgetSelected</code> is called when the selection changes. <br>
	 * <code>widgetDefaultSelected</code> is typically called when selection
	 * is finalized.
	 * 
	 * @param listener
	 *            instance called when selection events occur
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_ADDED - if the operation fails because
	 *                of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see ListBox#removeSelectionListener
	 * @see SelectionListener
	 */
	public void addSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null)  SWT.error(SWT.ERROR_NULL_ARGUMENT);
		
		TypedListener typedListener = new TypedListener(listener);
		addListener(SWT.Selection, typedListener);
		addListener(SWT.DefaultSelection, typedListener);
				
	}

	/**
	 * Deselects the item at the given zero-relative index in the receiver. If
	 * the item at the index was already deselected, it remains deselected.
	 * Indices that are out of range are ignored.
	 * 
	 * @param index
	 *            the index of the item to deselect
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deselect(int index) {
		checkWidget();
		if(fItems != null){
			if(index < fItems.length && index >= 0){
				for(int i = 0; i < selectedCount; i++){
					if(index == selectedIndex[i]){
						unfillRow(index);
						shrink(i);
					}
				}
			}	
		}

		return;
	}
	
	// shrinks the selectedIndex array when elements are removed
	void shrink(int index){
		for(int i = index; i< selectedCount; i++){
			if(i == selectedCount-1){
				selectedCount--;
			} else{
				selectedIndex[i] = selectedIndex[i+1];
			}			
		}
		return;
	}

	/**
	 * Deselects the items at the given zero-relative indices in the receiver.
	 * If the items at the given zero-relative indexes in the receiver are
	 * selected, they are deselected. If they were not selected, they remain
	 * deselected. The range of the indices is inclusive. Indices that are out
	 * of range are ignored.
	 * 
	 * @param start
	 *            the start index of the items to deselect
	 * @param end
	 *            the end index of the items to deselect
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deselect(int start, int end) {
		checkWidget();
		for(int i = start; i <= end; i++){
			deselect(i);
		}
	}

	/**
	 * Deselects the items at the given zero-relative indices in the receiver.
	 * If the items at the given zero-relative indexes in the receiver are
	 * selected, they are deselected. If they were not selected, they remain
	 * deselected. Indices that are out of range and duplicate indices are
	 * ignored.
	 * 
	 * @param indices
	 *            the array of indices for the items to deselect
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the set of indices is null
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deselect(int[] indices) {
		checkWidget();
		if(indices == null){
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
		}
		for (int i = 0; i < indices.length; i++){
			deselect(indices[i]);
		}
	}

	/**
	 * Deselects all selected items in the receiver.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void deselectAll() {
		checkWidget();
		if(fItems!= null){
			for(int i = 0; i<fItems.length; i++){
				deselect(i);
			}
			selectedCount = 0;
		}
		return;
	}
	
	public Point computeSize(int wHint, int hHint, boolean changed) {	
		checkWidget();
		return this.getSize();
	}

	/**
	 * Returns the zero-relative index of the item which currently has the focus
	 * in the receiver, or -1 if no item has focus.
	 * 
	 * @return the index of the selected item
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public int getFocusIndex() {
		checkWidget();
		return focusIndex;
	}


	/**
	 * Returns the number of items currently selected.
	 * <p>
	 * 
	 * @return count of selected items
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_COUNT - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see #getSelectionIndices
	 */
	public int getSelectionCount() {
		checkWidget();
		return selectedCount;
	}

	/**
	 * Returns the zero-relative indices of the items which are currently
	 * selected in the receiver. The array is empty if no items are selected.
	 * <p>
	 * Note: This is not the actual structure used by the receiver to maintain
	 * its selection, so modifying the array will not affect the receiver.
	 * </p>
	 * 
	 * @return the array of indices of the selected items
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_CANNOT_GET_SELECTION - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 */
	public int[] getSelectionIndices() {
		checkWidget();
		int[] result = new int[selectedCount];
		System.arraycopy(selectedIndex, 0, result, 0, selectedCount);	
		int temp;

		//Sort before return by Uriel
		for (int i=0; i<(selectedCount-1);i++)
			for (int j=0; j<(selectedCount-1);j++)
				if (result[j] > result[j+1]) {
					temp = result[j];
					result[j] = result[j+1];
					result[j+1] = temp;
				}
		
		return result;
	}

	/**
	 * Notifies this ListBox that the data for the item at the given index has
	 * been updated and the item display needs to be refreshed.
	 * 
	 * @param index
	 *            an index into the data model array
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_RANGE - if the index is not between 0
	 *                and the number of elements in the array minus 1
	 *                (inclusive)</li>
	 *                </ul>
	 * 
	 * @see ListBox#refreshList
	 */
	public void refreshItem(int index) {
		checkWidget();
		if(fItems != null){
			if(index<0 || index >= fItems.length){
				SWT.error(SWT.ERROR_INVALID_RANGE);
			}
			int row = index;
			int start = (row)*fColumns;		
			if(showNumber){
				start++;
			}
			
			if(showHeadingIcon){
				if(fItems[row].getHeadingIcons()!=null){
					fLabels[start].setImage(fItems[row].getHeadingIcons()[0]);
					fLabels[start].pack();
					listCells[start].setSize(fLabels[start].getSize());
				}
				start++;
			}
		
			if(oneline){
				
				fLabels[start].setText(getheading(row));
				fLabels[start].setFont(headingFont);
				fLabels[start].pack();
				listCells[start].setSize(fLabels[start].getSize());
				start++;
				fLabels[start].setText(fItems[row].getDetailText());
				fLabels[start].setFont(font);
				fLabels[start].pack();
				listCells[start].setSize(fLabels[start].getSize());
				start++;			
			}
			
			else if(twoLine){
				
				String text = new String();
				text = getheading(row);
				fLabels[start].setText(text);
				fLabels[start].setFont(headingFont);
				fLabels[start].pack();
				listCells[start].setSize(fLabels[start].getSize());
				start++;
	
			}
			
			else {
				fLabels[start].setText(fItems[row].getDetailText());
				fLabels[start].setFont(font);
				fLabels[start].pack();
				listCells[start].setSize(fLabels[start].getSize());
	
			}	
			
			if(showDetailIcon){
				
				if(fItems[row].getDetailIcons()!=null){
					fLabels[start].setImage(fItems[row].getDetailIcons()[0]);
					fLabels[start].pack();
					listCells[start].setSize(fLabels[start].getSize());
				}
				
				start++;
	
			}	
			
			if(twoLine){
				fLabels[start].setText(fItems[row].getDetailText());
				fLabels[start].setFont(font);
				fLabels[start].pack();
				listCells[start].setSize(fLabels[start].getSize());
			}
			updateSize();
		}
	}
	
	

	/**
	 * Notifies this ListBox that multiple items may have been updated and the
	 * entire list display needs to be refreshed.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * 
	 * @see ListBox#refreshItem
	 */
	public void refreshList() {
		checkWidget();
		if(fItems != null){
			for(int i=0; i < fItems.length; i++ ){
				refreshItem(i);
				
			}
		}
	}

	/**
	 * Removes the listener from the collection of listeners who are notified
	 * when the receiver's selection changes.
	 * 
	 * @param listener
	 *            instance called when selection events occur
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the listener is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception SWTError
	 *                <ul>
	 *                <li>ERROR_ITEM_NOT_REMOVED - if the operation fails
	 *                because of an operating system failure</li>
	 *                </ul>
	 * 
	 * @see ListBox#addSelectionListener
	 * @see SelectionListener
	 */
	public void removeSelectionListener(SelectionListener listener) {
		checkWidget();
		if (listener == null)  SWT.error(SWT.ERROR_NULL_ARGUMENT);

		removeListener(SWT.Selection, listener);	
		removeListener(SWT.DefaultSelection, listener);
		
	}

	/**
	 * Sets the font for the details text of an item. If the argument is null,
	 * the default font will be used.
	 * 
	 * @param font
	 *            the new font or null
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the argument has been
	 *                disposed</li>
	 *                </ul>
	 * 
	 * @see ListBox#setHeadingFont
	 */
	public void setFont(Font font) {
		checkWidget();
		if (null == font) {
			this.font = getDisplay().getSystemFont(); //default font
		} else if(font.isDisposed()){
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		}
		this.font = font;
		
		for (int i=0; i<fLabelCount; i++){
			if(i%fColumns==detailPosition)
				fLabels[i].setFont(font);
		}
		
		updateSize();
	}
	
	public Font getFont() {
		checkWidget();
		if (font != null) return this.font;
		return getDisplay().getSystemFont();
	}

	/**
	 * Sets the font for the heading text of an item. If the argument is null,
	 * the default font will be used.
	 * 
	 * @param font
	 *            the new font or null
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the argument has been
	 *                disposed</li>
	 *                </ul>
	 * 
	 * #see ListBox#setFont
	 */
	public void setHeadingFont(Font font) {
		checkWidget();
		if (null == font) {
			this.headingFont = getDisplay().getSystemFont(); //default font
		} else if(font.isDisposed()){
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
		}
		this.headingFont = font;
		
		for (int i=0; i<fLabelCount; i++){
			if(headingPosition != 0 && i%fColumns==headingPosition)
			fLabels[i].setFont(font);
		}
		
		updateSize();
	}

	/**
	 * Selects the item at the given zero-relative index in the receiver's list.
	 * If the item at the index was already selected, it remains selected.
	 * Indices that are out of range are ignored.
	 * 
	 * @param index
	 *            the index of the item to select
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void select(int index) {
		checkWidget();
		if(fItems != null){
			if((widgetStyle & SWT.SINGLE) == SWT.SINGLE){
				deselectAll();		
			}
			if(index < fItems.length && index >= 0){
				for(int i =0; i<selectedCount; i++){
					if(selectedIndex[i] == index){
						fillRow(index, selectedColor);
						return;
					} 
				}
				selectedIndex[selectedCount] = index;
				selectedCount++;
				
				//scale selectedindex up if more than the limits are selected
				if(selectedCount==selectedIndex.length){
					int [] newArray = new int [selectedIndex.length * 2];
					System.arraycopy(selectedIndex, 0, newArray, 0, selectedIndex.length);
					selectedIndex = newArray;
				}
				// focus effect
				fillRow(index, selectedColor);
				}
		}		
		return;
	}

	/**
	 * Selects the items in the range specified by the given zero-relative
	 * indices in the receiver. The range of indices is inclusive. The current
	 * selection is not cleared before the new items are selected.
	 * <p>
	 * If an item in the given range is not selected, it is selected. If an item
	 * in the given range was already selected, it remains selected. Indices
	 * that are out of range are ignored and no items will be selected if start
	 * is greater than end. If the receiver is single-select and there is more
	 * than one item in the given range, then all indices are ignored.
	 * 
	 * @param start
	 *            the start of the range
	 * @param end
	 *            the end of the range
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see #setSelection(int,int)
	 */
	public void select(int start, int end) {
		checkWidget();
		if(fItems != null){
			if((widgetStyle & SWT.SINGLE) == SWT.SINGLE){
				if(start == end && start >= 0 && end < fItems.length){
					select(start);
				}
			}
			else{		
				for (int i = start; i<= end; i++){
					select(i);
				}
			}
		}
		return;
	}

	/**
	 * Selects the items at the given zero-relative indices in the receiver. The
	 * current selection is not cleared before the new items are selected.
	 * <p>
	 * If the item at a given index is not selected, it is selected. If the item
	 * at a given index was already selected, it remains selected. Indices that
	 * are out of range and duplicate indices are ignored. If the receiver is
	 * single-select and multiple indices are specified, then all indices are
	 * ignored.
	 * 
	 * @param indices
	 *            the array of indices for the items to select
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the array of indices is null
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see #setSelection(int[])
	 */
	public void select(int[] indices) {
		checkWidget();
		if(indices == null){
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
		}
		
		if((widgetStyle & SWT.SINGLE) == SWT.SINGLE){
			if( indices.length > 1 || indices.length == 0) return;
			else select(indices[0]);
		} else {
			for(int i =0; i<indices.length; i++){
				select(indices[i]);
			}
		}
		return;
	}

	/**
	 * Selects all of the items in the receiver.
	 * <p>
	 * If the receiver is single-select, do nothing.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void selectAll() {
		checkWidget();
		if(fItems != null){
			if(!((widgetStyle & SWT.SINGLE) == SWT.SINGLE)){
				for(int i = 0; i<fItems.length; i++){
					select(i);
				}
			}
		}
		return;
	}

	/**
	 * Establishes the data model for this ListBox. The provided array is used
	 * for the life of the ListBox or until a new data model is set. Elements of
	 * a ListBoxItem which are <code>null</code> or disposed are not displayed, 
	 * leaving a blank area within the layout.
	 * 
	 * @param items
	 *            an array of ListBoxItems or <code>null</code>
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the parent</li>
	 *                </ul>
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the items is null</li>
	 *                </ul>
	 * 
	 * @see ListBoxItem
	 */
	public void setDataModel(ListBoxItem[] items) {
		checkWidget();
		if(items == null){
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
		}
		selectedCount = 0;
		fItems = items;
		deleteContent();
		createContent();

		
		/*
		 * Add mouseListener for all Labels in the widget, and setSelection(select)
		 * depending on SINGLE or MULTI upon clicking.
		 */
		
		Control [] children =innerComposite.getTabList();
		for (int i = 0; i<children.length; i++){
			final int index = i;
			children[i].addMouseListener(new MouseListener(){
				
				public void mouseDoubleClick(MouseEvent e) {
					
				}
	
				public void mouseDown(MouseEvent e) {	
					lb.forceFocus();
					pressed(index);
					lb.internal_sendEvent(SWT.DefaultSelection); //send the DefaultSelection event
					
				}
	
				public void mouseUp(MouseEvent e) {					
				}
			});
			Control [] grandchildren = ((Composite) children[i]).getChildren();
			for(int j =0; j<grandchildren.length; j++){
				grandchildren[j].addMouseListener(new MouseListener(){
					
					public void mouseDoubleClick(MouseEvent e) {
						
					}
		
					public void mouseDown(MouseEvent e) {
						lb.forceFocus();
						pressed(index);
						lb.internal_sendEvent(SWT.DefaultSelection); //send the DefaultSelection event
						
					}
		
					public void mouseUp(MouseEvent e) {					
					}
				});
				grandchildren[j] = null;
			}//for loop of grandchildren
			grandchildren = null;
			children[i] = null;
		}//for loop of children
		children = null;
	}
	
	//The effect of a mouse press, select, set focus and background color
	void pressed(int index){
		int row = index/fColumns;		
		//Onle unselect the previous seleted or focused item as SWT.SINGLE syle or unselected.
		if(((widgetStyle & SWT.SINGLE) == SWT.SINGLE)){
			deselectAll();
		}
		if (!isSelectedItem(focusIndex)) {
			unfillRow(focusIndex);
		} else {
			setKeyStrokeColor(focusIndex, selectedColor);
		}
		focusIndex = row; //set the focusIndex, added by Uriel
		if((widgetStyle & SWT.SINGLE) == SWT.SINGLE){			
			setSelection(row);
		} else if((widgetStyle & SWT.MULTI) == SWT.MULTI){
			
			for(int i = 0; i < selectedCount; i++){
				if(selectedIndex[i] == row){
				
				deselect(row);
				return;
				}
			}
		
			select(row);
		}
	}
	
	
	//This is used to set background color to focused item while typing up/down to switch between each item.
	private void setKeyStrokeColor(int index, Color backgroundColor) {
		if(fItems != null){
			if(index < fItems.length && index >= 0){
				fillRow(index, backgroundColor);
			}
		}		
	}

	/**
	 * Selects the item at the given zero-relative index in the receiver. If the
	 * item at the index was already selected, it remains selected. The current
	 * selected is first cleared, then the new items are selected. Index that
	 * is out of range are ignored.
	 * 
	 * @param index
	 *            the index of the item to select
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setSelection(int index) {
		
		checkWidget();
		for(int i = selectedCount-1; i >=0; i--){
			deselect(selectedIndex[i]);
		}
		selectedCount = 0;
		select(index);
	}

	/**
	 * Selects the items in the range specified by the given zero-relative
	 * indices in the receiver. The range of indices is inclusive. The current
	 * selection is cleared before the new items are selected.
	 * <p>
	 * Indices that are out of range are ignored and no items will be selected
	 * if start is greater than end. If the receiver is single-select and there
	 * is more than one item in the given range, then all indices are ignored.
	 * 
	 * @param start
	 *            the start index of the items to select
	 * @param end
	 *            the end index of the items to select
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 *  
	 */
	public void setSelection(int start, int end) {
		checkWidget();
		for(int i = selectedCount-1; i >=0; i--){
			deselect(selectedIndex[i]);
		}
		if((widgetStyle & SWT.SINGLE) == SWT.SINGLE){

			if(start == end){
				setSelection(start);
			}
			
		} else {

			selectedCount = 0;
			select(start, end);
		}
	}

	/**
	 * Selects the items at the given zero-relative indices in the receiver. The
	 * current selection is cleared before the new items are selected.
	 * <p>
	 * Indices that are out of range and duplicate indices are ignored. If the
	 * receiver is single-select and multiple indices are specified, then all
	 * indices are ignored.
	 * 
	 * @param indices
	 *            the indices of the items to select
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the array of indices is null
	 *                </li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 * 
	 * @see #deselectAll()
	 * @see #select(int[])
	 */
	public void setSelection(int[] indices) {
		checkWidget();
		
		for(int i = selectedCount-1; i >=0; i--){
			deselect(selectedIndex[i]);
		}
		
		if(((widgetStyle & SWT.SINGLE) != 0) && indices.length > 1) {
//		    for (int i = 1; i < indices.length; ++i) {
//		        if (indices[i] != indices[0]) {
		            return;
//		        }		        
//		    }
//		    if (indices[0] != -1) {
//		    	deselectAll();
//				select (indices[0]);
//			} 
//		    return;
		
		}		
		
		if(indices == null){
			SWT.error(SWT.ERROR_NULL_ARGUMENT);
		}

		selectedCount = 0;
		select(indices);
	}

	/**
	 * Shows the selection. If the selection is already showing in the receiver,
	 * this method simply returns. Otherwise, the items are scrolled until the
	 * selection is visible. When multiple items are selected, the selection of
	 * which item becomes visible is implementation-dependent.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void showSelection() {
		checkWidget();
		int [] selected = getSelectionIndices();
		
		
		
//		Rectangle r = fLabels[selected[0]*fColumns].getBounds();
		Rectangle r = listCells[selected[0]*fColumns].getBounds();
		//if Selected Item is already in View, do nothing
		if(r.y>ScrollY && (r.y+r.height) < (ScrollY+fComposite.getClientArea().height)){
				return;
				
		} else {
			
//			else scroll the Selected item to the top of the widget
			Rectangle innerR = innerComposite.getBounds();
			if(r.y >= (innerR.height-fComposite.getClientArea().height)){
				r.y = innerR.height-fComposite.getClientArea().height;
			}
			ScrollY = r.y;
			innerComposite.setBounds(innerR.x, -r.y, innerR.width, innerR.height);
			
			// computer the closest value of the scrollbar and set it to reflect the scrolling
			if(fVScrollBar != null){
				int max = fVScrollBar.getMaximum()-fVScrollBar.getThumb();
				int min = fVScrollBar.getMinimum();
				int diff = innerComposite.getBounds().height-fComposite.getClientArea().height;
				
				int percent = r.y*(max-min);
				if(diff == 0) return;					
				int value = percent/diff;
				if(value >= fVScrollBar.getMaximum()){
					value = fVScrollBar.getMaximum();
				}
				
				fVScrollBar.setSelection(value);
			}
		}
	}
	
	void scrollNext(int focusIndex){
		Rectangle r = listCells[focusIndex*fColumns].getBounds();
		//if Selected Item is already in View, do nothing
		if(r.y>ScrollY && (r.y+r.height) < (ScrollY+fComposite.getClientArea().height)){
				return;
				
		} else {
//			else scroll the Selected item to the bottom of the widget
			Rectangle innerR = innerComposite.getBounds();
			if(r.y+r.height < fComposite.getClientArea().height){
				r.y = 0;
			} else {
				r.y = r.y +r.height - fComposite.getClientArea().height;
			}
			ScrollY = r.y;
			innerComposite.setBounds(innerR.x, -r.y, innerR.width, innerR.height);
				
			// computer the closest value of the scrollbar and set it to reflect the scrolling
			if(fVScrollBar != null){
				int max = fVScrollBar.getMaximum()-fVScrollBar.getThumb();
				int min = fVScrollBar.getMinimum();
				int diff = innerComposite.getBounds().height-fComposite.getClientArea().height;
				int percent = (r.y+r.height)*(max-min);
				int value = percent/diff;
				if(value >= fVScrollBar.getMaximum()){
					value = fVScrollBar.getMaximum() + 1;
				}			
				fVScrollBar.setSelection(value);
			}
		}		
	}
	
	// Re-layout the widget whenever the content changes
	void updateSize(){
		
		if(setWidth != -1 && setHeight != -1)
			setSize(setWidth, setHeight);
		else		
			pack();
	}
	
	/* pack the widget, set scrollbar visible to false since widget takes on
	 * it's prefered size (non-Javadoc)
	 * @see org.eclipse.swt.widgets.Control#pack()
	 */ 
	public void pack(){
		
		checkWidget();
		setWidth = -1;
		setHeight = -1;
		for(int i=0; i<fLabelCount; i++){
			listCells[i].setSize(fLabels[i].getSize());
		}
		innerComposite.pack();
		preferredWidth = innerComposite.getSize().x;
		preferredHeight = innerComposite.getSize().y;
		fComposite.pack();
		
		if((fVScrollBar = fComposite.getVerticalBar()) != null){
			fVScrollBar.setVisible(false);
		}
		if((fHScrollBar = fComposite.getHorizontalBar()) != null){
			fHScrollBar.setVisible(false);
		}
	
		vCenterTexts();
	}
	
	/* setBounds, reimplement it so that the widget would be laid out correctly
	 *  (non-Javadoc)
	 * @see org.eclipse.swt.widgets.Control#setBounds(int, int, int, int)
	 */
	public void setBounds(int x, int y, int w, int h){
		
		checkWidget();
		setLocation(x, y);
		setSize(w, h);
	}
	
	/* setsize, if the w, h is set to less than the prefered size, scroll bar will be
	 * visible and vice versa.  Scale the thumb to max and min percentage the same
	 * as the displayed and the full content percentage
	 */
	public void setSize(int w, int h){
		checkWidget();
		if((fHScrollBar = fComposite.getHorizontalBar()) != null){
			if(w<preferredWidth){
				fHScrollBar.setVisible(true);
			} else {
				fHScrollBar.setVisible(false);
			}
		}
		if((fVScrollBar = fComposite.getVerticalBar()) != null){
			if(h<preferredHeight){
				fVScrollBar.setVisible(true);
			} else {
				fVScrollBar.setVisible(false);
			}
		}
		if(w<0 || h<0) return;
		setWidth = w;
		setHeight = h;
		super.setSize(w,h);
		for(int i=0; i<fLabelCount; i++){
			listCells[i].setSize(fLabels[i].getSize());
		}
		if(innerComposite != null && !innerComposite.isDisposed())
			innerComposite.pack();
//		Rectangle rr = innerComposite.getBounds();
		fComposite.setSize(w, h);
		
		if(fItems != null){
		
			
			if((fVScrollBar = fComposite.getVerticalBar()) != null){
//					fVScrollBar.setVisible(true);
					
					fVScrollBar.setMaximum(innerComposite.getSize().y);
					int page = fComposite.getClientArea().height;
					fVScrollBar.setThumb(page);
					fVScrollBar.setPageIncrement(page);
					fVScrollBar.setIncrement(page/10);
					fVScrollBar.setMinimum(0);
					

//					if(fVScrollBar.getThumb()==fVScrollBar.getMaximum()){
//						fVScrollBar.setVisible(false);
//					}
			}
			
			if((fHScrollBar = fComposite.getHorizontalBar()) != null){
//					fHScrollBar.setVisible(true);
					fHScrollBar.setMaximum(innerComposite.getSize().x);
					int page = fComposite.getClientArea().width;
					fHScrollBar.setThumb(page);
					fHScrollBar.setPageIncrement(page);
					fHScrollBar.setIncrement(page/10);
					fHScrollBar.setMinimum(0);
					
//					 r = fComposite.getClientArea();
//					if(fHScrollBar.getThumb()==fHScrollBar.getMaximum()){
//						fHScrollBar.setVisible(false);
//					}
					
			}
		}
		vCenterTexts();

		
	}
	
	void vCenterTexts(){
		
		for(int i =0; i<fLabelCount; i++){
			int col = i%fColumns;
			if(showNumber){
				if(col == 0){
					Point pp = listCells[i].getSize();
					Point p = fLabels[i].getSize();
					fLabels[i].setLocation((pp.x-p.x)/2, (pp.y-p.y)/2);
					pp=null;
					p=null;
				}
			}
			if(oneline || twoLine){
				if(col == detailPosition || col == headingPosition){
					Point pp = listCells[i].getSize();
					Point p = fLabels[i].getSize();
					fLabels[i].setLocation((pp.x-p.x)/2, (pp.y-p.y)/2);
					pp=null;
					p=null;
				}
			} else {
				if(col == detailPosition){
					Point pp = listCells[i].getSize();
					Point p = fLabels[i].getSize();
					fLabels[i].setLocation((pp.x-p.x)/2, (pp.y-p.y)/2);
					pp=null;
					p=null;
				}
			}
			// anchor detail icon to the bottom right
			if(showDetailIcon){
				if(twoLine){
					if(col == fColumns-2){
						Point pp = listCells[i].getSize();
						Point p = fLabels[i].getSize();
						fLabels[i].setLocation((pp.x-p.x), (pp.y-p.y));
						pp=null;
						p=null;
					}
				} else 
				if(col == fColumns-1){
					Point pp = listCells[i].getSize();
					Point p = fLabels[i].getSize();
					fLabels[i].setLocation((pp.x-p.x), (pp.y-p.y));
					pp=null;
					p=null;
				}
			}
			// Vcenter the heading Icon
			if(showHeadingIcon){
				if(col == headingIconPosition){
					Point pp = listCells[i].getSize();
					Point p = fLabels[i].getSize();
					fLabels[i].setLocation((pp.x-p.x)/2, (pp.y-p.y)/2);
					pp=null;
					p=null;
				}
			}
			
			}
		
	}
	
	
	
	
	/* creates a handle for widget to use
	 *  (non-Javadoc)
	 * @see org.eclipse.swt.widgets.Widget#internal_createHandle(int)
	 */
	public void internal_createHandle(int index) {
		
		// List styles: SINGLE, MULTI
		// Scrollable styles: V_SCROLL, H_SCROLL
		fComposite = new Canvas(hackComposite, hackStyle);	
		CompositeLayout layout = new CompositeLayout();
		fComposite.setLayout(layout);		
		innerComposite = new Composite(fComposite, 0);
		
		internal_handle = fComposite.internal_handle;
		
		hackComposite.internal_removeChild(fComposite);
		

		
	}
	
	// Save the parent and the Style of the widget
	private static Composite SaveStyle(Composite parent, int style) {
		hackStyle = style;
		hackComposite = parent;
		return parent;
	}
	
//	fix against bug# 100942
	protected void releaseWidget(){
		if (isDisposed()) return; //fix against bug# 100942
		
		if(fVScrollBar!=null){
			if(!fVScrollBar.isDisposed()){
				fVScrollBar.dispose();
			}
			fVScrollBar = null;
		}
		
		if(fHScrollBar!=null){
			if(!fHScrollBar.isDisposed()){
				fHScrollBar.dispose();
			}
			fHScrollBar = null;
		}
		if(fItems!=null){
			//fix bug SHLE7U5AGR
        	//for(int i=0;i<fItems.length;i++){
    			//if(fItems[i]!=null){
    				//fItems[i]=null;
    			//}
    		//}
        	fItems = null;
        }
		if(fListBoxLayout!=null){
			fListBoxLayout = null;
		}
		if(selectedIndex!=null){
			selectedIndex = null;
		}
        
		if(font!=null){
			if(!font.isDisposed()){
				font.dispose();	
			}
			font =null;
		}
		
		if(headingFont!=null){
			if(!headingFont.isDisposed()){
				headingFont.dispose();
			}
			headingFont =null;
		}
		
		if(textFocusColor!=null){
			if(!textFocusColor.isDisposed()){
				textFocusColor = null;
			}
		}
		if(focusColor!=null){
			if(!focusColor.isDisposed()){
				focusColor = null;
			}
		}
		if(focusAndSelColor!=null){
			if(!focusAndSelColor.isDisposed()){
				focusAndSelColor = null;
			}
		}
		if(selectedColor!=null){
			if(!selectedColor.isDisposed()){
				selectedColor = null;
			}
		}
		if(normalColor!=null){
			if(!normalColor.isDisposed()){
				normalColor = null;
			}
		}
		
		if(fLabels!=null){
			for(int i=0;i<fLabels.length;i++){
				if(fLabels[i]!=null){
					if(!fLabels[i].isDisposed()){
						fLabels[i].dispose();	
					}
					fLabels[i] = null;
				}
			}
			fLabels = null;
		}
		if(listCells!=null){
			for(int i=0;i<listCells.length;i++){
				if(listCells[i]!=null){
					if(!listCells[i].isDisposed()){
						listCells[i].dispose();	
					}
					listCells[i] = null;
				}
			}
			listCells = null;
		}
		fLabelCount = 0;
		
		if(innerComposite!=null){
			if(!innerComposite.isDisposed()){
				innerComposite.dispose();	
			}
			innerComposite = null;
		}
		removeInternalFilter();
		
		if(keyListener!=null){
			keyListener = null;
		}
		
		if(fComposite!=null){
			if(!fComposite.isDisposed()){
				fComposite.dispose();
			}
			fComposite = null;
		}
		
		//Sam: can not dispose parent shell and composite
		if(parentComposite!=null){
				parentComposite = null;
		}
		

		lb=null;
		//Sam: I should put internal_handle = 0 here
		//otherwise, it will crash while executing 
		//OS.Widget_SetData(internal_handle, null); in Widget
		//since the internal_handle of it is equal with fComposite
		//and it has been set to 0 while disposing.
		//So, if we would like to call super.releaseWidget
		//we should set internal_handle =0 here
		internal_handle = 0;
		super.releaseWidget(); //fix against bug# 100942
		isDisposed = true;

	}
	
	protected void releaseHandle() {
		
		if(display2!=null){
			display2 = null;
		}
	}
	//we should overwrite the isDisposed() in Listbox 
	//since it will call checkWidget() --> if (isDisposed())
	//in Widget.java while calling super.releaseWidget(), 
	//then if we do not overwrite the isDisposed(), it will
	// return true if internal_handle = 0, however, since 
	//we set internal_handle = 0 before calling super.releaseWidget(), 
	//then it will throw error here. So, we should overwrite here to 
	//prevent this problem
	
	public boolean isDisposed() {
		return isDisposed;
	}
	
	protected void removeInternalFilter(){
		if(keyListener!=null){
			this.getDisplay().removeFilter(SWT.KeyDown, keyListener);
		}
	}
	
	public ScrollBar getVerticalBar(){
		
		if(fComposite.getVerticalBar() != null)
			return fComposite.getVerticalBar();
		else return null;
	}
	
	public ScrollBar getHorizontalBar(){
		
		if(fComposite.getHorizontalBar() != null)
			return fComposite.getHorizontalBar();
		else return null;
	}
	
	
	void deleteContent(){
		for(int i = 0; i<fLabelCount; i++){
			fLabels[i].dispose();
			listCells[i].dispose();
		}
		fLabelCount = 0;		
		//added by sam
		detailPosition = 0;
		headingPosition = 0;
		headingIconPosition = 0;
		
		removeInternalFilter();
	}
	/* Create the content of the widget after loading in the data model.  Lay
	 * it out depending on the style given.
	 */
	void createContent(){
		fColumns = 0;
		setColumns();
		if(fItems != null){
			for(int i = 0; i<fItems.length; i++){
							
				if(showNumber){
					Label l = new Label(innerComposite, 0);
					l.setText(Integer.toString(i+1));
					FontData fontData = l.getFont().getFontData()[0];
					Font font = new Font(display2, fontData.getName(), fontData.getHeight(), SWT.BOLD);
					l.setFont(font);						
			
					newLabel(l);
					l = null;
					
					
				}
				
				if(showHeadingIcon){
					Label l = new Label(innerComposite, 0);
					if(fItems[i]!=null){
						if (fItems[i].getHeadingIcons()!=null){ //fix against bug# 100597
						l.setImage(fItems[i].getHeadingIcons()[0]);
						}
					}
					newLabel(l);
					l = null;
				}
	
				if(oneline){
					styleDefined = true;
					Label l = new Label(innerComposite, 0);
					l.setText(getheading(i));
					l.setFont(headingFont);
					
					newLabel(l);		
					l = new Label(innerComposite, 0);
					if(fItems[i]!=null){
						l.setText(fItems[i].getDetailText());
						l.setFont(font);
					}
					
					newLabel(l);
					l = null;
				} else if(twoLine){
					styleDefined = true;				
					String text = new String();
					text = getheading(i);
					Label l = new Label(innerComposite, 0);
					l.setText(text);
					l.setFont(headingFont);
					
					newLabel(l);					
					l = null;
				} else {
					Label l = new Label(innerComposite, 0);
					if(fItems[i]!=null){
						l.setText(fItems[i].getDetailText());
						l.setFont(font);
					}
					
					newLabel(l);
					l = null;
				}	
				


				if(showDetailIcon){
					Label l = new Label(innerComposite, 0);
					if(fItems[i]!=null){
						if (fItems[i].getDetailIcons()!=null) {//fix against bug# 100597
							l.setImage(fItems[i].getDetailIcons()[0]);
						}
					}
					newLabel(l);
					l = null;
				}
				if(twoLine){
					
//					Label l = new Label(innerComposite, SWT.BORDER);
					Label l = new Label(innerComposite, 0);
					if(fItems[i]!=null){
						l.setText(fItems[i].getDetailText());
						l.setFont(font);
					}
					
					newLabel(l);
				}
			}
		}
		updateSize();
		
		/* Handles Scroll bar events, do appropreate scrolling for both vertical
		 * and horizontal scroll bar 
		 */
		if(fComposite.getVerticalBar() != null){
			
			fVScrollBar = fComposite.getVerticalBar();
			
			fVScrollBar.addSelectionListener(new SelectionListener(){

				public void widgetSelected(SelectionEvent e) {
					int sel = fVScrollBar.getSelection();
					doScroll(fVScrollBar, sel);
				}
				public void widgetDefaultSelected(SelectionEvent e) {
				}				
				});
		}
		if(fComposite.getHorizontalBar() != null){
			fHScrollBar = fComposite.getHorizontalBar();
			fHScrollBar.addSelectionListener(new SelectionListener(){
				public void widgetSelected(SelectionEvent e) {
					int sel = fHScrollBar.getSelection();
					doScroll(fHScrollBar, sel);
				}
				public void widgetDefaultSelected(SelectionEvent e) {					
				}				
				});
		}
		
		this.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				if (fItems.length > 0) {
					if((widgetStyle & SWT.MULTI) == SWT.MULTI){					
						if (!isSelectedItem(focusIndex)) {
							setKeyStrokeColor(focusIndex, focusColor);
						} else {
							setKeyStrokeColor(focusIndex, focusAndSelColor);
						}
					} else	
						select(focusIndex);
					
				}
			}

			public void focusLost(FocusEvent e) {
				if((widgetStyle & SWT.MULTI) == SWT.MULTI){		
					if (!isSelectedItem(focusIndex)) {
						unfillRow(focusIndex);
					} else {
						setKeyStrokeColor(focusIndex, selectedColor);
					}
				} else	
					select(focusIndex);
			}
			
		});
			
		keyListener = new Listener(){
		
			public void handleEvent(Event event) {
				if(display2.getFocusControl() == lb){
						switch(event.keyCode){		
											
						case SWT.ARROW_UP:{
							if((widgetStyle & SWT.MULTI) == SWT.MULTI){
								if (!isSelectedItem(focusIndex)) {
									unfillRow(focusIndex);
								} else {
									setKeyStrokeColor(focusIndex, selectedColor);
								}
								
								focusIndex--;
								if(focusIndex <0){
									focusIndex = fItems.length-1;
								}
								
								if (!isSelectedItem(focusIndex)) {
									setKeyStrokeColor(focusIndex, focusColor);
								}
								else{
									setKeyStrokeColor(focusIndex, focusAndSelColor);
								}
								((ListBox)lb).internal_sendEvent(SWT.Selection); //send the Selection event
								showFocusedItem(focusIndex);
								
							}
							else {					
								focusIndex--;
								if(focusIndex <0){
									focusIndex = fItems.length-1;
								}
								
								setSelection(focusIndex);
								showSelection();
							}
							
						} break;
						
						case SWT.ARROW_DOWN:{		
							if((widgetStyle & SWT.MULTI) == SWT.MULTI){
								if (!isSelectedItem(focusIndex)) {
									unfillRow(focusIndex);
								} else {
									setKeyStrokeColor(focusIndex, selectedColor);
								}
								
								focusIndex++;
								
								if(focusIndex == fItems.length){
									focusIndex=0;
								}
								
								if (!isSelectedItem(focusIndex)) {
									setKeyStrokeColor(focusIndex, focusColor);
								}
								else{
									setKeyStrokeColor(focusIndex, focusAndSelColor);
								}
								((ListBox)lb).internal_sendEvent(SWT.Selection); //send the Selection event
	//							setSelection(focusIndex);
								if(focusIndex == 0) {
									showFocusedItem(focusIndex);
								} else
									{
									scrollNext(focusIndex);
								}
							} else {
								focusIndex++;								
								if(focusIndex == fItems.length){
									focusIndex=0;
								}
								setSelection(focusIndex);
								showSelection();								
							}
						} break;
						
						// ok/enter keystoke is used to select a focused item and issue defaultSelection event. 
						case SWT.CR :{
							
							if((widgetStyle & SWT.SINGLE) == SWT.SINGLE) {
								deselectAll();
								select(focusIndex);
							}
							else {							
								if (isSelectedItem(focusIndex)) {
									deselect(focusIndex);
									setKeyStrokeColor(focusIndex, focusColor);
								}
								else {
									select(focusIndex);
									setKeyStrokeColor(focusIndex, focusAndSelColor);
								}
							}
							((ListBox)lb).internal_sendEvent(SWT.DefaultSelection); //send the DefaultSelection event
						}
						break;
						
						case SWT.KEYPAD_1:
						case 49:
							if (fItems.length >= 1) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(0);
									setKeyStrokeColor(0, focusAndSelColor);
								} else {
									select(0);
								}
								focusIndex = 0;
							}
							break;
						case SWT.KEYPAD_2:
						case 50:
							if (fItems.length >= 2) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(1);
									setKeyStrokeColor(1, focusAndSelColor);
								} else {
									select(1);
								}
								focusIndex = 1;
							}
							break;
						case SWT.KEYPAD_3:
						case 51:
							if (fItems.length >= 3) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(2);
									setKeyStrokeColor(2, focusAndSelColor);
								} else {
									select(2);
								}
								focusIndex = 2;
							}
							break;
						case SWT.KEYPAD_4:
						case 52:
							if (fItems.length >= 4) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(3);
									setKeyStrokeColor(3, focusAndSelColor);
								} else {
									select(3);
								}
								focusIndex = 3;
							}
							break;
						case SWT.KEYPAD_5:
						case 53:
							if (fItems.length >= 5) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(4);
									setKeyStrokeColor(4, focusAndSelColor);
								} else {
									select(4);
								}
								focusIndex = 4;
							}
							break;
						case SWT.KEYPAD_6:
						case 54:
							if (fItems.length >= 6) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(5);
									setKeyStrokeColor(5, focusAndSelColor);
								} else {
									select(5);
								}
								focusIndex = 5;
							}
							break;
						case SWT.KEYPAD_7:
						case 55:
							if (fItems.length >= 7) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(6);
									setKeyStrokeColor(6, focusAndSelColor);
								} else {
									select(6);
								}
								focusIndex = 6;
							}
							break;
						case SWT.KEYPAD_8:
						case 56:
							if (fItems.length >= 8) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(7);
									setKeyStrokeColor(7, focusAndSelColor);
								} else {
									select(7);
								}
								focusIndex = 7;
							}
							break;
						case SWT.KEYPAD_9:
						case 57: 
							if (fItems.length >= 9) {
								if((widgetStyle & SWT.MULTI) == SWT.MULTI){
									if (!isSelectedItem(focusIndex))
										unfillRow(focusIndex);
									else
										setKeyStrokeColor(focusIndex, selectedColor);
									select(8);
									setKeyStrokeColor(8, focusAndSelColor);
								} else {
									select(8);
								}
								focusIndex = 8;
							}
							break;
					}
				}				
			}};
		display2.addFilter(SWT.KeyDown, keyListener);
		
	}
	
	private void showFocusedItem(int index) {		
//		Rectangle r = fLabels[selected[0]*fColumns].getBounds();
		Rectangle r = listCells[index*fColumns].getBounds();
		//if Selected Item is already in View, do nothing
		if(r.y>ScrollY && (r.y+r.height) < (ScrollY+fComposite.getClientArea().height)){
				return;
				
		} else {
			
//			else scroll the Selected item to the top of the widget
			Rectangle innerR = innerComposite.getBounds();
			if(r.y >= (innerR.height-fComposite.getClientArea().height)){
				r.y = innerR.height-fComposite.getClientArea().height;
			}
			ScrollY = r.y;
			innerComposite.setBounds(innerR.x, -r.y, innerR.width, innerR.height);
			if(innerR!=null){
				innerR = null;
			}
			
			// computer the closest value of the scrollbar and set it to reflect the scrolling
			if(fVScrollBar != null){
				int max = fVScrollBar.getMaximum()-fVScrollBar.getThumb();
				int min = fVScrollBar.getMinimum();
				int diff = innerComposite.getBounds().height-fComposite.getClientArea().height;
				
				int percent = r.y*(max-min);
				if(diff == 0) return;					
				int value = percent/diff;
				if(value >= fVScrollBar.getMaximum()){
					value = fVScrollBar.getMaximum();
				}
				
				fVScrollBar.setSelection(value);
			}
		}
	}
	
	//Veirfy whether a index item has been selected already or not.
	boolean isSelectedItem(int index) {
		boolean isSelected = false;
		for(int num = 0 ; num < selectedCount ; num ++ ) {								
			if (selectedIndex[num] == index) {
				isSelected = true;
				break;
			}
		}
		return isSelected;
	}
	
	/* do the actual scrolling by computing the amout to be shifted and set
	 * bounds for the innerComposite
	 */
	void doScroll(ScrollBar scrollbar, int value){
		int max = scrollbar.getMaximum()-scrollbar.getThumb();
		int min = scrollbar.getMinimum();		
		Rectangle innerRect = innerComposite.getBounds();		
		if(scrollbar == fHScrollBar){
			int diff = innerRect.width-fComposite.getClientArea().width;
			int Scale = diff*value/(max-min);
			innerComposite.setBounds(-Scale, innerRect.y, innerRect.width, innerRect.height);
		} else {
			int diff = innerRect.height-fComposite.getClientArea().height;
		    int Scale = diff*value/(max-min);
		    ScrollY = Scale;
			innerComposite.setBounds(innerRect.x, -value, innerRect.width, innerRect.height);
		}
	}
	
	/* decides the number of columns by the styles given, also compute the 
	 * indices for heading text and detail text for setFont 
	 */
	void setColumns(){		
		if((fLayoutStyle & LB_STYLE_1LINE_ITEM) == LB_STYLE_1LINE_ITEM){
			oneline = true;
			detailPosition++;
			fColumns+=2;			
		}		
		else if((fLayoutStyle & LB_STYLE_2LINE_ITEM) == LB_STYLE_2LINE_ITEM){
			twoLine = true;
			detailPosition++;
			fColumns+=2;
		}
		
		else {
			fColumns++;
		}
		
		if((fLayoutStyle & LB_MOD_SHOW_SELECTION_NUMBER) == LB_MOD_SHOW_SELECTION_NUMBER){
			showNumber = true;
			detailPosition++;
			headingPosition++;
			headingIconPosition++;
			fColumns++;
		}
		if((fLayoutStyle & LB_MOD_SHOW_HEADING_ICONS) == LB_MOD_SHOW_HEADING_ICONS){
			showHeadingIcon = true;
			headingPosition++;
			detailPosition++;
			fColumns++;
		}
		if((fLayoutStyle & LB_MOD_SHOW_DETAIL_ICONS) == LB_MOD_SHOW_DETAIL_ICONS){
			showDetailIcon = true;
			
			if(twoLine){
				detailPosition++;
			}
			fColumns++;
		}	
		
		//ListBoxLayout Properties
		if(twoLine){
			fListBoxLayout.numColumns = fColumns-1;
		} else{
			fListBoxLayout.numColumns = fColumns;
		}			
		fListBoxLayout.verticalSpacing = 0;
		fListBoxLayout.horizontalSpacing = 0;
		fListBoxLayout.marginWidth=1;
		fListBoxLayout.marginHeight=1;
		fListBoxLayout.makeColumnsEqualWidth = false;
	}
	
	/* copy the newly created label to the fLabels, that way we could control
	 * and manipulate all the labels within this widget, this also keep the layout
	 * data of the labels
	 */
	void newLabel(Label l){
		//scale if the amount of labels exceeds the declared limit
		if(fLabelCount == fLabels.length){
			Label [] newArray = new Label[fLabels.length * 2];
			System.arraycopy(fLabels, 0, newArray, 0, fLabels.length);
			fLabels = newArray;
		}
		if(fLabelCount == listCells.length){
			ListComposite [] newArray = new ListComposite[listCells.length * 2];
			System.arraycopy(listCells, 0, newArray, 0, listCells.length);
			listCells = newArray;
		}

			
		
		// the indentation pretty much draws the border
		ListBoxData lbd = new ListBoxData(ListBoxData.FILL_BOTH);
		lbd.verticalIndent = 1;
		lbd.horizontalIndent = 0;
		
		
		 if ((fLabelCount%fColumns == detailPosition)){
		 	lbd.horizontalIndent = 1;
		 }
		 
		 if(showNumber){
			 
		 	if(fLabelCount%fColumns == 1){
		 		lbd.horizontalIndent = 1;
		 	}
		 } else if(showHeadingIcon && (!styleDefined)){
		 
			 if ((fLabelCount%fColumns == detailPosition)){
			 	lbd.horizontalIndent = 0;
			 }
		 }
		 
		 // 2 line item has a special treatment of drawing the line
		 if(twoLine){
		 	if(fLabelCount%fColumns!= detailPosition && fLabelCount%fColumns != headingPosition){	 		
		 		lbd.verticalSpan=2;
		 	} else if (fLabelCount%fColumns == headingPosition){
		 		if(showHeadingIcon){
		 			lbd.verticalIndent = 1;
		 			lbd.horizontalIndent = 0;
		 		} else if(showNumber) {
		 			lbd.verticalIndent = 1;
		 			lbd.horizontalIndent = 1;
		 		} else {
		 			lbd.verticalIndent = 1;
		 			lbd.horizontalIndent = 0;
		 		}
		 	} else if(fLabelCount%fColumns == detailPosition){
		 		if(showHeadingIcon){
		 		
		 			lbd.verticalIndent = 0;
			 		lbd.horizontalIndent = 0;
		 		} else if(showNumber) {
		 			
		 			lbd.verticalIndent = 0;
				 	lbd.horizontalIndent = 1;
		 		} else {
		 			lbd.verticalIndent = 0;
			 		lbd.horizontalIndent = 0;
		 		}
		 			
			}else{
				
		 		lbd.verticalIndent = 0;
		 		lbd.horizontalIndent = 1;
		 	}
		 }


		 if (fLabelCount < fColumns){
		 	lbd.verticalIndent = 0;
		 }
		 
		 
		 if((widgetStyle & SWT.BORDER) != SWT.BORDER){
			 lbd.verticalIndent=0;
			 lbd.horizontalIndent=0;
		 }
			listCells[fLabelCount]= new ListComposite(innerComposite, SWT.NONE);
			listCells[fLabelCount].setLayoutData(lbd);
			
			fLabels[fLabelCount] = l;
			fLabels[fLabelCount].setParent(listCells[fLabelCount]);
			fLabels[fLabelCount].pack();
			
			fLabels[fLabelCount].setBackground(normalColor);
			listCells[fLabelCount].setBackground(normalColor);
		fLabelCount++;
		if(lbd != null){
			lbd = null;
		}
		
	}	
	
	// basically set foreground, background color to display a select effect
	void fillRow(int index, Color backgroundColor){
		int target= fColumns*index;
		for( int i = target; i < target + fColumns; i++){
			//Get rid of flicking problem while setting background and foreground to image label.
			if(fLabels[i].getImage() == null) {
				fLabels[i].setForeground(textFocusColor);
				fLabels[i].setBackground(backgroundColor);
				listCells[i].setBackground(backgroundColor);
			}
		}
	}
	// unset foreground, background color to display a deselect effect
	void unfillRow(int index){
		int target= fColumns*index;
		for( int i = target; i < target + fColumns; i++){
			fLabels[i].setForeground(null);
			fLabels[i].setBackground(normalColor);
			listCells[i].setBackground(normalColor);		
		}
	}
	
	String getheading(int i){
		if(fItems[i] != null){
			String s = fItems[i].getHeadingText();
			if(s == null){
				return "";
			}
			else
				return s;
		}
		else
			return "";
	}
	
	public boolean allowTraverseByArrowKey(Event event) {
		switch (event.keyCode) {
			case SWT.ARROW_LEFT :
			case SWT.ARROW_RIGHT :	
				return true;
		}
		return false;
	}
	
	protected boolean traverse(Event event) {
		if (isDisposed()) return false;
		if(allowTraverseByArrowKey(event)) {
			return traverseByArrowKey(event);
		}
		return super.traverse(event);
	}
	
} 	// end of ListBox

final class ListComposite extends Composite{

	public ListComposite(Composite parent, int style) {
		super(parent, style);
		// TODO Auto-generated constructor stub
	}
	
	public Point computeSize(int wHint, int hHint, boolean changed) {
		return this.getSize();
	}
	
	
	
	
	
	
}



final class CompositeLayout extends Layout {

	/* (non-Javadoc)
	 * @see org.eclipse.swt.widgets.Layout#computeSize(org.eclipse.swt.widgets.Composite, int, int, boolean)
	 */
	protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache) {
		return composite.getChildren()[0].computeSize(wHint, hHint);
		
	}

	/* (non-Javadoc)
	 * @see org.eclipse.swt.widgets.Layout#layout(org.eclipse.swt.widgets.Composite, boolean)
	 */
	protected void layout(Composite composite, boolean flushCache) {
		Composite innerComposite = (Composite)composite.getChildren()[0];
		int x,y,width,height;
		Point innerPoint = innerComposite.computeSize(SWT.DEFAULT,SWT.DEFAULT);
		Rectangle r = composite.getClientArea();
		if (innerPoint.x < r.width) {
			width = r.width;
		} else {
			width = innerPoint.x;
		}
		if (innerPoint.y < r.height) {
			height = r.height;
		} else {
			height = innerPoint.y;
		}
		x = r.x;
		y = r.y;
		innerComposite.setBounds(x,y,width,height);
	}
}

final class ListBoxLayout extends Layout {
	 
	 	/**
	 	 * numColumns specifies the number of cell columns in the layout.
	 	 *
	 	 * The default value is 1.
	 	 */
		public int numColumns = 1;

		/**
		 * makeColumnsEqualWidth specifies whether all columns in the layout
		 * will be forced to have the same width.
		 *
		 * The default value is false.
		 */
		public boolean makeColumnsEqualWidth = false;
		
		/**
		 * marginWidth specifies the number of pixels of horizontal margin
		 * that will be placed along the left and right edges of the layout.
		 *
		 * The default value is 5.
		 */
	 	public int marginWidth = 5;
	 	
		/**
		 * marginHeight specifies the number of pixels of vertical margin
		 * that will be placed along the top and bottom edges of the layout.
		 *
		 * The default value is 5.
		 */
	 	public int marginHeight = 5;

	 	/**
		 * marginLeft specifies the number of pixels of horizontal margin
		 * that will be placed along the left edge of the layout.
		 *
		 * The default value is 0.
		 * 
		 * @since 3.1
		 */
		public int marginLeft = 0;

		/**
		 * marginTop specifies the number of pixels of vertical margin
		 * that will be placed along the top edge of the layout.
		 *
		 * The default value is 0.
		 * 
		 * @since 3.1
		 */
		public int marginTop = 0;

		/**
		 * marginRight specifies the number of pixels of horizontal margin
		 * that will be placed along the right edge of the layout.
		 *
		 * The default value is 0.
		 * 
		 * @since 3.1
		 */
		public int marginRight = 0;

		/**
		 * marginBottom specifies the number of pixels of vertical margin
		 * that will be placed along the bottom edge of the layout.
		 *
		 * The default value is 0.
		 * 
		 * @since 3.1
		 */
		public int marginBottom = 0;

		/**
		 * horizontalSpacing specifies the number of pixels between the right
		 * edge of one cell and the left edge of its neighbouring cell to
		 * the right.
		 *
		 * The default value is 5.
		 */
	 	public int horizontalSpacing = 5;

		/**
		 * verticalSpacing specifies the number of pixels between the bottom
		 * edge of one cell and the top edge of its neighbouring cell underneath.
		 *
		 * The default value is 5.
		 */
	 	public int verticalSpacing = 5;
	 
	/**
	 * Constructs a new instance of this class.
	 */
	public ListBoxLayout () {}

	/**
	 * Constructs a new instance of this class given the
	 * number of columns, and whether or not the columns
	 * should be forced to have the same width.
	 *
	 * @param numColumns the number of columns in the grid
	 * @param makeColumnsEqualWidth whether or not the columns will have equal width
	 * 
	 * @since 2.0
	 */
	public ListBoxLayout (int numColumns, boolean makeColumnsEqualWidth) {
		this.numColumns = numColumns;
		this.makeColumnsEqualWidth = makeColumnsEqualWidth;
	}

	protected Point computeSize (Composite composite, int wHint, int hHint, boolean flushCache) {
		Point size = layout (composite, false, 0, 0, wHint, hHint, flushCache);
		if (wHint != SWT.DEFAULT) size.x = wHint;
		if (hHint != SWT.DEFAULT) size.y = hHint;
		return size;
	}

	protected boolean flushCache (Control control) {
		Object data = control.getLayoutData ();
		if (data != null) ((ListBoxData) data).flushCache ();
		return true;
	}

	ListBoxData getData (Control [][] grid, int row, int column, int rowCount, int columnCount, boolean first) {
		Control control = grid [row] [column];
		if (control != null) {
			ListBoxData data = (ListBoxData) control.getLayoutData ();
			int hSpan = Math.max (1, Math.min (data.horizontalSpan, columnCount));
			int vSpan = Math.max (1, data.verticalSpan);
			int i = first ? row + vSpan - 1 : row - vSpan + 1;
			int j = first ? column + hSpan - 1 : column - hSpan + 1;
			if (0 <= i && i < rowCount) {
				if (0 <= j && j < columnCount) {
					if (control == grid [i][j]) return data;
				}
			}
		}
		return null;
	}

	protected void layout (Composite composite, boolean flushCache) {
		Rectangle rect = composite.getClientArea ();
		layout (composite, true, rect.x, rect.y, rect.width, rect.height, flushCache);
		if(rect!=null){
			rect = null;
		}
	}

	Point layout (Composite composite, boolean move, int x, int y, int width, int height, boolean flushCache) {
		if (numColumns < 1) {
			return new Point (marginLeft + marginWidth * 2 + marginRight, marginTop + marginHeight * 2 + marginBottom);
		}
		int count = 0;
		Control [] children = composite.getChildren ();
		for (int i=0; i<children.length; i++) {
			Control control = children [i];
			ListBoxData data = (ListBoxData) control.getLayoutData ();
			if (data == null || !data.exclude) {
				children [count++] = children [i];
			} 
		}
		for (int i=0; i<count; i++) {
			Control child = children [i];
			ListBoxData data = (ListBoxData) child.getLayoutData ();
			if (data == null) child.setLayoutData (data = new ListBoxData ());
			if (flushCache) data.flushCache ();
			data.computeSize (child, data.widthHint, data.heightHint, flushCache);
			if (data.grabExcessHorizontalSpace && data.minimumWidth > 0) {
				if (data.cacheWidth < data.minimumWidth) {
					int trim = 0;
					//TEMPORARY CODE
					if (child instanceof Scrollable) {
						Rectangle rect = ((Scrollable) child).computeTrim (0, 0, 0, 0);
						trim = rect.width;
					} else {
						trim = child.getBorderWidth () * 2;
					}
					data.cacheWidth = data.cacheHeight = SWT.DEFAULT;
					data.computeSize (child, Math.max (0, data.minimumWidth - trim), data.heightHint, false);
				}
			}
			if (data.grabExcessVerticalSpace && data.minimumHeight > 0) {
				data.cacheHeight = Math.max (data.cacheHeight, data.minimumHeight);
			}
		}

		/* Build the grid */
		int row = 0, column = 0, rowCount = 0, columnCount = numColumns;
		Control [][] grid = new Control [4] [columnCount];
		for (int i=0; i<count; i++) {	
			Control child = children [i];
			ListBoxData data = (ListBoxData) child.getLayoutData ();
			int hSpan = Math.max (1, Math.min (data.horizontalSpan, columnCount));
			int vSpan = Math.max (1, data.verticalSpan);
			while (true) {
				int lastRow = row + vSpan;
				if (lastRow >= grid.length) {
					Control [][] newGrid = new Control [lastRow + 4] [columnCount];
					System.arraycopy (grid, 0, newGrid, 0, grid.length);
					grid = newGrid;
				}
				if (grid [row] == null) {
					grid [row] = new Control [columnCount];
				}
				while (column < columnCount && grid [row] [column] != null) {
					column++;
				}
				int endCount = column + hSpan;
				if (endCount <= columnCount) {
					int index = column;
					while (index < endCount && grid [row] [index] == null) {
						index++;
					}
					if (index == endCount) break;
					column = index;
				}
				if (column + hSpan >= columnCount) {
					column = 0;
					row++;
				}
			}
			for (int j=0; j<vSpan; j++) {
				if (grid [row + j] == null) {
					grid [row + j] = new Control [columnCount];
				}
				for (int k=0; k<hSpan; k++) {
					grid [row + j] [column + k] = child;
				}
			}
			rowCount = Math.max (rowCount, row + vSpan);
			column += hSpan;
		}

		/* Column widths */
		int availableWidth = width - horizontalSpacing * (columnCount - 1) - (marginLeft + marginWidth * 2 + marginRight);
		int expandCount = 0;
		int [] widths = new int [columnCount];
		int [] minWidths = new int [columnCount];
		boolean [] expandColumn = new boolean [columnCount];
		for (int j=0; j<columnCount; j++) {
			for (int i=0; i<rowCount; i++) {
				ListBoxData data = getData (grid, i, j, rowCount, columnCount, true);
				if (data != null) {
					int hSpan = Math.max (1, Math.min (data.horizontalSpan, columnCount));
					if (hSpan == 1) {
						int w = data.cacheWidth + data.horizontalIndent;
						widths [j] = Math.max (widths [j], w);
						if (data.grabExcessHorizontalSpace) {
							if (!expandColumn [j]) expandCount++;
							expandColumn [j] = true;
						}
						if (!data.grabExcessHorizontalSpace || data.minimumWidth != 0) {
							w = !data.grabExcessHorizontalSpace || data.minimumWidth == SWT.DEFAULT ? data.cacheWidth : data.minimumWidth;
							w += data.horizontalIndent;
							minWidths [j] = Math.max (minWidths [j], w);
						}
					}
				}
			}
			for (int i=0; i<rowCount; i++) {
				ListBoxData data = getData (grid, i, j, rowCount, columnCount, false);
				if (data != null) {
					int hSpan = Math.max (1, Math.min (data.horizontalSpan, columnCount));
					if (hSpan > 1) {
						int spanWidth = 0, spanMinWidth = 0, spanExpandCount = 0;
						for (int k=0; k<hSpan; k++) {
							spanWidth += widths [j-k];
							spanMinWidth += minWidths [j-k];
							if (expandColumn [j-k]) spanExpandCount++;
						}
						if (data.grabExcessHorizontalSpace && spanExpandCount == 0) {
							expandCount++;
							expandColumn [j] = true;
						}
						int w = data.cacheWidth + data.horizontalIndent - spanWidth - (hSpan - 1) * horizontalSpacing;
						if (w > 0) {
							if (spanExpandCount == 0) {
								widths [j] += w;
							} else {
								int delta = w / spanExpandCount;
								int remainder = w % spanExpandCount, last = -1;
								for (int k = 0; k < hSpan; k++) {
									if (expandColumn [j-k]) {
										widths [last=j-k] += delta;
									}
								}
								if (last > -1) widths [last] += remainder;
							}
						}
						if (!data.grabExcessHorizontalSpace || data.minimumWidth != 0) {
							w = !data.grabExcessHorizontalSpace || data.minimumWidth == SWT.DEFAULT ? data.cacheWidth : data.minimumWidth;
							w += data.horizontalIndent - spanMinWidth - (hSpan - 1) * horizontalSpacing;
							if (w > 0) {
								if (spanExpandCount == 0) {
									minWidths [j] += w;
								} else {
									int delta = w / spanExpandCount;
									int remainder = w % spanExpandCount, last = -1;
									for (int k = 0; k < hSpan; k++) {
										if (expandColumn [j-k]) {
											minWidths [last=j-k] += delta;
										}
									}
									if (last > -1) minWidths [last] += remainder;
								}
							}
						}
					}
				}
			}
		}
		if (makeColumnsEqualWidth) {
			int minColumnWidth = 0;
			int columnWidth = 0;
			for (int i=0; i<columnCount; i++) {
				minColumnWidth = Math.max (minColumnWidth, minWidths [i]);
				columnWidth = Math.max (columnWidth, widths [i]);
			}
			columnWidth = width == SWT.DEFAULT || expandCount == 0 ? columnWidth : Math.max (minColumnWidth, availableWidth / columnCount);
			for (int i=0; i<columnCount; i++) {
				expandColumn [i] = expandCount > 0;
				widths [i] = columnWidth;
			}
		} else {
			if (width != SWT.DEFAULT && expandCount > 0) {
				int totalWidth = 0;
				for (int i=0; i<columnCount; i++) {
					totalWidth += widths [i];
				}
				int c = expandCount;
				int delta = (availableWidth - totalWidth) / c;
				int remainder = (availableWidth - totalWidth) % c;
				int last = -1;
				while (totalWidth != availableWidth) {
					for (int j=0; j<columnCount; j++) {
						if (expandColumn [j]) {
							if (widths [j] + delta > minWidths [j]) {
								widths [last = j] = widths [j] + delta;
							} else {
								widths [j] = minWidths [j];
								expandColumn [j] = false;
								c--;
							}
						}
					}
					if (last > -1) widths [last] += remainder;
					
					for (int j=0; j<columnCount; j++) {
						for (int i=0; i<rowCount; i++) {
							ListBoxData data = getData (grid, i, j, rowCount, columnCount, false);
							if (data != null) {
								int hSpan = Math.max (1, Math.min (data.horizontalSpan, columnCount));
								if (hSpan > 1) {
									if (!data.grabExcessHorizontalSpace || data.minimumWidth != 0) {
										int spanWidth = 0, spanExpandCount = 0;
										for (int k=0; k<hSpan; k++) {
											spanWidth += widths [j-k];
											if (expandColumn [j-k]) spanExpandCount++;
										}
										int w = !data.grabExcessHorizontalSpace || data.minimumWidth == SWT.DEFAULT ? data.cacheWidth : data.minimumWidth;
										w += data.horizontalIndent - spanWidth - (hSpan - 1) * horizontalSpacing;
										if (w > 0) {
											if (spanExpandCount == 0) {
												widths [j] += w;
											} else {
												int delta2 = w / spanExpandCount;
												int remainder2 = w % spanExpandCount, last2 = -1;
												for (int k = 0; k < hSpan; k++) {
													if (expandColumn [j-k]) {
														widths [last2=j-k] += delta2;
													}
												}
												if (last2 > -1) widths [last2] += remainder2;	
											}
										}
									}
								}
							}
						}
					}
					if (c == 0) break;
					totalWidth = 0;
					for (int i=0; i<columnCount; i++) {
						totalWidth += widths [i];
					}
					delta = (availableWidth - totalWidth) / c;
					remainder = (availableWidth - totalWidth) % c;
					last = -1;
				}
			}
		}

		/* Wrapping */
		ListBoxData [] flush = null;
		int flushLength = 0;
		if (width != SWT.DEFAULT) {
			for (int j=0; j<columnCount; j++) {
				for (int i=0; i<rowCount; i++) {
					ListBoxData data = getData (grid, i, j, rowCount, columnCount, false);
					if (data != null) {
						if (data.heightHint == SWT.DEFAULT) {
							Control child = grid [i][j];
							//TEMPORARY CODE
							int hSpan = Math.max (1, Math.min (data.horizontalSpan, columnCount));
							int currentWidth = 0;
							for (int k=0; k<hSpan; k++) {
								currentWidth += widths [j-k];
							}
							currentWidth += (hSpan - 1) * horizontalSpacing - data.horizontalIndent;
							if ((currentWidth != data.cacheWidth && data.horizontalAlignment == SWT.FILL) || (data.cacheWidth > currentWidth)) {
								int trim = 0;
								if (child instanceof Scrollable) {
									Rectangle rect = ((Scrollable) child).computeTrim (0, 0, 0, 0);
									trim = rect.width;
								} else {
									trim = child.getBorderWidth () * 2;
								}
								data.cacheWidth = data.cacheHeight = SWT.DEFAULT;
								data.computeSize (child, Math.max (0, currentWidth - trim), data.heightHint, false);
								if (data.grabExcessVerticalSpace && data.minimumHeight > 0) {
									data.cacheHeight = Math.max (data.cacheHeight, data.minimumHeight);
								}
								if (flush == null) flush = new ListBoxData [count];
								flush [flushLength++] = data;
							}
						}
					}
				}
			}
		}

		/* Row heights */
		int availableHeight = height - verticalSpacing * (rowCount - 1) - (marginTop + marginHeight * 2 + marginBottom);
		expandCount = 0;
		int [] heights = new int [rowCount];
		int [] minHeights = new int [rowCount];
		boolean [] expandRow = new boolean [rowCount];
		for (int i=0; i<rowCount; i++) {
			for (int j=0; j<columnCount; j++) {
				ListBoxData data = getData (grid, i, j, rowCount, columnCount, true);
				if (data != null) {
					int vSpan = Math.max (1, Math.min (data.verticalSpan, rowCount));
					if (vSpan == 1) {
						int h = data.cacheHeight + data.verticalIndent;
						heights [i] = Math.max (heights [i], h);
						if (data.grabExcessVerticalSpace) {
							if (!expandRow [i]) expandCount++;
							expandRow [i] = true;
						}
						if (!data.grabExcessVerticalSpace || data.minimumHeight != 0) {
							h = !data.grabExcessVerticalSpace || data.minimumHeight == SWT.DEFAULT ? data.cacheHeight : data.minimumHeight;
							h += data.verticalIndent;
							minHeights [i] = Math.max (minHeights [i], h);
						}
					}
				}
			}
			for (int j=0; j<columnCount; j++) {
				ListBoxData data = getData (grid, i, j, rowCount, columnCount, false);
				if (data != null) {
					int vSpan = Math.max (1, Math.min (data.verticalSpan, rowCount));
					if (vSpan > 1) {
						int spanHeight = 0, spanMinHeight = 0, spanExpandCount = 0;
						for (int k=0; k<vSpan; k++) {
							spanHeight += heights [i-k];
							spanMinHeight += minHeights [i-k];
							if (expandRow [i-k]) spanExpandCount++;
						}
						if (data.grabExcessVerticalSpace && spanExpandCount == 0) {
							expandCount++;
							expandRow [i] = true;
						}
						int h = data.cacheHeight + data.verticalIndent - spanHeight - (vSpan - 1) * verticalSpacing;
						if (h > 0) {
							if (spanExpandCount == 0) {
								heights [i] += h;
							} else {
								int delta = h / spanExpandCount;
								int remainder = h % spanExpandCount, last = -1;
								for (int k = 0; k < vSpan; k++) {
									if (expandRow [i-k]) {
										heights [last=i-k] += delta;
									}
								}
								if (last > -1) heights [last] += remainder;	
							}
						}
						if (!data.grabExcessVerticalSpace || data.minimumHeight != 0) {
							h = !data.grabExcessVerticalSpace || data.minimumHeight == SWT.DEFAULT ? data.cacheHeight : data.minimumHeight;
							h += data.verticalIndent - spanMinHeight - (vSpan - 1) * verticalSpacing;
							if (h > 0) {
								if (spanExpandCount == 0) {
									minHeights [i] += h;
								} else {
									int delta = h / spanExpandCount;
									int remainder = h % spanExpandCount, last = -1;
									for (int k = 0; k < vSpan; k++) {
										if (expandRow [i-k]) {
											minHeights [last=i-k] += delta;
										}
									}
									if (last > -1) minHeights [last] += remainder;	
								}
							}
						}
					}
				}
			}
		}
		if (height != SWT.DEFAULT && expandCount > 0) {
			int totalHeight = 0;
			for (int i=0; i<rowCount; i++) {
				totalHeight += heights [i];
			}
			int c = expandCount;
			int delta = (availableHeight - totalHeight) / c;
			int remainder = (availableHeight - totalHeight) % c;
			int last = -1;
			while (totalHeight != availableHeight) {
				for (int i=0; i<rowCount; i++) {
					if (expandRow [i]) {
						if (heights [i] + delta > minHeights [i]) {
							heights [last = i] = heights [i] + delta;
						} else {
							heights [i] = minHeights [i];
							expandRow [i] = false;
							c--;
						}
					}
				}
				if (last > -1) heights [last] += remainder;
				
				for (int i=0; i<rowCount; i++) {
					for (int j=0; j<columnCount; j++) {
						ListBoxData data = getData (grid, i, j, rowCount, columnCount, false);
						if (data != null) {
							int vSpan = Math.max (1, Math.min (data.verticalSpan, rowCount));
							if (vSpan > 1) {
								if (!data.grabExcessVerticalSpace || data.minimumHeight != 0) {
									int spanHeight = 0, spanExpandCount = 0;
									for (int k=0; k<vSpan; k++) {
										spanHeight += heights [i-k];
										if (expandRow [i-k]) spanExpandCount++;
									}
									int h = !data.grabExcessVerticalSpace || data.minimumHeight == SWT.DEFAULT ? data.cacheHeight : data.minimumHeight;
									h += data.verticalIndent - spanHeight - (vSpan - 1) * verticalSpacing;
									if (h > 0) {
										if (spanExpandCount == 0) {
											heights [i] += h;
										} else {
											int delta2 = h / spanExpandCount;
											int remainder2 = h % spanExpandCount, last2 = -1;
											for (int k = 0; k < vSpan; k++) {
												if (expandRow [i-k]) {
													heights [last2=i-k] += delta2;
												}
											}
											if (last2 > -1) heights [last2] += remainder2;
										}
									}
								}
							}
						}
					}
				}
				if (c == 0) break;
				totalHeight = 0;
				for (int i=0; i<rowCount; i++) {
					totalHeight += heights [i];
				}
				delta = (availableHeight - totalHeight) / c;
				remainder = (availableHeight - totalHeight) % c;
				last = -1;
			}
		}

		/* Position the controls */
		if (move) {
			int gridY = y + marginTop + marginHeight;
			for (int i=0; i<rowCount; i++) {
				int gridX = x + marginLeft + marginWidth;
				for (int j=0; j<columnCount; j++) {
					ListBoxData data = getData (grid, i, j, rowCount, columnCount, true);
					if (data != null) {
						int hSpan = Math.max (1, Math.min (data.horizontalSpan, columnCount));
						int vSpan = Math.max (1, data.verticalSpan);
						int cellWidth = 0, cellHeight = 0;
						for (int k=0; k<hSpan; k++) {
							cellWidth += widths [j+k];
						}
						for (int k=0; k<vSpan; k++) {
							cellHeight += heights [i+k];
						}
						cellWidth += horizontalSpacing * (hSpan - 1);
						int childX = gridX + data.horizontalIndent;
						int childWidth = Math.min (data.cacheWidth, cellWidth);
						switch (data.horizontalAlignment) {
							case SWT.CENTER:
							case ListBoxData.CENTER:
								childX = gridX + Math.max (0, (cellWidth - childWidth) / 2);
								break;
							case SWT.RIGHT:
							case SWT.END:
							case ListBoxData.END:
								childX = gridX + Math.max (0, cellWidth - childWidth);
								break;
							case SWT.FILL:
								childWidth = cellWidth - data.horizontalIndent;
								break;
						}
						cellHeight += verticalSpacing * (vSpan - 1);
						int childY = gridY + data.verticalIndent;
						int childHeight = Math.min (data.cacheHeight, cellHeight);
						switch (data.verticalAlignment) {
							case SWT.CENTER:
							case ListBoxData.CENTER:
								childY = gridY + Math.max (0, (cellHeight - childHeight) / 2);
								break;
							case SWT.BOTTOM:
							case SWT.END:
							case ListBoxData.END:
								childY = gridY + Math.max (0, cellHeight - childHeight);
								break;
							case SWT.FILL:
								childHeight = cellHeight - data.verticalIndent;
								break;
						}
						Control child = grid [i][j];
						if (child != null) {
							child.setBounds (childX, childY, childWidth, childHeight);
						}
					}
					gridX += widths [j] + horizontalSpacing;
				}
				gridY += heights [i] + verticalSpacing;
			}
		}

		// clean up cache
		for (int i = 0; i < flushLength; i++) {
			flush [i].cacheWidth = flush [i].cacheHeight = -1;
		}

		int totalDefaultWidth = 0;
		int totalDefaultHeight = 0;
		for (int i=0; i<columnCount; i++) {
			totalDefaultWidth += widths [i];
		}
		for (int i=0; i<rowCount; i++) {
			totalDefaultHeight += heights [i];
		}
		totalDefaultWidth += horizontalSpacing * (columnCount - 1) + marginLeft + marginWidth * 2 + marginRight;
		totalDefaultHeight += verticalSpacing * (rowCount - 1) + marginTop + marginHeight * 2 + marginBottom;
		return new Point (totalDefaultWidth, totalDefaultHeight);
	}

	String getName () {
		String string = getClass ().getName ();
		int index = string.lastIndexOf ('.');
		if (index == -1) return string;
		return string.substring (index + 1, string.length ());
	}

	public String toString () {
	 	String string = getName ()+" {";
	 	if (numColumns != 1) string += "numColumns="+numColumns+" ";
	 	if (makeColumnsEqualWidth) string += "makeColumnsEqualWidth="+makeColumnsEqualWidth+" ";
	 	if (marginWidth != 0) string += "marginWidth="+marginWidth+" ";
	 	if (marginHeight != 0) string += "marginHeight="+marginHeight+" ";
	 	if (marginLeft != 0) string += "marginLeft="+marginLeft+" ";
	 	if (marginRight != 0) string += "marginRight="+marginRight+" ";
	 	if (marginTop != 0) string += "marginTop="+marginTop+" ";
	 	if (marginBottom != 0) string += "marginBottom="+marginBottom+" ";
	 	if (horizontalSpacing != 0) string += "horizontalSpacing="+horizontalSpacing+" ";
	 	if (verticalSpacing != 0) string += "verticalSpacing="+verticalSpacing+" ";
	 	string = string.trim();
	 	string += "}";
	 	return string;
	}
}



final class ListBoxData {
	/**
	 * verticalAlignment specifies how controls will be positioned 
	 * vertically within a cell. 
	 *
	 * The default value is CENTER.
	 *
	 * Possible values are:
	 *
	 * SWT.BEGINNING (or SWT.TOP): Position the control at the top of the cell
	 * SWT.CENTER: Position the control in the vertical center of the cell
	 * SWT.END (or SWT.BOTTOM): Position the control at the bottom of the cell
	 * SWT.FILL: Resize the control to fill the cell vertically
	 */
	public int verticalAlignment = CENTER;
	
	/**
	 * horizontalAlignment specifies how controls will be positioned 
	 * horizontally within a cell. 
	 *
	 * The default value is BEGINNING.
	 *
	 * Possible values are:
	 *
	 * SWT.BEGINNING (or SWT.LEFT): Position the control at the left of the cell
	 * SWT.CENTER: Position the control in the horizontal center of the cell
	 * SWT.END (or SWT.RIGHT): Position the control at the right of the cell
	 * SWT.FILL: Resize the control to fill the cell horizontally
	 */
	public int horizontalAlignment = BEGINNING;
	
	/**
	 * widthHint specifies the preferred width in pixels. This value
	 * is the wHint passed into Control#computeSize(int, int, boolean) 
	 * to determine the preferred size of the control.
	 *
	 * The default value is SWT.DEFAULT.
	 */
	public int widthHint = SWT.DEFAULT;
	
	/**
	 * heightHint specifies the preferred height in pixels. This value
	 * is the hHint passed into Control#computeSize(int, int, boolean) 
	 * to determine the preferred size of the control.
	 *
	 * The default value is SWT.DEFAULT.
	 */
	public int heightHint = SWT.DEFAULT;
	
	/**
	 * horizontalIndent specifies the number of pixels of indentation
	 * that will be placed along the left side of the cell.
	 *
	 * The default value is 0.
	 */
	public int horizontalIndent = 0;
	
	/**
	 * verticalIndent specifies the number of pixels of indentation
	 * that will be placed along the top side of the cell.
	 *
	 * The default value is 0.
	 * 
	 * @since 3.1
	 */
	public int verticalIndent = 0;
	
	/**
	 * horizontalSpan specifies the number of column cells that the control
	 * will take up.
	 *
	 * The default value is 1.
	 */
	public int horizontalSpan = 1;
	
	/**
	 * verticalSpan specifies the number of row cells that the control
	 * will take up.
	 *
	 * The default value is 1.
	 */
	public int verticalSpan = 1;
	
	/**
	 * <p>grabExcessHorizontalSpace specifies whether the width of the cell 
	 * changes depending on the size of the parent Composite.  If 
	 * grabExcessHorizontalSpace is <code>true</code>, the following rules
	 * apply to the width of the cell:</p>
	 * <ul>
	 * <li>If extra horizontal space is available in the parent, the cell will 
	 * grow to be wider than its preferred width.  The new width 
	 * will be "preferred width + delta" where delta is the extra 
	 * horizontal space divided by the number of grabbing columns.</li>
	 * <li>If there is not enough horizontal space available in the parent, the 
	 * cell will shrink until it reaches its minimum width as specified by 
	 * ListBoxData#minimumWidth. The new width will be the maximum of 
	 * "minimumWidth" and "preferred width - delta", where delta is 
	 * the amount of space missing divided by the number of grabbing columns.</li>
	 * <li>If the parent is packed, the cell will be its preferred width 
	 * as specified by ListBoxData#widthHint.</li>
	 * <li>If the control spans multiple columns and there are no other grabbing 
	 * controls in any of the spanned columns, the last column in the span will
	 * grab the extra space.  If there is at least one other grabbing control
	 * in the span, the grabbing will be spread over the columns already 
	 * marked as grabExcessHorizontalSpace.</li>
	 * </ul>
	 * 
	 * <p>The default value is false.</p>
	 */	
	public boolean grabExcessHorizontalSpace = false;
	
	/**
	 * <p>grabExcessVerticalSpace specifies whether the height of the cell 
	 * changes depending on the size of the parent Composite.  If 
	 * grabExcessVerticalSpace is <code>true</code>, the following rules
	 * apply to the height of the cell:</p>
	 * <ul>
	 * <li>If extra vertical space is available in the parent, the cell will 
	 * grow to be taller than its preferred height.  The new height 
	 * will be "preferred height + delta" where delta is the extra 
	 * vertical space divided by the number of grabbing rows.</li>
	 * <li>If there is not enough vertical space available in the parent, the 
	 * cell will shrink until it reaches its minimum height as specified by 
	 * ListBoxData#minimumHeight. The new height will be the maximum of 
	 * "minimumHeight" and "preferred height - delta", where delta is 
	 * the amount of space missing divided by the number of grabbing rows.</li>
	 * <li>If the parent is packed, the cell will be its preferred height 
	 * as specified by ListBoxData#heightHint.</li>
	 * <li>If the control spans multiple rows and there are no other grabbing 
	 * controls in any of the spanned rows, the last row in the span will
	 * grab the extra space.  If there is at least one other grabbing control
	 * in the span, the grabbing will be spread over the rows already 
	 * marked as grabExcessVerticalSpace.</li>
	 * </ul>
	 * 
	 * <p>The default value is false.</p>
	 */	
	public boolean grabExcessVerticalSpace = false;

	/**
	 * minimumWidth specifies the minimum width in pixels.  This value
	 * applies only if grabExcessHorizontalSpace is true. A value of 
	 * SWT#DEFAULT means that the minimum width will be the result
	 * of Control#computeSize(int, int, boolean) where wHint is 
	 * determined by ListBoxData#widthHint.
	 *
	 * The default value is 0.
	 *
	 * @since 3.1
	 */
	public int minimumWidth = 0;
	
	/**
	 * minimumHeight specifies the minimum height in pixels.  This value
	 * applies only if grabExcessVerticalSpace is true.  A value of 
	 * SWT#DEFAULT means that the minimum height will be the result
	 * of Control#computeSize(int, int, boolean) where hHint is 
	 * determined by ListBoxData#heightHint.
	 *
	 * The default value is 0.
	 *
	 * @since 3.1
	 */
	public int minimumHeight = 0;
	
	/**
	 * exclude informs the layout to ignore this control when sizing
	 * and positioning controls.  If this value is <code>true</code>,
	 * the size and position of the control will not be managed by the
	 * layout.  If this	value is <code>false</code>, the size and 
	 * position of the control will be computed and assigned.
	 * 
	 * The default value is <code>false</code>.
	 * 
	 * @since 3.1
	 */
	public boolean exclude = false;
	
	/**
	 * Value for horizontalAlignment or verticalAlignment.
	 * Position the control at the top or left of the cell.
	 * Not recommended. Use SWT.BEGINNING, SWT.TOP or SWT.LEFT instead.
	 */
	public static final int BEGINNING = SWT.BEGINNING;
	
	/**
	 * Value for horizontalAlignment or verticalAlignment.
	 * Position the control in the vertical or horizontal center of the cell
	 * Not recommended. Use SWT.CENTER instead.
	 */
	public static final int CENTER = 2;
	
	/**
	 * Value for horizontalAlignment or verticalAlignment.
	 * Position the control at the bottom or right of the cell
	 * Not recommended. Use SWT.END, SWT.BOTTOM or SWT.RIGHT instead.
	 */
	public static final int END = 3;
	
	/**
	 * Value for horizontalAlignment or verticalAlignment.
	 * Resize the control to fill the cell horizontally or vertically.
	 * Not recommended. Use SWT.FILL instead.
	 */
	public static final int FILL = SWT.FILL;

	/**
	 * Style bit for <code>new ListBoxData(int)</code>.
	 * Position the control at the top of the cell.
	 * Not recommended. Use 
	 * <code>new ListBoxData(int, SWT.BEGINNING, boolean, boolean)</code>
	 * instead.
	 */
	public static final int VERTICAL_ALIGN_BEGINNING =  1 << 1;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to position the 
	 * control in the vertical center of the cell.
	 * Not recommended. Use
	 * <code>new ListBoxData(int, SWT.CENTER, boolean, boolean)</code>
	 * instead.
	 */
	public static final int VERTICAL_ALIGN_CENTER = 1 << 2;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to position the 
	 * control at the bottom of the cell.
	 * Not recommended. Use
	 * <code>new ListBoxData(int, SWT.END, boolean, boolean)</code>
	 * instead.
	 */
	public static final int VERTICAL_ALIGN_END = 1 << 3;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to resize the 
	 * control to fill the cell vertically.
	 * Not recommended. Use
	 * <code>new ListBoxData(int, SWT.FILL, boolean, boolean)</code>
	 * instead
	 */
	public static final int VERTICAL_ALIGN_FILL = 1 << 4;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to position the 
	 * control at the left of the cell.
	 * Not recommended. Use
	 * <code>new ListBoxData(SWT.BEGINNING, int, boolean, boolean)</code>
	 * instead.
	 */
	public static final int HORIZONTAL_ALIGN_BEGINNING =  1 << 5;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to position the 
	 * control in the horizontal center of the cell.
	 * Not recommended. Use
	 * <code>new ListBoxData(SWT.CENTER, int, boolean, boolean)</code>
	 * instead.
	 */
	public static final int HORIZONTAL_ALIGN_CENTER = 1 << 6;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to position the 
	 * control at the right of the cell.
	 * Not recommended. Use
	 * <code>new ListBoxData(SWT.END, int, boolean, boolean)</code>
	 * instead.
	 */
	public static final int HORIZONTAL_ALIGN_END = 1 << 7;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to resize the 
	 * control to fill the cell horizontally.
	 * Not recommended. Use
	 * <code>new ListBoxData(SWT.FILL, int, boolean, boolean)</code>
	 * instead.
	 */
	public static final int HORIZONTAL_ALIGN_FILL = 1 << 8;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to resize the 
	 * control to fit the remaining horizontal space.
	 * Not recommended. Use
	 * <code>new ListBoxData(int, int, true, boolean)</code>
	 * instead.
	 */
	public static final int GRAB_HORIZONTAL = 1 << 9;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to resize the 
	 * control to fit the remaining vertical space.
	 * Not recommended. Use
	 * <code>new ListBoxData(int, int, boolean, true)</code>
	 * instead.
	 */
	public static final int GRAB_VERTICAL = 1 << 10;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to resize the 
	 * control to fill the cell vertically and to fit the remaining
	 * vertical space.
	 * FILL_VERTICAL = VERTICAL_ALIGN_FILL | GRAB_VERTICAL
	 * Not recommended. Use
	 * <code>new ListBoxData(int, SWT.FILL, boolean, true)</code>
	 * instead.
	 */	
	public static final int FILL_VERTICAL = VERTICAL_ALIGN_FILL | GRAB_VERTICAL;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to resize the 
	 * control to fill the cell horizontally and to fit the remaining
	 * horizontal space.
	 * FILL_HORIZONTAL = HORIZONTAL_ALIGN_FILL | GRAB_HORIZONTAL
	 * Not recommended. Use
	 * <code>new ListBoxData(SWT.FILL, int, true, boolean)</code>
	 * instead.
	 */	
	public static final int FILL_HORIZONTAL = HORIZONTAL_ALIGN_FILL | GRAB_HORIZONTAL;
	
	/**
	 * Style bit for <code>new ListBoxData(int)</code> to resize the 
	 * control to fill the cell horizontally and vertically and 
	 * to fit the remaining horizontal and vertical space.
	 * FILL_BOTH = FILL_VERTICAL | FILL_HORIZONTAL
	 * Not recommended. Use
	 * <code>new ListBoxData(SWT.FILL, SWT.FILL, true, true)</code>
	 * instead.
	 */	
	public static final int FILL_BOTH = FILL_VERTICAL | FILL_HORIZONTAL;

	int cacheWidth = -1, cacheHeight = -1;
	int defaultWhint, defaultHhint, defaultWidth = -1, defaultHeight = -1;
	int currentWhint, currentHhint, currentWidth = -1, currentHeight = -1;

/**
 * Constructs a new instance of ListBoxData using
 * default values.
 */
public ListBoxData () {
	super ();
}

/**
 * Constructs a new instance based on the ListBoxData style.
 * This constructor is not recommended.
 * 
 * @param style the ListBoxData style
 */
public ListBoxData (int style) {
	super ();
	if ((style & VERTICAL_ALIGN_BEGINNING) != 0) verticalAlignment = BEGINNING;
	if ((style & VERTICAL_ALIGN_CENTER) != 0) verticalAlignment = CENTER;
	if ((style & VERTICAL_ALIGN_FILL) != 0) verticalAlignment = FILL;
	if ((style & VERTICAL_ALIGN_END) != 0) verticalAlignment = END;
	if ((style & HORIZONTAL_ALIGN_BEGINNING) != 0) horizontalAlignment = BEGINNING;
	if ((style & HORIZONTAL_ALIGN_CENTER) != 0) horizontalAlignment = CENTER;
	if ((style & HORIZONTAL_ALIGN_FILL) != 0) horizontalAlignment = FILL;
	if ((style & HORIZONTAL_ALIGN_END) != 0) horizontalAlignment = END;
	grabExcessHorizontalSpace = (style & GRAB_HORIZONTAL) != 0;
	grabExcessVerticalSpace = (style & GRAB_VERTICAL) != 0;
}

/**
 * Constructs a new instance of ListBoxData according to the parameters.
 * 
 * @param horizontalAlignment how control will be positioned horizontally within a cell
 * @param verticalAlignment how control will be positioned vertically within a cell
 * @param grabExcessHorizontalSpace whether cell will be made wide enough to fit the remaining horizontal space
 * @param grabExcessVerticalSpace whether cell will be made high enough to fit the remaining vertical space
 * 
 * @since 3.0
 */
public ListBoxData (int horizontalAlignment, int verticalAlignment, boolean grabExcessHorizontalSpace, boolean grabExcessVerticalSpace) {
	this (horizontalAlignment, verticalAlignment, grabExcessHorizontalSpace, grabExcessVerticalSpace, 1, 1);
}

/**
 * Constructs a new instance of ListBoxData according to the parameters.
 *  
 * @param horizontalAlignment how control will be positioned horizontally within a cell
 * @param verticalAlignment how control will be positioned vertically within a cell
 * @param grabExcessHorizontalSpace whether cell will be made wide enough to fit the remaining horizontal space
 * @param grabExcessVerticalSpace whether cell will be made high enough to fit the remaining vertical space
 * @param horizontalSpan the number of column cells that the control will take up
 * @param verticalSpan the number of row cells that the control will take up
 * 
 * @since 3.0
 */
public ListBoxData (int horizontalAlignment, int verticalAlignment, boolean grabExcessHorizontalSpace, boolean grabExcessVerticalSpace, int horizontalSpan, int verticalSpan) {
	super ();
	this.horizontalAlignment = horizontalAlignment;
	this.verticalAlignment = verticalAlignment;
	this.grabExcessHorizontalSpace = grabExcessHorizontalSpace;
	this.grabExcessVerticalSpace = grabExcessVerticalSpace;
	this.horizontalSpan = horizontalSpan;
	this.verticalSpan = verticalSpan;
}

/**
 * Constructs a new instance of ListBoxData according to the parameters.
 * A value of SWT.DEFAULT indicates that no minimum width or
 * no minumum height is specified.
 * 
 * @param width a minimum width for the column
 * @param height a minimum height for the row
 * 
 * @since 3.0
 */
public ListBoxData (int width, int height) {
	super ();
	this.widthHint = width;
	this.heightHint = height;
}

void computeSize (Control control, int wHint, int hHint, boolean flushCache) {
	if (cacheWidth != -1 && cacheHeight != -1) return;
	if (wHint == this.widthHint && hHint == this.heightHint) {
		if (defaultWidth == -1 || defaultHeight == -1 || wHint != defaultWhint || hHint != defaultHhint) {
			Point size = control.computeSize (wHint, hHint, flushCache);
			defaultWhint = wHint;
			defaultHhint = hHint;
			defaultWidth = size.x;
			defaultHeight = size.y;
		}
		cacheWidth = defaultWidth;
		cacheHeight = defaultHeight;
		return;
	}
	if (currentWidth == -1 || currentHeight == -1 || wHint != currentWhint || hHint != currentHhint) {
		Point size = control.computeSize (wHint, hHint, flushCache);
		currentWhint = wHint;
		currentHhint = hHint;
		currentWidth = size.x;
		currentHeight = size.y;
	}
	cacheWidth = currentWidth;
	cacheHeight = currentHeight;
}

void flushCache () {
	cacheWidth = cacheHeight = -1;
	defaultWidth = defaultHeight = -1;
	currentWidth = currentHeight = -1;
}

String getName () {
	String string = getClass ().getName ();
	int index = string.lastIndexOf ('.');
	if (index == -1) return string;
	return string.substring (index + 1, string.length ());
}

public String toString () {
	String hAlign = "";
	switch (horizontalAlignment) {
		case SWT.FILL: hAlign = "SWT.FILL"; break;
		case SWT.BEGINNING: hAlign = "SWT.BEGINNING"; break;
		case SWT.LEFT: hAlign = "SWT.LEFT"; break;
		case SWT.END: hAlign = "SWT.END"; break;
		case END: hAlign = "ListBoxData.END"; break;
		case SWT.RIGHT: hAlign = "SWT.RIGHT"; break;
		case SWT.CENTER: hAlign = "SWT.CENTER"; break;
		case CENTER: hAlign = "ListBoxData.CENTER"; break;
		default: hAlign = "Undefined "+horizontalAlignment; break;
	}
	String vAlign = "";
	switch (verticalAlignment) {
		case SWT.FILL: vAlign = "SWT.FILL"; break;
		case SWT.BEGINNING: vAlign = "SWT.BEGINNING"; break;
		case SWT.TOP: vAlign = "SWT.TOP"; break;
		case SWT.END: vAlign = "SWT.END"; break;
		case END: vAlign = "ListBoxData.END"; break;
		case SWT.BOTTOM: vAlign = "SWT.BOTTOM"; break;
		case SWT.CENTER: vAlign = "SWT.CENTER"; break;
		case CENTER: vAlign = "ListBoxData.CENTER"; break;
		default: vAlign = "Undefined "+verticalAlignment; break;
	}
 	String string = getName()+" {";
 	string += "horizontalAlignment="+hAlign+" ";
 	if (horizontalIndent != 0) string += "horizontalIndent="+horizontalIndent+" ";
 	if (horizontalSpan != 1) string += "horizontalSpan="+horizontalSpan+" ";
 	if (grabExcessHorizontalSpace) string += "grabExcessHorizontalSpace="+grabExcessHorizontalSpace+" ";
 	if (widthHint != SWT.DEFAULT) string += "widthHint="+widthHint+" ";
 	if (minimumWidth != 0) string += "minimumWidth="+minimumWidth+" ";
 	string += "verticalAlignment="+vAlign+" ";
 	if (verticalIndent != 0) string += "verticalIndent="+verticalIndent+" ";
	if (verticalSpan != 1) string += "verticalSpan="+verticalSpan+" ";
 	if (grabExcessVerticalSpace) string += "grabExcessVerticalSpace="+grabExcessVerticalSpace+" ";
 	if (heightHint != SWT.DEFAULT) string += "heightHint="+heightHint+" ";
 	if (minimumHeight != 0) string += "minimumHeight="+minimumHeight+" ";
 	if (exclude) string += "exclude="+exclude+" ";
 	string = string.trim();
 	string += "}";
	return string;
}
}
