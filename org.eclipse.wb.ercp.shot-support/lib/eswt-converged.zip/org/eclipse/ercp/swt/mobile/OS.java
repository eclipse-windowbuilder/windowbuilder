/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class OS {
	static {
		System.loadLibrary("mobile");
	}

	public OS(){
		}
	//callback function id
	public static final int CALLBACK_DATEEDITOR = 30;
	public static final int CALLBACK_CONSTRAINEDTEXT = 31;
	public static final int CALLBACK_MULTIPAGECOMPOSITE = 32;
	public static final int CALLBACK_LISTVIEW = 33;
	public static final int CALLBACK_SCREEN = 34;
	
//	public static final int CALLBACK_DATEEDITOR = 292000;
//	public static final int CALLBACK_CONSTRAINEDTEXT = 292001;
//	public static final int CALLBACK_MULTIPAGECOMPOSITE = 292002;
//	public static final int CALLBACK_LISTVIEW = 292003;
//	public static final int CALLBACK_SCREEN = 292004;
	
	
	public static final int NULL = -1;
	
	/** Single selection and single line style */
	public static final int STYLE_SINGLE = 1 << 22;

	boolean isValidSubclass() {
		return isValidClass(getClass());
	}
	
	boolean isValidClass(Class clazz) {
		String name = clazz.getName();
		int index = name.lastIndexOf('.');
		
		// allow mobile extensions
		if (name.substring(0, index + 1).equals("org.eclipse.ercp.swt.mobile.")) return true;

		return false;	
	}
	

	// MultiPageComposite function	
	public static final native int MultiPageComposite_New(int parentHandle, int style);
	public static final native boolean MultiPageComposite_AddPage(int handle, String title, int imageHandle);
	public static final native boolean MultiPageComposite_SetPageComposite(int handle, int index, int compositeHandle);
	public static final native boolean MultiPageComposite_DeletePage(int handle, int index);
	public static final native boolean MultiPageComposite_SetTitle(int handle, int index, String title);
	public static final native boolean MultiPageComposite_SetImage(int handle, int index, int imageHandle);
	public static final native boolean MultiPageComposite_SetSelection(int handle, int index, int compositeHandle);
	public static final native int[] MultiPageComposite_GetWorkArea();

	//DateEditor function
	public static final native int DateEditor_New(int parentHandle, int style, int flag);
	public static final native int SendMessageW(int handle, int msg, int arg1, String arg2);
	public static final native int SendMessageW(int handle, int msg, int arg1, short[] arg2);
	public static final native int DateTime_GetSystemTime(int handle, int[] retValue);
	public static final native String DateTime_GetTimeFormat(int handle);
	public static final native String DateTime_GetDateFormat(int handle);
	public static final native String DateTime_GetTimeSeparator(int handle);
	public static final native String DateTime_GetDateSeparator(int handle);
	public static final native int [] DateEditor_ComputeSize(int handle, int flag);
	
	
	
	//ListView function
	public static final native int ListView_New(int parentHandle, int style, int density);
	public static final native boolean ListView_Add(int handle, String string, int imageHandle, int index);
	public static final native boolean ListView_IsSelected(int handle, int index);
	public static final native void ListView_Select(int handle, int index, boolean selected);
	public static final native boolean ListView_Delete(int handle, int index);
	public static final native boolean ListView_DeleteAll(int handle);
	public static final native int ListView_GetTopItemIndex(int handle);
	public static final native int ListView_GetFocusIndex(int handle);
	public static final native int[] ListView_GetSelectionIndices(int handle);
	public static final native int ListView_GetSelectionCount(int handle);
	public static final native boolean ListView_Set(int handle, String string, int imageHandle, int index);
	public static final native void ListView_SetLayoutDensity(int handle, int style, int density);
	public static final native void ListView_MakeSelectionVisible(int handle);
	public static final native int ListView_GetIconSize(int handle, int density);
	public static final native int[] ListView_GetDimension(int handle);
	//HyperLink function
    public static final native void HyperLink_Launch(int handle, int type, String argument);
    public static final native void HyperLink_SetText(int handle, String string);
    public static final native void HyperLink_SetUnderLine(int handle);
    public static final native void HyperLink_SetItalic(int handle, boolean isItalic);
	//ConstrainedText function
	public static final native int ConstrainedText_New(int parent, int style);
	public static final native int[] ConstrainedText_GetMinimumSize(int handle, int columns);
    public static final native void ConstrainedText_Replace(int handle, String string, int start, int end);
    public static final native void ConstrainedText_SetSelection(int handle, int start, int end);
    //MobileShell function
    public static final native void MobileShell_SetFullScreenMode(int handle, int menu_handle, boolean mode, boolean hasMenu, boolean showSIP);
    public static final native void MobileShell_ChangeTrim(int handle, int style);
    public static final native void MobileShell_SetTaskBar(boolean visible);    
    //MobileDevice function
    public static final native void MobileDevice_Alert(int level);
    public static final native int MobileDevice_isIMEActive();
    public static final native void MobileDevice_SetVKStatus(boolean show, int handle);
    //Screen function
    public static final native int Screen_GetColorDepth();
    public static final native int[] Screen_GetRes();
    public static final native void Screen_SetOrientation(int orientation);
    public static final native int Screen_GetOrientation();
    //RotDetectDisplay
    public static final native int RotDetectDisplay_New(int defDisplayhandle);
    //Input
    public static final native int getKeyboardStatus();
    
	public static final int DTM_FIRST = 0x1000;
	public static final int DTM_SETSYSTEMTIME = DTM_FIRST + 2;
	public static final int DTM_GETMONTHCAL = DTM_FIRST + 8;
	public static final int DTM_SETFORMATW = DTM_FIRST + 50;
	public static final int DTS_TIMEFORMAT = 0x0009;
	public static final int DTS_SHORTDATEFORMAT = 0x0000;
	public static final int DTS_UPDOWN  = 0x0001;
	public static final int WS_BORDER = 0x800000;
	public static final int WS_CHILD = 0x40000000;
	public static final int WS_VISIBLE = 0x10000000;
	
	public static final int LVS_ICON = 0x0000;
	public static final int LVS_REPORT = 0x0001;
	public static final int LVS_SMALLICON = 0x0002;
	public static final int LVS_LIST = 0x0003;
	
	/** DateEditor event which indicates that a new item has been selected. */
	public static final int EVENT_DATEEDITOR_SELECTION = 1;
	/** DateEditor event which indicates that a new item has been modified. */
	public static final int EVENT_DATEEDITOR_MODIFY = 2;

	public static final int EVENT_CONSTRAINEDTEXT_MODIFY = 3;
	public static final int EVENT_CONSTRAINEDTEXT_FOCUSIN = 4;
	public static final int EVENT_CONSTRAINEDTEXT_FOCUSOUT = 5;
	
	public static final int EVENT_MULTIPAGEDIALOG_SELECTION = 1;
	public static final int EVENT_MULTIPAGEDIALOG_GETPAGEHANDLE = 2;
}
