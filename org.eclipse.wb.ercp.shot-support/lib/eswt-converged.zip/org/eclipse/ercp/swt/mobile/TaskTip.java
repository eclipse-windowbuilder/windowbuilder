/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ercp.swt.mobile;
import org.eclipse.swt.events.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;

// TaskTip test usage
/*
import java.util.Vector;

import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
*/
/**
 * 
 * This class provides feedback to the user about the state of a long-running
 * task.
 * 
 * <p>
 * A TaskTip may contain text and an optional progress bar or another object to
 * illustrate current task state. Like a MessageBox, the look and feel of
 * TaskTip is platform-dependent, which means that there is no API level access
 * to the UI components inside a TaskTip. Unlike a MessageBox, the TaskTip is a
 * non-focusable window and will not change the current window's activation or
 * focus.
 * </p>
 * <p>
 * When constructed without a style constant, a TaskTip displays plain text to 
 * indicate task progress.
 * </p>
 * <p>
 * A TaskTip becomes visible by calling <code>setVisible(true)</code> and
 * remains visible until the application calls
 * <code>setVisible(false)</code>. When a new TaskTip is created before
 * hiding or disposing of a prior TaskTip, the newest becomes the top-most one 
 * and obscures the prior ones, if any.
 * </p>
 * <p>
 * A TaskTip can not be positioned programmatically or by the user. The position
 * is implementation-dependent.
 * </p>
 * <dl>
 * <dt><b>Styles: </b></dt>
 * <dd>SMOOTH: displays a visual indicator of what portion of the progress is
 * left to go</dd>
 * <dd>INDETERMINATE: displays a visual indicator that a long-running process
 * is progressing</dd>
 * <dt><b>Events: </b></dt>
 * <dd>(none)</dd>
 * </dl>
 * 
 * <p>
 * Note: The methods <code>setMaximum</code>, <code>setMinimum</code>,
 * and <code>setSelection</code>, are silently ignored if the style is not
 * SWT.SMOOTH.
 * 
 * @see SWT#SMOOTH
 * @see SWT#INDETERMINATE
  * <p>
 * IMPORTANT: This class is <em>not</em> intended to be subclassed.
 * </p>
 */
public class TaskTip extends Widget {
	// default layout setting
	private static int MARGIN_WIDTH = 3;
	private static int MARGIN_HEIGHT = 3;
	private static int SHELL_MARGIN_WIDTH = 20;
	private static int SHELL_HEIGHT_STYLE_NONE = 26;
	private static int SHELL_HEIGHT_STYLE_SMOOTH = 26;
	private static int SHELL_HEIGHT_STYLE_INDETERMINATE = 22;
	private static int PROGRESS_BAR_HEIGHT = 2;
	private static int TITLE_HEIGHT = 26;

	private final static int PROGRESSBAR_VALUE_MINIMUM = 0;
	private final static int PROGRESSBAR_VALUE_MAXIMUM = 100;

	private final static String STYLE_NONE_SYMBOL = "/resources/stopwatch.png";
	
	private Display display;
	private Shell shell = null;
	private int style;
	private Label msgLabel;
	private Label progressLabel;
	private ProgressThread progressThread;
	private LocationHandle locHandle;
	private ProgressBar progressBar;
	private int minimum = PROGRESSBAR_VALUE_MINIMUM;
	private int maximum = PROGRESSBAR_VALUE_MAXIMUM;
	private int selection = PROGRESSBAR_VALUE_MINIMUM;
	private boolean isOpen = false;
	private boolean isModifyText = false; 

	/**
	 * 
	 * Constructs a TaskTip with plain text style.
	 * 
	 * The default style displays plain text to indicate progress. The TaskTip 
	 * is disposed if the parent Shell is disposed.
	 * 
	 * @param shell
	 *            The Shell the TaskTip is associated with
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the shell value is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the display</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 */
	public TaskTip(Shell shell) {
		this(shell, SWT.NONE);
	}

	/**
	 * 
	 * Constructs a TaskTip with a given style value. The TaskTip 
	 * is disposed if the parent Shell is disposed.
	 * 
	 * @param shell
	 *            The Shell the TaskTip is associated with
	 * @param style
	 *            style of TaskTip: NONE, SMOOTH or INDETERMINATE.
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_NULL_ARGUMENT - if the shell value is null</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the display</li>
	 *                <li>ERROR_INVALID_SUBCLASS - if this class is not an
	 *                allowed subclass</li>
	 *                </ul>
	 * @see SWT#SMOOTH
	 * @see SWT#INDETERMINATE
	 */
	public TaskTip(Shell shell, int style) {
		super(shell, style);
		if(shell == null)		SWT.error(SWT.ERROR_NULL_ARGUMENT);

		//Adjust Tasktip size to VGA device size.
		if (Display.getCurrent().getDPI().equals(new Point(192,192))) {
			MARGIN_WIDTH = 6;
			MARGIN_HEIGHT = 6;
			SHELL_MARGIN_WIDTH = 40;
			SHELL_HEIGHT_STYLE_NONE = 52;
			SHELL_HEIGHT_STYLE_SMOOTH = 52;
			SHELL_HEIGHT_STYLE_INDETERMINATE = 44;
			PROGRESS_BAR_HEIGHT = 4;
			TITLE_HEIGHT = 52;		
			
		}
		
		final TaskTip tasktip = this;
		shell.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
				tasktip.dispose();
			}
		});
		this.display = shell.getDisplay();
		if(style != SWT.NONE && style != SWT.SMOOTH && style != SWT.INDETERMINATE)
			this.style = SWT.NONE;
		else
			this.style = style;
		this.shell = new Shell(shell, SWT.BORDER);
		this.locHandle = new LocationHandle(this.shell);
		
		init();
	}

	/**
	 * Sets the maximum value that the TaskTip will allow.
	 * If the new maximum is applied, the TaskTip's selection value is
	 * adjusted if necessary to fall within the new range. If a maximum 
	 * value is not set, the default is 100.
	 * <p>
	 * This method works only for {@link SWT#SMOOTH SWT.SMOOTH} style. This method 
	 * is silently ignored for other styles.
	 * </p>
	 * 
	 * @param value
	 *            the new maximum, which must be positive and greater than or 
	 * 			  equal to the current minimum
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the value is negative or
	 *                less than the current minimum</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setMaximum(int value) {
		checkWidget();
		if(style != SWT.SMOOTH)
			return;
		if(value < 0 || value < minimum) {
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			return;
		}
		maximum = value;
		if(selection > maximum)
			selection = maximum;
		progressBar.setMaximum(maximum);
		shell.redraw();
	}

	/**
	 * Sets the minimum value that the TaskTip will allow. 
	 * If the new minimum is applied, the TaskTip's selection
	 * value is adjusted if necessary to fall within the new range.
	 * If a minimum value is not set, the default is 0.
	 * 
	 * <p>
	 * This method works only for {@link SWT#SMOOTH SWT.SMOOTH} style. This method 
	 * is silently ignored for other styles.
	 * </p>
	 * 
	 * @param value
	 *            the new minimum, which must be positive and less than or 
	 * 			  equal to the current maximum
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the value is negative or
	 *                greater than the current maximum</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */
	public void setMinimum(int value) {
		checkWidget();
		if(style != SWT.SMOOTH)
			return;
		if(value < 0 || value > maximum) {
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			return;
		}
		minimum = value;
		if(selection < minimum)
			selection = minimum;
		progressBar.setMinimum(minimum);
		shell.redraw();
	}
	
	/**
	 * 
	 * Sets the position of the TaskTip's indicator to the provided value.
	 * The value must fall in the range defined by setMinimum() and setMaximum().
	 * If a value is not set, the default is 0.
	 * 
	 * <p>
	 * This method works only for {@link SWT#SMOOTH SWT.SMOOTH} style. This method 
	 * is silently ignored for other styles.
	 * </p>
	 * 
	 * @param value
	 *            the new selection (must be zero or greater).
	 * 
	 * @exception IllegalArgumentException
	 *                <ul>
	 *                <li>ERROR_INVALID_ARGUMENT - if the value is not in
	 *                between the current minimum and maximum</li>
	 *                </ul>
	 * @exception SWTException
	 *                <ul>
	 *                <li>IllegalArgumentException - if the vlaue falls out of
	 *                the range defined by setMinimum() and setMaximum()</li>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 *  
	 */
	public void setSelection(int value) {
		checkWidget();
		if(style != SWT.SMOOTH)
			return;
		if(value < minimum || value > maximum) {
			SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			return;
		}
		selection = value;
		progressBar.setSelection(selection);
		shell.redraw();
	}

	/**
	 * Sets the label text.
	 * <p>
	 * This method sets a TaskTip's label . The label can be null. The label's
	 * position and the visibility of label text is platform-dependent.
	 * </p>
	 * 
	 * @param string
	 *            the label text
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the receiver has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 *  
	 */
	public void setText(String string) {
		checkWidget();
		if(string == null) {
			if(!msgLabel.getText().equals(""))
				isModifyText = true; 
			msgLabel.setText("");
		} else {
			if(!msgLabel.getText().equals(string))
				isModifyText = true; 
			msgLabel.setText(string);
		}
		if(shell.isVisible()) {
			isModifyText = false;
		}
	}

	/**
	 * Makes the TaskTip visible and brings it to the front of the display.
	 * 
	 * <p>
	 * This method will return immediately after showing or hiding the TaskTip.
	 * </p>
	 * <p>
	 * Despite setting a TaskTip visible, it may not actually be displayed if the
	 * device's main screen is not active.
	 * </p>
	 * 
	 * @param visible
	 *            the value to show or hide the TaskTip. The method will not
	 *            return an error if the value matches the current visibility
	 *            state.
	 * 
	 * @exception SWTException
	 *                <ul>
	 *                <li>ERROR_WIDGET_DISPOSED - if the TaskTip has been
	 *                disposed</li>
	 *                <li>ERROR_THREAD_INVALID_ACCESS - if not called from the
	 *                thread that created the receiver</li>
	 *                </ul>
	 */

	public void setVisible(boolean visible) {
		checkWidget();
		if(shell.isVisible() == visible)
			return;
		if(progressThread != null) {
			progressThread.setActive(visible);
			if(visible)
				new Thread(progressThread).start();
		}
		if(visible) {
			if(isModifyText || !isOpen) {
				isModifyText = false;
			}
			if(!isOpen) {
				shell.open();
				isOpen = true;
			}
			shell.setActive();
			shell.setBounds(locHandle.getShellBounds());
		}
		shell.setVisible(visible);
	}
	
	public void dispose() {
		if(isDisposed())
			return;
		// if ProgressBarThread exist, stop thread and delete
		if(progressThread != null) {
			progressThread.setActive(false);
			progressThread = null;
		}
		if(locHandle != null) {
			locHandle.dispose();
			locHandle = null;
		}
		if(progressBar != null)
			shell.removePaintListener(progressBar);
		progressBar = null;
		if(msgLabel != null && !msgLabel.isDisposed())
			msgLabel.dispose();
		if(progressLabel != null && !progressLabel.isDisposed())
			progressLabel.dispose();

		if(shell != null && !shell.isDisposed())
			shell.close();
		shell = null;
		super.dispose();
	}
	
	public boolean isDisposed() {
		if(shell == null || shell.isDisposed())
			return true;
		else
			return false;			
	}
	
	// initial TaskTip
	private void init() {
		int progressWidth = 0;
		int shellx = SHELL_MARGIN_WIDTH;
		int shelly = TITLE_HEIGHT;
		int shellw = display.getBounds().width - SHELL_MARGIN_WIDTH * 2;
		int shellh;
		if(style == SWT.NONE)
			shellh = SHELL_HEIGHT_STYLE_NONE;
		else if(style == SWT.SMOOTH)
			shellh = SHELL_HEIGHT_STYLE_SMOOTH;
		else
			shellh = SHELL_HEIGHT_STYLE_INDETERMINATE;
		if(org.eclipse.swt.SWT.getPlatform().equals("win32")) {
			shellw = display.getBounds().width / 2;
			shellx = shellw / 2;
		}
		int validw = shellw - MARGIN_WIDTH * 2;

		Color bgColor = new Color(display, 0xFF, 0xFF, 0xCC);
		shell.setBackground(bgColor);
		if(style == SWT.NONE) {
			progressLabel = new Label(shell, SWT.RIGHT);
			progressLabel.setForeground(display.getSystemColor(SWT.COLOR_BLUE));
			progressLabel.setBackground(bgColor);
			progressLabel.setImage(new Image(display, this.getClass().getResourceAsStream(STYLE_NONE_SYMBOL)));
			progressLabel.pack();
			progressWidth = progressLabel.getBounds().width + MARGIN_WIDTH;
			progressLabel.setLocation(validw - progressWidth + MARGIN_WIDTH, MARGIN_HEIGHT);
		} else if(style == SWT.INDETERMINATE) {
			progressLabel = new Label(shell, SWT.RIGHT);
			progressLabel.setForeground(display.getSystemColor(SWT.COLOR_BLUE));
			progressLabel.setBackground(bgColor);
			progressLabel.setText("/");
			progressLabel.pack();
			progressWidth = progressLabel.getBounds().width + MARGIN_WIDTH;
			progressLabel.setLocation(validw - progressWidth, MARGIN_HEIGHT);
			progressThread = new ProgressThread(display, progressLabel);
		}
		msgLabel = new Label(shell, SWT.LEFT);
		msgLabel.setBackground(bgColor);
		msgLabel.setText("W");
		msgLabel.pack();
		msgLabel.setBounds(MARGIN_WIDTH, MARGIN_HEIGHT, validw - progressWidth - MARGIN_WIDTH, msgLabel.getSize().y);
		msgLabel.setText("");

		shell.setBounds(shellx, shelly, shellw, shellh);

		locHandle.setShellBounds(shellx, shelly, shellw, shellh);
		msgLabel.addMouseListener(locHandle);
		msgLabel.addMouseMoveListener(locHandle);
		shell.addMouseListener(locHandle);
		shell.addMouseMoveListener(locHandle);
		if(style == SWT.NONE || style ==  SWT.INDETERMINATE) {
			progressLabel.addMouseListener(locHandle);
			progressLabel.addMouseMoveListener(locHandle);
		}
		if(style == SWT.SMOOTH) {
			int y = msgLabel.getLocation().y + msgLabel.getSize().y + MARGIN_HEIGHT;
			int w = validw - MARGIN_WIDTH;
			progressBar = new ProgressBar(MARGIN_WIDTH, y, w, PROGRESS_BAR_HEIGHT);
			shell.addPaintListener(progressBar);
		}
	}

	// Draw ProgressBar
	private class ProgressBar implements PaintListener {
		int x, y, w, h;
		int maximum = PROGRESSBAR_VALUE_MAXIMUM;
		int minimum = PROGRESSBAR_VALUE_MINIMUM;
		int selection = PROGRESSBAR_VALUE_MINIMUM;
		int prevSelect = -1; 
		public ProgressBar(int x, int y, int w, int h) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
		}
		public void setMaximum(int maximum) {
			this.maximum = maximum;
			prevSelect = -1;
		}
		public void setMinimum(int minimum) {
			this.minimum = minimum;
			prevSelect = -1;
		}
		public void setSelection(int selection) {
			this.selection = selection;
		}
		public void paintControl(PaintEvent e) {
			if(prevSelect == selection)
				return;
			int sw = (selection - minimum) * w / (maximum - minimum);

			e.gc.setBackground(display.getSystemColor(SWT.COLOR_DARK_BLUE));
			e.gc.fillRectangle(x + sw, y, w - sw, h);
			
			e.gc.setBackground(display.getSystemColor(SWT.COLOR_BLUE));
			e.gc.fillRectangle(x, y, sw, h);
			prevSelect = selection;
		}
		
	}

	// auto-run indeterminate ProgressBar
	private class ProgressThread implements Runnable {
		long sleepTime = 500;
		Display display;
		boolean active = true;
		String[] animations = new String[4];
		int select = 0;
		Label label;
		public ProgressThread(Display display, Label label) {
			this.display = display;
			this.label = label;
			animations[0] = "-";
			animations[1] = "\\";
			animations[2] = "|";
			animations[3] = "/";
        }
		public ProgressThread(Display display, Label label, long sleepTime) {
			this(display, label);
			this.sleepTime = sleepTime;
        }
		public void setActive(boolean active) {
			this.active = active;
		}
		public void run() {
			while(active) { 
				final String animation = animations[select];
				try {
					if(display != null && !display.isDisposed()) {
						display.asyncExec(new Runnable() {
							public void run() {
								if(label != null && !label.isDisposed())
									label.setText(animation);
							}
						});
					}
					if(++select == animations.length)
						select = 0;
					try {
						Thread.sleep(sleepTime);
					} catch(Exception e) {
						return;
					}
				} catch(Exception e) {
					return;
				}
			}
		}
	}

	// Drag TaskTip and Reset TaskTip size
	public class LocationHandle implements MouseListener, MouseMoveListener {
		Point mousePoint;
		Control control;
		Shell shell;
		Rectangle rectangle;
		boolean isMouseDown = false;
		public LocationHandle(Shell shell) {
			this.shell = shell;
			mousePoint = new Point(0, 0);
			rectangle = new Rectangle(0, 0, 0, 0);
		}
		public void setShellBounds(int x, int y, int width, int height) {
			rectangle.x = x;
			rectangle.y = y;
			rectangle.width = width;
			rectangle.height = height;
		}
		public void mouseDoubleClick(MouseEvent e) {
		}
		public void mouseDown(MouseEvent e) {
			control = (Control)e.widget;
			if(shell.getSize().y > SHELL_HEIGHT_STYLE_NONE) {
				shell.setBounds(rectangle);
				return;
			}

			mousePoint.x = e.x;
			mousePoint.y = e.y;
			rectangle.x = shell.getLocation().x;
			rectangle.y = shell.getLocation().y;
			isMouseDown = true;
		}
		public void mouseUp(MouseEvent e) {
			if(!isMouseDown)
				return;
			if(control == null || (Control)e.widget != control)
				return;
			control = null;
			isMouseDown = false;
		}
		public void mouseMove(MouseEvent e) {
			if(!isMouseDown)
				return;
			if(control == null || (Control)e.widget != control)
				return;
			rectangle.x += (e.x - mousePoint.x);
			rectangle.y += (e.y - mousePoint.y);
			if(rectangle.y < 0)
				rectangle.y = 0;
			shell.setLocation(rectangle.x, rectangle.y);
		}
		public Rectangle getShellBounds() {
			return rectangle;
		}
		public void dispose() {
			mousePoint = null;
			rectangle = null;
		}
	}
	

	// TaskTip test usage, don't trust test code
/*
	public static void main(String[] args){
		final Display display = new Display();
		final Shell shell = new Shell(display);
		int minValue = 0, maxValue = 100;
		final Vector taskTipVector = new Vector();
		final Vector taskTipValueVector = new Vector();

		shell.setText("TaskTip Test");
		int style = 0;//SWT.BORDER;
		
		final Button displayCheckButton = new Button(shell, SWT.CHECK | style);
		displayCheckButton.setText("Set display is null");
		displayCheckButton.pack();

		final Button typeCheckButton = new Button(shell, SWT.CHECK | style);
		typeCheckButton.setText("TaskTip Style : ");
		typeCheckButton.pack();

		final Combo typeCombo = new Combo(shell, SWT.DROP_DOWN | style);
		typeCombo.add("NONE");
		typeCombo.add("SMOOTH");
		typeCombo.add("INDETERMINATE");
		typeCombo.select(1);
		typeCombo.pack();
		
		final Button minCheckButton = new Button(shell, SWT.CHECK | style);
		minCheckButton.setText("Set Minimum Value : ");
		minCheckButton.pack();

		Button minSubButton = new Button(shell, style);
		minSubButton.setText("-");
		minSubButton.pack();

		final Label minValueLabel = new Label(shell, SWT.CENTER | style);
		minValueLabel.setText("       ");
		minValueLabel.pack();

		Button minAddButton = new Button(shell, style);
		minAddButton.setText("+");
		minAddButton.pack();

		final Button maxCheckButton = new Button(shell, SWT.CHECK | style);
		maxCheckButton.setText("Set Maximum Value : ");
		maxCheckButton.pack();

		Button maxSubButton = new Button(shell, style);
		maxSubButton.setText("-");
		maxSubButton.pack();

		final Label maxValueLabel = new Label(shell, SWT.CENTER | style);
		maxValueLabel.setText("       ");
		maxValueLabel.pack();

		Button maxAddButton = new Button(shell,style);
		maxAddButton.setText("+");
		maxAddButton.pack();

		final Button textCheckButton = new Button(shell, SWT.CHECK | style);
		textCheckButton.setText("Set Text : ");
		textCheckButton.pack();

		final Text valueText = new Text(shell, SWT.MULTI | SWT.LEFT | SWT.WRAP | SWT.BORDER | style);
		
		Label separatorLabel = new Label(shell, SWT.SEPARATOR | SWT.HORIZONTAL | style);

		Label taskTipNumberLabel = new Label(shell, SWT.CENTER | style);
		taskTipNumberLabel.setText("TaskTip Number : ");
		taskTipNumberLabel.pack();

		final Label taskTipNumberValueLabel = new Label(shell, SWT.CENTER | style);
		taskTipNumberValueLabel.setText("       ");
		taskTipNumberValueLabel.pack();

		final Button createButton = new Button(shell, SWT.PUSH | style);
		createButton.setText("Create");
		createButton.pack();

		Label operateTaskTipLabel = new Label(shell, SWT.CENTER | style);
		operateTaskTipLabel.setText("Operate : ");
		operateTaskTipLabel.pack();
		
		final Combo operateTaskTipCombo = new Combo(shell, SWT.DROP_DOWN | style);
		operateTaskTipCombo.pack();
		
		final Button deleteButton = new Button(shell, SWT.PUSH | style);
		deleteButton.setText("Delete");
		deleteButton.pack();
	
		Label setVisibleLabel = new Label(shell, SWT.CENTER | style);
		setVisibleLabel.setText("Set Visible : ");
		setVisibleLabel.pack();

		final Button enableButton = new Button(shell, SWT.PUSH | style);
		enableButton.setText("TRUE");
		enableButton.pack();
		
		final Button disableButton = new Button(shell, SWT.PUSH | style);
		disableButton.setText("FALSE");
		disableButton.pack();
		
		Label setValueLabel = new Label(shell, SWT.CENTER | style);
		setValueLabel.setText("Set Value : ");
		setValueLabel.pack();
		
		final Button subValueButton = new Button(shell, SWT.PUSH | style);
		subValueButton.setText("-");
		subValueButton.pack();

		final Label selValueLabel = new Label(shell, SWT.CENTER | style);
		selValueLabel.setText("       ");
		selValueLabel.pack();

		final Button addValueButton = new Button(shell, SWT.PUSH | style);
		addValueButton.setText("+");
		addValueButton.pack();
		
		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		layout.spacing = 3;
		shell.setLayout(layout);
		
		
		
		FormData fd00 = new FormData();
		fd00.left = new FormAttachment(0, 0);
		fd00.top = new FormAttachment(0, 0);
		displayCheckButton.setLayoutData(fd00);

		FormData fd11 = new FormData();
		fd11.left = new FormAttachment(0, 0);
		fd11.top = new FormAttachment(displayCheckButton, 0);
		typeCheckButton.setLayoutData(fd11);

		FormData fd12 = new FormData();
		fd12.left = new FormAttachment(typeCheckButton, 0);
		fd12.top = new FormAttachment(displayCheckButton, 0);
		typeCombo.setLayoutData(fd12);

		FormData fd21 = new FormData();
		fd21.left = new FormAttachment(0, 0);
		fd21.top = new FormAttachment(typeCombo, 0);
		minCheckButton.setLayoutData(fd21);

		FormData fd22 = new FormData();
		fd22.left = new FormAttachment(minCheckButton, 0);
		fd22.top = new FormAttachment(typeCombo, 0);
		minSubButton.setLayoutData(fd22);

		FormData fd23 = new FormData();
		fd23.left = new FormAttachment(minSubButton, 0);
		fd23.top = new FormAttachment(typeCombo, 0);
		minValueLabel.setLayoutData(fd23);

		FormData fd24 = new FormData();
		fd24.left = new FormAttachment(minValueLabel, 0);
		fd24.top = new FormAttachment(typeCombo, 0);
		minAddButton.setLayoutData(fd24);

		FormData fd31 = new FormData();
		fd31.left = new FormAttachment(0, 0);
		fd31.top = new FormAttachment(minAddButton, 0);
		maxCheckButton.setLayoutData(fd31);

		FormData fd32 = new FormData();
		fd32.left = new FormAttachment(maxCheckButton, 0);
		fd32.top = new FormAttachment(minAddButton, 0);
		maxSubButton.setLayoutData(fd32);

		FormData fd33 = new FormData();
		fd33.left = new FormAttachment(maxSubButton, 0);
		fd33.top = new FormAttachment(minAddButton, 0);
		maxValueLabel.setLayoutData(fd33);

		FormData fd34 = new FormData();
		fd34.left = new FormAttachment(maxValueLabel, 0);
		fd34.top = new FormAttachment(minAddButton, 0);
		maxAddButton.setLayoutData(fd34);

		FormData fd41 = new FormData();
		fd41.left = new FormAttachment(0, 0);
		fd41.top = new FormAttachment(maxAddButton, 0);
		textCheckButton.setLayoutData(fd41);

		FormData fd42 = new FormData();
		fd42.left = new FormAttachment(textCheckButton, 0);
		fd42.top = new FormAttachment(maxAddButton, 0);
		fd42.right = new FormAttachment(100, 0);
		fd42.bottom = new FormAttachment(maxAddButton, 60);
		valueText.setLayoutData(fd42);
		
		FormData fd51 = new FormData();
		fd51.left = new FormAttachment(0, 0);
		fd51.top = new FormAttachment(valueText, 0);
		fd51.right = new FormAttachment(100, 0);
		separatorLabel.setLayoutData(fd51);

		FormData fdA1 = new FormData();
		fdA1.left = new FormAttachment(0, 0);
		fdA1.top = new FormAttachment(separatorLabel, 0);
		taskTipNumberLabel.setLayoutData(fdA1);

		FormData fdA2 = new FormData();
		fdA2.left = new FormAttachment(taskTipNumberLabel, 0);
		fdA2.top = new FormAttachment(separatorLabel, 0);
		taskTipNumberValueLabel.setLayoutData(fdA2);

		FormData fdA3 = new FormData();
		fdA3.left = new FormAttachment(taskTipNumberValueLabel, 0);
		fdA3.top = new FormAttachment(separatorLabel, 0);
		createButton.setLayoutData(fdA3);

		FormData fdB1 = new FormData();
		fdB1.left = new FormAttachment(0, 0);
		fdB1.top = new FormAttachment(createButton, 0);
		operateTaskTipLabel.setLayoutData(fdB1);

		FormData fdB2 = new FormData();
		fdB2.left = new FormAttachment(operateTaskTipLabel, 0);
		fdB2.top = new FormAttachment(createButton, 0);
		operateTaskTipCombo.setLayoutData(fdB2);

		FormData fdB3 = new FormData();
		fdB3.left = new FormAttachment(operateTaskTipCombo, 0);
		fdB3.top = new FormAttachment(createButton, 0);
		deleteButton.setLayoutData(fdB3);

		FormData fd62 = new FormData();
		fd62.left = new FormAttachment(0, 0);
		fd62.top = new FormAttachment(deleteButton, 0);
		setVisibleLabel.setLayoutData(fd62);
		
		FormData fd63 = new FormData();
		fd63.left = new FormAttachment(setVisibleLabel, 0);
		fd63.top = new FormAttachment(deleteButton, 0);
		enableButton.setLayoutData(fd63);

		FormData fd64 = new FormData();
		fd64.left = new FormAttachment(enableButton, 0);
		fd64.top = new FormAttachment(deleteButton, 0);
		disableButton.setLayoutData(fd64);

		FormData fd71 = new FormData();
		fd71.left = new FormAttachment(0, 0);
		fd71.top = new FormAttachment(disableButton, 0);
		setValueLabel.setLayoutData(fd71);

		FormData fd72 = new FormData();
		fd72.left = new FormAttachment(setValueLabel, 0);
		fd72.top = new FormAttachment(disableButton, 0);
		subValueButton.setLayoutData(fd72);
		
		FormData fd73 = new FormData();
		fd73.left = new FormAttachment(subValueButton, 0);
		fd73.top = new FormAttachment(disableButton, 0);
		selValueLabel.setLayoutData(fd73);
		
		FormData fd74 = new FormData();
		fd74.left = new FormAttachment(selValueLabel, 0);
		fd74.top = new FormAttachment(disableButton, 0);
		addValueButton.setLayoutData(fd74);
		
		minSubButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int value = Integer.parseInt(minValueLabel.getText());
				if(value < 0)
					return;
				value --;
				minValueLabel.setText(String.valueOf(value));

				if(minCheckButton.getSelection()) {
					int idx = operateTaskTipCombo.getSelectionIndex();
					if(idx < 0 || idx >= taskTipVector.size())
						return;
					TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
					taskTip.setMinimum(value);
				}
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		minAddButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int value = Integer.parseInt(minValueLabel.getText());
				if(value > Integer.MAX_VALUE)
					return;
				value ++;
				minValueLabel.setText(String.valueOf(value));

				if(minCheckButton.getSelection()) {
					int idx = operateTaskTipCombo.getSelectionIndex();
					if(idx < 0 || idx >= taskTipVector.size())
						return;
					TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
					taskTip.setMinimum(value);
				}
}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		maxSubButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int value = Integer.parseInt(maxValueLabel.getText());
				if(value < 0)
					return;
				value --;
				maxValueLabel.setText(String.valueOf(value));

				if(maxCheckButton.getSelection()) {
					int idx = operateTaskTipCombo.getSelectionIndex();
					if(idx < 0 || idx >= taskTipVector.size())
						return;
					TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
					taskTip.setMaximum(value);
				}
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		maxAddButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int value = Integer.parseInt(maxValueLabel.getText());
				if(value > Integer.MAX_VALUE)
					return;
				value ++;
				maxValueLabel.setText(String.valueOf(value));

				if(maxCheckButton.getSelection()) {
					int idx = operateTaskTipCombo.getSelectionIndex();
					if(idx < 0 || idx >= taskTipVector.size())
						return;
					TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
					taskTip.setMaximum(value);
				}
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		valueText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!textCheckButton.getSelection())
					return;
				int idx = operateTaskTipCombo.getSelectionIndex();
				if(idx < 0 || idx >= taskTipVector.size())
					return;
				TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
				taskTip.setText(valueText.getText());
			}
		});
		
		
		createButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				boolean setStyle = false;
				boolean setDisplayNull = false;
				int style = SWT.NONE;
//				Display d = null;
				Shell s = null;
				
				TaskTip taskTip = null;
				if(displayCheckButton.getSelection())
					setDisplayNull = true;
				String queryTypeString = typeCombo.getItem(typeCombo.getSelectionIndex());
				if(typeCheckButton.getSelection()) {
					if(queryTypeString.equals("SMOOTH")) {
						setStyle = true;
						style = SWT.SMOOTH;
					} else if(queryTypeString.equals("INDETERMINATE")) {
						setStyle = true;
						style = SWT.INDETERMINATE;
					}
				}
				if(setDisplayNull) {
					if(setStyle)
						taskTip = new TaskTip(s, style);
					else
						taskTip = new TaskTip(s);
				} else {
					if(setStyle)
						taskTip = new TaskTip(shell, style);
					else
						taskTip = new TaskTip(shell);
				}
				int min = 0;
				if(minCheckButton.getSelection()) {
					min = Integer.parseInt(minValueLabel.getText());
					taskTip.setMinimum(min);
				}
				if(maxCheckButton.getSelection()) {
					int max = Integer.parseInt(maxValueLabel.getText());
					taskTip.setMaximum(max);				
				}
				if(textCheckButton.getSelection()) {
					taskTip.setText(valueText.getText());				
				}

				taskTipValueVector.add(new Integer(min));
				taskTipVector.add(taskTip);
				taskTip.setSelection(min);

				taskTipNumberValueLabel.setText(String.valueOf(taskTipVector.size()));
				operateTaskTipCombo.add(String.valueOf(taskTipVector.size()));
				operateTaskTipCombo.select(operateTaskTipCombo.getItemCount() - 1);
			}
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		deleteButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int idx = operateTaskTipCombo.getSelectionIndex();
				if(idx < 0 || idx >= taskTipVector.size())
					return;
				TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
				taskTipVector.removeElementAt(idx);
				taskTipValueVector.removeElementAt(idx);
				taskTip.dispose();
				taskTip = null;
				
				taskTipNumberValueLabel.setText(String.valueOf(taskTipVector.size()));
				operateTaskTipCombo.remove(operateTaskTipCombo.getItemCount() - 1);
				if(operateTaskTipCombo.getItemCount() >= 1)
					operateTaskTipCombo.select(operateTaskTipCombo.getItemCount() - 1);
				else if(operateTaskTipCombo.getItemCount() == 0)
					operateTaskTipCombo.setText("");
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		enableButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int idx = operateTaskTipCombo.getSelectionIndex();
				if(idx < 0 || idx >= taskTipVector.size())
					return;
				TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
				taskTip.setVisible(true);
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		disableButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int idx = operateTaskTipCombo.getSelectionIndex();
				if(idx < 0 || idx >= taskTipVector.size())
					return;
				TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
				taskTip.setVisible(false);
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		subValueButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int idx = operateTaskTipCombo.getSelectionIndex();
				if(idx < 0 || idx >= taskTipVector.size())
					return;
				TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
				Integer taskTipValue = (Integer)taskTipValueVector.elementAt(idx); 
				int newValue = taskTipValue.intValue() - 1;
				selValueLabel.setText(String.valueOf(newValue));
				taskTipValueVector.setElementAt(new Integer(newValue), idx);
				taskTipValue = null;
				taskTip.setSelection(newValue);
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		addValueButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent e) {
				int idx = operateTaskTipCombo.getSelectionIndex();
				if(idx < 0 || idx >= taskTipVector.size())
					return;
				TaskTip taskTip = (TaskTip)taskTipVector.elementAt(idx);
				Integer taskTipValue = (Integer)taskTipValueVector.elementAt(idx); 
				int newValue = taskTipValue.intValue() + 1;
				selValueLabel.setText(String.valueOf(newValue));
				taskTipValueVector.setElementAt(new Integer(newValue), idx);
				taskTipValue = null;
				taskTip.setSelection(newValue);
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		shell.pack();
		minValue = 60;
		maxValue = 60;
		minValueLabel.setText(String.valueOf(minValue));
		maxValueLabel.setText(String.valueOf(maxValue));
		taskTipNumberValueLabel.setText("0");
		shell.open();

		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() )
				display.sleep();
		}
		display.dispose();
	}
*/
}